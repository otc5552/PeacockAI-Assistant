"""
main.py — PeacockGPT v7 Production Entry Point
Hardened: Rate limiting middleware, security headers, request validation.
Author: PeacockAI – Mostafa

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2
"""
import asyncio, time
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware

from core.config import ENV, FRONTEND_URL, APP_VERSION, log, FLAGS, MODELS, PLANS, PRICING, PERSONA
from core.database import init_db, get_db, FeatureFlag
from core.security import check_rate_limit, cleanup_rate_store
from workers.jobs import worker_loop, scheduler_loop

from routes.auth import router as auth_router
from routes.chat import router as chat_router
from routes.all_routes import conv_router, mem_router, misc_router, admin_router
from routes.agent_routes import router as agent_router
from routes.document_routes import router as doc_router

# ══════════════════════════════════════════════════════════════════
# APP
# ══════════════════════════════════════════════════════════════════

app = FastAPI(
    title       = "PeacockGPT v7 API",
    description = "PeacockAI – Arabic AI Platform (Hardened)",
    version     = APP_VERSION,
    docs_url    = "/docs" if ENV == "development" else None,
    redoc_url   = None,
)

# ══════════════════════════════════════════════════════════════════
# MIDDLEWARE
# ══════════════════════════════════════════════════════════════════

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins  = [FRONTEND_URL] if FRONTEND_URL != "*" else ["*"],
    allow_methods  = ["GET", "POST", "DELETE", "PATCH", "PUT", "OPTIONS"],
    allow_headers  = ["*"],
    expose_headers = ["X-RateLimit-Remaining"],
)


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    """
    Security middleware:
    1. Rate limiting per IP
    2. Security headers on all responses
    3. Request size limit
    4. Basic kill switch
    """
    # Global kill switch
    if FLAGS.get("kill_switch"):
        return Response(
            content='{"error":"الخدمة متوقفة مؤقتاً"}',
            status_code=503,
            media_type="application/json",
        )

    # IP rate limiting (global — not per-endpoint)
    ip = request.client.host if request.client else "0.0.0.0"
    # Skip rate limiting for health endpoint
    if request.url.path not in ("/health", "/"):
        allowed, remaining = check_rate_limit(f"ip:{ip}")
        if not allowed:
            return Response(
                content='{"error":"تجاوزت حد الطلبات. انتظر قليلاً."}',
                status_code=429,
                media_type="application/json",
                headers={"Retry-After": "60"},
            )

    # Process request
    t0       = time.time()
    response = await call_next(request)
    latency  = int((time.time() - t0) * 1000)

    # Security headers
    response.headers["X-Content-Type-Options"]    = "nosniff"
    response.headers["X-Frame-Options"]           = "DENY"
    response.headers["X-XSS-Protection"]          = "1; mode=block"
    response.headers["Referrer-Policy"]            = "strict-origin-when-cross-origin"
    response.headers["X-Response-Time"]            = f"{latency}ms"
    if ENV == "production":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"

    return response


# ══════════════════════════════════════════════════════════════════
# ROUTERS
# ══════════════════════════════════════════════════════════════════

app.include_router(auth_router)
app.include_router(chat_router)
app.include_router(conv_router)
app.include_router(mem_router)
app.include_router(misc_router)
app.include_router(admin_router)
app.include_router(agent_router)
app.include_router(doc_router)


# ══════════════════════════════════════════════════════════════════
# STARTUP
# ══════════════════════════════════════════════════════════════════

@app.on_event("startup")
async def startup():
    import os
    from core.config import AGENT_SANDBOX, PDF_OUTPUT_DIR

    # Directories
    os.makedirs(AGENT_SANDBOX, exist_ok=True)
    os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)

    # Database
    init_db()

    # Feature flags from DB
    _load_flags_from_db()

    # Background workers
    asyncio.create_task(worker_loop())
    asyncio.create_task(scheduler_loop())
    asyncio.create_task(_warm_start())
    asyncio.create_task(_rate_cleaner())

    log.info(f"🚀 PeacockGPT v{APP_VERSION} started (ENV={ENV})")
    log.info(f"   Sandbox: {AGENT_SANDBOX}")
    log.info(f"   PDF:     {PDF_OUTPUT_DIR}")


def _load_flags_from_db():
    try:
        with get_db() as db:
            rows = db.query(FeatureFlag).all()
            for r in rows:
                if r.name in FLAGS:
                    FLAGS[r.name] = bool(r.enabled)
        log.info(f"✅ Loaded {len(rows) if 'rows' in dir() else 0} feature flags from DB")
    except Exception as e:
        log.warning(f"Could not load flags from DB: {e}")


async def _warm_start():
    if not FLAGS.get("warm_start"):
        return
    await asyncio.sleep(3)
    try:
        from services.vector_cache import cache_set
        WARM = {
            "ما هو PeacockGPT؟": "أنا PeacockGPT، مساعد ذكاء اصطناعي من PeacockAI. بساعدك في برمجة، بحث، تحليل، صور وأكتر!",
            "كيف أستخدم التطبيق؟": "اكتب سؤالك واضغط إرسال. استخدم ➕ لتوليد صور أو رفع ملفات.",
            "ما الفرق بين الخطط؟": "Free: 50 رسالة. Plus: 700 جنيه/شهر - 500 رسالة. Pro: 1500 جنيه/شهر - 5000 رسالة + كل الميزات.",
        }
        for q, a in WARM.items():
            cache_set(q, a, "peacockgpt-5-fast", "chat")
        log.info(f"🔥 Warm start: {len(WARM)} queries cached")
    except Exception as e:
        log.warning(f"Warm start failed: {e}")


async def _rate_cleaner():
    """Periodically clean up rate limit store to prevent memory leak."""
    while True:
        await asyncio.sleep(300)  # every 5 minutes
        try:
            cleanup_rate_store()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════
# ENDPOINTS
# ══════════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return {"app": "PeacockGPT", "by": "PeacockAI",
            "version": APP_VERSION, "status": "ok", "env": ENV}


@app.get("/health")
def health():
    from datetime import datetime
    return {"status": "healthy", "version": APP_VERSION,
            "ts": datetime.now().isoformat()}


@app.get("/models")
def get_models():
    return [{"id": k, "name": v["display"], "type": v["type"], "plan": v["plan"]}
            for k, v in MODELS.items()]


@app.get("/plans")
def get_plans():
    return {k: {**v, "pricing": PRICING.get(k, {})} for k, v in PLANS.items()}


@app.get("/personas")
def get_personas():
    labels = {"friendly": "ودود", "formal": "رسمي", "technical": "تقني", "quick": "سريع"}
    return [{"id": k, "label": labels.get(k, k)} for k in PERSONA]
