"""
repositories/log_repo.py — Re-exports from conv_repo for backwards compatibility
Author: PeacockAI – Mostafa
"""
from repositories.conv_repo import write_log, write_event, get_analytics_summary, get_recent_logs

__all__ = ["write_log", "write_event", "get_analytics_summary", "get_recent_logs"]
