"""
main.py — PeacockGPT 5 Production Entry Point
Author: PeacockAI – Mostafa

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2
"""
import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.config import ENV, FRONTEND_URL, APP_VERSION, log, FLAGS, MODELS, PLANS, PRICING, PERSONA
from core.database import init_db, get_db, FeatureFlag
from workers.jobs import worker_loop, scheduler_loop

# ── Import all routers ────────────────────────────────────────────
from routes.auth import router as auth_router
from routes.chat import router as chat_router
from routes.all_routes import (
    conv_router, mem_router, misc_router, admin_router
)
from routes.agent_routes import router as agent_router

# ── App ───────────────────────────────────────────────────────────
app = FastAPI(
    title       = "PeacockGPT 5 API",
    description = "PeacockAI – Arabic AI Platform",
    version     = APP_VERSION,
    docs_url    = "/docs" if ENV == "development" else None,
    redoc_url   = None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins  = [FRONTEND_URL] if FRONTEND_URL != "*" else ["*"],
    allow_methods  = ["GET","POST","DELETE","PATCH","PUT","OPTIONS"],
    allow_headers  = ["*"],
    expose_headers = ["*"],
)

# ── Register routers ──────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(chat_router)
app.include_router(conv_router)
app.include_router(mem_router)
app.include_router(misc_router)
app.include_router(admin_router)
app.include_router(agent_router)

# ── Startup ───────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    import os
    from core.config import AGENT_SANDBOX, PDF_OUTPUT_DIR
    # Create required directories
    os.makedirs(AGENT_SANDBOX, exist_ok=True)
    os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)
    # 1. Init database
    init_db()
    # 2. Load feature flags
    _load_flags_from_db()
    # 3. Background worker
    asyncio.create_task(worker_loop())
    # 4. Hourly scheduler
    asyncio.create_task(scheduler_loop())
    # 5. Warm start
    asyncio.create_task(_warm_start())
    log.info(f"🚀 PeacockGPT v{APP_VERSION} started (ENV={ENV})")
    log.info(f"   Agent sandbox: {AGENT_SANDBOX}")
    log.info(f"   PDF exports:   {PDF_OUTPUT_DIR}")

def _load_flags_from_db():
    try:
        with get_db() as db:
            rows = db.query(FeatureFlag).all()
            for r in rows:
                if r.name in FLAGS:
                    FLAGS[r.name] = bool(r.enabled)
        log.info(f"✅ Loaded {len(rows)} feature flags from DB")
    except Exception as e:
        log.warning(f"Could not load flags from DB: {e}")

async def _warm_start():
    if not FLAGS.get("warm_start"):
        return
    await asyncio.sleep(3)   # wait for DB to settle
    from services.vector_cache import cache_set
    WARM = {
        "ما هو PeacockGPT 5؟":
            "أنا PeacockGPT 5، مساعد ذكاء اصطناعي من PeacockAI. بساعدك في برمجة، بحث، تحليل، صور وأكتر!",
        "كيف أستخدم التطبيق؟":
            "اكتب سؤالك واضغط إرسال. استخدم ➕ لتوليد صور أو رفع ملفات.",
        "ما الفرق بين الخطط؟":
            f"Free: 50 رسالة. Plus: 700 جنيه/شهر - 500 رسالة. Pro: 1500 جنيه/شهر - 5000 رسالة + كل الميزات.",
        "كيف أنشئ صورة؟":
            "اضغط ➕ ثم 'إنشاء صورة' واكتب وصف الصورة.",
    }
    for q, a in WARM.items():
        cache_set(q, a, "peacockgpt-5-fast", "chat")
    log.info(f"🔥 Warm start: {len(WARM)} queries cached")

# ── Root ──────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {
        "app":     "PeacockGPT 5",
        "by":      "PeacockAI",
        "version": APP_VERSION,
        "status":  "ok",
        "env":     ENV,
    }

@app.get("/health")
def health():
    from datetime import datetime
    return {"status": "healthy", "version": APP_VERSION, "ts": datetime.now().isoformat()}

@app.get("/models")
def get_models():
    return [{"id":k,"name":v["display"],"type":v["type"],"plan":v["plan"]}
            for k,v in MODELS.items()]

@app.get("/plans")
def get_plans():
    return {k: {**v, "pricing": PRICING.get(k,{})} for k,v in PLANS.items()}

@app.get("/personas")
def get_personas():
    labels = {"friendly":"ودود","formal":"رسمي","technical":"تقني","quick":"سريع"}
    return [{"id":k,"label":labels.get(k,k)} for k in PERSONA]
