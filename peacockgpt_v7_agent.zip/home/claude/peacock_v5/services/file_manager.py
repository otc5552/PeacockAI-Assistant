"""
services/file_manager.py — Sandboxed File Manager (Pro Agent Only)
All operations are confined to AGENT_SANDBOX directory.
Author: PeacockAI – Mostafa
"""
import os, re, json, zipfile, shutil, secrets, mimetypes
from pathlib import Path
from typing import List, Optional, Tuple
from datetime import datetime
from core.config import AGENT_SANDBOX, log

# ── Allowed extensions ────────────────────────────────────────────
ALLOWED_EXTENSIONS = {
    ".py", ".txt", ".md", ".json", ".yaml", ".yml", ".toml",
    ".js", ".ts", ".jsx", ".tsx", ".html", ".css", ".scss",
    ".env", ".example", ".sh", ".sql", ".csv",
}

# ── Blocked path patterns (security) ─────────────────────────────
BLOCKED_PATTERNS = [
    r"\.\.",          # directory traversal
    r"^/",            # absolute paths
    r"~",             # home dir
    r"\.env$",        # env files with secrets (read-only allowed)
    r"/etc/",r"/sys/",r"/proc/",r"/dev/",  # system dirs
    r"\.exe$",r"\.dll$",r"\.so$",r"\.bin$",  # executables
]

MAX_FILE_SIZE   = 2 * 1024 * 1024   # 2 MB per file
MAX_FILES_USER  = 100               # max files per user sandbox
MAX_FILE_NAME   = 100


class FileManagerError(Exception):
    pass


def _sandbox(user_id: str) -> Path:
    """Return the user's sandboxed directory, creating it if needed."""
    p = Path(AGENT_SANDBOX) / user_id
    p.mkdir(parents=True, exist_ok=True)
    return p


def _safe_path(user_id: str, filename: str) -> Path:
    """
    Validate and resolve a filename to an absolute path inside sandbox.
    Raises FileManagerError if the path escapes the sandbox.
    """
    # Sanitise filename
    if len(filename) > MAX_FILE_NAME:
        raise FileManagerError(f"اسم الملف طويل جداً (max {MAX_FILE_NAME})")

    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, filename):
            raise FileManagerError(f"اسم ملف غير مسموح: {filename}")

    ext = Path(filename).suffix.lower()
    if ext and ext not in ALLOWED_EXTENSIONS:
        raise FileManagerError(f"نوع الملف غير مدعوم: {ext}. المدعومة: {', '.join(ALLOWED_EXTENSIONS)}")

    sandbox = _sandbox(user_id)
    full    = (sandbox / filename).resolve()

    # Ensure path stays inside sandbox
    if not str(full).startswith(str(sandbox)):
        raise FileManagerError("محاولة الوصول خارج منطقة الملفات الآمنة!")

    return full


# ════════════════════════════════════════════════════════════════
# PUBLIC API
# ════════════════════════════════════════════════════════════════

def list_files(user_id: str, subdir: str = "") -> List[dict]:
    """List all files in user's sandbox (or a subdirectory)."""
    try:
        base = _sandbox(user_id)
        if subdir:
            base = _safe_path(user_id, subdir)

        files = []
        for p in sorted(base.rglob("*")):
            if p.is_file():
                rel = str(p.relative_to(_sandbox(user_id)))
                files.append({
                    "name":      p.name,
                    "path":      rel,
                    "size_kb":   round(p.stat().st_size / 1024, 1),
                    "ext":       p.suffix,
                    "modified":  datetime.fromtimestamp(p.stat().st_mtime).isoformat(),
                })
        return files
    except FileManagerError:
        raise
    except Exception as e:
        raise FileManagerError(f"خطأ في قراءة قائمة الملفات: {e}")


def read_file(user_id: str, filename: str) -> Tuple[str, int]:
    """
    Read file content. Returns (content, size_bytes).
    Raises FileManagerError if file is too large or not found.
    """
    full = _safe_path(user_id, filename)
    if not full.exists():
        raise FileManagerError(f"الملف غير موجود: {filename}")
    size = full.stat().st_size
    if size > MAX_FILE_SIZE:
        raise FileManagerError(f"الملف كبير جداً ({size//1024}KB). الحد الأقصى 2MB")
    content = full.read_text(encoding="utf-8", errors="replace")
    log.info(f"[FileManager] read: {user_id}/{filename} ({size}B)")
    return content, size


def write_file(user_id: str, filename: str, content: str,
               overwrite: bool = True) -> dict:
    """
    Write content to a file inside sandbox.
    Returns metadata dict.
    """
    _check_quota(user_id)
    full = _safe_path(user_id, filename)

    if not overwrite and full.exists():
        raise FileManagerError(f"الملف موجود بالفعل: {filename}. استخدم overwrite=True للكتابة فوقه")

    if len(content.encode("utf-8")) > MAX_FILE_SIZE:
        raise FileManagerError("المحتوى كبير جداً (max 2MB)")

    # Create parent dirs if needed
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content, encoding="utf-8")

    size = full.stat().st_size
    log.info(f"[FileManager] write: {user_id}/{filename} ({size}B)")
    return {
        "path":    filename,
        "size_kb": round(size / 1024, 2),
        "created": datetime.now().isoformat(),
    }


def create_file(user_id: str, filename: str,
                content: str = "") -> dict:
    """Create a new file (fails if exists)."""
    return write_file(user_id, filename, content, overwrite=False)


def delete_file(user_id: str, filename: str) -> bool:
    """Delete a file from sandbox. Returns True on success."""
    full = _safe_path(user_id, filename)
    if not full.exists():
        raise FileManagerError(f"الملف غير موجود: {filename}")
    full.unlink()
    log.info(f"[FileManager] delete: {user_id}/{filename}")
    return True


def rename_file(user_id: str, old_name: str, new_name: str) -> bool:
    old_path = _safe_path(user_id, old_name)
    new_path = _safe_path(user_id, new_name)
    if not old_path.exists():
        raise FileManagerError(f"الملف غير موجود: {old_name}")
    if new_path.exists():
        raise FileManagerError(f"الاسم الجديد موجود بالفعل: {new_name}")
    old_path.rename(new_path)
    return True


def get_project_tree(user_id: str) -> str:
    """Return a text tree of the project structure."""
    files = list_files(user_id)
    if not files:
        return "المشروع فارغ."
    lines = [f"📁 sandbox/{user_id}/"]
    for f in files:
        depth = f["path"].count("/")
        indent = "  " * depth
        lines.append(f"{indent}├── {f['name']} ({f['size_kb']}KB)")
    return "\n".join(lines)


def export_zip(user_id: str) -> bytes:
    """Zip the entire user sandbox and return bytes."""
    import io
    buf  = io.BytesIO()
    base = _sandbox(user_id)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in base.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(base))
    return buf.getvalue()


def import_zip(user_id: str, zip_bytes: bytes) -> List[str]:
    """Extract a ZIP into user sandbox. Returns list of extracted files."""
    _check_quota(user_id)
    base = _sandbox(user_id)
    extracted = []
    import io
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for name in zf.namelist():
            ext = Path(name).suffix.lower()
            if ext not in ALLOWED_EXTENSIONS:
                continue
            if len(name) > MAX_FILE_NAME or ".." in name:
                continue
            content = zf.read(name)
            if len(content) > MAX_FILE_SIZE:
                continue
            dest = (base / name).resolve()
            if not str(dest).startswith(str(base)):
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
            extracted.append(name)
    return extracted


def clear_sandbox(user_id: str):
    """Remove all user files (called on account deletion)."""
    p = Path(AGENT_SANDBOX) / user_id
    if p.exists():
        shutil.rmtree(p)


def _check_quota(user_id: str):
    """Raise if user has too many files."""
    files = list_files(user_id)
    if len(files) >= MAX_FILES_USER:
        raise FileManagerError(
            f"تجاوزت حد الملفات ({MAX_FILES_USER}). احذف بعض الملفات أولاً."
        )
