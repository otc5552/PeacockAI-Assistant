"""
services/orchestrator.py — Smart Request Pipeline
Request → Analyze → Intent → Route → Optimize → Execute → Post-process
Author: PeacockAI – Mostafa
"""
import time, asyncio
from dataclasses import dataclass, field
from typing import Optional, AsyncGenerator, Tuple
from core.config import MODELS, FLAGS, log
from services.intent import detect_intent, intent_to_model_key, Intent
from services.vector_cache import cache_get, cache_set
from services.memory import build_memory_context, extract_and_update
from services.search import hybrid_search, needs_search
from services.context import build_context, post_process
from services.llm import execute, track_cost
from services.usage import get_adapter
from repositories.user_repo import increment_usage
from repositories.log_repo import write_log, write_event
from workers.jobs import enqueue


# ════════════════════════════════════════════════════════════════
# Pipeline context object (passed through all stages)
# ════════════════════════════════════════════════════════════════
@dataclass
class PipelineCtx:
    # Input
    message:        str
    user_id:        str
    user_plan:      str
    user_tone:      str
    history:        list
    conv_id:        Optional[str]
    enable_search:  bool
    deep_think:     bool
    model_override: Optional[str]
    groq_key:       str
    gemini_key:     str
    # Derived (filled by stages)
    intent:         Optional[Intent]     = None
    model_key:      str                  = "peacockgpt-5-fast"
    max_tokens:     int                  = 4096
    memory_ctx:     str                  = ""
    search_ctx:     str                  = ""
    system_prompt:  str                  = ""
    messages:       list                 = field(default_factory=list)
    cached_resp:    Optional[str]        = None
    t0:             float                = field(default_factory=time.time)


# ════════════════════════════════════════════════════════════════
# Stage 1 — Analyse: intent detection
# ════════════════════════════════════════════════════════════════
def stage_analyse(ctx: PipelineCtx) -> PipelineCtx:
    ctx.intent    = detect_intent(ctx.message)
    log.info(f"[Orchestrator] Intent: {ctx.intent.type} "
             f"({ctx.intent.confidence:.2f}) signals={ctx.intent.signals[:3]}")
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 2 — Cache lookup (before any LLM call)
# ════════════════════════════════════════════════════════════════
def stage_cache(ctx: PipelineCtx) -> PipelineCtx:
    ctx.cached_resp = cache_get(ctx.message, "chat")
    if ctx.cached_resp:
        log.info(f"[Orchestrator] Cache HIT for: {ctx.message[:40]}")
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 3 — Route: pick model + adapt to load
# ════════════════════════════════════════════════════════════════
def stage_route(ctx: PipelineCtx) -> PipelineCtx:
    adapter = get_adapter()
    # Pick based on intent
    key = ctx.model_override or intent_to_model_key(
        ctx.intent, ctx.user_plan, ctx.user_id
    )
    # Rate adaptation: degrade under load
    key           = adapter.adapt_model(key)
    ctx.model_key = key
    ctx.max_tokens = adapter.adapt_tokens(
        MODELS[key].get("max_tokens", 4096)
    )
    log.info(f"[Orchestrator] Routed → {key} "
             f"(tokens={ctx.max_tokens}, load={adapter.level()})")
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 4 — Memory load
# ════════════════════════════════════════════════════════════════
def stage_memory(ctx: PipelineCtx) -> PipelineCtx:
    ctx.memory_ctx = build_memory_context(ctx.user_id)
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 5 — Search (only when needed)
# ════════════════════════════════════════════════════════════════
async def stage_search(ctx: PipelineCtx) -> PipelineCtx:
    do_search = (
        ctx.enable_search
        and ctx.intent.type in ("search", "chat", "complex")
        and needs_search(ctx.message)
        and not FLAGS.get("kill_search")
    )
    if do_search:
        increment_usage(ctx.user_id, "search")
        asyncio.create_task(
            _fire_event(ctx.user_id, "search_used",
                        {"query": ctx.message[:60]})
        )
        try:
            ctx.search_ctx = await hybrid_search(ctx.message)
        except Exception as e:
            log.warning(f"[Orchestrator] Search failed: {e}")
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 6 — Prompt build (optimise + assemble)
# ════════════════════════════════════════════════════════════════
def stage_prompt(ctx: PipelineCtx) -> PipelineCtx:
    ctx.system_prompt, ctx.messages = build_context(
        ctx.message, ctx.history, ctx.user_tone,
        ctx.memory_ctx, ctx.search_ctx, ctx.deep_think
    )
    return ctx


# ════════════════════════════════════════════════════════════════
# Stage 7 — Execute (stream from LLM with fallback)
# ════════════════════════════════════════════════════════════════
async def stage_execute(
    ctx: PipelineCtx,
) -> AsyncGenerator[Tuple[str, str], None]:
    async for chunk, used_key in execute(
        ctx.model_key,
        ctx.messages,
        ctx.system_prompt,
        ctx.groq_key,
        ctx.gemini_key,
        ctx.max_tokens,
    ):
        yield chunk, used_key


# ════════════════════════════════════════════════════════════════
# Stage 8 — Post-process + persist
# ════════════════════════════════════════════════════════════════
async def stage_post(ctx: PipelineCtx, full_resp: str,
                     actual_key: str, latency_ms: int):
    # Clean response
    processed = post_process(full_resp, ctx.user_tone)

    # Cache
    cache_set(ctx.message, processed, actual_key, "chat")

    # Memory extraction
    extract_and_update(ctx.user_id, ctx.message, processed)

    # Cost
    tokens = len(full_resp.split())
    cost   = track_cost(ctx.user_id, actual_key, tokens)

    # Log
    write_log(ctx.user_id, "chat", actual_key, tokens, cost,
              latency_ms, False, True)
    asyncio.create_task(
        _fire_event(ctx.user_id, "msg_sent", {
            "model": actual_key, "latency_ms": latency_ms,
            "tokens": tokens, "intent": ctx.intent.type,
            "cost_usd": round(cost, 5),
        })
    )

    # Background jobs
    if ctx.user_id and ctx.user_id != "guest":
        await enqueue("analyse_user",
                      {"user_id": ctx.user_id}, delay_s=5)
        await enqueue("generate_suggestions",
                      {"user_id": ctx.user_id}, delay_s=12)
        if ctx.conv_id:
            await enqueue("summarise_conv",
                          {"conv_id": ctx.conv_id,
                           "user_id": ctx.user_id}, delay_s=30)

    log.info(f"[Orchestrator] Done | model={actual_key} | "
             f"{latency_ms}ms | ${cost:.5f} | tokens={tokens}")
    return processed


# ════════════════════════════════════════════════════════════════
# Full orchestration (used by chat route)
# ════════════════════════════════════════════════════════════════
async def run_pipeline(ctx: PipelineCtx):
    """
    Run all pipeline stages.
    Yields SSE-formatted strings for StreamingResponse.
    """
    import json

    # Stage 1-2: analyse + cache
    ctx = stage_analyse(ctx)
    ctx = stage_cache(ctx)

    # Cache hit → stream directly
    if ctx.cached_resp:
        yield f"data: {json.dumps({'type':'meta','model':'PeacockGPT 5','cached':True})}\n\n"
        chunk = ""
        for word in ctx.cached_resp.split(" "):
            chunk += word + " "
            if len(chunk) >= 30:
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
                chunk = ""
                await asyncio.sleep(0.008)
        if chunk:
            yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
        yield f"data: {json.dumps({'type':'done','model':'PeacockGPT 5'})}\n\n"
        write_log(ctx.user_id, "chat", "cache", 0, 0.0,
                  int((time.time() - ctx.t0) * 1000), True, True)
        asyncio.create_task(_fire_event(ctx.user_id, "cache_hit"))
        return

    # Stage 3-6: route, memory, search, prompt
    ctx = stage_route(ctx)
    ctx = stage_memory(ctx)
    ctx = await stage_search(ctx)
    ctx = stage_prompt(ctx)

    yield f"data: {json.dumps({'type':'meta','model':MODELS[ctx.model_key]['display'],'intent':ctx.intent.type,'search':bool(ctx.search_ctx)})}\n\n"

    full_resp  = ""
    actual_key = ctx.model_key

    try:
        # Stage 7: execute
        async for chunk, used_key in stage_execute(ctx):
            full_resp  += chunk
            actual_key  = used_key
            yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"

        latency = int((time.time() - ctx.t0) * 1000)
        # Stage 8: post-process
        await stage_post(ctx, full_resp, actual_key, latency)
        yield f"data: {json.dumps({'type':'done','model':MODELS[actual_key]['display']})}\n\n"

    except Exception as e:
        latency = int((time.time() - ctx.t0) * 1000)
        write_log(ctx.user_id, "chat", ctx.model_key, 0, 0.0,
                  latency, False, False, str(e))
        asyncio.create_task(_fire_event(ctx.user_id, "error",
                                        {"err": str(e)[:100]}))
        log.error(f"[Orchestrator] Error: {e}")
        if not full_resp:
            yield f"data: {json.dumps({'type':'error','content':'في مشكلة. تأكد من مفاتيح API في الإعدادات ⚙️'})}\n\n"
        yield f"data: {json.dumps({'type':'done','model':MODELS[ctx.model_key]['display']})}\n\n"


async def _fire_event(user_id: str, event: str, meta: dict = None):
    await enqueue("track_analytics",
                  {"user_id": user_id, "event": event, "meta": meta or {}})
