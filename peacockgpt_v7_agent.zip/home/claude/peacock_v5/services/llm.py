"""
services/llm.py — LLM calls with streaming, fallback, cost tracking
Author: PeacockAI – Mostafa
"""
import asyncio, json, time
from typing import AsyncGenerator, Tuple, Optional
from core.config import MODELS, FALLBACK_CHAIN, FLAGS, log
from core.database import get_db, User
import httpx

# ── Cost tracking ─────────────────────────────────────────────────
def track_cost(user_id: str, model_key: str, token_count: int) -> float:
    cfg  = MODELS.get(model_key, {})
    cost = cfg.get("cost_per_1k", 0) * token_count / 1000
    if user_id and user_id != "guest" and cost > 0:
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                u.token_cost = (u.token_cost or 0) + cost
    return cost

# ── Groq streaming call ───────────────────────────────────────────
async def call_groq(model_id: str, messages: list, api_key: str,
                    max_tokens: int = 4096,
                    stream: bool = True) -> AsyncGenerator[str, None]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":      model_id,
        "messages":   messages,
        "max_tokens": max_tokens,
        "temperature":0.7,
        "stream":     stream,
    }
    async with httpx.AsyncClient(timeout=90) as client:
        if stream:
            async with client.stream(
                "POST",
                "https://api.groq.com/openai/v1/chat/completions",
                headers=headers,
                json=payload,
            ) as r:
                if r.status_code != 200:
                    body = await r.aread()
                    raise RuntimeError(f"Groq {r.status_code}: {body[:200]}")
                async for line in r.aiter_lines():
                    if line.startswith("data: ") and line != "data: [DONE]":
                        try:
                            delta = json.loads(line[6:])["choices"][0]["delta"].get("content","")
                            if delta:
                                yield delta
                        except Exception:
                            pass
        else:
            r = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers=headers, json=payload,
            )
            if r.status_code != 200:
                raise RuntimeError(f"Groq {r.status_code}")
            yield r.json()["choices"][0]["message"]["content"]

# ── Gemini call ───────────────────────────────────────────────────
async def call_gemini(model_id: str, messages: list, api_key: str,
                      system: str = "",
                      max_tokens: int = 4096) -> AsyncGenerator[str, None]:
    contents = [
        {"role": "user" if m["role"] == "user" else "model",
         "parts": [{"text": m["content"]}]}
        for m in messages if m["role"] != "system"
    ]
    url     = (f"https://generativelanguage.googleapis.com/v1beta/"
               f"models/{model_id}:generateContent?key={api_key}")
    payload = {
        "contents": contents,
        "systemInstruction": {"parts": [{"text": system}]},
        "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.7},
    }
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(url, json=payload)
        if r.status_code != 200:
            raise RuntimeError(f"Gemini {r.status_code}: {r.text[:200]}")
        text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        yield text

# ── Fallback executor ─────────────────────────────────────────────
async def execute(
    model_key:   str,
    messages:    list,
    system:      str,
    groq_key:    str,
    gemini_key:  str,
    max_tokens:  int = 4096,
) -> AsyncGenerator[Tuple[str, str], None]:
    """
    Tries model_key → follows FALLBACK_CHAIN on error.
    Yields (chunk, actual_model_key).
    Transparent to the user.
    """
    current  = model_key
    attempts = 0
    max_attempts = 4

    while current and attempts < max_attempts:
        cfg    = MODELS.get(current)
        if not cfg:
            break

        retries = 2 if FLAGS.get("offline_retry") else 1
        for attempt in range(retries):
            try:
                log.info(f"LLM → {current} ({cfg['model_id']}) attempt {attempt+1}")
                if cfg["provider"] == "groq" and groq_key:
                    async for chunk in call_groq(
                        cfg["model_id"], messages, groq_key, max_tokens
                    ):
                        yield chunk, current
                    return  # success

                elif cfg["provider"] == "gemini" and gemini_key:
                    async for chunk in call_gemini(
                        cfg["model_id"], messages, gemini_key, system, max_tokens
                    ):
                        yield chunk, current
                    return  # success

                else:
                    raise RuntimeError(f"No API key for provider {cfg['provider']}")

            except Exception as e:
                log.warning(f"Model {current} attempt {attempt+1} failed: {e}")
                if attempt < retries - 1:
                    await asyncio.sleep(0.5 * (attempt + 1))

        # Move to next fallback
        prev    = current
        current = FALLBACK_CHAIN.get(current)
        attempts += 1
        log.info(f"Falling back: {prev} → {current}")
        if current:
            await asyncio.sleep(0.3)

    raise RuntimeError("All models exhausted after fallback chain")
