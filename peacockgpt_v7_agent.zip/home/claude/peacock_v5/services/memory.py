"""
services/memory.py — Intelligent Memory Engine v2
Pipeline: message → analyze → extract → structure → store
Levels: short | session | long (persistent across conversations)
Author: PeacockAI – Mostafa
"""
import re
from datetime import datetime
from typing import Dict, Optional, List
from core.config import FLAGS, log
from core.database import get_db, UserMemory


# ════════════════════════════════════════════════════════════════
# READ / WRITE / DELETE  (unchanged API, improved internals)
# ════════════════════════════════════════════════════════════════

def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest":
        return {}
    with get_db() as db:
        rows = db.query(UserMemory).filter_by(
            user_id=user_id, scope=scope
        ).order_by(UserMemory.confidence.desc()).all()
    return {r.key: r.value for r in rows}


def mem_get_all(user_id: str) -> Dict[str, Dict[str, str]]:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0):
    if not user_id or user_id == "guest":
        return
    mid = f"{user_id}:{scope}:{key}"
    now = datetime.now().isoformat()
    with get_db() as db:
        existing = db.query(UserMemory).filter_by(id=mid).first()
        if existing:
            # Only update if new confidence >= current (don't downgrade)
            if confidence >= (existing.confidence or 0):
                existing.value      = value[:500]
                existing.confidence = confidence
                existing.updated_at = now
        else:
            db.add(UserMemory(
                id=mid, user_id=user_id, scope=scope,
                key=key, value=value[:500],
                confidence=confidence,
                updated_at=now
            ))


def mem_delete(user_id: str, scope: Optional[str] = None,
               key: Optional[str] = None):
    with get_db() as db:
        q = db.query(UserMemory).filter_by(user_id=user_id)
        if scope: q = q.filter_by(scope=scope)
        if key:   q = q.filter_by(key=key)
        q.delete()


# ════════════════════════════════════════════════════════════════
# EXTRACTION PIPELINE  (message → structured facts)
# ════════════════════════════════════════════════════════════════

# Domain taxonomy (keyword → canonical domain)
_DOMAIN_MAP: Dict[str, str] = {
    # Software
    "برمجة":"software","تطوير":"software","كود":"software",
    "python":"software","javascript":"software","typescript":"software",
    "react":"software","nodejs":"software","backend":"software",
    "frontend":"software","fullstack":"software","devops":"software",
    # Medicine
    "طب":"medicine","دكتور":"medicine","مريض":"medicine","صيدلة":"medicine",
    # Law
    "قانون":"law","محامي":"law","حقوق":"law","قضاء":"law",
    # Finance
    "اقتصاد":"finance","مال":"finance","استثمار":"finance",
    "بورصة":"finance","تداول":"finance","عملات":"finance",
    # Design
    "تصميم":"design","ui":"design","ux":"design",
    "figma":"design","photoshop":"design","illustrator":"design",
    # Education
    "تعليم":"education","دراسة":"education","مدرسة":"education",
    "جامعة":"education","امتحان":"education",
    # Business
    "بيزنس":"business","شركة":"business","تسويق":"business",
    "ريادة":"business","startup":"business","مشروع":"business",
    # AI
    "ذكاء اصطناعي":"ai","ai":"ai","machine learning":"ai",
    "deep learning":"ai","llm":"ai","neural":"ai","model":"ai",
    # Writing
    "كتابة":"writing","مقال":"writing","محتوى":"writing",
    "تدوين":"writing","روايه":"writing",
}

_BEGINNER_RE = re.compile(
    r"مبتدئ|مش\s*فاهم|ازاي|ايه\s*معنى|لا\s*أعرف|مش\s*عارف|"
    r"للمبتدئين|أول\s*مرة|شرح\s*بسيط|من\s*الصفر|explain\s*simply|"
    r"i\s*don.t\s*know|for\s*beginners|step\s*by\s*step",
    re.IGNORECASE
)

_ADVANCED_RE = re.compile(
    r"architecture|trade.off|complexity|production\s*deploy|ci/cd|"
    r"distributed|microservices|scalable|concurrency|async\s+await|"
    r"optimization|benchmark|profiling|kubernetes|terraform|"
    r"design\s*pattern|system\s*design|low.level|internals",
    re.IGNORECASE
)

_NAME_RE = re.compile(
    r"(?:اسمي|أنا|my\s+name\s+is|i\s+am)\s+([A-Za-z\u0600-\u06FF]{2,25})",
    re.IGNORECASE
)

_ROLE_RE = re.compile(
    r"(?:أنا|i\s+am|i\s+work\s+as|شغلتي)\s+"
    r"(مطور|مهندس|دكتور|طبيب|محامي|مصمم|معلم|طالب|"
    r"developer|engineer|doctor|lawyer|designer|student|teacher)\b",
    re.IGNORECASE
)


def _extract_facts(message: str) -> List[dict]:
    """
    Extract structured facts from a message.
    Returns list of {key, value, scope, confidence} dicts.
    """
    low   = message.lower()
    facts = []

    # ── Domain ──────────────────────────────────────────────
    domain_votes: Dict[str, float] = {}
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            domain_votes[domain] = domain_votes.get(domain, 0) + 1
    if domain_votes:
        top_domain = max(domain_votes, key=domain_votes.get)  # type: ignore
        score = min(domain_votes[top_domain] * 0.25, 0.9)
        facts.append({"key":"domain","value":top_domain,"scope":"long","confidence":score})

    # ── Expertise level ──────────────────────────────────────
    if _BEGINNER_RE.search(message):
        facts.append({"key":"level","value":"beginner","scope":"long","confidence":0.8})
    elif _ADVANCED_RE.search(message):
        facts.append({"key":"level","value":"advanced","scope":"long","confidence":0.9})

    # ── Name ────────────────────────────────────────────────
    m = _NAME_RE.search(message)
    if m:
        name = m.group(1).strip()
        if 2 <= len(name) <= 25:
            facts.append({"key":"preferred_name","value":name,"scope":"long","confidence":0.95})

    # ── Role / Profession ────────────────────────────────────
    r = _ROLE_RE.search(message)
    if r:
        facts.append({"key":"role","value":r.group(1).lower(),"scope":"long","confidence":0.85})

    # ── Language preference ───────────────────────────────────
    eng_words = len(re.findall(r"\b[a-zA-Z]{4,}\b", message))
    ar_chars  = len(re.findall(r"[\u0600-\u06FF]", message))
    if eng_words >= 5 and ar_chars < 10:
        facts.append({"key":"lang_pref","value":"english","scope":"long","confidence":0.7})
    elif eng_words >= 3 and ar_chars > 10:
        facts.append({"key":"lang_pref","value":"bilingual","scope":"long","confidence":0.6})

    # ── Session topic ────────────────────────────────────────
    if len(message) > 20:
        topic = message[:70].replace("\n"," ").strip()
        facts.append({"key":"last_topic","value":topic,"scope":"session","confidence":1.0})

    return facts


def extract_and_update(user_id: str, message: str, response: str = ""):
    """
    Full extraction pipeline: analyze → extract → store.
    Called after each AI response.
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return
    facts = _extract_facts(message)
    for f in facts:
        mem_set(user_id, f["scope"], f["key"], f["value"], f["confidence"])
    if facts:
        log.debug(f"[Memory] Extracted {len(facts)} facts for {user_id}")


# ════════════════════════════════════════════════════════════════
# CONTEXT BUILDER  (serialize memory → prompt string)
# ════════════════════════════════════════════════════════════════

def build_memory_context(user_id: str) -> str:
    """
    Assemble memory into a concise, prompt-ready string.
    Prioritises long-term facts, adds session context.
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return ""

    long    = mem_get(user_id, "long")
    session = mem_get(user_id, "session")

    parts: List[str] = []

    if long:
        # Build human-readable summary
        summary_parts = []
        if "preferred_name" in long:
            summary_parts.append(f"اسم المستخدم: {long['preferred_name']}")
        if "role" in long:
            summary_parts.append(f"مهنته: {long['role']}")
        if "domain" in long:
            summary_parts.append(f"مجاله: {long['domain']}")
        if "level" in long:
            lvl = {"beginner":"مبتدئ","advanced":"متقدم"}.get(long["level"], long["level"])
            summary_parts.append(f"مستواه: {lvl}")
        if "lang_pref" in long:
            summary_parts.append(f"يفضل: {long['lang_pref']}")
        # Any other keys
        for k, v in long.items():
            if k not in ("preferred_name","role","domain","level","lang_pref"):
                summary_parts.append(f"{k}: {v}")
        if summary_parts:
            parts.append("معلومات المستخدم: " + " | ".join(summary_parts))

    if session:
        sess_parts = [f"{k}: {v}" for k, v in session.items()]
        if sess_parts:
            parts.append("الجلسة الحالية: " + " | ".join(sess_parts))

    return "\n".join(parts)
import re
from datetime import datetime
from typing import Dict, Optional
from core.config import FLAGS, log
from core.database import get_db, UserMemory


# ── Read ──────────────────────────────────────────────────────────
def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest":
        return {}
    with get_db() as db:
        rows = db.query(UserMemory).filter_by(
            user_id=user_id, scope=scope
        ).order_by(UserMemory.confidence.desc()).all()
    return {r.key: r.value for r in rows}


def mem_get_all(user_id: str) -> Dict[str, Dict[str, str]]:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


# ── Write ─────────────────────────────────────────────────────────
def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0):
    if not user_id or user_id == "guest":
        return
    mid = f"{user_id}:{scope}:{key}"
    with get_db() as db:
        existing = db.query(UserMemory).filter_by(id=mid).first()
        if existing:
            existing.value      = value[:500]
            existing.confidence = confidence
            existing.updated_at = datetime.now().isoformat()
        else:
            db.add(UserMemory(
                id=mid, user_id=user_id, scope=scope,
                key=key, value=value[:500],
                confidence=confidence,
                updated_at=datetime.now().isoformat()
            ))


# ── Delete ────────────────────────────────────────────────────────
def mem_delete(user_id: str, scope: Optional[str] = None,
               key: Optional[str] = None):
    with get_db() as db:
        q = db.query(UserMemory).filter_by(user_id=user_id)
        if scope:
            q = q.filter_by(scope=scope)
        if key:
            q = q.filter_by(key=key)
        q.delete()


# ── Extraction ────────────────────────────────────────────────────
_DOMAIN_MAP = {
    "برمجة":             "software",
    "تطوير":             "software",
    "كود":               "software",
    "python":            "software",
    "javascript":        "software",
    "طب":                "medicine",
    "دكتور":             "medicine",
    "مريض":              "medicine",
    "قانون":             "law",
    "محامي":             "law",
    "اقتصاد":            "economics",
    "مال":               "finance",
    "استثمار":           "finance",
    "تصميم":             "design",
    "ui":                "design",
    "ux":                "design",
    "تعليم":             "education",
    "دراسة":             "education",
    "بيزنس":             "business",
    "شركة":              "business",
    "ذكاء اصطناعي":      "ai",
    "ai":                "ai",
    "machine learning":  "ai",
}

_BEGINNER_SIGNALS = {
    "مبتدئ","مش فاهم","ازاي","ايه معنى","لا أعرف","مش عارف","للمبتدئين",
    "أول مرة","شرح بسيط","من الصفر",
}

_ADVANCED_SIGNALS = {
    "architecture","trade-off","complexity","production","deploy","ci/cd",
    "distributed","microservices","scalable","concurrency","async","thread",
    "optimization","benchmark","profiling","kubernetes","terraform",
}

_PREFER_CODE_SIGNALS = {
    "github","git commit","pull request","merge","branch","refactor",
    "اكتب كود","اعمل function","اعمل class","unit test","integration test",
}


def extract_and_update(user_id: str, message: str, response: str = ""):
    """
    Heuristic extraction of long-term facts from user message.
    Runs asynchronously after each response (via background job).
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return
    low = message.lower()

    # ── Domain detection ──────────────────────────────────────
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            mem_set(user_id, "long", "domain", domain, confidence=0.7)
            break   # first match wins

    # ── Expertise level ───────────────────────────────────────
    if any(w in low for w in _BEGINNER_SIGNALS):
        mem_set(user_id, "long", "level", "beginner", confidence=0.8)
    elif any(w in low for w in _ADVANCED_SIGNALS):
        mem_set(user_id, "long", "level", "advanced", confidence=0.9)

    # ── Prefers code model ────────────────────────────────────
    if any(w in low for w in _PREFER_CODE_SIGNALS):
        mem_set(user_id, "long", "prefers_code_model", "yes", confidence=0.75)

    # ── Language preference ───────────────────────────────────
    eng_words = re.findall(r"\b[a-zA-Z]{4,}\b", message)
    if len(eng_words) >= 4:
        mem_set(user_id, "long", "lang_pref", "bilingual", confidence=0.6)

    # ── Explicit name/role ────────────────────────────────────
    m = re.search(r"(اسمي|أنا|My name is|I am)\s+([A-Za-z\u0600-\u06FF]{2,25})", message)
    if m:
        name = m.group(2).strip()
        if len(name) > 1:
            mem_set(user_id, "long", "preferred_name", name, confidence=0.95)

    # ── Session: last topic ────────────────────────────────────
    if len(message) > 20:
        topic = message[:60].replace("\n", " ")
        mem_set(user_id, "session", "last_topic", topic, confidence=1.0)


# ── Context Builder ───────────────────────────────────────────────
def build_memory_context(user_id: str) -> str:
    """Serialise memory into a concise context string for the prompt."""
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return ""
    long    = mem_get(user_id, "long")
    session = mem_get(user_id, "session")
    parts   = []
    if long:
        parts.append("معلومات عن المستخدم: " + " | ".join(
            f"{k}: {v}" for k, v in long.items()
        ))
    if session:
        parts.append("اهتمامات هذه الجلسة: " + " | ".join(
            f"{k}: {v}" for k, v in session.items()
        ))
    return "\n".join(parts)
