"""
services/agent.py — Pro Agent System (Plan → Execute → Deliver)
Exclusive to plan = "pro"
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio
from datetime import datetime
from typing import List, Dict, Optional, AsyncGenerator
from dataclasses import dataclass, field

from core.config import MODELS, FLAGS, PLANS, log
from core.database import get_db, AgentTask
from services.file_manager import (
    write_file, read_file, list_files, create_file,
    get_project_tree, FileManagerError
)
from services.llm import execute


# ── Permission guard ──────────────────────────────────────────────
def require_pro(user_plan: str):
    if user_plan != "pro" or not PLANS["pro"].get("agent"):
        raise PermissionError(
            "🔒 Agent Mode متاح فقط لمستخدمي Pro.\n"
            "ترقية لـ Pro: 1500 جنيه أو $35/شهر"
        )

def check_agent_ops(user_id: str, user_plan: str) -> tuple[bool, str]:
    """Check agent operation quota."""
    limit = PLANS.get(user_plan, {}).get("agent_ops", 0)
    if limit == 0:
        return False, "Agent Mode غير متاح في خطتك"
    with get_db() as db:
        from core.database import User
        u = db.query(User).filter_by(id=user_id).first()
        if u and (u.agent_ops or 0) >= limit:
            return False, f"تجاوزت حد {limit} عملية وكيل يومياً"
    return True, ""

def increment_agent_ops(user_id: str):
    with get_db() as db:
        from core.database import User
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.agent_ops = (u.agent_ops or 0) + 1


# ── Agent intent detection ────────────────────────────────────────
AGENT_TRIGGERS = {
    "اعمل", "ابني", "أنشئ مشروع", "build", "create project",
    "عدل الكود", "modify", "refactor", "اكتب تطبيق",
    "افتح ملف", "open file", "اقرأ ملف", "read file",
    "اعرض الملفات", "list files", "احذف ملف",
    "حلل المشروع", "analyze project", "review code",
}

def is_agent_request(message: str) -> bool:
    """Detect if message requires Agent Mode."""
    low = message.lower()
    return any(t in low for t in AGENT_TRIGGERS)


# ── Task planner ──────────────────────────────────────────────────
PLAN_SYSTEM = """أنت PeacockGPT Agent، مخطط مهام ذكي من PeacockAI.
مهمتك: تحليل طلب المستخدم وإنشاء خطة تنفيذ مفصلة.

أعد JSON فقط بهذا الشكل:
{
  "goal": "وصف مختصر للهدف",
  "steps": [
    {"id": 1, "type": "think",      "description": "..."},
    {"id": 2, "type": "create_file","filename": "...", "description": "..."},
    {"id": 3, "type": "write_file", "filename": "...", "description": "..."},
    {"id": 4, "type": "read_file",  "filename": "...", "description": "..."},
    {"id": 5, "type": "summarise",  "description": "..."}
  ],
  "estimated_files": 3
}

أنواع الخطوات المتاحة:
- think:       تحليل أو تفكير (لا ملفات)
- create_file: إنشاء ملف جديد
- write_file:  كتابة محتوى في ملف
- read_file:   قراءة ملف
- list_files:  عرض قائمة الملفات
- summarise:   تلخيص النتائج

قواعد:
- الخطوات يجب أن تكون منطقية ومرتبة
- لا تنشئ أكثر من 10 ملفات
- ردك JSON فقط بدون أي نص إضافي"""

async def plan_task(goal: str, context: str,
                    groq_key: str, gemini_key: str) -> dict:
    """Use AI to generate a step-by-step task plan."""
    messages = [
        {"role": "system", "content": PLAN_SYSTEM},
        {"role": "user",   "content": f"الطلب: {goal}\n\nالسياق: {context[:500]}"}
    ]
    full = ""
    async for chunk, _ in execute(
        "peacockgpt-5", messages, PLAN_SYSTEM,
        groq_key, gemini_key, max_tokens=1500
    ):
        full += chunk

    # Parse JSON
    try:
        clean = full.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        return json.loads(clean.strip())
    except Exception as e:
        log.warning(f"[Agent] Plan parse error: {e} — using fallback")
        return {
            "goal": goal,
            "steps": [
                {"id": 1, "type": "think", "description": f"تحليل: {goal}"},
                {"id": 2, "type": "write_file", "filename": "output.md",
                 "description": "كتابة النتيجة"},
                {"id": 3, "type": "summarise", "description": "تلخيص النتيجة"},
            ],
            "estimated_files": 1,
        }


# ── Step executor ─────────────────────────────────────────────────
STEP_SYSTEM_TEMPLATE = """أنت PeacockGPT Agent من PeacockAI.
تنفذ الخطوة التالية كجزء من مهمة: {goal}

الخطوة: {step_desc}
{file_context}

{extra_instruction}

أجب مباشرة بالمحتوى المطلوب فقط بدون شرح إضافي."""

async def execute_step(step: dict, goal: str, user_id: str,
                       file_context: str, groq_key: str,
                       gemini_key: str) -> dict:
    """Execute a single agent step. Returns result dict."""
    step_type = step.get("type","think")
    step_desc = step.get("description","")
    filename  = step.get("filename","")
    result    = {"step_id": step["id"], "type": step_type,
                 "status": "done", "output": ""}

    try:
        if step_type == "list_files":
            files = list_files(user_id)
            result["output"] = json.dumps(
                [f["path"] for f in files], ensure_ascii=False
            )

        elif step_type == "read_file":
            if not filename:
                result["status"] = "skipped"
                result["output"] = "لا يوجد اسم ملف"
                return result
            content, _ = read_file(user_id, filename)
            result["output"]   = content[:3000]
            result["filename"] = filename

        elif step_type in ("create_file", "write_file"):
            extra = (f"اكتب محتوى الملف `{filename}` كاملاً وجاهزاً للتشغيل."
                     if filename.endswith((".py",".js",".ts",".html"))
                     else f"اكتب محتوى الملف `{filename}`.")
            prompt = STEP_SYSTEM_TEMPLATE.format(
                goal=goal, step_desc=step_desc,
                file_context=file_context[:800] if file_context else "",
                extra_instruction=extra,
            )
            messages = [{"role":"system","content":prompt},
                        {"role":"user","content":f"انشئ/اكتب: {filename}"}]
            content = ""
            async for chunk, _ in execute(
                "peacockgpt-5", messages, prompt,
                groq_key, gemini_key, max_tokens=3000
            ):
                content += chunk

            write_file(user_id, filename, content, overwrite=True)
            result["output"]   = content[:500] + ("…" if len(content)>500 else "")
            result["filename"] = filename

        elif step_type in ("think", "summarise"):
            prompt = STEP_SYSTEM_TEMPLATE.format(
                goal=goal, step_desc=step_desc,
                file_context=file_context[:600] if file_context else "",
                extra_instruction="",
            )
            messages = [{"role":"system","content":prompt},
                        {"role":"user","content":step_desc}]
            out = ""
            async for chunk, _ in execute(
                "peacockgpt-5-fast", messages, prompt,
                groq_key, gemini_key, max_tokens=800
            ):
                out += chunk
            result["output"] = out

    except FileManagerError as e:
        result["status"] = "error"
        result["output"] = f"خطأ في الملفات: {e}"
    except Exception as e:
        result["status"] = "error"
        result["output"] = f"خطأ: {e}"

    return result


# ════════════════════════════════════════════════════════════════
# MAIN AGENT RUNNER (streaming)
# ════════════════════════════════════════════════════════════════
async def run_agent(
    goal:       str,
    user_id:    str,
    user_plan:  str,
    groq_key:   str,
    gemini_key: str,
    context:    str = "",
) -> AsyncGenerator[str, None]:
    """
    Full agent execution pipeline.
    Yields SSE-formatted JSON strings for StreamingResponse.
    """
    # Permission check
    require_pro(user_plan)
    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok:
        yield _sse({"type":"error","content":reason})
        return

    if FLAGS.get("kill_agent"):
        yield _sse({"type":"error","content":"Agent Mode متوقف مؤقتاً. جرب لاحقاً."})
        return

    # Create DB task record
    task_id = secrets.token_hex(10)
    now     = datetime.now().isoformat()
    with get_db() as db:
        db.add(AgentTask(
            id=task_id, user_id=user_id, goal=goal,
            status="planning", created_at=now, updated_at=now
        ))

    yield _sse({"type":"agent_start","task_id":task_id,
                "message":f"🤖 بدء التخطيط: {goal[:80]}"})

    # ── Stage 1: Plan ──────────────────────────────────────────
    yield _sse({"type":"agent_phase","phase":"planning",
                "message":"📋 جارٍ إنشاء خطة التنفيذ…"})
    try:
        plan_data = await plan_task(goal, context, groq_key, gemini_key)
    except Exception as e:
        yield _sse({"type":"error","content":f"فشل التخطيط: {e}"})
        return

    steps = plan_data.get("steps", [])
    yield _sse({"type":"agent_plan","steps":steps,
                "message":f"✅ خطة جاهزة — {len(steps)} خطوات"})

    # Save plan
    with get_db() as db:
        t = db.query(AgentTask).filter_by(id=task_id).first()
        if t:
            t.plan      = json.dumps(steps, ensure_ascii=False)
            t.status    = "running"
            t.updated_at = datetime.now().isoformat()

    # ── Stage 2: Execute steps ─────────────────────────────────
    file_ops_log = []
    accumulated_context = ""

    for step in steps:
        yield _sse({"type":"agent_step",
                    "step_id":  step["id"],
                    "step_type":step.get("type",""),
                    "message":  f"⚡ الخطوة {step['id']}: {step.get('description','')[:60]}"})

        result = await execute_step(
            step, goal, user_id,
            accumulated_context, groq_key, gemini_key
        )

        # Build context for next steps
        if result.get("output"):
            accumulated_context += f"\n[خطوة {step['id']}]: {result['output'][:400]}"

        if result.get("filename"):
            file_ops_log.append({
                "step": step["id"],
                "type": step.get("type"),
                "file": result["filename"],
                "status": result["status"],
            })

        yield _sse({"type":"agent_step_done",
                    "step_id":result["step_id"],
                    "status": result["status"],
                    "output": result.get("output","")[:300],
                    "filename":result.get("filename","")})

        # Increment ops counter
        increment_agent_ops(user_id)

        await asyncio.sleep(0.1)   # small pause between steps

    # ── Stage 3: Summary ──────────────────────────────────────
    files = list_files(user_id)
    summary_lines = [f"✅ اكتملت المهمة: {goal[:80]}", ""]
    summary_lines.append(f"📁 الملفات المُنشأة: {len(file_ops_log)}")
    for op in file_ops_log:
        icon = "✅" if op["status"]=="done" else "❌"
        summary_lines.append(f"  {icon} {op['file']} ({op['type']})")
    summary_lines.append(f"\n📂 إجمالي الملفات في المشروع: {len(files)}")

    summary = "\n".join(summary_lines)
    yield _sse({"type":"agent_done",
                "task_id":  task_id,
                "summary":  summary,
                "files":    [f["path"] for f in files],
                "ops_count":len(file_ops_log)})

    # Update DB
    with get_db() as db:
        t = db.query(AgentTask).filter_by(id=task_id).first()
        if t:
            t.status    = "done"
            t.result    = summary[:1000]
            t.file_ops  = json.dumps(file_ops_log, ensure_ascii=False)
            t.steps_done = len(steps)
            t.updated_at = datetime.now().isoformat()


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
