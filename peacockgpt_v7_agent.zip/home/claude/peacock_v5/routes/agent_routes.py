"""
routes/agent_routes.py — Agent, File Manager, and PDF endpoints
Author: PeacockAI – Mostafa
"""
import json
from fastapi import APIRouter, HTTPException, Header, Request, UploadFile, File
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel, validator
from typing import Optional

from core.config import FLAGS, PLANS, log
from core.security import verify_token
from core.database import get_db, User
from services.agent import run_agent, is_agent_request
from services.file_manager import (
    list_files, read_file, write_file, create_file,
    delete_file, rename_file, get_project_tree,
    export_zip, import_zip, FileManagerError
)
from services.pdf_service import (
    generate_pdf, get_pdf_records, get_pdf_count, check_pdf_quota
)

router = APIRouter(tags=["agent"])


# ── Auth helper ───────────────────────────────────────────────────
def _get_user(x_token: str) -> Optional[dict]:
    if not x_token:
        return None
    payload = verify_token(x_token)
    if not payload:
        return None
    with get_db() as db:
        u = db.query(User).filter_by(id=payload["sub"]).first()
        if u:
            return {"id": u.id, "plan": u.plan or "free", "name": u.name}
    return None

def _require_pro(x_token: str) -> dict:
    user = _get_user(x_token)
    if not user:
        raise HTTPException(401, "سجل دخولك أولاً")
    if user["plan"] != "pro":
        raise HTTPException(403,
            "🔒 هذه الميزة متاحة فقط لمستخدمي Pro.\n"
            "ترقية: 1500 جنيه / $35 شهرياً")
    return user


# ════════════════════════════════════════════════════════════════
# AGENT ROUTES
# ════════════════════════════════════════════════════════════════

class AgentRequest(BaseModel):
    goal:      str
    context:   str = ""
    user_id:   str = "guest"

    @validator("goal")
    def goal_valid(cls, v):
        v = v.strip()
        if not v:        raise ValueError("الهدف مطلوب")
        if len(v) > 2000: raise ValueError("الهدف طويل جداً")
        return v

@router.post("/agent/run")
async def agent_run(
    req:          AgentRequest,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """Run Pro Agent to execute a multi-step goal."""
    if FLAGS.get("kill_agent"):
        raise HTTPException(503, "Agent Mode متوقف مؤقتاً")

    user = _require_pro(x_token)

    return StreamingResponse(
        run_agent(
            goal       = req.goal,
            user_id    = user["id"],
            user_plan  = user["plan"],
            groq_key   = x_groq_key  or "",
            gemini_key = x_gemini_key or "",
            context    = req.context,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"},
    )


@router.get("/agent/tasks/{user_id}")
def list_agent_tasks(user_id: str, x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    from core.database import AgentTask
    with get_db() as db:
        rows = db.query(AgentTask).filter_by(user_id=user_id)\
                 .order_by(AgentTask.created_at.desc()).limit(20).all()
    return [{"id":r.id,"goal":r.goal[:80],"status":r.status,
             "steps_done":r.steps_done,"created_at":r.created_at} for r in rows]


@router.get("/agent/check")
def agent_check(message: str = "", x_token: Optional[str] = Header(None)):
    """Check if a message should trigger agent mode."""
    user = _get_user(x_token)
    is_pro = user and user.get("plan") == "pro"
    return {
        "is_agent_request": is_agent_request(message) and is_pro,
        "agent_available":  is_pro and FLAGS.get("agent_mode"),
    }


# ════════════════════════════════════════════════════════════════
# FILE MANAGER ROUTES (Pro only)
# ════════════════════════════════════════════════════════════════

@router.get("/files/{user_id}")
def fm_list(user_id: str, x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        return {"files": list_files(user_id), "tree": get_project_tree(user_id)}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.get("/files/{user_id}/read")
def fm_read(user_id: str, filename: str,
            x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        content, size = read_file(user_id, filename)
        return {"filename": filename, "content": content, "size_bytes": size}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


class WriteRequest(BaseModel):
    filename:  str
    content:   str
    overwrite: bool = True

@router.post("/files/{user_id}/write")
def fm_write(user_id: str, req: WriteRequest,
             x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        meta = write_file(user_id, req.filename, req.content, req.overwrite)
        return {"ok": True, **meta}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/create")
def fm_create(user_id: str, data: dict,
              x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        meta = create_file(user_id, data.get("filename",""), data.get("content",""))
        return {"ok": True, **meta}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.delete("/files/{user_id}/delete")
def fm_delete(user_id: str, filename: str,
              x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        delete_file(user_id, filename)
        return {"ok": True}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/rename")
def fm_rename(user_id: str, data: dict,
              x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        rename_file(user_id, data.get("old_name",""), data.get("new_name",""))
        return {"ok": True}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.get("/files/{user_id}/export")
def fm_export(user_id: str, x_token: Optional[str] = Header(None)):
    """Download all files as ZIP."""
    _require_pro(x_token)
    try:
        zip_bytes = export_zip(user_id)
        return Response(
            content=zip_bytes,
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=peacock_project_{user_id[:8]}.zip"}
        )
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/import")
async def fm_import(user_id: str, file: UploadFile = File(...),
                    x_token: Optional[str] = Header(None)):
    """Upload and extract a ZIP project."""
    _require_pro(x_token)
    if not file.filename.endswith(".zip"):
        raise HTTPException(400, "الملف يجب أن يكون بصيغة ZIP")
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:   # 10MB max
        raise HTTPException(413, "الملف كبير جداً (max 10MB)")
    try:
        extracted = import_zip(user_id, content)
        return {"ok": True, "extracted": extracted, "count": len(extracted)}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


# ════════════════════════════════════════════════════════════════
# PDF ROUTES
# ════════════════════════════════════════════════════════════════

class PdfRequest(BaseModel):
    content:   str
    title:     str = "PeacockGPT Export"
    user_id:   str = "guest"
    user_plan: str = "free"

    @validator("content")
    def content_not_empty(cls, v):
        if not v.strip(): raise ValueError("المحتوى مطلوب")
        return v

@router.post("/pdf/generate")
async def pdf_generate(
    req:     PdfRequest,
    x_token: Optional[str] = Header(None),
):
    """Generate a PDF from content. Enforces plan limits."""
    if FLAGS.get("kill_pdf"):
        raise HTTPException(503, "تصدير PDF متوقف مؤقتاً")

    # Resolve user
    user_id   = req.user_id
    user_plan = req.user_plan
    user_name = ""
    if x_token:
        payload = verify_token(x_token)
        if payload:
            user_id = payload.get("sub", user_id)
            with get_db() as db:
                u = db.query(User).filter_by(id=user_id).first()
                if u:
                    user_plan = u.plan or "free"
                    user_name = u.name or ""

    try:
        pdf_bytes, record_id = generate_pdf(
            content   = req.content,
            user_id   = user_id,
            user_plan = user_plan,
            title     = req.title,
            user_name = user_name,
            save      = True,
        )
    except PermissionError as e:
        raise HTTPException(403, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))

    safe_title = req.title[:30].replace(" ","_")
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="peacock_{safe_title}.pdf"',
            "X-Record-Id": record_id,
        }
    )


@router.get("/pdf/quota/{user_id}")
def pdf_quota(user_id: str, x_token: Optional[str] = Header(None)):
    """Get current PDF usage vs limit for user."""
    user_plan = "free"
    if x_token:
        payload = verify_token(x_token)
        if payload:
            with get_db() as db:
                u = db.query(User).filter_by(id=payload["sub"]).first()
                if u: user_plan = u.plan or "free"

    limit = PLANS.get(user_plan, PLANS["free"]).get("pdf", 1)
    used  = get_pdf_count(user_id)
    ok, reason = check_pdf_quota(user_id, user_plan)
    return {
        "used":      used,
        "limit":     limit if limit != -1 else "unlimited",
        "available": ok,
        "reason":    reason if not ok else "",
        "plan":      user_plan,
    }


@router.get("/pdf/history/{user_id}")
def pdf_history(user_id: str, x_token: Optional[str] = Header(None)):
    """List user's PDF generation history."""
    return {"records": get_pdf_records(user_id)}
