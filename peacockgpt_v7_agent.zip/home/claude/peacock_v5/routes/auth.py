"""
routes/auth.py — Authentication routes
Author: PeacockAI – Mostafa
"""
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
import hashlib, secrets

from core.database import get_db, User, Session_
from core.security import hash_password, verify_password, create_token, verify_token
from core.config import log, PERSONA

router = APIRouter(prefix="/users", tags=["auth"])

# ── Schemas ───────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    name:     str
    email:    str
    password: str
    region:   str = "global"   # egypt | global

    @validator("password")
    def pw_length(cls, v):
        if len(v) < 6:
            raise ValueError("كلمة المرور 6 أحرف على الأقل")
        return v

    @validator("name")
    def name_not_empty(cls, v):
        v = v.strip()
        if not v:
            raise ValueError("الاسم مطلوب")
        return v

class LoginRequest(BaseModel):
    email:    str
    password: str

# ── Register ──────────────────────────────────────────────────────
@router.post("/register", status_code=201)
def register(req: RegisterRequest):
    uid = hashlib.md5(req.email.lower().encode()).hexdigest()
    with get_db() as db:
        if db.query(User).filter_by(email=req.email.lower()).first():
            raise HTTPException(400, "البريد الإلكتروني مستخدم بالفعل")
        now = datetime.now().isoformat()
        db.add(User(
            id            = uid,
            name          = req.name.strip(),
            email         = req.email.lower().strip(),
            password_hash = hash_password(req.password),
            plan          = "free",
            tone          = "friendly",
            region        = req.region,
            created_at    = now,
            msg_reset_at  = now,
        ))
    token = create_token(uid, "free")
    log.info(f"✅ Register: {req.email}")
    return {"id": uid, "name": req.name, "plan": "free",
            "tone": "friendly", "region": req.region, "token": token}

# ── Login ─────────────────────────────────────────────────────────
@router.post("/login")
def login(req: LoginRequest):
    with get_db() as db:
        user = db.query(User).filter_by(email=req.email.lower().strip()).first()
        if not user or not verify_password(req.password, user.password_hash):
            raise HTTPException(401, "البريد الإلكتروني أو كلمة المرور غلط")
        user.last_seen = datetime.now().isoformat()
        token = create_token(user.id, user.plan or "free")
        log.info(f"✅ Login: {req.email}")
        return {
            "id":           user.id,
            "name":         user.name,
            "plan":         user.plan,
            "tone":         user.tone,
            "region":       user.region,
            "msg_count":    user.msg_count,
            "img_count":    user.img_count,
            "search_count": user.search_count,
            "sub_expires":  user.sub_expires,
            "token":        token,
        }

# ── Logout ────────────────────────────────────────────────────────
@router.post("/logout")
def logout(x_token: Optional[str] = Header(None)):
    # JWT tokens are stateless; client just discards the token
    return {"ok": True}

# ── Me ────────────────────────────────────────────────────────────
@router.get("/me")
def get_me(x_token: Optional[str] = Header(None)):
    payload = verify_token(x_token)
    if not payload:
        raise HTTPException(401, "غير مصادق — سجل دخولك")
    with get_db() as db:
        user = db.query(User).filter_by(id=payload["sub"]).first()
        if not user:
            raise HTTPException(404, "المستخدم غير موجود")
        return {"id": user.id, "name": user.name, "plan": user.plan,
                "tone": user.tone, "region": user.region}

# ── Update tone ───────────────────────────────────────────────────
@router.patch("/tone")
def update_tone(data: dict):
    tone    = data.get("tone", "friendly")
    user_id = data.get("user_id", "")
    if tone not in PERSONA:
        raise HTTPException(400, f"الأسلوب غير صحيح. الخيارات: {list(PERSONA.keys())}")
    with get_db() as db:
        user = db.query(User).filter_by(id=user_id).first()
        if user:
            user.tone = tone
    return {"ok": True, "tone": tone}

# ── Activate subscription ─────────────────────────────────────────
@router.patch("/subscription")
def activate_subscription(data: dict):
    """Called by payment webhook."""
    uid    = data.get("user_id", "")
    plan   = data.get("plan", "pro")
    months = data.get("months", 1)
    from datetime import timedelta
    expires = (datetime.now() + timedelta(days=30 * months)).isoformat()
    with get_db() as db:
        user = db.query(User).filter_by(id=uid).first()
        if not user:
            raise HTTPException(404, "المستخدم غير موجود")
        user.plan        = plan
        user.sub_expires = expires
    return {"ok": True, "plan": plan, "expires": expires}
