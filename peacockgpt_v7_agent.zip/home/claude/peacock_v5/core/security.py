"""
core/security.py — JWT Authentication + bcrypt password hashing
Author: PeacockAI – Mostafa
"""
import hashlib, secrets, time
from datetime import datetime, timedelta
from typing import Optional
from core.config import SECRET_KEY, log

# ── Simple JWT implementation (no extra deps) ─────────────────────
# Format: base64(header).base64(payload).hmac_signature

import base64, hmac, json as _json

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64d(s: str) -> bytes:
    pad = 4 - len(s) % 4
    return base64.urlsafe_b64decode(s + "=" * (pad % 4))

def create_token(user_id: str, plan: str = "free", expires_h: int = 720) -> str:
    """Create a signed JWT-like token valid for expires_h hours."""
    header  = _b64(_json.dumps({"alg":"HS256","typ":"JWT"}).encode())
    payload = _b64(_json.dumps({
        "sub":  user_id,
        "plan": plan,
        "iat":  int(time.time()),
        "exp":  int(time.time()) + expires_h * 3600,
    }).encode())
    sig = _b64(hmac.new(
        SECRET_KEY.encode(), f"{header}.{payload}".encode(), "sha256"
    ).digest())
    return f"{header}.{payload}.{sig}"

def verify_token(token: str) -> Optional[dict]:
    """Verify token signature and expiry. Returns payload dict or None."""
    if not token:
        return None
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header, payload, sig = parts
        expected_sig = _b64(hmac.new(
            SECRET_KEY.encode(), f"{header}.{payload}".encode(), "sha256"
        ).digest())
        if not hmac.compare_digest(sig, expected_sig):
            return None
        data = _json.loads(_b64d(payload))
        if data.get("exp", 0) < time.time():
            return None
        return data
    except Exception as e:
        log.debug(f"Token verify error: {e}")
        return None

# ── Password hashing (SHA-256 + salt, no bcrypt dep needed) ───────
def hash_password(password: str) -> str:
    """Hash password with random salt using SHA-256."""
    salt = secrets.token_hex(16)
    h    = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
    return f"{salt}:{h}"

def verify_password(password: str, hashed: str) -> bool:
    """Verify password against stored hash."""
    try:
        salt, stored_h = hashed.split(":", 1)
        h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
        return hmac.compare_digest(h, stored_h)
    except Exception:
        # Backwards compat with old plain sha256
        return hashlib.sha256(password.encode()).hexdigest() == hashed

# ── API Key masking ───────────────────────────────────────────────
def mask_key(key: str) -> str:
    if len(key) < 8:
        return "***"
    return key[:6] + "..." + key[-4:]
