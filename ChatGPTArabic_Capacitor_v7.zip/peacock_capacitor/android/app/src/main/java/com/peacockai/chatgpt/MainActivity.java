package com.peacockai.chatgpt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {

    // ═══════════════════════════════════════════════════════════
    // ⚠️  CHANGE THIS to your server IP / domain before building
    // Examples:
    //   Local WiFi:   "http://192.168.1.50:8000"
    //   Production:   "https://api.peacockai.com"
    // ═══════════════════════════════════════════════════════════
    private static final String API_BASE = "http://YOUR_SERVER_IP:8000";

    private WebView         webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int    FILE_REQ = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Window flags ─────────────────────────────────────────
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
            WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
        );
        getWindow().setStatusBarColor(Color.parseColor("#08080F"));
        getWindow().setNavigationBarColor(Color.parseColor("#08080F"));

        // ── Layout ───────────────────────────────────────────────
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#08080F"));
        setContentView(root);

        // ── WebView ──────────────────────────────────────────────
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setupWebView();
        setupWebViewClient();
        setupWebChromeClient();

        webView.loadUrl("file:///android_asset/public/index.html");
    }

    // ── WebView Settings ─────────────────────────────────────────
    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();

        // Core
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);

        // Files & Media
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Performance
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setRenderPriority(WebSettings.RenderPriority.HIGH);

        // Text
        s.setDefaultTextEncodingName("UTF-8");
        s.setTextZoom(100);

        // Viewport
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        // User agent — identifies as PeacockGPT app
        s.setUserAgentString("PeacockGPT-Android/7.0 " + s.getUserAgentString());

        // Cookies
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        // Bridge
        webView.addJavascriptInterface(new Bridge(), "NativeBridge");
    }

    // ── WebViewClient ─────────────────────────────────────────────
    private void setupWebViewClient() {
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String url = req.getUrl().toString();
                // Keep local and API URLs inside WebView
                if (url.startsWith("file://") || url.startsWith(API_BASE)) return false;
                // Open external links in browser
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                // Inject API URL into the page JS context
                String js = "window.PEACOCK_API_BASE = '" + API_BASE + "';"
                          + "window.IS_ANDROID_APP = true;"
                          + "console.log('[Native] API injected:', window.PEACOCK_API_BASE);";
                v.evaluateJavascript(js, null);
            }
        });
    }

    // ── WebChromeClient (permissions, file chooser) ───────────────
    private void setupWebChromeClient() {
        webView.setWebChromeClient(new WebChromeClient() {

            // File chooser (upload images, documents)
            @Override
            public boolean onShowFileChooser(WebView wv,
                    ValueCallback<Uri[]> cb, FileChooserParams p) {
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                startActivityForResult(Intent.createChooser(i, "اختر ملفاً"), FILE_REQ);
                return true;
            }

            // WebRTC / camera permission
            @Override
            public void onPermissionRequest(PermissionRequest req) {
                req.grant(req.getResources());
            }
        });
    }

    // ── Native Bridge (JS → Android) ─────────────────────────────
    class Bridge {

        @JavascriptInterface
        public String getApiBase() { return API_BASE; }

        @JavascriptInterface
        public boolean isAndroidApp() { return true; }

        @JavascriptInterface
        public String getAppVersion() { return "7.0"; }

        // Share text via Android share sheet
        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "مشاركة"));
            });
        }

        // Open URL in external browser
        @JavascriptInterface
        public void openBrowser(final String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {}
            });
        }

        // Haptic feedback
        @JavascriptInterface
        public void vibrate(int ms) {
            android.os.Vibrator vib =
                (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(Math.min(ms, 200));
            }
        }

        // Copy to clipboard
        @JavascriptInterface
        public void copyToClipboard(final String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(
                        android.content.ClipData.newPlainText("PeacockGPT", text)
                    );
                }
            });
        }
    }

    // ── File picker result ────────────────────────────────────────
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCallback != null) {
            Uri[] uris = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                uris = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(uris);
            fileCallback = null;
        }
        super.onActivityResult(req, res, data);
    }

    // ── Back button → WebView history → exit confirm ─────────────
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            webView.evaluateJavascript(
                "(function(){ return typeof window.onAppExit==='function'; })()",
                value -> {
                    if ("true".equals(value)) {
                        webView.evaluateJavascript("window.onAppExit()", null);
                    } else {
                        showExitDialog();
                    }
                }
            );
        }
    }

    private void showExitDialog() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("خروج")
            .setMessage("هل تريد الخروج من PeacockGPT؟")
            .setPositiveButton("نعم", (d, w) -> finish())
            .setNegativeButton("لا", null)
            .show();
    }

    // ── Lifecycle ─────────────────────────────────────────────────
    @Override protected void onPause()  { super.onPause();  webView.onPause();  }
    @Override protected void onResume() { super.onResume(); webView.onResume(); }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
