# 📱 ChatGPT Arabic — Capacitor Android Project
**PeacockAI — Mostafa | v7.0**

---

## ✅ هيكل المشروع

```
peacock_capacitor/
├── capacitor.config.json          ← إعدادات Capacitor
├── README.md                      ← هذا الملف
├── BUILD_GUIDE.md                 ← دليل بناء تفصيلي
├── android/
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── assets/public/     ← التطبيق الكامل (HTML+JS+CSS)
│   │   │   │   ├── index.html     ← الـ UI الكامل مع Android bridge
│   │   │   │   ├── manifest.json
│   │   │   │   ├── sw.js
│   │   │   │   ├── icon-192.png
│   │   │   │   └── icon-512.png
│   │   │   ├── java/com/peacockai/chatgpt/
│   │   │   │   └── MainActivity.java  ← WebView wrapper + Native Bridge
│   │   │   ├── res/
│   │   │   │   ├── mipmap-*/      ← أيقونات (mdpi→xxxhdpi)
│   │   │   │   ├── drawable/      ← splash screen
│   │   │   │   ├── values/        ← strings, colors, styles
│   │   │   │   └── xml/           ← network config, file paths
│   │   │   └── AndroidManifest.xml
│   │   ├── build.gradle
│   │   └── proguard-rules.pro
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle.properties
│   ├── local.properties           ← ⚠️ عدّل مسار SDK هنا
│   └── gradle/wrapper/
│       └── gradle-wrapper.properties
```

---

## 🚀 خطوات بناء APK

### الخطوة 1 — تعديل API URL (مطلوب)

افتح:
```
android/app/src/main/java/com/peacockai/chatgpt/MainActivity.java
```

السطر 30:
```java
private static final String API_BASE = "http://YOUR_SERVER_IP:8000";
```

**بدّله لـ:**
```java
// للتطوير على نفس الـ WiFi:
private static final String API_BASE = "http://192.168.1.100:8000";

// للإنتاج (VPS):
private static final String API_BASE = "https://api.peacockai.com";
```

---

### الخطوة 2 — تعديل SDK Path

افتح `android/local.properties`:
```
sdk.dir=C:\Users\YourName\AppData\Local\Android\Sdk
```
**غيّر `YourName` لاسم مستخدم جهازك.**

---

### الخطوة 3 — فتح Android Studio

1. افتح **Android Studio**
2. `File → Open`
3. اختر مجلد `android/`
4. انتظر **Gradle Sync** (قد يأخذ 2-5 دقائق أول مرة)

---

### الخطوة 4 — بناء APK

#### Debug APK (للتجربة):
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
أو في Terminal داخل Android Studio:
```bash
./gradlew assembleDebug
```
**المسار:** `app/build/outputs/apk/debug/app-debug.apk`

#### Release APK (للنشر):
```bash
./gradlew assembleRelease
```

---

### الخطوة 5 — تثبيت على التليفون

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

أو انقل الـ APK للتليفون وافتحه مباشرة.

---

## 🔧 تشغيل الـ Backend

على السيرفر أو لابتوبك:
```bash
cd peacock_v7_hardened/
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

> **للتطوير:** الـ backend على لابتوبك + التليفون على نفس الـ WiFi
> **للإنتاج:** VPS + دومين + HTTPS (Let's Encrypt مجاني)

---

## 📲 مميزات Native Bridge

| الوظيفة | JavaScript | Android |
|---------|-----------|---------|
| مشاركة نص | `NativeBridge.shareText(text)` | Android Share Sheet |
| فتح رابط | `NativeBridge.openBrowser(url)` | External Browser |
| اهتزاز | `NativeBridge.vibrate(ms)` | Vibrator API |
| نسخ | `NativeBridge.copyToClipboard(text)` | Clipboard |
| API URL | `NativeBridge.getApiBase()` | Static constant |

---

## ⚙️ المتطلبات

- Android Studio Hedgehog (2023.1.1) أو أحدث
- JDK 11 أو أحدث (بييجي مع Android Studio)
- Android SDK API 34
- Android 7.0+ على التليفون (API 24)

---

## 🔑 للنشر على Google Play

1. أنشئ Keystore:
```bash
keytool -genkey -v -keystore peacockai.keystore \
  -alias peacockai -keyalg RSA -keysize 2048 -validity 10000
```

2. أضف في `app/build.gradle`:
```groovy
signingConfigs {
    release {
        storeFile     file('../peacockai.keystore')
        storePassword 'YOUR_PASSWORD'
        keyAlias      'peacockai'
        keyPassword   'YOUR_PASSWORD'
    }
}
```

3. `./gradlew bundleRelease` لـ AAB (Play Store)

---

**PeacockAI © 2025 — Mostafa**
