"""
services/memory.py — Hyper-Intelligent Memory System v7 Final
Semantic Memory + User Profile Builder + Adaptive Response Style
Pipeline: message → extract → score → profile → retrieve
Author: PeacockAI – Mostafa
"""
import re, math, hashlib
from datetime import datetime
from typing import Dict, Optional, List, Tuple
from core.config import FLAGS, log
from core.database import get_db, UserMemory

# ══════════════════════════════════════════════════════════════════
# MEMORY SCORES  (importance weighting)
# ══════════════════════════════════════════════════════════════════
class Score:
    CRITICAL = 1.0   # name, profession — never overwrite
    HIGH     = 0.85  # domain, level, language
    MEDIUM   = 0.65  # interests, tools, preferences
    LOW      = 0.40  # casual mentions
    SESSION  = 1.0   # always update session facts


# ══════════════════════════════════════════════════════════════════
# CORE CRUD
# ══════════════════════════════════════════════════════════════════

def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest": return {}
    try:
        with get_db() as db:
            rows = db.query(UserMemory).filter_by(
                user_id=user_id, scope=scope
            ).order_by(UserMemory.confidence.desc()).all()
        return {r.key: r.value for r in rows}
    except Exception as e:
        log.warning(f"[Memory] mem_get error: {e}"); return {}


def mem_get_all(user_id: str) -> Dict[str, Dict]:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0):
    if not user_id or user_id == "guest": return
    mid = f"{user_id}:{scope}:{key}"
    now = datetime.now().isoformat()
    try:
        with get_db() as db:
            existing = db.query(UserMemory).filter_by(id=mid).first()
            if existing:
                # Only upgrade, never downgrade high-confidence facts
                if confidence >= (existing.confidence or 0):
                    existing.value      = str(value)[:500]
                    existing.confidence = confidence
                    existing.updated_at = now
            else:
                db.add(UserMemory(
                    id=mid, user_id=user_id, scope=scope,
                    key=key, value=str(value)[:500],
                    confidence=confidence, updated_at=now
                ))
    except Exception as e:
        log.warning(f"[Memory] mem_set error: {e}")


def mem_delete(user_id: str, scope: Optional[str] = None, key: Optional[str] = None):
    try:
        with get_db() as db:
            q = db.query(UserMemory).filter_by(user_id=user_id)
            if scope: q = q.filter_by(scope=scope)
            if key:   q = q.filter_by(key=key)
            q.delete()
    except Exception as e:
        log.warning(f"[Memory] mem_delete error: {e}")


# ══════════════════════════════════════════════════════════════════
# DOMAIN + INTEREST TAXONOMY
# ══════════════════════════════════════════════════════════════════

_DOMAIN_MAP = {
    # Tech
    "برمجة":"software","تطوير":"software","كود":"software","python":"software",
    "javascript":"software","typescript":"software","react":"software",
    "nodejs":"software","backend":"software","frontend":"software",
    "fullstack":"software","devops":"software","docker":"software",
    "kubernetes":"software","git":"software","api":"software",
    # AI/ML
    "ذكاء اصطناعي":"ai","ai":"ai","machine learning":"ai","deep learning":"ai",
    "llm":"ai","neural":"ai","gpt":"ai","transformer":"ai","model":"ai",
    "تعلم الآلة":"ai","شبكة عصبية":"ai",
    # Medicine
    "طب":"medicine","دكتور":"medicine","مريض":"medicine","صيدلة":"medicine",
    "تشخيص":"medicine","علاج":"medicine","مرض":"medicine",
    # Law
    "قانون":"law","محامي":"law","حقوق":"law","قضاء":"law","عقد":"law",
    # Finance
    "اقتصاد":"finance","مال":"finance","استثمار":"finance","بورصة":"finance",
    "تداول":"finance","عملات":"finance","بيتكوين":"crypto","crypto":"crypto",
    # Design
    "تصميم":"design","ui":"design","ux":"design","figma":"design",
    "photoshop":"design","illustrator":"design","canva":"design",
    # Education
    "تعليم":"education","دراسة":"education","جامعة":"education",
    "امتحان":"education","مدرسة":"education","بحث":"education",
    # Business
    "بيزنس":"business","شركة":"business","تسويق":"business",
    "ريادة":"business","startup":"business","مشروع":"business",
    "سوشيال ميديا":"marketing","إعلان":"marketing",
    # Writing
    "كتابة":"writing","مقال":"writing","محتوى":"writing","رواية":"writing",
    "قصة":"writing","تدوين":"writing","ترجمة":"translation",
}

_LEVEL_SIGNALS = {
    "beginner": {
        "r": re.compile(
            r"مبتدئ|مش\s*فاهم|ازاي|ايه\s*معنى|لا\s*أعرف|مش\s*عارف|"
            r"للمبتدئين|أول\s*مرة|شرح\s*بسيط|من\s*الصفر|explain\s*simply|"
            r"i\s*don.t\s*know|beginner|step\s*by\s*step|how\s*to\s*start",
            re.IGNORECASE
        ), "score": Score.HIGH
    },
    "intermediate": {
        "r": re.compile(
            r"أفهم\s*الأساسيات|عندي\s*خبرة|شغال\s*على|بستخدم|i\s*know\s*the\s*basics|"
            r"intermediate|some\s*experience|familiar\s*with",
            re.IGNORECASE
        ), "score": Score.MEDIUM
    },
    "advanced": {
        "r": re.compile(
            r"architecture|trade.off|complexity|production\s*deploy|ci/cd|"
            r"distributed|microservices|scalable|concurrency|async\s+await|"
            r"optimization|benchmark|profiling|kubernetes|terraform|"
            r"design\s*pattern|system\s*design|low.level|internals|متقدم|"
            r"senior|expert|principal|lead\s*dev",
            re.IGNORECASE
        ), "score": Score.HIGH
    }
}

_NAME_RE   = re.compile(r"(?:اسمي|أنا|my\s+name\s+is|call\s+me|i\s+am)\s+([A-Za-z\u0600-\u06FF]{2,25})", re.I)
_ROLE_RE   = re.compile(
    r"(?:أنا|شغلتي|i\s+am|i\s+work\s+as|i.m\s+a)\s+"
    r"(مطور|مهندس|دكتور|طبيب|محامي|مصمم|معلم|طالب|مدير|"
    r"developer|engineer|doctor|lawyer|designer|student|teacher|manager|"
    r"founder|ceo|cto|product\s+manager|data\s+scientist)\b", re.I)
_AGE_RE    = re.compile(r"(?:عمري|عندي|i.m|i\s+am)\s+(\d{1,2})\s*(?:سنة|years?\s+old|سنه)", re.I)
_GOAL_RE   = re.compile(r"(?:هدفي|أريد\s*أن|بدي|i\s+want\s+to|my\s+goal\s+is)\s+(.{10,80}?)(?:\.|،|$)", re.I)
_TOOL_RE   = re.compile(r"\b(vscode|vim|pycharm|android\s+studio|figma|notion|slack|github|gitlab|jira|postman|insomnia)\b", re.I)
_LANG_RE   = re.compile(r"\b(python|javascript|typescript|java|kotlin|swift|dart|go|rust|c\+\+|php|ruby|r\b|matlab)\b", re.I)


def _extract_facts(message: str, response: str = "") -> List[dict]:
    """Extract all facts from user message. Returns scored fact list."""
    low   = message.lower()
    facts = []

    # ── Domain (vote-based) ──────────────────────────────────────
    votes: Dict[str, float] = {}
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            votes[domain] = votes.get(domain, 0) + 1
    if votes:
        top = max(votes, key=votes.get)  # type: ignore
        facts.append({"key":"domain","value":top,"scope":"long",
                      "conf": min(votes[top]*0.22, Score.HIGH)})

    # ── Expertise level ──────────────────────────────────────────
    for level, sig in _LEVEL_SIGNALS.items():
        if sig["r"].search(message):
            facts.append({"key":"level","value":level,"scope":"long","conf":sig["score"]})
            break

    # ── Name ────────────────────────────────────────────────────
    m = _NAME_RE.search(message)
    if m:
        name = m.group(1).strip()
        if 2 <= len(name) <= 25 and name.lower() not in {"ai","gpt","api","llm"}:
            facts.append({"key":"name","value":name,"scope":"long","conf":Score.CRITICAL})

    # ── Role / Profession ────────────────────────────────────────
    r = _ROLE_RE.search(message)
    if r:
        facts.append({"key":"role","value":r.group(1).lower(),"scope":"long","conf":Score.HIGH})

    # ── Age ─────────────────────────────────────────────────────
    a = _AGE_RE.search(message)
    if a:
        age = int(a.group(1))
        if 10 <= age <= 80:
            facts.append({"key":"age","value":str(age),"scope":"long","conf":Score.MEDIUM})

    # ── Goal ─────────────────────────────────────────────────────
    g = _GOAL_RE.search(message)
    if g:
        facts.append({"key":"goal","value":g.group(1).strip()[:100],"scope":"long","conf":Score.MEDIUM})

    # ── Tools ────────────────────────────────────────────────────
    tools = _TOOL_RE.findall(message)
    if tools:
        facts.append({"key":"tools","value":",".join(set(t.lower() for t in tools[:4])),
                      "scope":"long","conf":Score.MEDIUM})

    # ── Programming languages ────────────────────────────────────
    langs = _LANG_RE.findall(message)
    if langs:
        facts.append({"key":"languages","value":",".join(set(l.lower() for l in langs[:5])),
                      "scope":"long","conf":Score.MEDIUM})

    # ── Language preference ───────────────────────────────────────
    eng  = len(re.findall(r"\b[a-zA-Z]{4,}\b", message))
    ar   = len(re.findall(r"[\u0600-\u06FF]", message))
    if eng >= 6 and ar < 8:
        facts.append({"key":"lang_pref","value":"english","scope":"long","conf":Score.LOW})
    elif eng >= 3 and ar > 10:
        facts.append({"key":"lang_pref","value":"bilingual","scope":"long","conf":Score.LOW})

    # ── Session: topic + message count ───────────────────────────
    if len(message) > 20:
        facts.append({"key":"last_topic","value":message[:70].replace("\n"," "),"scope":"session","conf":Score.SESSION})

    return facts


# ══════════════════════════════════════════════════════════════════
# USER PROFILE BUILDER
# ══════════════════════════════════════════════════════════════════

def build_user_profile(user_id: str) -> dict:
    """Build a complete user profile from long-term memory."""
    long = mem_get(user_id, "long")
    return {
        "name":      long.get("name", ""),
        "role":      long.get("role", ""),
        "domain":    long.get("domain", "general"),
        "level":     long.get("level", "unknown"),
        "age":       long.get("age", ""),
        "goal":      long.get("goal", ""),
        "tools":     long.get("tools", "").split(",") if long.get("tools") else [],
        "languages": long.get("languages", "").split(",") if long.get("languages") else [],
        "lang_pref": long.get("lang_pref", "arabic"),
        "msg_count": int(long.get("msg_count", 0)),
    }


def increment_message_count(user_id: str):
    """Track total messages for engagement scoring."""
    long  = mem_get(user_id, "long")
    count = int(long.get("msg_count", 0)) + 1
    mem_set(user_id, "long", "msg_count", str(count), Score.LOW)


# ══════════════════════════════════════════════════════════════════
# ADAPTIVE STYLE SELECTOR
# ══════════════════════════════════════════════════════════════════

def get_adaptive_style(user_id: str) -> dict:
    """
    Returns recommended response style based on user profile.
    Used by orchestrator to adjust tone/depth automatically.
    """
    profile = build_user_profile(user_id)
    level   = profile.get("level", "unknown")
    domain  = profile.get("domain", "general")
    count   = profile.get("msg_count", 0)

    style = {
        "depth":     "normal",   # brief | normal | deep
        "examples":  True,
        "emoji":     True,
        "formal":    False,
        "code_pref": False,
    }

    if level == "beginner":
        style.update({"depth":"normal","examples":True,"emoji":True,"formal":False})
    elif level == "advanced":
        style.update({"depth":"deep","examples":False,"emoji":False,"formal":True,"code_pref":True})
    elif level == "intermediate":
        style.update({"depth":"normal","examples":True,"code_pref":True})

    if domain in ("software","ai"):
        style["code_pref"] = True
    if domain == "law":
        style["formal"]    = True
        style["emoji"]     = False

    # Long-time users → less hand-holding
    if count > 50:
        style["examples"] = False

    return style


# ══════════════════════════════════════════════════════════════════
# SEMANTIC RETRIEVAL  (embedding-based similarity)
# ══════════════════════════════════════════════════════════════════

def _simple_embed(text: str, dims: int = 128) -> List[float]:
    """Fast deterministic embedding for memory retrieval."""
    text  = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text.lower())
    words = text.split()
    if not words: return []
    vec = [0.0] * dims
    for w in words:
        i = int(hashlib.md5(w.encode()).hexdigest(), 16) % dims
        vec[i] += 1.0
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v/norm for v in vec]


def _cosine(a: List[float], b: List[float]) -> float:
    if len(a) != len(b) or not a: return 0.0
    return sum(x*y for x, y in zip(a, b))


def semantic_retrieve(user_id: str, query: str, top_k: int = 5) -> List[Tuple[str, str, float]]:
    """
    Retrieve most relevant memories for a query.
    Returns [(key, value, similarity_score), ...]
    """
    if not user_id or user_id == "guest": return []
    try:
        q_emb = _simple_embed(query)
        if not q_emb: return []
        long = mem_get(user_id, "long")
        scored = []
        for k, v in long.items():
            v_emb = _simple_embed(f"{k} {v}")
            sim   = _cosine(q_emb, v_emb)
            if sim > 0.05:
                scored.append((k, v, round(sim, 3)))
        scored.sort(key=lambda x: -x[2])
        return scored[:top_k]
    except Exception as e:
        log.warning(f"[Memory] semantic_retrieve error: {e}")
        return []


# ══════════════════════════════════════════════════════════════════
# EXTRACT + UPDATE  (main entry point)
# ══════════════════════════════════════════════════════════════════

def extract_and_update(user_id: str, message: str, response: str = ""):
    """Full extraction pipeline. Safe to call after every turn."""
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest": return
    try:
        facts = _extract_facts(message, response)
        for f in facts:
            mem_set(user_id, f["scope"], f["key"], f["value"], f["conf"])
        increment_message_count(user_id)
        if facts:
            log.debug(f"[Memory] +{len(facts)} facts for {user_id[:12]}")
    except Exception as e:
        log.warning(f"[Memory] extract_and_update error: {e}")


# ══════════════════════════════════════════════════════════════════
# CONTEXT BUILDER  (prompt injection)
# ══════════════════════════════════════════════════════════════════

def build_memory_context(user_id: str, query: str = "") -> str:
    """
    Build a rich, contextual memory string for the prompt.
    Uses semantic retrieval when query is provided.
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest": return ""
    try:
        long    = mem_get(user_id, "long")
        session = mem_get(user_id, "session")
        parts   = []

        # ── Profile summary ──────────────────────────────────────
        if long:
            profile_parts = []
            ORDER = [("name","اسمه"),("role","مهنته"),("domain","مجاله"),
                     ("level","مستواه"),("age","عمره"),("goal","هدفه"),
                     ("languages","لغاته"),("tools","أدواته"),("lang_pref","يفضل")]
            for k, label in ORDER:
                if k in long and long[k]:
                    v = long[k]
                    if k == "level":
                        v = {"beginner":"مبتدئ 🟢","intermediate":"متوسط 🟡","advanced":"متقدم 🔴"}.get(v, v)
                    profile_parts.append(f"{label}: {v}")
            if profile_parts:
                parts.append("👤 المستخدم — " + " | ".join(profile_parts))

        # ── Semantic retrieval for relevant memories ─────────────
        if query:
            relevant = semantic_retrieve(user_id, query, top_k=3)
            rel_parts = [f"{k}={v}" for k,v,s in relevant
                         if k not in ("name","role","domain","level","age","goal","lang_pref","languages","tools","msg_count")]
            if rel_parts:
                parts.append("🧠 ذاكرة ذات صلة: " + " | ".join(rel_parts))

        # ── Session context ──────────────────────────────────────
        if session:
            s_parts = [f"{k}: {v}" for k, v in session.items() if k != "last_topic"]
            if s_parts:
                parts.append("📍 الجلسة: " + " | ".join(s_parts))

        return "\n".join(parts)
    except Exception as e:
        log.warning(f"[Memory] build_memory_context error: {e}")
        return ""


# ══════════════════════════════════════════════════════════════════
# CONVERSATION SUMMARIZER
# ══════════════════════════════════════════════════════════════════

def summarize_and_store(user_id: str, messages: list):
    """Summarize conversation and extract domain/topic. Called periodically."""
    if not messages or not user_id: return
    try:
        user_msgs = [m["content"] for m in messages if m.get("role") == "user"]
        if len(user_msgs) < 3: return
        combined  = " ".join(user_msgs[-10:])[:600].lower()
        # Domain detection
        votes: Dict[str, int] = {}
        for kw, domain in _DOMAIN_MAP.items():
            if kw in combined:
                votes[domain] = votes.get(domain, 0) + 1
        if votes:
            top_domain = max(votes, key=votes.get)  # type: ignore
            mem_set(user_id, "session", "conv_domain", top_domain, Score.MEDIUM)
        # Topic snippet
        last = user_msgs[-1][:80].replace("\n"," ").strip()
        mem_set(user_id, "session", "last_topic", last, Score.SESSION)
        log.debug(f"[Memory] Summarized conv for {user_id[:12]}")
    except Exception as e:
        log.warning(f"[Memory] summarize error: {e}")
