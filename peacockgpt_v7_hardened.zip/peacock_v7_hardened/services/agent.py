"""
services/agent.py — Hardened Pro Agent v7
Pipeline: Request → Validate → Plan → Execute → Deliver
Sandbox enforced, quota checked, audit logged, retry resilient.
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time
from datetime import datetime
from typing import List, Dict, Optional, AsyncGenerator
from dataclasses import dataclass, field

from core.config import MODELS, FLAGS, PLANS, log
from core.database import get_db, AgentTask
from services.file_manager import (
    write_file, read_file, list_files, create_file,
    get_project_tree, FileManagerError
)
from services.llm import execute


# ══════════════════════════════════════════════════════════════════
# PERMISSION + QUOTA GUARDS
# ══════════════════════════════════════════════════════════════════

def require_pro(user_plan: str):
    if user_plan != "pro" or not PLANS["pro"].get("agent"):
        raise PermissionError(
            "🔒 Agent Mode متاح فقط لمستخدمي Pro.\n"
            "ترقية لـ Pro: 1500 جنيه أو $35/شهر"
        )


def check_agent_ops(user_id: str, user_plan: str) -> tuple:
    limit = PLANS.get(user_plan, {}).get("agent_ops", 0)
    if limit == 0:
        return False, "Agent Mode غير متاح في خطتك"
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u and (u.agent_ops or 0) >= limit:
                return False, f"تجاوزت حد {limit} عملية وكيل يومياً"
    except Exception as e:
        log.warning(f"[Agent] Quota check error: {e}")
    return True, ""


def increment_agent_ops(user_id: str):
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                u.agent_ops = (u.agent_ops or 0) + 1
    except Exception as e:
        log.warning(f"[Agent] Increment ops error: {e}")


# ══════════════════════════════════════════════════════════════════
# INTENT DETECTION
# ══════════════════════════════════════════════════════════════════

AGENT_TRIGGERS = {
    "اعمل", "ابني", "أنشئ مشروع", "build", "create project",
    "عدل الكود", "modify", "refactor", "اكتب تطبيق",
    "افتح ملف", "open file", "اقرأ ملف", "read file",
    "اعرض الملفات", "list files", "احذف ملف",
    "حلل المشروع", "analyze project", "review code",
}


def is_agent_request(message: str) -> bool:
    low = message.lower()
    return any(t in low for t in AGENT_TRIGGERS)


# ══════════════════════════════════════════════════════════════════
# TASK PLANNER
# ══════════════════════════════════════════════════════════════════

PLAN_SYSTEM = """أنت PeacockGPT Agent، مخطط مهام ذكي من PeacockAI.
مهمتك: تحليل طلب المستخدم وإنشاء خطة تنفيذ مفصلة.

أعد JSON فقط بهذا الشكل:
{
  "goal": "وصف مختصر للهدف",
  "steps": [
    {"id": 1, "type": "think",       "description": "..."},
    {"id": 2, "type": "create_file", "filename": "...", "description": "..."},
    {"id": 3, "type": "write_file",  "filename": "...", "description": "..."},
    {"id": 4, "type": "read_file",   "filename": "...", "description": "..."},
    {"id": 5, "type": "summarise",   "description": "..."}
  ],
  "estimated_files": 3
}

أنواع الخطوات:
- think:       تحليل أو تفكير
- create_file: إنشاء ملف جديد
- write_file:  كتابة محتوى في ملف
- read_file:   قراءة ملف
- list_files:  عرض قائمة الملفات
- summarise:   تلخيص النتائج

قواعد:
- الخطوات يجب أن تكون منطقية ومرتبة
- لا تنشئ أكثر من 10 ملفات
- JSON فقط بدون أي نص إضافي"""


async def plan_task(goal: str, context: str, groq_key: str, gemini_key: str) -> dict:
    """Generate step-by-step plan via AI. Resilient to parse failures."""
    messages = [
        {"role": "system", "content": PLAN_SYSTEM},
        {"role": "user",   "content": f"الطلب: {goal}\n\nالسياق: {context[:500]}"}
    ]
    full = ""
    try:
        async for chunk, _ in execute(
            "peacockgpt-5", messages, PLAN_SYSTEM,
            groq_key, gemini_key, max_tokens=1500
        ):
            full += chunk
    except Exception as e:
        log.warning(f"[Agent] Plan LLM error: {e} — using fallback plan")
        return _fallback_plan(goal)

    # Parse JSON (handle markdown code fences)
    try:
        clean = full.strip()
        if "```" in clean:
            parts = clean.split("```")
            for part in parts:
                stripped = part.strip()
                if stripped.startswith("json"):
                    stripped = stripped[4:].strip()
                try:
                    return json.loads(stripped)
                except Exception:
                    pass
        return json.loads(clean)
    except Exception as e:
        log.warning(f"[Agent] Plan parse error: {e} — using fallback plan")
        return _fallback_plan(goal)


def _fallback_plan(goal: str) -> dict:
    return {
        "goal": goal,
        "steps": [
            {"id": 1, "type": "think",       "description": f"تحليل: {goal}"},
            {"id": 2, "type": "write_file",  "filename": "output.md", "description": "كتابة النتيجة"},
            {"id": 3, "type": "summarise",   "description": "تلخيص النتيجة"},
        ],
        "estimated_files": 1,
    }


# ══════════════════════════════════════════════════════════════════
# STEP EXECUTOR
# ══════════════════════════════════════════════════════════════════

STEP_SYSTEM = """أنت PeacockGPT Agent من PeacockAI.
تنفذ الخطوة التالية كجزء من مهمة: {goal}
الخطوة: {step_desc}
{file_context}
{extra}
أجب مباشرة بالمحتوى المطلوب فقط بدون شرح إضافي."""


async def execute_step(step: dict, goal: str, user_id: str,
                       file_context: str, groq_key: str,
                       gemini_key: str) -> dict:
    """
    Execute a single agent step.
    All file ops go through the hardened file_manager.
    Returns result dict with status, output, optional filename.
    """
    step_type = step.get("type", "think")
    step_desc = step.get("description", "")
    filename  = step.get("filename", "")
    result    = {
        "step_id":  step["id"],
        "type":     step_type,
        "status":   "done",
        "output":   "",
        "filename": "",
    }

    try:
        # ── list_files ─────────────────────────────────────────
        if step_type == "list_files":
            files = list_files(user_id)
            result["output"] = json.dumps(
                [f["path"] for f in files], ensure_ascii=False
            )

        # ── read_file ──────────────────────────────────────────
        elif step_type == "read_file":
            if not filename:
                result["status"] = "skipped"
                result["output"] = "لا يوجد اسم ملف"
                return result
            content, _ = read_file(user_id, filename)
            result["output"]   = content[:3000]
            result["filename"] = filename

        # ── create_file / write_file ───────────────────────────
        elif step_type in ("create_file", "write_file"):
            extra = (
                f"اكتب محتوى الملف `{filename}` كاملاً وجاهزاً للتشغيل."
                if filename.endswith((".py", ".js", ".ts", ".html"))
                else f"اكتب محتوى الملف `{filename}`."
            )
            prompt = STEP_SYSTEM.format(
                goal=goal, step_desc=step_desc,
                file_context=file_context[:800] if file_context else "",
                extra=extra,
            )
            messages = [
                {"role": "system", "content": prompt},
                {"role": "user",   "content": f"انشئ/اكتب: {filename}"}
            ]
            content = ""
            try:
                async for chunk, _ in execute(
                    "peacockgpt-5", messages, prompt,
                    groq_key, gemini_key, max_tokens=3000
                ):
                    content += chunk
            except Exception as e:
                result["status"] = "error"
                result["output"] = f"فشل توليد المحتوى: {e}"
                return result

            # Write via sandboxed file manager
            write_file(user_id, filename, content, overwrite=True)
            result["output"]   = content[:500] + ("…" if len(content) > 500 else "")
            result["filename"] = filename

        # ── think / summarise ──────────────────────────────────
        elif step_type in ("think", "summarise"):
            prompt = STEP_SYSTEM.format(
                goal=goal, step_desc=step_desc,
                file_context=file_context[:600] if file_context else "",
                extra="",
            )
            messages = [
                {"role": "system", "content": prompt},
                {"role": "user",   "content": step_desc}
            ]
            out = ""
            try:
                async for chunk, _ in execute(
                    "peacockgpt-5-fast", messages, prompt,
                    groq_key, gemini_key, max_tokens=800
                ):
                    out += chunk
            except Exception as e:
                out = f"(تعذّر التحليل: {e})"
            result["output"] = out

        else:
            result["status"] = "skipped"
            result["output"] = f"نوع خطوة غير معروف: {step_type}"

    except FileManagerError as e:
        result["status"] = "error"
        result["output"] = f"⛔ خطأ في الملفات: {e}"
        log.warning(f"[Agent] FileManagerError step {step['id']}: {e}")
    except Exception as e:
        result["status"] = "error"
        result["output"] = f"خطأ غير متوقع: {e}"
        log.error(f"[Agent] Step {step['id']} unexpected error: {e}")

    return result


# ══════════════════════════════════════════════════════════════════
# MAIN AGENT RUNNER (streaming SSE)
# ══════════════════════════════════════════════════════════════════

async def run_agent(
    goal:       str,
    user_id:    str,
    user_plan:  str,
    groq_key:   str,
    gemini_key: str,
    context:    str = "",
) -> AsyncGenerator[str, None]:
    """
    Full agent execution pipeline.
    Yields SSE-formatted JSON strings.
    Pipeline: Validate → Plan → Execute steps → Summarise → Audit
    """
    t0 = time.time()

    # ── Permission + kill switch ───────────────────────────────
    try:
        require_pro(user_plan)
    except PermissionError as e:
        yield _sse({"type": "error", "content": str(e)})
        return

    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok:
        yield _sse({"type": "error", "content": reason})
        return

    if FLAGS.get("kill_agent"):
        yield _sse({"type": "error", "content": "⚠️ Agent Mode متوقف مؤقتاً. جرب لاحقاً."})
        return

    # ── Create DB task record ──────────────────────────────────
    task_id = secrets.token_hex(10)
    now     = datetime.now().isoformat()
    try:
        with get_db() as db:
            db.add(AgentTask(
                id=task_id, user_id=user_id, goal=goal,
                status="planning", created_at=now, updated_at=now
            ))
    except Exception as e:
        log.warning(f"[Agent] DB task create failed: {e}")

    yield _sse({"type": "agent_start", "task_id": task_id,
                "message": f"🤖 بدء التخطيط: {goal[:80]}"})

    # ── Stage 1: Plan ──────────────────────────────────────────
    yield _sse({"type": "agent_phase", "phase": "planning",
                "message": "📋 جارٍ إنشاء خطة التنفيذ…"})

    plan_data = await plan_task(goal, context, groq_key, gemini_key)
    steps     = plan_data.get("steps", [])

    # Cap steps at 15 to prevent runaway
    if len(steps) > 15:
        steps = steps[:15]
        log.warning(f"[Agent] Truncated plan to 15 steps for safety")

    yield _sse({"type": "agent_plan", "steps": steps,
                "message": f"✅ خطة جاهزة — {len(steps)} خطوات"})

    # Save plan to DB
    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.plan       = json.dumps(steps, ensure_ascii=False)
                t.status     = "running"
                t.updated_at = datetime.now().isoformat()
    except Exception as e:
        log.warning(f"[Agent] DB plan save failed: {e}")

    # ── Stage 2: Execute steps ─────────────────────────────────
    file_ops_log        = []
    accumulated_context = ""

    for step in steps:
        yield _sse({
            "type":      "agent_step",
            "step_id":   step["id"],
            "step_type": step.get("type", ""),
            "message":   f"⚡ الخطوة {step['id']}: {step.get('description','')[:60]}"
        })

        result = await execute_step(
            step, goal, user_id,
            accumulated_context, groq_key, gemini_key
        )

        # Build context for next steps
        if result.get("output"):
            accumulated_context += f"\n[خطوة {step['id']}]: {result['output'][:400]}"
            # Cap accumulated context size
            if len(accumulated_context) > 4000:
                accumulated_context = accumulated_context[-3000:]

        if result.get("filename"):
            file_ops_log.append({
                "step":   step["id"],
                "type":   step.get("type"),
                "file":   result["filename"],
                "status": result["status"],
            })
            # Audit log every file operation
            log.info(
                f"[AUDIT][Agent] task={task_id} user={user_id} "
                f"step={step['id']} op={step.get('type')} "
                f"file='{result['filename']}' status={result['status']}"
            )

        yield _sse({
            "type":     "agent_step_done",
            "step_id":  result["step_id"],
            "status":   result["status"],
            "output":   result.get("output", "")[:300],
            "filename": result.get("filename", ""),
        })

        increment_agent_ops(user_id)
        await asyncio.sleep(0.1)

    # ── Stage 3: Summary ───────────────────────────────────────
    elapsed = round(time.time() - t0, 1)
    try:
        files = list_files(user_id)
    except Exception:
        files = []

    summary_lines = [f"✅ اكتملت المهمة: {goal[:80]}", ""]
    summary_lines.append(f"⏱️ الوقت: {elapsed}s")
    summary_lines.append(f"📁 الملفات المُنشأة: {len(file_ops_log)}")
    for op in file_ops_log:
        icon = "✅" if op["status"] == "done" else "❌"
        summary_lines.append(f"  {icon} {op['file']} ({op['type']})")
    summary_lines.append(f"\n📂 إجمالي الملفات في المشروع: {len(files)}")

    summary = "\n".join(summary_lines)
    yield _sse({
        "type":      "agent_done",
        "task_id":   task_id,
        "summary":   summary,
        "files":     [f["path"] for f in files],
        "ops_count": len(file_ops_log),
        "elapsed_s": elapsed,
    })

    # Update DB
    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.status     = "done"
                t.result     = summary[:1000]
                t.file_ops   = json.dumps(file_ops_log, ensure_ascii=False)
                t.steps_done = len(steps)
                t.updated_at = datetime.now().isoformat()
    except Exception as e:
        log.warning(f"[Agent] DB final update failed: {e}")

    log.info(
        f"[AUDIT][Agent] task={task_id} user={user_id} "
        f"goal='{goal[:60]}' steps={len(steps)} "
        f"files={len(file_ops_log)} elapsed={elapsed}s"
    )


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
