"""
PeacockAgent - API Management System
Tracks usage, enforces rate limits, manages plans.
"""
import json
import sqlite3
from datetime import datetime, date
from pathlib import Path
from config.config_manager import get, set_value

BASE_DIR = Path(__file__).parent.parent
DB_PATH = BASE_DIR / "config" / "usage.db"

PLAN_LIMITS = {
    "free":  {"daily_requests": 50,    "daily_tokens": 100_000},
    "plus":  {"daily_requests": 500,   "daily_tokens": 1_000_000},
    "pro":   {"daily_requests": 99999, "daily_tokens": 99_999_999},
}


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS usage (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            date      TEXT NOT NULL,
            session   TEXT,
            tool      TEXT,
            tokens    INTEGER DEFAULT 0,
            requests  INTEGER DEFAULT 1,
            ts        TEXT
        )
    """)
    conn.commit()
    return conn


class APIManager:
    def __init__(self):
        self.plan = get("api.plan", "free")
        self._limits = PLAN_LIMITS.get(self.plan, PLAN_LIMITS["free"])

    # ── Usage recording ───────────────────────────────────────────────────────
    def record(self, session_id: str = "", tool: str = "", tokens: int = 0):
        try:
            conn = _get_conn()
            conn.execute(
                "INSERT INTO usage (date, session, tool, tokens, requests, ts) VALUES (?,?,?,?,1,?)",
                (str(date.today()), session_id, tool, tokens, datetime.now().isoformat())
            )
            conn.commit()
            conn.close()
        except Exception:
            pass

    # ── Daily totals ──────────────────────────────────────────────────────────
    def get_today_usage(self) -> dict:
        try:
            conn = _get_conn()
            row = conn.execute(
                "SELECT COALESCE(SUM(requests),0), COALESCE(SUM(tokens),0) FROM usage WHERE date=?",
                (str(date.today()),)
            ).fetchone()
            conn.close()
            return {"requests": row[0], "tokens": row[1]}
        except Exception:
            return {"requests": 0, "tokens": 0}

    # ── Rate limit check ──────────────────────────────────────────────────────
    def check_limit(self) -> tuple[bool, str]:
        """Returns (allowed, reason)."""
        usage = self.get_today_usage()
        limit = self._limits["daily_requests"]
        if usage["requests"] >= limit:
            return False, f"Daily limit reached ({limit} requests on {self.plan} plan). Upgrade your plan."
        return True, "ok"

    # ── Stats summary ─────────────────────────────────────────────────────────
    def get_stats(self) -> dict:
        usage = self.get_today_usage()
        limits = self._limits
        return {
            "plan": self.plan,
            "today_requests": usage["requests"],
            "today_tokens": usage["tokens"],
            "limit_requests": limits["daily_requests"],
            "limit_tokens": limits["daily_tokens"],
            "requests_left": max(0, limits["daily_requests"] - usage["requests"]),
        }

    # ── Plan management ───────────────────────────────────────────────────────
    def set_plan(self, plan: str):
        if plan in PLAN_LIMITS:
            self.plan = plan
            self._limits = PLAN_LIMITS[plan]
            set_value("api.plan", plan)

    # ── Tool usage breakdown ──────────────────────────────────────────────────
    def get_tool_usage(self, days: int = 7) -> list:
        try:
            conn = _get_conn()
            rows = conn.execute("""
                SELECT tool, COUNT(*) as cnt
                FROM usage
                WHERE tool != ''
                  AND date >= date('now', ?)
                GROUP BY tool
                ORDER BY cnt DESC
                LIMIT 10
            """, (f"-{days} days",)).fetchall()
            conn.close()
            return [{"tool": r[0], "count": r[1]} for r in rows]
        except Exception:
            return []


# Singleton
api_manager = APIManager()
