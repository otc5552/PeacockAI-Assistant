"""
PeacockAgent - Session Management System
Handles multi-session chats with auto-save, rename, delete, export.
"""
import os
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

BASE_DIR = Path(__file__).parent.parent
SESSIONS_DIR = BASE_DIR / "sessions"
SESSIONS_DIR.mkdir(exist_ok=True)


class Session:
    def __init__(self, session_id: str, name: str, messages: list = None):
        self.id = session_id
        self.name = name
        self.messages = messages or []
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "messages": self.messages,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Session":
        s = cls(d["id"], d["name"], d.get("messages", []))
        s.created_at = d.get("created_at", "")
        s.updated_at = d.get("updated_at", "")
        return s

    def add_message(self, role: str, content: str):
        self.messages.append({"role": role, "content": content})
        self.updated_at = datetime.now().isoformat()

    def get_llm_messages(self) -> list:
        """Return messages in LLM format (role + content only)."""
        result = []
        for m in self.messages:
            if m["role"] in ("user", "assistant", "tool"):
                result.append({"role": m["role"], "content": m["content"]})
        return result


class SessionManager:
    def __init__(self):
        self.active_session: Optional[Session] = None
        self._sessions_index: dict = {}  # id -> metadata
        self._load_index()

    # ── Index ─────────────────────────────────────────────────────────────────
    def _index_path(self) -> Path:
        return SESSIONS_DIR / "index.json"

    def _load_index(self):
        if self._index_path().exists():
            with open(self._index_path(), "r", encoding="utf-8") as f:
                self._sessions_index = json.load(f)

    def _save_index(self):
        with open(self._index_path(), "w", encoding="utf-8") as f:
            json.dump(self._sessions_index, f, ensure_ascii=False, indent=2)

    # ── CRUD ──────────────────────────────────────────────────────────────────
    def create_session(self, name: str = None) -> Session:
        sid = str(uuid.uuid4())[:8]
        name = name or f"Chat {datetime.now().strftime('%b %d %H:%M')}"
        session = Session(sid, name)
        self._sessions_index[sid] = {
            "name": name,
            "created_at": session.created_at,
            "updated_at": session.updated_at,
            "message_count": 0
        }
        self._save_index()
        self.save_session(session)
        self.active_session = session
        return session

    def load_session(self, session_id: str) -> Optional[Session]:
        path = SESSIONS_DIR / f"{session_id}.json"
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        session = Session.from_dict(data)
        self.active_session = session
        return session

    def save_session(self, session: Session = None):
        s = session or self.active_session
        if not s:
            return
        path = SESSIONS_DIR / f"{s.id}.json"
        s.updated_at = datetime.now().isoformat()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(s.to_dict(), f, ensure_ascii=False, indent=2)
        # Update index
        if s.id in self._sessions_index:
            self._sessions_index[s.id]["updated_at"] = s.updated_at
            self._sessions_index[s.id]["message_count"] = len(s.messages)
            self._sessions_index[s.id]["name"] = s.name
        else:
            self._sessions_index[s.id] = {
                "name": s.name,
                "created_at": s.created_at,
                "updated_at": s.updated_at,
                "message_count": len(s.messages)
            }
        self._save_index()

    def rename_session(self, session_id: str, new_name: str):
        if session_id in self._sessions_index:
            self._sessions_index[session_id]["name"] = new_name
            self._save_index()
        path = SESSIONS_DIR / f"{session_id}.json"
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            data["name"] = new_name
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        if self.active_session and self.active_session.id == session_id:
            self.active_session.name = new_name

    def delete_session(self, session_id: str):
        path = SESSIONS_DIR / f"{session_id}.json"
        if path.exists():
            path.unlink()
        self._sessions_index.pop(session_id, None)
        self._save_index()
        if self.active_session and self.active_session.id == session_id:
            self.active_session = None

    def list_sessions(self) -> list:
        """Return sessions sorted by updated_at descending."""
        result = []
        for sid, meta in self._sessions_index.items():
            result.append({"id": sid, **meta})
        result.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        return result

    # ── Export ────────────────────────────────────────────────────────────────
    def export_txt(self, session_id: str, out_path: str) -> str:
        s = self.load_session(session_id)
        if not s:
            return "Session not found"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"PeacockAgent — {s.name}\n")
            f.write(f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
            f.write("=" * 60 + "\n\n")
            for m in s.messages:
                role = m["role"].upper()
                f.write(f"[{role}]\n{m['content']}\n\n")
        return f"✅ Exported to {out_path}"

    def export_pdf(self, session_id: str, out_path: str) -> str:
        s = self.load_session(session_id)
        if not s:
            return "Session not found"
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import cm
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib import colors

            doc = SimpleDocTemplate(out_path, pagesize=A4,
                                    leftMargin=2*cm, rightMargin=2*cm,
                                    topMargin=2*cm, bottomMargin=2*cm)
            styles = getSampleStyleSheet()
            story = []
            story.append(Paragraph(f"PeacockAgent — {s.name}", styles["Title"]))
            story.append(Spacer(1, 0.5*cm))

            for m in s.messages:
                role = m["role"].upper()
                story.append(Paragraph(f"<b>[{role}]</b>", styles["Normal"]))
                text = m["content"].replace("<", "&lt;").replace(">", "&gt;")
                story.append(Paragraph(text[:2000], styles["Normal"]))
                story.append(Spacer(1, 0.3*cm))

            doc.build(story)
            return f"✅ PDF exported to {out_path}"
        except Exception as e:
            return f"❌ PDF export failed: {e}"


# Singleton
session_manager = SessionManager()
