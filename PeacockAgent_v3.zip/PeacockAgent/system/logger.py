"""
PeacockAgent - Logging System
Logs tool calls, errors, steps to logs/agent.log
"""
import os
import logging
import json
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "agent.log"


def _get_logger(name: str = "PeacockAgent") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    # File handler
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger


_logger = _get_logger()


def log_tool_call(tool_name: str, args: dict, result: str, success: bool):
    status = "SUCCESS" if success else "FAILED"
    _logger.info(f"[TOOL:{status}] {tool_name} | args={json.dumps(args, ensure_ascii=False)[:200]} | result={result[:200]}")


def log_step(step: int, action: str, status: str, detail: str = ""):
    _logger.info(f"[STEP:{step}] {action} | status={status} | {detail}")


def log_error(source: str, error: str, error_type: str = "unknown"):
    _logger.error(f"[ERROR:{error_type}] {source} | {error}")


def log_plan(plan: list):
    _logger.info(f"[PLAN] Generated {len(plan)} steps: {json.dumps(plan, ensure_ascii=False)[:500]}")


def log_session(session_id: str, action: str):
    _logger.info(f"[SESSION] {action} | id={session_id}")


def log_api(tokens: int, requests: int, plan: str):
    _logger.info(f"[API] tokens={tokens} | requests={requests} | plan={plan}")


def get_recent_logs(n: int = 50) -> list:
    """Return last n log lines."""
    if not LOG_FILE.exists():
        return []
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return [l.strip() for l in lines[-n:]]
