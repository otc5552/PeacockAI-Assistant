import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from ui.app_window import PeacockAgentApp
from PyQt6.QtWidgets import QApplication


def _start_background_services(window):
    """Start scheduler + Telegram polling if configured."""
    # Scheduler
    try:
        from integrations.scheduler import schedule_manager
        from core.llm_provider import LLMProvider

        def on_scheduled_task(task):
            """Run scheduled task through the agent."""
            if window.worker and window.worker.isRunning():
                return
            window.history.append({"role": "user", "content": f"[Scheduled Task: {task.name}]\n{task.prompt}"})
            window.chat_display.add_message("thinking",
                f"⏰ Auto-running scheduled task: {task.name}")
            window._start_agent(task.prompt)

        schedule_manager.set_callback(on_scheduled_task)
        schedule_manager.start()
    except Exception:
        pass

    # Telegram auto-reply
    try:
        from config.config_manager import get
        from integrations.telegram_bot import telegram_bot

        if get("telegram.auto_reply", False) and get("telegram.bot_token", ""):
            def on_telegram_message(chat_id, text, username):
                """Reply to Telegram messages using AI."""
                import threading
                from core.llm_provider import LLMProvider
                from tools.executor import dispatch_tool
                from core.agent import TOOLS, SYSTEM_PROMPT
                import requests

                def reply_thread():
                    try:
                        headers = {
                            "Authorization": f"Bearer {window.llm.groq_api_key}",
                            "Content-Type": "application/json"
                        }
                        tools_schema = [{"type": "function", "function": {
                            "name": t["name"], "description": t["description"],
                            "parameters": t["parameters"]}} for t in TOOLS]

                        payload = {
                            "model": window.llm.groq_model,
                            "messages": [
                                {"role": "system", "content": SYSTEM_PROMPT +
                                 f"\n\nأنت الآن ترد على رسالة Telegram من المستخدم: {username}"},
                                {"role": "user", "content": text}
                            ],
                            "tools": tools_schema,
                            "tool_choice": "auto",
                            "max_tokens": 1024
                        }
                        resp = requests.post(
                            "https://api.groq.com/openai/v1/chat/completions",
                            headers=headers, json=payload, timeout=30
                        )
                        resp.raise_for_status()
                        choice = resp.json()["choices"][0]["message"]
                        reply = choice.get("content", "")

                        # Execute tool calls if any
                        for tc in choice.get("tool_calls", []):
                            fn = tc.get("function", {})
                            import json as _json
                            args = fn.get("arguments", {})
                            if isinstance(args, str):
                                try:
                                    args = _json.loads(args)
                                except Exception:
                                    args = {}
                            tool_result = dispatch_tool(fn.get("name", ""), args)
                            reply += f"\n\n🔧 {fn.get('name','')}: {tool_result[:300]}"

                        if reply:
                            telegram_bot.send_message(chat_id, reply)
                    except Exception as e:
                        telegram_bot.send_message(chat_id, f"❌ خطأ: {e}")

                threading.Thread(target=reply_thread, daemon=True).start()

            telegram_bot.set_message_handler(on_telegram_message)
            telegram_bot.start_polling()
    except Exception:
        pass


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("PeacockAgent")
    app.setApplicationVersion("2.0.0")
    window = PeacockAgentApp()
    window.show()
    _start_background_services(window)
    sys.exit(app.exec())
