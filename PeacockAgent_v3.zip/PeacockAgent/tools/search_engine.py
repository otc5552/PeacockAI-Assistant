"""
PeacockAgent - Advanced Web Search Engine
Multi-source search: DuckDuckGo + Wikipedia
With caching, deduplication, content extraction, ranking.
"""
import os
import re
import json
import hashlib
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from system.logger import log_error

BASE_DIR = Path(__file__).parent.parent
CACHE_DIR = BASE_DIR / "cache" / "search"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
CACHE_TTL_HOURS = 24


def _cache_key(query: str) -> str:
    return hashlib.md5(query.lower().strip().encode()).hexdigest()


def _load_cache(query: str) -> Optional[list]:
    key = _cache_key(query)
    path = CACHE_DIR / f"{key}.json"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    cached_at = datetime.fromisoformat(data.get("cached_at", "2000-01-01"))
    if datetime.now() - cached_at > timedelta(hours=CACHE_TTL_HOURS):
        path.unlink()
        return None
    return data.get("results", [])


def _save_cache(query: str, results: list):
    key = _cache_key(query)
    path = CACHE_DIR / f"{key}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"query": query, "cached_at": datetime.now().isoformat(), "results": results}, f, ensure_ascii=False)


def _clean_html(html: str) -> str:
    text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'&nbsp;', ' ', text)
    text = re.sub(r'&amp;', '&', text)
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'&quot;', '"', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def _search_duckduckgo(query: str, max_results: int = 5) -> list:
    """Search DuckDuckGo HTML interface."""
    results = []
    try:
        encoded = urllib.parse.quote(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        with urllib.request.urlopen(req, timeout=12) as resp:
            html = resp.read().decode("utf-8", errors="replace")

        titles = re.findall(r'class="result__a"[^>]*>(.*?)</a>', html, re.DOTALL)
        snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</(?:a|span)>', html, re.DOTALL)
        urls = re.findall(r'class="result__url"[^>]*>(.*?)</a>', html, re.DOTALL)

        for i in range(min(max_results, len(titles))):
            title = _clean_html(titles[i]) if i < len(titles) else ""
            snippet = _clean_html(snippets[i]) if i < len(snippets) else ""
            url = _clean_html(urls[i]).strip() if i < len(urls) else ""
            if title and snippet:
                results.append({
                    "title": title,
                    "snippet": snippet,
                    "source": url or "duckduckgo.com",
                    "provider": "DuckDuckGo",
                    "relevance": 1.0 - (i * 0.1)
                })
    except Exception as e:
        log_error("DuckDuckGo", str(e), "network")
    return results


def _search_wikipedia(query: str) -> list:
    """Search Wikipedia API for summary."""
    results = []
    try:
        encoded = urllib.parse.quote(query)
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{encoded}"
        req = urllib.request.Request(url, headers={"User-Agent": "PeacockAgent/2.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        if data.get("extract"):
            results.append({
                "title": data.get("title", query),
                "snippet": data["extract"][:400],
                "source": data.get("content_urls", {}).get("desktop", {}).get("page", "wikipedia.org"),
                "provider": "Wikipedia",
                "relevance": 0.95
            })
    except Exception:
        # Try search endpoint instead
        try:
            encoded = urllib.parse.quote(query)
            url = f"https://en.wikipedia.org/w/api.php?action=search&list=search&srsearch={encoded}&format=json&srlimit=2"
            req = urllib.request.Request(url, headers={"User-Agent": "PeacockAgent/2.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            for item in data.get("query", {}).get("search", [])[:2]:
                snippet = _clean_html(item.get("snippet", ""))
                results.append({
                    "title": item.get("title", ""),
                    "snippet": snippet,
                    "source": f"wikipedia.org/wiki/{urllib.parse.quote(item.get('title',''))}",
                    "provider": "Wikipedia",
                    "relevance": 0.85
                })
        except Exception as e:
            log_error("Wikipedia", str(e), "network")
    return results


def _deduplicate(results: list) -> list:
    """Remove duplicate results by title similarity."""
    seen_titles = set()
    unique = []
    for r in results:
        title_key = re.sub(r'\W+', '', r["title"].lower())[:30]
        if title_key not in seen_titles:
            seen_titles.add(title_key)
            unique.append(r)
    return unique


def _rank_results(results: list, query: str) -> list:
    """Rank by relevance score + keyword match."""
    query_words = set(query.lower().split())
    for r in results:
        text = (r["title"] + " " + r["snippet"]).lower()
        keyword_score = sum(1 for w in query_words if w in text) / max(len(query_words), 1)
        r["relevance"] = (r.get("relevance", 0.5) * 0.6) + (keyword_score * 0.4)
    return sorted(results, key=lambda x: x["relevance"], reverse=True)


def search(query: str, max_results: int = 5, use_cache: bool = True) -> str:
    """
    Main search function. Returns formatted string.
    Searches DuckDuckGo + Wikipedia, deduplicates, ranks, caches.
    """
    # Check cache
    if use_cache:
        cached = _load_cache(query)
        if cached:
            return _format_results(query, cached, from_cache=True)

    # Search all sources
    all_results = []
    all_results.extend(_search_duckduckgo(query, max_results))
    all_results.extend(_search_wikipedia(query))

    if not all_results:
        return f"❌ No results found for: {query}"

    # Process
    unique = _deduplicate(all_results)
    ranked = _rank_results(unique, query)[:max_results]

    # Cache
    if use_cache:
        _save_cache(query, ranked)

    return _format_results(query, ranked, from_cache=False)


def search_structured(query: str, max_results: int = 5) -> list:
    """Return structured list of results (for agent use)."""
    cached = _load_cache(query)
    if cached:
        return cached

    all_results = []
    all_results.extend(_search_duckduckgo(query, max_results))
    all_results.extend(_search_wikipedia(query))

    unique = _deduplicate(all_results)
    ranked = _rank_results(unique, query)[:max_results]
    _save_cache(query, ranked)
    return ranked


def _format_results(query: str, results: list, from_cache: bool = False) -> str:
    cache_note = " (cached)" if from_cache else ""
    output = f"🔍 Search results for: **{query}**{cache_note}\n\n"
    for i, r in enumerate(results, 1):
        output += f"**{i}. {r['title']}** [{r['provider']}]\n"
        output += f"{r['snippet']}\n"
        output += f"🔗 {r['source']}\n\n"
    return output.strip()
