"""
PeacockAgent - Facebook Integration
نشر على صفحتك + إحصائيات الصفحة عن طريق Facebook Graph API الرسمي

إزاي تجيب الـ tokens:
1. روح developers.facebook.com
2. أنشئ App -> Facebook Login -> Pages
3. جيب Page Access Token من Graph API Explorer
"""
import json
import urllib.request
import urllib.parse
from pathlib import Path
from system.logger import log_error

BASE_URL = "https://graph.facebook.com/v19.0"


class FacebookManager:
    def __init__(self):
        self.page_access_token = ""
        self.page_id = ""
        self._load_config()

    def _load_config(self):
        try:
            from config.config_manager import get
            self.page_access_token = get("facebook.page_access_token", "")
            self.page_id = get("facebook.page_id", "")
        except Exception:
            pass

    def save_config(self, page_access_token: str, page_id: str):
        self.page_access_token = page_access_token
        self.page_id = page_id
        try:
            from config.config_manager import set_value
            set_value("facebook.page_access_token", page_access_token)
            set_value("facebook.page_id", page_id)
        except Exception:
            pass

    def _is_configured(self) -> bool:
        return bool(self.page_access_token and self.page_id)

    def _api_get(self, endpoint: str, params: dict = None) -> dict:
        p = params or {}
        p["access_token"] = self.page_access_token
        query = urllib.parse.urlencode(p)
        url = f"{BASE_URL}/{endpoint}?{query}"
        req = urllib.request.Request(url, headers={"User-Agent": "PeacockAgent/2.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())

    def _api_post(self, endpoint: str, data: dict) -> dict:
        data["access_token"] = self.page_access_token
        encoded = urllib.parse.urlencode(data).encode("utf-8")
        url = f"{BASE_URL}/{endpoint}"
        req = urllib.request.Request(url, data=encoded, method="POST",
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())

    # ── النشر ────────────────────────────────────────────────────────────────
    def post_text(self, message: str) -> str:
        """نشر بوست نصي على صفحتك"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ. أضف Page Token و Page ID في الإعدادات."
        try:
            result = self._api_post(f"{self.page_id}/feed", {"message": message})
            post_id = result.get("id", "")
            return f"✅ تم النشر على Facebook!\nPost ID: {post_id}"
        except Exception as e:
            log_error("Facebook.post_text", str(e), "api")
            return f"❌ فشل النشر: {e}"

    def post_photo(self, image_path: str, caption: str = "") -> str:
        """نشر صورة على صفحتك"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ."
        try:
            import mimetypes
            with open(image_path, "rb") as f:
                img_data = f.read()
            import base64
            # Upload via multipart
            boundary = "PeacockBoundary123"
            body = (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="caption"\r\n\r\n'
                f"{caption}\r\n"
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="source"; filename="image.jpg"\r\n'
                f"Content-Type: image/jpeg\r\n\r\n"
            ).encode() + img_data + f"\r\n--{boundary}--\r\n".encode()

            url = f"{BASE_URL}/{self.page_id}/photos?access_token={self.page_access_token}"
            req = urllib.request.Request(url, data=body, method="POST",
                headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
            return f"✅ تم نشر الصورة! Post ID: {result.get('id','')}"
        except Exception as e:
            log_error("Facebook.post_photo", str(e), "api")
            return f"❌ فشل نشر الصورة: {e}"

    def schedule_post(self, message: str, publish_time_unix: int) -> str:
        """جدولة بوست في وقت معين (Unix timestamp)"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ."
        try:
            result = self._api_post(f"{self.page_id}/feed", {
                "message": message,
                "published": "false",
                "scheduled_publish_time": str(publish_time_unix)
            })
            return f"✅ تم جدولة البوست! ID: {result.get('id','')}"
        except Exception as e:
            log_error("Facebook.schedule_post", str(e), "api")
            return f"❌ فشل الجدولة: {e}"

    # ── إحصائيات الصفحة ──────────────────────────────────────────────────────
    def get_page_insights(self) -> str:
        """إحصائيات الصفحة: likes, reach, engagement"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ."
        try:
            metrics = "page_fans,page_impressions,page_engaged_users,page_post_engagements"
            result = self._api_get(f"{self.page_id}/insights", {
                "metric": metrics, "period": "day"
            })
            data = result.get("data", [])
            output = "📊 **إحصائيات صفحة Facebook:**\n\n"
            for item in data:
                name = item.get("name", "")
                values = item.get("values", [])
                latest = values[-1].get("value", 0) if values else 0
                labels = {
                    "page_fans": "👥 المعجبون",
                    "page_impressions": "👁 الوصول",
                    "page_engaged_users": "💬 المتفاعلون",
                    "page_post_engagements": "❤️ التفاعلات"
                }
                output += f"{labels.get(name, name)}: **{latest:,}**\n"
            return output
        except Exception as e:
            log_error("Facebook.get_page_insights", str(e), "api")
            return f"❌ فشل جلب الإحصائيات: {e}"

    def get_recent_posts(self, limit: int = 5) -> str:
        """عرض أحدث بوستات الصفحة"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ."
        try:
            result = self._api_get(f"{self.page_id}/posts", {
                "fields": "message,created_time,likes.summary(true),comments.summary(true)",
                "limit": str(limit)
            })
            posts = result.get("data", [])
            output = f"📝 **آخر {limit} بوستات:**\n\n"
            for i, p in enumerate(posts, 1):
                msg = (p.get("message", "")[:80] + "...") if len(p.get("message", "")) > 80 else p.get("message", "[بدون نص]")
                likes = p.get("likes", {}).get("summary", {}).get("total_count", 0)
                comments = p.get("comments", {}).get("summary", {}).get("total_count", 0)
                time_str = p.get("created_time", "")[:10]
                output += f"{i}. {msg}\n   ❤️ {likes} | 💬 {comments} | 📅 {time_str}\n\n"
            return output
        except Exception as e:
            log_error("Facebook.get_recent_posts", str(e), "api")
            return f"❌ فشل جلب البوستات: {e}"

    def get_page_info(self) -> str:
        """معلومات أساسية عن الصفحة"""
        if not self._is_configured():
            return "❌ Facebook غير مُعدّ."
        try:
            result = self._api_get(self.page_id, {
                "fields": "name,fan_count,followers_count,category,about"
            })
            return (
                f"📋 **معلومات الصفحة:**\n"
                f"الاسم: {result.get('name','')}\n"
                f"المعجبون: {result.get('fan_count',0):,}\n"
                f"المتابعون: {result.get('followers_count',0):,}\n"
                f"الفئة: {result.get('category','')}\n"
                f"الوصف: {result.get('about','')}"
            )
        except Exception as e:
            log_error("Facebook.get_page_info", str(e), "api")
            return f"❌ فشل جلب معلومات الصفحة: {e}"


facebook_manager = FacebookManager()
