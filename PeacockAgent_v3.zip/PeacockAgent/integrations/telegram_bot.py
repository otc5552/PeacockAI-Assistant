"""
PeacockAgent - Telegram Bot Integration
Bot شخصي + Bot لصفحة/خدمة
يستقبل رسائل ويرد عليها بالـ AI

إزاي تعمل Bot:
1. كلم @BotFather على Telegram
2. اكتب /newbot
3. خد الـ Token
"""
import json
import threading
import time
import urllib.request
import urllib.parse
from pathlib import Path
from typing import Optional, Callable
from system.logger import log_error

BASE_URL = "https://api.telegram.org/bot"


class TelegramBot:
    def __init__(self):
        self.token = ""
        self.allowed_chat_ids: list = []   # لو فاضي = يقبل من أي حد
        self._offset = 0
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._on_message: Optional[Callable] = None  # callback(chat_id, text, username)
        self._load_config()

    def _load_config(self):
        try:
            from config.config_manager import get
            self.token = get("telegram.bot_token", "")
            self.allowed_chat_ids = get("telegram.allowed_chat_ids", [])
        except Exception:
            pass

    def save_config(self, token: str, allowed_ids: list = None):
        self.token = token
        self.allowed_chat_ids = allowed_ids or []
        try:
            from config.config_manager import set_value
            set_value("telegram.bot_token", token)
            set_value("telegram.allowed_chat_ids", self.allowed_chat_ids)
        except Exception:
            pass

    def _is_configured(self) -> bool:
        return bool(self.token)

    def _request(self, method: str, data: dict = None) -> dict:
        url = f"{BASE_URL}{self.token}/{method}"
        if data:
            encoded = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(url, data=encoded,
                headers={"Content-Type": "application/json"})
        else:
            req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())

    # ── إرسال ─────────────────────────────────────────────────────────────────
    def send_message(self, chat_id, text: str, parse_mode: str = "HTML") -> str:
        if not self._is_configured():
            return "❌ Telegram Bot غير مُعدّ. أضف Bot Token في الإعدادات."
        try:
            # تقسيم الرسائل الطويلة
            chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
            for chunk in chunks:
                self._request("sendMessage", {
                    "chat_id": chat_id,
                    "text": chunk,
                    "parse_mode": parse_mode
                })
            return f"✅ تم إرسال الرسالة إلى {chat_id}"
        except Exception as e:
            log_error("Telegram.send_message", str(e), "api")
            return f"❌ فشل الإرسال: {e}"

    def send_photo(self, chat_id, image_path: str, caption: str = "") -> str:
        if not self._is_configured():
            return "❌ Telegram Bot غير مُعدّ."
        try:
            boundary = "TelegramBoundary456"
            with open(image_path, "rb") as f:
                img_data = f.read()
            body = (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="chat_id"\r\n\r\n'
                f"{chat_id}\r\n"
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="caption"\r\n\r\n'
                f"{caption}\r\n"
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="photo"; filename="image.jpg"\r\n'
                f"Content-Type: image/jpeg\r\n\r\n"
            ).encode() + img_data + f"\r\n--{boundary}--\r\n".encode()

            url = f"{BASE_URL}{self.token}/sendPhoto"
            req = urllib.request.Request(url, data=body, method="POST",
                headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                json.loads(resp.read().decode())
            return f"✅ تم إرسال الصورة إلى {chat_id}"
        except Exception as e:
            log_error("Telegram.send_photo", str(e), "api")
            return f"❌ فشل إرسال الصورة: {e}"

    def send_document(self, chat_id, file_path: str, caption: str = "") -> str:
        if not self._is_configured():
            return "❌ Telegram Bot غير مُعدّ."
        try:
            boundary = "TelegramDoc789"
            fname = Path(file_path).name
            with open(file_path, "rb") as f:
                file_data = f.read()
            body = (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="chat_id"\r\n\r\n'
                f"{chat_id}\r\n"
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="caption"\r\n\r\n'
                f"{caption}\r\n"
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="document"; filename="{fname}"\r\n'
                f"Content-Type: application/octet-stream\r\n\r\n"
            ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()

            url = f"{BASE_URL}{self.token}/sendDocument"
            req = urllib.request.Request(url, data=body, method="POST",
                headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                json.loads(resp.read().decode())
            return f"✅ تم إرسال الملف '{fname}' إلى {chat_id}"
        except Exception as e:
            log_error("Telegram.send_document", str(e), "api")
            return f"❌ فشل إرسال الملف: {e}"

    def broadcast(self, chat_ids: list, text: str) -> str:
        if not self._is_configured():
            return "❌ Telegram Bot غير مُعدّ."
        results = []
        for cid in chat_ids:
            r = self.send_message(cid, text)
            results.append(r)
            time.sleep(0.1)
        success = sum(1 for r in results if r.startswith("✅"))
        return f"✅ تم الإرسال إلى {success}/{len(chat_ids)} مستخدم"

    def get_bot_info(self) -> str:
        if not self._is_configured():
            return "❌ Telegram Bot غير مُعدّ."
        try:
            result = self._request("getMe")
            bot = result.get("result", {})
            return (
                f"🤖 **معلومات البوت:**\n"
                f"الاسم: {bot.get('first_name','')}\n"
                f"Username: @{bot.get('username','')}\n"
                f"ID: {bot.get('id','')}"
            )
        except Exception as e:
            return f"❌ {e}"

    # ── استقبال الرسائل (Polling) ─────────────────────────────────────────────
    def set_message_handler(self, fn: Callable):
        """fn(chat_id, text, username) يتكلم عند وصول رسالة"""
        self._on_message = fn

    def start_polling(self):
        if not self._is_configured() or self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()

    def stop_polling(self):
        self._running = False

    def _poll_loop(self):
        while self._running:
            try:
                result = self._request("getUpdates", {
                    "offset": self._offset,
                    "timeout": 20,
                    "allowed_updates": ["message"]
                })
                updates = result.get("result", [])
                for update in updates:
                    self._offset = update["update_id"] + 1
                    msg = update.get("message", {})
                    chat_id = msg.get("chat", {}).get("id")
                    text = msg.get("text", "")
                    username = msg.get("from", {}).get("username", "")
                    first_name = msg.get("from", {}).get("first_name", "")

                    if not chat_id or not text:
                        continue

                    # تحقق من الصلاحية
                    if self.allowed_chat_ids and chat_id not in self.allowed_chat_ids:
                        self.send_message(chat_id, "⛔ غير مصرح لك باستخدام هذا البوت.")
                        continue

                    if self._on_message:
                        try:
                            self._on_message(chat_id, text, username or first_name)
                        except Exception as e:
                            log_error("Telegram.handler", str(e))
            except Exception as e:
                log_error("Telegram.polling", str(e), "network")
                time.sleep(5)


telegram_bot = TelegramBot()
