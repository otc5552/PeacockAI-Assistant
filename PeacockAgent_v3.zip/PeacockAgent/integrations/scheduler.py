"""
PeacockAgent - Scheduled Automation
مهام بتشتغل في أوقات ثابتة (يومي / أسبوعي / كل X دقيقة)
"""
import json
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional

BASE_DIR = Path(__file__).parent.parent
SCHEDULE_FILE = BASE_DIR / "config" / "schedules.json"


class ScheduledTask:
    def __init__(self, task_id: str, name: str, prompt: str,
                 schedule_type: str, schedule_value: str,
                 enabled: bool = True):
        self.id = task_id
        self.name = name
        self.prompt = prompt          # الأمر اللي هيتبعت للـ agent
        self.schedule_type = schedule_type  # "interval" | "daily" | "weekly"
        self.schedule_value = schedule_value  # "30" (دقايق) | "08:00" | "mon:09:00"
        self.enabled = enabled
        self.last_run: Optional[str] = None
        self.next_run: Optional[str] = None
        self.run_count: int = 0
        self._calc_next_run()

    def _calc_next_run(self):
        now = datetime.now()
        if self.schedule_type == "interval":
            minutes = int(self.schedule_value)
            self.next_run = (now + timedelta(minutes=minutes)).isoformat()
        elif self.schedule_type == "daily":
            h, m = map(int, self.schedule_value.split(":"))
            target = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if target <= now:
                target += timedelta(days=1)
            self.next_run = target.isoformat()
        elif self.schedule_type == "weekly":
            day_str, time_str = self.schedule_value.split(":")
            days = {"mon": 0, "tue": 1, "wed": 2, "thu": 3,
                    "fri": 4, "sat": 5, "sun": 6}
            target_day = days.get(day_str.lower(), 0)
            h, m = map(int, time_str.split(":"))
            days_ahead = (target_day - now.weekday()) % 7
            target = now.replace(hour=h, minute=m, second=0) + timedelta(days=days_ahead)
            if target <= now:
                target += timedelta(weeks=1)
            self.next_run = target.isoformat()

    def is_due(self) -> bool:
        if not self.enabled or not self.next_run:
            return False
        return datetime.now() >= datetime.fromisoformat(self.next_run)

    def mark_ran(self):
        self.last_run = datetime.now().isoformat()
        self.run_count += 1
        self._calc_next_run()

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "prompt": self.prompt,
            "schedule_type": self.schedule_type,
            "schedule_value": self.schedule_value,
            "enabled": self.enabled, "last_run": self.last_run,
            "next_run": self.next_run, "run_count": self.run_count
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ScheduledTask":
        t = cls(d["id"], d["name"], d["prompt"],
                d["schedule_type"], d["schedule_value"], d.get("enabled", True))
        t.last_run = d.get("last_run")
        t.next_run = d.get("next_run")
        t.run_count = d.get("run_count", 0)
        return t


class ScheduleManager:
    def __init__(self):
        self.tasks: dict[str, ScheduledTask] = {}
        self._callback: Optional[Callable] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._load()

    def set_callback(self, fn: Callable):
        """fn(task) يتكلم لما تيجي المهمة"""
        self._callback = fn

    def add_task(self, name: str, prompt: str,
                 schedule_type: str, schedule_value: str) -> ScheduledTask:
        import uuid
        task_id = str(uuid.uuid4())[:8]
        task = ScheduledTask(task_id, name, prompt, schedule_type, schedule_value)
        self.tasks[task_id] = task
        self._save()
        return task

    def remove_task(self, task_id: str):
        self.tasks.pop(task_id, None)
        self._save()

    def toggle_task(self, task_id: str):
        if task_id in self.tasks:
            self.tasks[task_id].enabled = not self.tasks[task_id].enabled
            self._save()

    def list_tasks(self) -> list:
        return [t.to_dict() for t in self.tasks.values()]

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            for task in list(self.tasks.values()):
                if task.is_due() and self._callback:
                    try:
                        self._callback(task)
                        task.mark_ran()
                        self._save()
                    except Exception:
                        pass
            time.sleep(30)  # فحص كل 30 ثانية

    def _save(self):
        SCHEDULE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(SCHEDULE_FILE, "w", encoding="utf-8") as f:
            json.dump({k: v.to_dict() for k, v in self.tasks.items()},
                      f, ensure_ascii=False, indent=2)

    def _load(self):
        if SCHEDULE_FILE.exists():
            with open(SCHEDULE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for k, v in data.items():
                self.tasks[k] = ScheduledTask.from_dict(v)


schedule_manager = ScheduleManager()
