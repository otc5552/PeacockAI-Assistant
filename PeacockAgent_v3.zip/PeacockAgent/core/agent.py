import json
import base64
import os
import re
from typing import Optional

TOOLS = [
    {
        "name": "open_app",
        "description": "Open any installed application on Windows (e.g., VS Code, Android Studio, Notepad, Photoshop, Chrome, etc.)",
        "parameters": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "Name or path of the application to open"}
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "take_screenshot",
        "description": "Take a screenshot of the current screen and analyze it",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "mouse_click",
        "description": "Click at specific screen coordinates",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer"},
                "y": {"type": "integer"},
                "button": {"type": "string", "enum": ["left", "right", "double"], "default": "left"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "keyboard_type",
        "description": "Type text using the keyboard",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "press_enter": {"type": "boolean", "default": False}
            },
            "required": ["text"]
        }
    },
    {
        "name": "keyboard_shortcut",
        "description": "Press a keyboard shortcut (e.g., ctrl+c, ctrl+v, alt+f4)",
        "parameters": {
            "type": "object",
            "properties": {
                "keys": {"type": "string", "description": "Keys separated by + (e.g., ctrl+s)"}
            },
            "required": ["keys"]
        }
    },
    {
        "name": "read_file",
        "description": "Read the contents of a file",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Full file path"}
            },
            "required": ["path"]
        }
    },
    {
        "name": "write_file",
        "description": "Write or create a file with given content",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"}
            },
            "required": ["path", "content"]
        }
    },
    {
        "name": "list_directory",
        "description": "List files and folders in a directory",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path, default is Desktop"}
            }
        }
    },
    {
        "name": "delete_file",
        "description": "Delete a file or folder",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"}
            },
            "required": ["path"]
        }
    },
    {
        "name": "search_web",
        "description": "Search the web using DuckDuckGo",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "create_word_document",
        "description": "Create a Microsoft Word (.docx) document with content",
        "parameters": {
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "title": {"type": "string"},
                "content": {"type": "string", "description": "Main document content"},
                "save_path": {"type": "string", "description": "Where to save (default: Desktop)"}
            },
            "required": ["filename", "content"]
        }
    },
    {
        "name": "create_powerpoint",
        "description": "Create a PowerPoint (.pptx) presentation",
        "parameters": {
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "title": {"type": "string"},
                "slides": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "content": {"type": "string"}
                        }
                    }
                },
                "save_path": {"type": "string"}
            },
            "required": ["filename", "slides"]
        }
    },
    {
        "name": "create_pdf",
        "description": "Create a PDF document",
        "parameters": {
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "title": {"type": "string"},
                "content": {"type": "string"},
                "save_path": {"type": "string"}
            },
            "required": ["filename", "content"]
        }
    },
    {
        "name": "generate_image",
        "description": "Generate an image using AI (Pollinations AI - free)",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Detailed image description"},
                "width": {"type": "integer", "default": 1024},
                "height": {"type": "integer", "default": 1024},
                "save_path": {"type": "string", "description": "Where to save the image"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "edit_image",
        "description": "Edit an existing image (resize, crop, rotate, brightness, contrast, filters)",
        "parameters": {
            "type": "object",
            "properties": {
                "input_path": {"type": "string"},
                "output_path": {"type": "string"},
                "operations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string", "enum": ["resize", "crop", "rotate", "brightness", "contrast", "grayscale", "blur", "sharpen", "flip"]},
                            "params": {"type": "object"}
                        }
                    }
                }
            },
            "required": ["input_path", "operations"]
        }
    },
    {
        "name": "run_command",
        "description": "Run a terminal command (cmd/powershell)",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "shell": {"type": "string", "enum": ["cmd", "powershell"], "default": "cmd"}
            },
            "required": ["command"]
        }
    },
    {
        "name": "scroll",
        "description": "Scroll the mouse wheel",
        "parameters": {
            "type": "object",
            "properties": {
                "amount": {"type": "integer", "description": "Positive = up, negative = down"},
                "x": {"type": "integer", "description": "X position (optional)"},
                "y": {"type": "integer", "description": "Y position (optional)"}
            },
            "required": ["amount"]
        }
    },
    # ── Facebook ──────────────────────────────────────────────────────────────
    {
        "name": "facebook_post_text",
        "description": "نشر بوست نصي على صفحة Facebook بتاعتك",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "نص البوست"}
            },
            "required": ["message"]
        }
    },
    {
        "name": "facebook_post_photo",
        "description": "نشر صورة على صفحة Facebook بتاعتك",
        "parameters": {
            "type": "object",
            "properties": {
                "image_path": {"type": "string", "description": "مسار الصورة"},
                "caption": {"type": "string", "description": "وصف الصورة"}
            },
            "required": ["image_path"]
        }
    },
    {
        "name": "facebook_schedule_post",
        "description": "جدولة بوست على Facebook في وقت معين",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string"},
                "publish_time": {"type": "integer", "description": "Unix timestamp للوقت المطلوب"}
            },
            "required": ["message", "publish_time"]
        }
    },
    {
        "name": "facebook_page_insights",
        "description": "عرض إحصائيات صفحة Facebook (likes, reach, engagement)",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "facebook_recent_posts",
        "description": "عرض أحدث بوستات صفحة Facebook",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "default": 5}
            }
        }
    },
    {
        "name": "facebook_page_info",
        "description": "معلومات أساسية عن صفحة Facebook",
        "parameters": {"type": "object", "properties": {}}
    },
    # ── Telegram ──────────────────────────────────────────────────────────────
    {
        "name": "telegram_send_message",
        "description": "إرسال رسالة نصية عبر Telegram Bot",
        "parameters": {
            "type": "object",
            "properties": {
                "chat_id": {"type": "string", "description": "Chat ID أو username"},
                "text": {"type": "string", "description": "نص الرسالة"}
            },
            "required": ["chat_id", "text"]
        }
    },
    {
        "name": "telegram_send_photo",
        "description": "إرسال صورة عبر Telegram Bot",
        "parameters": {
            "type": "object",
            "properties": {
                "chat_id": {"type": "string"},
                "image_path": {"type": "string"},
                "caption": {"type": "string"}
            },
            "required": ["chat_id", "image_path"]
        }
    },
    {
        "name": "telegram_send_document",
        "description": "إرسال ملف (PDF, Word, إلخ) عبر Telegram Bot",
        "parameters": {
            "type": "object",
            "properties": {
                "chat_id": {"type": "string"},
                "file_path": {"type": "string"},
                "caption": {"type": "string"}
            },
            "required": ["chat_id", "file_path"]
        }
    },
    {
        "name": "telegram_broadcast",
        "description": "إرسال رسالة لعدة مستخدمين على Telegram",
        "parameters": {
            "type": "object",
            "properties": {
                "chat_ids": {"type": "array", "items": {"type": "string"}},
                "text": {"type": "string"}
            },
            "required": ["chat_ids", "text"]
        }
    },
    {
        "name": "telegram_bot_info",
        "description": "معلومات Telegram Bot",
        "parameters": {"type": "object", "properties": {}}
    },
    # ── Scheduler ─────────────────────────────────────────────────────────────
    {
        "name": "schedule_add_task",
        "description": "إضافة مهمة automation تتشغل تلقائياً في وقت ثابت",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "اسم المهمة"},
                "prompt": {"type": "string", "description": "الأمر اللي هيتنفذ"},
                "schedule_type": {"type": "string", "enum": ["interval", "daily", "weekly"],
                                  "description": "interval=كل X دقيقة, daily=يومي, weekly=أسبوعي"},
                "schedule_value": {"type": "string",
                                   "description": "interval: '30' (دقيقة) | daily: '08:00' | weekly: 'mon:09:00'"}
            },
            "required": ["name", "prompt", "schedule_type", "schedule_value"]
        }
    },
    {
        "name": "schedule_list_tasks",
        "description": "عرض كل المهام المجدولة",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "schedule_remove_task",
        "description": "حذف مهمة مجدولة",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"}
            },
            "required": ["task_id"]
        }
    }
]

SYSTEM_PROMPT = """You are PeacockAgent — a powerful AI assistant that controls a Windows computer.

You have access to tools for:
- Computer control: open apps, screenshot, mouse, keyboard
- Files: read, write, create, delete
- Web search (DuckDuckGo + Wikipedia)
- Office: Word, PowerPoint, PDF
- Images: generate (Pollinations AI) + edit
- Terminal commands
- Facebook Page: post text/photos, schedule posts, page insights, recent posts
- Telegram Bot: send messages/photos/files, broadcast to multiple users
- Scheduled Automation: add recurring tasks (interval/daily/weekly)

RULES:
1. Screenshot first when you need to see the screen
2. For Facebook/Telegram — only use on the user's own accounts/pages
3. Respond in the same language the user uses (Arabic or English)
4. Explain what you're doing before doing it
5. Confirm before deleting anything

You are PeacockAI's flagship agent. Be helpful, precise, and proactive."""


def build_messages(history: list, user_message: str, image_data: Optional[str] = None) -> list:
    messages = []
    for msg in history:
        messages.append(msg)

    if image_data:
        content = [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_data}"}},
            {"type": "text", "text": user_message}
        ]
    else:
        content = user_message

    messages.append({"role": "user", "content": content})
    return messages
