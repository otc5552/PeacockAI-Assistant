"""
PeacockAgent - Agent Planning System
Decomposes user requests into structured steps.
Supports reflection and replanning on failure.
"""
import json
import re
from typing import Optional
from core.task_manager import TaskPlan, TaskStep, TaskManager, StepStatus
from system.logger import log_plan, log_step, log_error

AVAILABLE_TOOLS = [
    "open_app", "take_screenshot", "mouse_click", "keyboard_type",
    "keyboard_shortcut", "scroll", "read_file", "write_file",
    "list_directory", "delete_file", "search_web", "create_word_document",
    "create_powerpoint", "create_pdf", "generate_image", "edit_image",
    "run_command"
]

PLAN_SYSTEM_PROMPT = """You are a planning AI. Given a user request, break it into small executable steps.

Return ONLY a JSON array. No explanation. No markdown. Just raw JSON.

Format:
[
  {"step": 1, "action": "description of what to do", "tool": "tool_name", "expected_output": "what success looks like"},
  {"step": 2, ...}
]

Available tools: open_app, take_screenshot, mouse_click, keyboard_type, keyboard_shortcut, scroll, 
read_file, write_file, list_directory, delete_file, search_web, create_word_document, 
create_powerpoint, create_pdf, generate_image, edit_image, run_command

Rules:
- Maximum 15 steps
- Each step must use exactly one tool
- Be specific and actionable
- If unclear, start with take_screenshot to see the screen state
- For simple single-tool tasks, return just 1 step"""

REFLECT_SYSTEM_PROMPT = """You are a reflection AI. A step in an agent plan has failed.
Decide whether to retry, use a fallback, or skip.

Return ONLY a JSON object:
{
  "decision": "retry" | "fallback" | "skip" | "abort",
  "reason": "brief explanation",
  "fallback_tool": "tool_name if decision is fallback",
  "fallback_action": "what to do instead if fallback"
}"""


class Planner:
    def __init__(self, llm_provider):
        self.llm = llm_provider
        self.max_steps = 15

    def create_plan(self, user_request: str) -> Optional[TaskPlan]:
        """Use LLM to decompose request into steps."""
        try:
            messages = [{"role": "user", "content": f"Create a step-by-step plan for: {user_request}"}]
            # Temporarily override system prompt
            orig = self.llm.groq_model if hasattr(self.llm, 'groq_model') else None

            response = self._call_planner(messages)
            if not response:
                return self._simple_plan(user_request)

            steps_data = self._parse_json(response)
            if not steps_data or not isinstance(steps_data, list):
                return self._simple_plan(user_request)

            steps = []
            for i, s in enumerate(steps_data[:self.max_steps], 1):
                tool = s.get("tool", "run_command")
                if tool not in AVAILABLE_TOOLS:
                    tool = "run_command"
                steps.append(TaskStep(
                    step=i,
                    action=s.get("action", f"Step {i}"),
                    tool=tool,
                    expected_output=s.get("expected_output", ""),
                    args=s.get("args", {})
                ))

            plan = TaskPlan(goal=user_request, steps=steps)
            log_plan([s.to_dict() for s in steps])
            return plan

        except Exception as e:
            log_error("Planner", str(e), "planning")
            return self._simple_plan(user_request)

    def reflect(self, step: TaskStep, error: str) -> dict:
        """Reflect on a failed step and decide what to do next."""
        try:
            prompt = f"""Step failed:
Action: {step.action}
Tool: {step.tool}
Error: {error}

What should we do?"""
            messages = [{"role": "user", "content": prompt}]
            response = self._call_reflect(messages)
            if not response:
                return {"decision": "retry", "reason": "Default retry"}

            result = self._parse_json(response)
            if isinstance(result, dict):
                return result
        except Exception as e:
            log_error("Planner.reflect", str(e), "reflection")

        return {"decision": "retry", "reason": "Fallback decision"}

    def _call_planner(self, messages: list) -> str:
        """Call LLM with planning system prompt."""
        if self.llm.provider == "groq":
            return self._groq_call(PLAN_SYSTEM_PROMPT, messages)
        else:
            return self._ollama_call(PLAN_SYSTEM_PROMPT, messages)

    def _call_reflect(self, messages: list) -> str:
        """Call LLM with reflection system prompt."""
        if self.llm.provider == "groq":
            return self._groq_call(REFLECT_SYSTEM_PROMPT, messages)
        else:
            return self._ollama_call(REFLECT_SYSTEM_PROMPT, messages)

    def _groq_call(self, system: str, messages: list) -> str:
        import requests
        if not self.llm.groq_api_key:
            return ""
        headers = {"Authorization": f"Bearer {self.llm.groq_api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.llm.groq_model,
            "messages": [{"role": "system", "content": system}] + messages,
            "max_tokens": 1024,
            "temperature": 0.3
        }
        try:
            resp = requests.post("https://api.groq.com/openai/v1/chat/completions",
                                 headers=headers, json=payload, timeout=30)
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]
        except Exception as e:
            log_error("Planner._groq_call", str(e), "api")
            return ""

    def _ollama_call(self, system: str, messages: list) -> str:
        import requests
        payload = {
            "model": self.llm.ollama_model,
            "messages": [{"role": "system", "content": system}] + messages,
            "stream": False
        }
        try:
            resp = requests.post(f"{self.llm.ollama_url}/api/chat", json=payload, timeout=60)
            resp.raise_for_status()
            return resp.json().get("message", {}).get("content", "")
        except Exception as e:
            log_error("Planner._ollama_call", str(e), "api")
            return ""

    def _parse_json(self, text: str):
        """Extract and parse JSON from LLM response."""
        text = text.strip()
        # Remove markdown fences
        text = re.sub(r'```json\s*', '', text)
        text = re.sub(r'```\s*', '', text)
        # Find JSON array or object
        match = re.search(r'(\[.*\]|\{.*\})', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except Exception:
                pass
        try:
            return json.loads(text)
        except Exception:
            return None

    def _simple_plan(self, user_request: str) -> TaskPlan:
        """Fallback: single-step plan when LLM planning fails."""
        step = TaskStep(
            step=1,
            action=user_request,
            tool="run_command",
            expected_output="Task completed"
        )
        return TaskPlan(goal=user_request, steps=[step])
