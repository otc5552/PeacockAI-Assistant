"""
PeacockAgent - Task Manager
Manages structured task plans with state tracking.
"""
import json
from datetime import datetime
from typing import Optional
from enum import Enum


class StepStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUCCESS   = "success"
    FAILED    = "failed"
    SKIPPED   = "skipped"


class TaskStep:
    def __init__(self, step: int, action: str, tool: str, expected_output: str = "", args: dict = None):
        self.step = step
        self.action = action
        self.tool = tool
        self.expected_output = expected_output
        self.args = args or {}
        self.status = StepStatus.PENDING
        self.result = ""
        self.error = ""
        self.retries = 0
        self.started_at = ""
        self.finished_at = ""

    def to_dict(self) -> dict:
        return {
            "step": self.step,
            "action": self.action,
            "tool": self.tool,
            "expected_output": self.expected_output,
            "args": self.args,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "retries": self.retries,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TaskStep":
        s = cls(d["step"], d["action"], d["tool"], d.get("expected_output", ""), d.get("args", {}))
        s.status = d.get("status", StepStatus.PENDING)
        s.result = d.get("result", "")
        s.error = d.get("error", "")
        s.retries = d.get("retries", 0)
        return s


class TaskPlan:
    def __init__(self, goal: str, steps: list[TaskStep]):
        self.goal = goal
        self.steps = steps
        self.current_step = 0
        self.created_at = datetime.now().isoformat()
        self.status = "running"

    def get_current(self) -> Optional[TaskStep]:
        if self.current_step < len(self.steps):
            return self.steps[self.current_step]
        return None

    def advance(self):
        self.current_step += 1
        if self.current_step >= len(self.steps):
            self.status = "completed"

    def mark_failed(self):
        self.status = "failed"

    def to_dict(self) -> dict:
        return {
            "goal": self.goal,
            "status": self.status,
            "current_step": self.current_step,
            "created_at": self.created_at,
            "steps": [s.to_dict() for s in self.steps]
        }

    def progress_summary(self) -> str:
        done = sum(1 for s in self.steps if s.status == StepStatus.SUCCESS)
        total = len(self.steps)
        return f"Progress: {done}/{total} steps completed"


class TaskManager:
    def __init__(self):
        self.current_plan: Optional[TaskPlan] = None
        self.history: list[TaskPlan] = []

    def set_plan(self, plan: TaskPlan):
        if self.current_plan:
            self.history.append(self.current_plan)
        self.current_plan = plan

    def get_plan_summary(self) -> str:
        if not self.current_plan:
            return "No active plan"
        p = self.current_plan
        lines = [f"🎯 Goal: {p.goal}", f"📊 {p.progress_summary()}"]
        for s in p.steps:
            icon = {"pending": "⬜", "running": "🔄", "success": "✅", "failed": "❌", "skipped": "⏭"}.get(s.status, "⬜")
            lines.append(f"  {icon} Step {s.step}: {s.action}")
        return "\n".join(lines)

    def clear(self):
        self.current_plan = None


# Singleton
task_manager = TaskManager()
