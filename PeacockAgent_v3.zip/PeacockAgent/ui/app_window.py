import os
import sys
import json
import base64
import threading
from pathlib import Path
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QLineEdit, QLabel,
    QFileDialog, QScrollArea, QFrame, QSplitter,
    QTabWidget, QComboBox, QSpinBox, QCheckBox,
    QProgressBar, QStatusBar, QToolBar, QSizePolicy,
    QApplication, QMessageBox, QDialog, QFormLayout,
    QDialogButtonBox
)
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QSize, QPropertyAnimation,
    QEasingCurve
)
from PyQt6.QtGui import (
    QFont, QIcon, QColor, QPalette, QPixmap,
    QTextCursor, QKeyEvent, QAction, QPainter
)

from core.agent import build_messages, TOOLS
from core.llm_provider import LLMProvider
from core.planner import Planner
from core.task_manager import task_manager, StepStatus
from tools.executor import dispatch_tool
from system.session_manager import session_manager, Session
from system.api_manager import api_manager
from system.logger import log_session, log_step


# ══════════════════════════════════════════════════════════════════════════════
#  STYLE SHEET
# ══════════════════════════════════════════════════════════════════════════════
DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #0d0d0f;
    color: #e8e8f0;
    font-family: 'Segoe UI', sans-serif;
}

QTextEdit, QLineEdit {
    background-color: #16161a;
    color: #e8e8f0;
    border: 1px solid #2a2a35;
    border-radius: 8px;
    padding: 8px;
    font-size: 13px;
}

QTextEdit:focus, QLineEdit:focus {
    border: 1px solid #6c63ff;
}

QPushButton {
    background-color: #1e1e28;
    color: #e8e8f0;
    border: 1px solid #2a2a35;
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 500;
}

QPushButton:hover {
    background-color: #2a2a38;
    border-color: #6c63ff;
}

QPushButton:pressed {
    background-color: #6c63ff;
}

QPushButton#send_btn {
    background-color: #6c63ff;
    color: white;
    font-weight: 600;
    min-width: 80px;
}

QPushButton#send_btn:hover {
    background-color: #7c73ff;
}

QPushButton#send_btn:disabled {
    background-color: #3a3a4a;
    color: #666;
}

QPushButton#stop_btn {
    background-color: #ff4757;
    color: white;
    font-weight: 600;
}

QPushButton#stop_btn:hover {
    background-color: #ff6b7a;
}

QScrollBar:vertical {
    background: #16161a;
    width: 6px;
    border-radius: 3px;
}

QScrollBar::handle:vertical {
    background: #3a3a4a;
    border-radius: 3px;
    min-height: 20px;
}

QScrollBar::handle:vertical:hover {
    background: #6c63ff;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}

QTabWidget::pane {
    border: 1px solid #2a2a35;
    border-radius: 8px;
    background: #16161a;
}

QTabBar::tab {
    background: #1e1e28;
    color: #888;
    padding: 8px 16px;
    border-radius: 6px;
    margin: 2px;
}

QTabBar::tab:selected {
    background: #6c63ff;
    color: white;
}

QComboBox {
    background-color: #1e1e28;
    color: #e8e8f0;
    border: 1px solid #2a2a35;
    border-radius: 6px;
    padding: 6px 12px;
}

QComboBox::drop-down {
    border: none;
}

QComboBox QAbstractItemView {
    background-color: #1e1e28;
    color: #e8e8f0;
    selection-background-color: #6c63ff;
}

QLabel#title_label {
    font-size: 20px;
    font-weight: 700;
    color: #6c63ff;
    letter-spacing: 2px;
}

QLabel#subtitle_label {
    font-size: 11px;
    color: #555;
    letter-spacing: 1px;
}

QFrame#chat_frame {
    background-color: #16161a;
    border-radius: 12px;
    border: 1px solid #2a2a35;
}

QFrame#input_frame {
    background-color: #16161a;
    border-radius: 12px;
    border: 1px solid #2a2a35;
    padding: 4px;
}

QStatusBar {
    background-color: #0d0d0f;
    color: #555;
    font-size: 11px;
}

QProgressBar {
    background-color: #1e1e28;
    border: none;
    border-radius: 3px;
    height: 4px;
}

QProgressBar::chunk {
    background-color: #6c63ff;
    border-radius: 3px;
}

QToolBar {
    background-color: #0d0d0f;
    border-bottom: 1px solid #2a2a35;
    spacing: 4px;
    padding: 4px;
}
"""

# ══════════════════════════════════════════════════════════════════════════════
#  WORKER THREAD — with Planning + Reflection
# ══════════════════════════════════════════════════════════════════════════════
class AgentWorker(QThread):
    message_ready = pyqtSignal(str, str)   # role, content
    tool_called   = pyqtSignal(str, str)   # tool_name, result
    thinking      = pyqtSignal(str)
    plan_ready    = pyqtSignal(list)       # plan steps as list of dicts
    step_update   = pyqtSignal(int, str)   # step index, status
    done          = pyqtSignal()
    error         = pyqtSignal(str)

    def __init__(self, llm: LLMProvider, messages: list,
                 use_planning: bool = False, user_request: str = "", parent=None):
        super().__init__(parent)
        self.llm = llm
        self.messages = list(messages)
        self.use_planning = use_planning
        self.user_request = user_request
        self._stop = False
        self.planner = Planner(llm)

    def stop(self):
        self._stop = True

    def run(self):
        try:
            if self.use_planning and self.user_request:
                self._run_with_planning()
            else:
                self._run_standard()
        except Exception as e:
            self.error.emit(str(e))

    # ── Standard mode (direct LLM tool calling) ───────────────────────────────
    def _run_standard(self):
        current_messages = list(self.messages)
        max_iterations = 20

        for iteration in range(max_iterations):
            if self._stop:
                break

            self.thinking.emit(f"🤔 Thinking... (step {iteration + 1})")
            response = self.llm.chat(current_messages)

            if "error" in response:
                self.error.emit(response["error"])
                return

            content = response.get("content", "")
            tool_calls = response.get("tool_calls", [])

            if content:
                self.message_ready.emit("assistant", content)
                # Record to active session
                try:
                    if session_manager.active_session:
                        session_manager.active_session.add_message("assistant", content)
                        session_manager.save_session()
                except Exception:
                    pass

            if not tool_calls:
                break

            tool_results = []
            for tc in tool_calls:
                if self._stop:
                    break
                fn = tc.get("function", tc)
                tool_name = fn.get("name", "")
                args_raw = fn.get("arguments", fn.get("parameters", {}))
                if isinstance(args_raw, str):
                    try:
                        args = json.loads(args_raw)
                    except Exception:
                        args = {}
                else:
                    args = args_raw

                self.thinking.emit(f"🔧 Using tool: {tool_name}")
                result = dispatch_tool(tool_name, args)
                self.tool_called.emit(tool_name, result)

                # Track API usage
                try:
                    api_manager.record(
                        session_id=session_manager.active_session.id if session_manager.active_session else "",
                        tool=tool_name, tokens=0
                    )
                except Exception:
                    pass

                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", tool_name),
                    "content": result
                })

            current_messages.append({
                "role": "assistant",
                "content": content or "",
                "tool_calls": tool_calls
            })
            current_messages.extend(tool_results)

        self.done.emit()

    # ── Planning mode (structured step-by-step) ───────────────────────────────
    def _run_with_planning(self):
        # Step 1: Create plan
        self.thinking.emit("📋 Creating execution plan...")
        plan = self.planner.create_plan(self.user_request)

        if not plan or not plan.steps:
            self.thinking.emit("⚠️ Planning failed, switching to standard mode")
            self._run_standard()
            return

        task_manager.set_plan(plan)
        self.plan_ready.emit([s.to_dict() for s in plan.steps])
        self.message_ready.emit("assistant",
            f"📋 **Plan created — {len(plan.steps)} steps:**\n" +
            "\n".join(f"{s.step}. {s.action}" for s in plan.steps))

        # Step 2: Execute each step
        for step in plan.steps:
            if self._stop:
                break

            step.status = StepStatus.RUNNING
            self.step_update.emit(step.step - 1, "running")
            self.thinking.emit(f"⚡ Step {step.step}/{len(plan.steps)}: {step.action}")
            log_step(step.step, step.action, "running")

            # Build message for this step
            step_messages = list(self.messages) + [{
                "role": "user",
                "content": f"Execute this step: {step.action}\nUse tool: {step.tool}\nExpected outcome: {step.expected_output}"
            }]

            success = False
            result_text = ""

            for attempt in range(1, 4):  # max 3 retries
                if self._stop:
                    break

                response = self.llm.chat(step_messages)

                if "error" in response:
                    result_text = response["error"]
                    break

                content = response.get("content", "")
                tool_calls = response.get("tool_calls", [])

                if content:
                    self.message_ready.emit("assistant", content)

                # Execute tool calls for this step
                step_ok = True
                for tc in tool_calls:
                    fn = tc.get("function", tc)
                    tool_name = fn.get("name", "")
                    args_raw = fn.get("arguments", fn.get("parameters", {}))
                    if isinstance(args_raw, str):
                        try:
                            args = json.loads(args_raw)
                        except Exception:
                            args = {}
                    else:
                        args = args_raw

                    self.thinking.emit(f"🔧 [{step.step}] {tool_name}")
                    result = dispatch_tool(tool_name, args)
                    self.tool_called.emit(tool_name, result)
                    result_text = result

                    if result.startswith("❌"):
                        step_ok = False
                        # Reflect
                        self.thinking.emit(f"🪞 Reflecting on failure...")
                        reflection = self.planner.reflect(step, result)
                        decision = reflection.get("decision", "retry")
                        self.thinking.emit(f"💭 Decision: {decision} — {reflection.get('reason','')}")

                        if decision == "skip":
                            step.status = StepStatus.SKIPPED
                            self.step_update.emit(step.step - 1, "skipped")
                            break
                        elif decision == "abort":
                            self.error.emit(f"Agent aborted at step {step.step}: {result}")
                            return
                        elif decision == "fallback" and reflection.get("fallback_tool"):
                            fb_result = dispatch_tool(reflection["fallback_tool"],
                                                      {"command": reflection.get("fallback_action", "")})
                            self.tool_called.emit(reflection["fallback_tool"], fb_result)
                            if not fb_result.startswith("❌"):
                                step_ok = True
                    else:
                        api_manager.record(
                            session_id=session_manager.active_session.id if session_manager.active_session else "",
                            tool=tool_name
                        )

                if step_ok or not tool_calls:
                    success = True
                    break

                if attempt < 3:
                    self.thinking.emit(f"🔁 Retrying step {step.step} (attempt {attempt + 1}/3)...")
                    time.sleep(0.5)

            # Update step status
            if success:
                step.status = StepStatus.SUCCESS
                step.result = result_text
                self.step_update.emit(step.step - 1, "success")
                log_step(step.step, step.action, "success")
            elif step.status not in (StepStatus.SKIPPED,):
                step.status = StepStatus.FAILED
                step.error = result_text
                self.step_update.emit(step.step - 1, "failed")
                log_step(step.step, step.action, "failed", result_text)

            plan.advance()

        # Final summary
        done_count = sum(1 for s in plan.steps if s.status == StepStatus.SUCCESS)
        self.message_ready.emit("assistant",
            f"✅ **Task complete!** {done_count}/{len(plan.steps)} steps succeeded.")
        self.done.emit()


# ══════════════════════════════════════════════════════════════════════════════
#  SETTINGS DIALOG
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
#  SETTINGS DIALOG — Tabbed (LLM + Facebook + Telegram + Scheduler)
# ══════════════════════════════════════════════════════════════════════════════
class SettingsDialog(QDialog):
    def __init__(self, llm: LLMProvider, parent=None):
        super().__init__(parent)
        self.llm = llm
        self.setWindowTitle("⚙️ Settings")
        self.setMinimumSize(520, 480)
        self.setStyleSheet(DARK_STYLE)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        title = QLabel("⚙️ Settings")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #6c63ff;")
        layout.addWidget(title)

        tabs = QTabWidget()
        tabs.addTab(self._build_llm_tab(),       "🤖 LLM")
        tabs.addTab(self._build_facebook_tab(),   "📘 Facebook")
        tabs.addTab(self._build_telegram_tab(),   "✈️ Telegram")
        tabs.addTab(self._build_scheduler_tab(),  "⏰ Scheduler")
        layout.addWidget(tabs)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    # ── LLM Tab ───────────────────────────────────────────────────────────────
    def _build_llm_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.setSpacing(12)
        form.setContentsMargins(16, 16, 16, 16)

        self.provider_combo = QComboBox()
        self.provider_combo.addItems(["Groq (Cloud - Fast)", "Ollama (Local)"])
        self.provider_combo.setCurrentIndex(0 if self.llm.provider == "groq" else 1)
        form.addRow("Provider:", self.provider_combo)

        self.groq_key = QLineEdit()
        self.groq_key.setPlaceholderText("gsk_...")
        self.groq_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.groq_key.setText(self.llm.groq_api_key)
        form.addRow("Groq API Key:", self.groq_key)

        self.groq_model = QComboBox()
        self.groq_model.addItems([
            "llama-3.3-70b-versatile", "llama-3.1-70b-versatile",
            "llama3-70b-8192", "mixtral-8x7b-32768", "gemma2-9b-it"
        ])
        idx = self.groq_model.findText(self.llm.groq_model)
        if idx >= 0:
            self.groq_model.setCurrentIndex(idx)
        form.addRow("Groq Model:", self.groq_model)

        self.ollama_url = QLineEdit()
        self.ollama_url.setText(self.llm.ollama_url)
        form.addRow("Ollama URL:", self.ollama_url)

        self.ollama_model_edit = QLineEdit()
        self.ollama_model_edit.setText(self.llm.ollama_model)
        form.addRow("Ollama Model:", self.ollama_model_edit)

        note = QLabel("💡 Groq free key: console.groq.com")
        note.setStyleSheet("color: #888; font-size: 11px;")
        form.addRow("", note)
        return w

    # ── Facebook Tab ──────────────────────────────────────────────────────────
    def _build_facebook_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.setSpacing(12)
        form.setContentsMargins(16, 16, 16, 16)

        try:
            from config.config_manager import get
            fb_token = get("facebook.page_access_token", "")
            fb_page  = get("facebook.page_id", "")
        except Exception:
            fb_token = fb_page = ""

        self.fb_token = QLineEdit()
        self.fb_token.setPlaceholderText("EAAxxxxxx...")
        self.fb_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.fb_token.setText(fb_token)
        form.addRow("Page Access Token:", self.fb_token)

        self.fb_page_id = QLineEdit()
        self.fb_page_id.setPlaceholderText("123456789")
        self.fb_page_id.setText(fb_page)
        form.addRow("Page ID:", self.fb_page_id)

        test_btn = QPushButton("🔍 اختبر الاتصال")
        test_btn.clicked.connect(self._test_facebook)
        form.addRow("", test_btn)

        self.fb_status = QLabel("")
        self.fb_status.setStyleSheet("color: #888; font-size: 11px;")
        self.fb_status.setWordWrap(True)
        form.addRow("", self.fb_status)

        note = QLabel(
            "💡 إزاي تجيب الـ Token:\n"
            "1. روح developers.facebook.com\n"
            "2. أنشئ App → Add Product → Facebook Login\n"
            "3. Graph API Explorer → جيب Page Access Token"
        )
        note.setStyleSheet("color: #666; font-size: 10px;")
        note.setWordWrap(True)
        form.addRow("", note)
        return w

    # ── Telegram Tab ──────────────────────────────────────────────────────────
    def _build_telegram_tab(self) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.setSpacing(12)
        form.setContentsMargins(16, 16, 16, 16)

        try:
            from config.config_manager import get
            tg_token = get("telegram.bot_token", "")
            tg_ids   = ", ".join(str(x) for x in get("telegram.allowed_chat_ids", []))
        except Exception:
            tg_token = tg_ids = ""

        self.tg_token = QLineEdit()
        self.tg_token.setPlaceholderText("1234567890:AAxxxxxx...")
        self.tg_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.tg_token.setText(tg_token)
        form.addRow("Bot Token:", self.tg_token)

        self.tg_ids = QLineEdit()
        self.tg_ids.setPlaceholderText("123456, 789012 (اتركه فاضي للكل)")
        self.tg_ids.setText(tg_ids)
        form.addRow("Allowed Chat IDs:", self.tg_ids)

        self.tg_auto_reply = QCheckBox("تفعيل الرد التلقائي بالـ AI")
        try:
            from config.config_manager import get
            self.tg_auto_reply.setChecked(get("telegram.auto_reply", False))
        except Exception:
            pass
        form.addRow("", self.tg_auto_reply)

        test_btn = QPushButton("🔍 اختبر البوت")
        test_btn.clicked.connect(self._test_telegram)
        form.addRow("", test_btn)

        self.tg_status = QLabel("")
        self.tg_status.setStyleSheet("color: #888; font-size: 11px;")
        form.addRow("", self.tg_status)

        note = QLabel(
            "💡 إزاي تعمل Bot:\n"
            "1. كلم @BotFather على Telegram\n"
            "2. اكتب /newbot\n"
            "3. خد الـ Token وحطه هنا"
        )
        note.setStyleSheet("color: #666; font-size: 10px;")
        note.setWordWrap(True)
        form.addRow("", note)
        return w

    # ── Scheduler Tab ─────────────────────────────────────────────────────────
    def _build_scheduler_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        layout.addWidget(QLabel("⏰ المهام المجدولة الحالية:"))

        self.tasks_display = QTextEdit()
        self.tasks_display.setReadOnly(True)
        self.tasks_display.setMaximumHeight(150)
        layout.addWidget(self.tasks_display)
        self._refresh_tasks_display()

        layout.addWidget(QLabel("➕ إضافة مهمة جديدة:"))

        form = QFormLayout()
        form.setSpacing(8)

        self.task_name = QLineEdit()
        self.task_name.setPlaceholderText("مثال: نشر تقرير صباحي")
        form.addRow("اسم المهمة:", self.task_name)

        self.task_prompt = QLineEdit()
        self.task_prompt.setPlaceholderText("مثال: ابحث عن أخبار AI وأرسلها على Telegram")
        form.addRow("الأمر:", self.task_prompt)

        self.task_type = QComboBox()
        self.task_type.addItems(["interval (كل X دقيقة)", "daily (يومي)", "weekly (أسبوعي)"])
        form.addRow("النوع:", self.task_type)

        self.task_value = QLineEdit()
        self.task_value.setPlaceholderText("30 (دقيقة) / 08:00 / mon:09:00")
        form.addRow("القيمة:", self.task_value)

        layout.addLayout(form)

        add_btn = QPushButton("➕ إضافة المهمة")
        add_btn.clicked.connect(self._add_task)
        layout.addWidget(add_btn)

        self.task_status = QLabel("")
        self.task_status.setStyleSheet("color: #2ed573; font-size: 11px;")
        layout.addWidget(self.task_status)

        layout.addStretch()
        return w

    def _refresh_tasks_display(self):
        try:
            from integrations.scheduler import schedule_manager
            tasks = schedule_manager.list_tasks()
            if not tasks:
                self.tasks_display.setPlainText("لا توجد مهام مجدولة")
                return
            text = ""
            for t in tasks:
                status = "✅" if t["enabled"] else "⏸"
                text += f"{status} {t['name']} | {t['schedule_type']}: {t['schedule_value']}\n"
                text += f"   التالي: {t.get('next_run','')[:16]} | عدد مرات التشغيل: {t['run_count']}\n\n"
            self.tasks_display.setPlainText(text)
        except Exception as e:
            self.tasks_display.setPlainText(f"خطأ: {e}")

    def _add_task(self):
        try:
            from integrations.scheduler import schedule_manager
            type_map = {0: "interval", 1: "daily", 2: "weekly"}
            stype = type_map[self.task_type.currentIndex()]
            task = schedule_manager.add_task(
                self.task_name.text().strip(),
                self.task_prompt.text().strip(),
                stype,
                self.task_value.text().strip()
            )
            self.task_status.setText(f"✅ تمت إضافة: {task.name}")
            self._refresh_tasks_display()
        except Exception as e:
            self.task_status.setText(f"❌ {e}")
            self.task_status.setStyleSheet("color: #ff4757; font-size: 11px;")

    def _test_facebook(self):
        try:
            from integrations.facebook_manager import FacebookManager
            fb = FacebookManager()
            fb.save_config(self.fb_token.text().strip(), self.fb_page_id.text().strip())
            result = fb.get_page_info()
            self.fb_status.setText(result[:200])
            self.fb_status.setStyleSheet("color: #2ed573; font-size: 11px;")
        except Exception as e:
            self.fb_status.setText(f"❌ {e}")
            self.fb_status.setStyleSheet("color: #ff4757; font-size: 11px;")

    def _test_telegram(self):
        try:
            from integrations.telegram_bot import TelegramBot
            tg = TelegramBot()
            tg.save_config(self.tg_token.text().strip())
            result = tg.get_bot_info()
            self.tg_status.setText(result[:200])
            self.tg_status.setStyleSheet("color: #2ed573; font-size: 11px;")
        except Exception as e:
            self.tg_status.setText(f"❌ {e}")
            self.tg_status.setStyleSheet("color: #ff4757; font-size: 11px;")

    # ── Save all ──────────────────────────────────────────────────────────────
    def _save(self):
        # LLM
        provider = "groq" if self.provider_combo.currentIndex() == 0 else "ollama"
        self.llm.set_provider(
            provider,
            groq_api_key=self.groq_key.text().strip(),
            groq_model=self.groq_model.currentText(),
            ollama_url=self.ollama_url.text().strip(),
            ollama_model=self.ollama_model_edit.text().strip()
        )
        try:
            from config.config_manager import set_value
            set_value("llm.provider",     provider)
            set_value("llm.groq_api_key", self.groq_key.text().strip())
            set_value("llm.groq_model",   self.groq_model.currentText())
            set_value("llm.ollama_url",   self.ollama_url.text().strip())
            set_value("llm.ollama_model", self.ollama_model_edit.text().strip())

            # Facebook
            set_value("facebook.page_access_token", self.fb_token.text().strip())
            set_value("facebook.page_id",           self.fb_page_id.text().strip())

            # Telegram
            ids_raw = self.tg_ids.text().strip()
            ids = [x.strip() for x in ids_raw.split(",") if x.strip()] if ids_raw else []
            set_value("telegram.bot_token",       self.tg_token.text().strip())
            set_value("telegram.allowed_chat_ids", ids)
            set_value("telegram.auto_reply",       self.tg_auto_reply.isChecked())

            # Apply Telegram config live
            from integrations.telegram_bot import telegram_bot
            telegram_bot.save_config(self.tg_token.text().strip(), ids)
            if self.tg_auto_reply.isChecked() and self.tg_token.text().strip():
                telegram_bot.start_polling()

            # Apply Facebook config live
            from integrations.facebook_manager import facebook_manager
            facebook_manager.save_config(
                self.fb_token.text().strip(),
                self.fb_page_id.text().strip()
            )
        except Exception:
            pass

        self.accept()
        self.accept()


# ══════════════════════════════════════════════════════════════════════════════
#  CHAT BUBBLE
# ══════════════════════════════════════════════════════════════════════════════
class ChatDisplay(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont("Segoe UI", 13))

    def add_message(self, role: str, content: str):
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        if role == "user":
            html = f'''
            <div style="margin: 12px 0; text-align: right;">
                <div style="display: inline-block; background: #6c63ff; color: white;
                            border-radius: 16px 16px 4px 16px; padding: 10px 16px;
                            max-width: 70%; font-size: 13px; line-height: 1.5;">
                    {content.replace(chr(10), "<br>")}
                </div>
                <div style="color: #555; font-size: 10px; margin-top: 4px;">You</div>
            </div>
            '''
        elif role == "assistant":
            html = f'''
            <div style="margin: 12px 0;">
                <div style="color: #6c63ff; font-size: 11px; margin-bottom: 4px; font-weight: 600;">
                    🦚 PeacockAgent
                </div>
                <div style="background: #1e1e28; color: #e8e8f0;
                            border-radius: 4px 16px 16px 16px; padding: 10px 16px;
                            max-width: 80%; font-size: 13px; line-height: 1.6;
                            border-left: 3px solid #6c63ff;">
                    {content.replace(chr(10), "<br>")}
                </div>
            </div>
            '''
        elif role == "tool":
            tool_name, result = content.split("|||", 1) if "|||" in content else ("tool", content)
            html = f'''
            <div style="margin: 6px 0 6px 24px;">
                <div style="background: #0d1a0d; color: #4caf50;
                            border-radius: 6px; padding: 8px 12px;
                            font-size: 11px; font-family: 'Consolas', monospace;
                            border-left: 3px solid #4caf50;">
                    🔧 <b>{tool_name}</b><br>
                    {result[:300].replace(chr(10), "<br>")}{"..." if len(result) > 300 else ""}
                </div>
            </div>
            '''
        elif role == "thinking":
            html = f'''
            <div style="margin: 4px 0 4px 24px; color: #888; font-size: 11px; font-style: italic;">
                {content}
            </div>
            '''
        elif role == "error":
            html = f'''
            <div style="margin: 8px 0; background: #1a0d0d; color: #ff6b6b;
                        border-radius: 8px; padding: 10px 14px;
                        border-left: 3px solid #ff4757;">
                ❌ {content}
            </div>
            '''
        else:
            html = f"<div style='margin:8px 0; color: #888;'>{content}</div>"

        self.insertHtml(html)
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ══════════════════════════════════════════════════════════════════════════════
class PeacockAgentApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.llm = LLMProvider()
        self.history = []
        self.worker = None
        self.uploaded_file = None
        self.use_planning = False

        self._load_config()
        self._build_ui()
        self._refresh_session_list()
        self.setWindowTitle("PeacockAgent v2 — AI Desktop Assistant")
        self.resize(1200, 820)
        self.setMinimumSize(900, 600)

    def _load_config(self):
        try:
            from config.config_manager import get, set_value
            self.llm.set_provider(
                get("llm.provider", "groq"),
                groq_api_key=get("llm.groq_api_key", ""),
                groq_model=get("llm.groq_model", "llama-3.3-70b-versatile"),
                ollama_url=get("llm.ollama_url", "http://localhost:11434"),
                ollama_model=get("llm.ollama_model", "llama3")
            )
        except Exception:
            # Fallback to old config
            config_path = os.path.join(Path.home(), ".peacockagent_config.json")
            if os.path.exists(config_path):
                try:
                    with open(config_path) as f:
                        cfg = json.load(f)
                    self.llm.set_provider(
                        cfg.get("provider", "groq"),
                        groq_api_key=cfg.get("groq_api_key", ""),
                        groq_model=cfg.get("groq_model", "llama-3.3-70b-versatile"),
                        ollama_url=cfg.get("ollama_url", "http://localhost:11434"),
                        ollama_model=cfg.get("ollama_model", "llama3")
                    )
                except Exception:
                    pass

        # Load or create active session
        sessions = session_manager.list_sessions()
        if sessions:
            session_manager.load_session(sessions[0]["id"])
        else:
            session_manager.create_session("New Chat")

    def _build_ui(self):
        self.setStyleSheet(DARK_STYLE)

        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Header ────────────────────────────────────────────────────────────
        header = QFrame()
        header.setFixedHeight(64)
        header.setStyleSheet("background: #0d0d0f; border-bottom: 1px solid #2a2a35;")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(20, 0, 20, 0)

        logo_label = QLabel("🦚 PeacockAgent v2")
        logo_label.setObjectName("title_label")
        header_layout.addWidget(logo_label)

        header_layout.addStretch()

        # Usage stats label
        self.usage_label = QLabel("")
        self.usage_label.setStyleSheet("color: #555; font-size: 11px;")
        header_layout.addWidget(self.usage_label)
        self._update_usage_label()

        self.status_indicator = QLabel("● Offline")
        self.status_indicator.setStyleSheet("color: #ff4757; font-size: 11px;")
        header_layout.addWidget(self.status_indicator)

        settings_btn = QPushButton("⚙️ Settings")
        settings_btn.clicked.connect(self._open_settings)
        settings_btn.setFixedWidth(100)
        header_layout.addWidget(settings_btn)

        clear_btn = QPushButton("🗑 Clear")
        clear_btn.clicked.connect(self._clear_chat)
        clear_btn.setFixedWidth(80)
        header_layout.addWidget(clear_btn)

        main_layout.addWidget(header)

        # ── Body ──────────────────────────────────────────────────────────────
        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(16, 16, 16, 16)
        body_layout.setSpacing(12)

        # ── Sessions sidebar ──────────────────────────────────────────────────
        sessions_panel = QFrame()
        sessions_panel.setFixedWidth(200)
        sessions_panel.setStyleSheet("background: #16161a; border-radius: 12px; border: 1px solid #2a2a35;")
        sessions_layout = QVBoxLayout(sessions_panel)
        sessions_layout.setContentsMargins(10, 12, 10, 12)
        sessions_layout.setSpacing(6)

        sess_title = QLabel("💬 Sessions")
        sess_title.setStyleSheet("color: #888; font-size: 11px; font-weight: 600; letter-spacing: 1px;")
        sessions_layout.addWidget(sess_title)

        new_chat_btn = QPushButton("＋ New Chat")
        new_chat_btn.setFixedHeight(32)
        new_chat_btn.setStyleSheet("""
            QPushButton { background: #6c63ff; color: white; border-radius: 6px;
                          font-weight: 600; font-size: 12px; }
            QPushButton:hover { background: #7c73ff; }
        """)
        new_chat_btn.clicked.connect(self._new_session)
        sessions_layout.addWidget(new_chat_btn)

        self.sessions_list = QTextEdit()
        self.sessions_list.setReadOnly(True)
        self.sessions_list.setMaximumHeight(220)
        self.sessions_list.setStyleSheet("""
            QTextEdit { background: #0d0d0f; border-radius: 6px;
                        border: 1px solid #2a2a35; font-size: 11px; }
        """)
        sessions_layout.addWidget(self.sessions_list)

        # Export buttons
        export_txt_btn = QPushButton("📄 Export TXT")
        export_txt_btn.setFixedHeight(28)
        export_txt_btn.clicked.connect(self._export_txt)
        sessions_layout.addWidget(export_txt_btn)

        export_pdf_btn = QPushButton("📑 Export PDF")
        export_pdf_btn.setFixedHeight(28)
        export_pdf_btn.clicked.connect(self._export_pdf)
        sessions_layout.addWidget(export_pdf_btn)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color: #2a2a35;")
        sessions_layout.addWidget(sep)

        # Quick actions panel
        panel_title = QLabel("⚡ Quick Actions")
        panel_title.setStyleSheet("color: #888; font-size: 11px; font-weight: 600; letter-spacing: 1px;")
        sessions_layout.addWidget(panel_title)

        quick_actions = [
            ("📸 Screenshot",   "Take a screenshot of the current screen"),
            ("🌐 Web Search",   "Search the web for: "),
            ("📄 Create Word",  "Create a Word document about: "),
            ("📊 Create PPT",   "Create a PowerPoint presentation about: "),
            ("📑 Create PDF",   "Create a PDF document about: "),
            ("🖼 Gen Image",    "Generate an image of: "),
            ("📁 List Desktop", "List the files on my Desktop"),
            ("💻 Open VS Code", "Open VS Code"),
        ]

        for label, prompt in quick_actions:
            btn = QPushButton(label)
            btn.setFixedHeight(32)
            btn.setStyleSheet("""
                QPushButton { background: #1e1e28; border: 1px solid #2a2a35;
                    border-radius: 6px; color: #ccc; font-size: 11px;
                    text-align: left; padding-left: 8px; }
                QPushButton:hover { background: #2a2a38; color: #fff; border-color: #6c63ff; }
            """)
            btn.clicked.connect(lambda checked, p=prompt: self._quick_action(p))
            sessions_layout.addWidget(btn)

        sessions_layout.addStretch()
        body_layout.addWidget(sessions_panel)

        # ── Center: chat + plan panel ─────────────────────────────────────────
        center_layout = QVBoxLayout()
        center_layout.setSpacing(10)

        # Planning toggle bar
        plan_bar = QFrame()
        plan_bar.setFixedHeight(36)
        plan_bar.setStyleSheet("background: #16161a; border-radius: 8px; border: 1px solid #2a2a35;")
        plan_bar_layout = QHBoxLayout(plan_bar)
        plan_bar_layout.setContentsMargins(12, 0, 12, 0)

        plan_label = QLabel("🧠 Planning Mode:")
        plan_label.setStyleSheet("color: #888; font-size: 12px;")
        plan_bar_layout.addWidget(plan_label)

        self.plan_toggle = QPushButton("OFF")
        self.plan_toggle.setCheckable(True)
        self.plan_toggle.setFixedSize(60, 24)
        self.plan_toggle.setStyleSheet("""
            QPushButton { background: #2a2a38; color: #888; border-radius: 12px;
                          font-size: 11px; font-weight: 700; border: none; }
            QPushButton:checked { background: #6c63ff; color: white; }
        """)
        self.plan_toggle.toggled.connect(self._toggle_planning)
        plan_bar_layout.addWidget(self.plan_toggle)

        plan_bar_layout.addStretch()

        self.plan_status_label = QLabel("")
        self.plan_status_label.setStyleSheet("color: #888; font-size: 11px;")
        plan_bar_layout.addWidget(self.plan_status_label)

        center_layout.addWidget(plan_bar)

        # Chat display
        self.chat_display = ChatDisplay()
        self.chat_display.setObjectName("chat_frame")
        center_layout.addWidget(self.chat_display)

        # File upload bar (hidden by default)
        self.file_bar = QFrame()
        self.file_bar.setFixedHeight(36)
        self.file_bar.setStyleSheet("background: #1a1a2e; border-radius: 6px; border: 1px solid #6c63ff;")
        file_bar_layout = QHBoxLayout(self.file_bar)
        file_bar_layout.setContentsMargins(12, 0, 12, 0)
        self.file_label = QLabel("No file selected")
        self.file_label.setStyleSheet("color: #6c63ff; font-size: 12px;")
        file_bar_layout.addWidget(self.file_label)
        file_bar_layout.addStretch()
        remove_file_btn = QPushButton("✕")
        remove_file_btn.setFixedSize(24, 24)
        remove_file_btn.clicked.connect(self._remove_file)
        file_bar_layout.addWidget(remove_file_btn)
        self.file_bar.hide()
        center_layout.addWidget(self.file_bar)

        # Input area
        input_frame = QFrame()
        input_frame.setObjectName("input_frame")
        input_frame.setFixedHeight(100)
        input_layout = QVBoxLayout(input_frame)
        input_layout.setContentsMargins(8, 8, 8, 8)
        input_layout.setSpacing(6)

        self.input_box = QTextEdit()
        self.input_box.setPlaceholderText("Ask PeacockAgent to do anything... (Ctrl+Enter to send)")
        self.input_box.setFixedHeight(52)
        self.input_box.installEventFilter(self)
        input_layout.addWidget(self.input_box)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        upload_btn = QPushButton("📎 Attach File")
        upload_btn.setFixedHeight(32)
        upload_btn.clicked.connect(self._upload_file)
        btn_row.addWidget(upload_btn)

        btn_row.addStretch()

        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.setObjectName("stop_btn")
        self.stop_btn.setFixedSize(80, 32)
        self.stop_btn.hide()
        self.stop_btn.clicked.connect(self._stop_agent)
        btn_row.addWidget(self.stop_btn)

        self.send_btn = QPushButton("Send ➤")
        self.send_btn.setObjectName("send_btn")
        self.send_btn.setFixedSize(100, 32)
        self.send_btn.clicked.connect(self._send_message)
        btn_row.addWidget(self.send_btn)

        input_layout.addLayout(btn_row)
        center_layout.addWidget(input_frame)

        body_layout.addLayout(center_layout)

        # ── Right: plan steps panel ───────────────────────────────────────────
        plan_panel = QFrame()
        plan_panel.setFixedWidth(200)
        plan_panel.setStyleSheet("background: #16161a; border-radius: 12px; border: 1px solid #2a2a35;")
        plan_panel_layout = QVBoxLayout(plan_panel)
        plan_panel_layout.setContentsMargins(10, 12, 10, 12)
        plan_panel_layout.setSpacing(6)

        plan_panel_title = QLabel("📋 Execution Plan")
        plan_panel_title.setStyleSheet("color: #888; font-size: 11px; font-weight: 600; letter-spacing: 1px;")
        plan_panel_layout.addWidget(plan_panel_title)

        self.plan_display = QTextEdit()
        self.plan_display.setReadOnly(True)
        self.plan_display.setStyleSheet("""
            QTextEdit { background: #0d0d0f; border: 1px solid #2a2a35;
                        border-radius: 6px; font-size: 11px; color: #aaa; }
        """)
        self.plan_display.setPlaceholderText("Plan steps will appear here when planning mode is ON")
        plan_panel_layout.addWidget(self.plan_display)

        sep2 = QFrame()
        sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet("color: #2a2a35;")
        plan_panel_layout.addWidget(sep2)

        stats_title = QLabel("📊 Usage Today")
        stats_title.setStyleSheet("color: #888; font-size: 11px; font-weight: 600;")
        plan_panel_layout.addWidget(stats_title)

        self.stats_display = QLabel("")
        self.stats_display.setStyleSheet("color: #666; font-size: 11px; line-height: 1.6;")
        self.stats_display.setWordWrap(True)
        plan_panel_layout.addWidget(self.stats_display)

        plan_panel_layout.addStretch()
        body_layout.addWidget(plan_panel)

        main_layout.addWidget(body)

        # ── Progress bar ──────────────────────────────────────────────────────
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedHeight(3)
        self.progress.hide()
        main_layout.addWidget(self.progress)

        # ── Status bar ────────────────────────────────────────────────────────
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready — Configure API key in Settings to get started")

        # Welcome message
        self._show_welcome()

    def _show_welcome(self):
        welcome = """<div style="text-align: center; padding: 40px 20px; color: #666;">
            <div style="font-size: 48px;">🦚</div>
            <div style="font-size: 22px; font-weight: 700; color: #6c63ff; margin: 12px 0;">PeacockAgent</div>
            <div style="font-size: 13px; color: #888; line-height: 1.8; max-width: 500px; margin: 0 auto;">
                Your AI Desktop Assistant<br>
                Can open apps · control mouse & keyboard · create files<br>
                generate images · search the web · and much more<br><br>
                <span style="color: #6c63ff;">⚙️ Go to Settings to add your Groq API key first</span>
            </div>
        </div>"""
        self.chat_display.insertHtml(welcome)

    def eventFilter(self, obj, event):
        if obj == self.input_box and isinstance(event, QKeyEvent):
            if event.key() == Qt.Key.Key_Return and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
                self._send_message()
                return True
        return super().eventFilter(obj, event)

    # ── Message sending ───────────────────────────────────────────────────────
    def _send_message(self):
        text = self.input_box.toPlainText().strip()
        if not text:
            return
        if self.worker and self.worker.isRunning():
            return

        # Check API rate limit
        allowed, reason = api_manager.check_limit()
        if not allowed:
            self.chat_display.add_message("error", f"🚫 {reason}")
            return

        self.input_box.clear()
        self.chat_display.add_message("user", text)

        # Save to session
        if session_manager.active_session:
            session_manager.active_session.add_message("user", text)
            if self.uploaded_file:
                session_manager.active_session.add_message("user",
                    f"[Attached file: {self.uploaded_file}]")

        content = text
        if self.uploaded_file:
            content += f"\n[Attached file: {self.uploaded_file}]"
        self.history.append({"role": "user", "content": content})

        self._remove_file()
        self._start_agent(text)

    def _start_agent(self, user_request: str = ""):
        self.send_btn.setEnabled(False)
        self.stop_btn.show()
        self.progress.show()
        self.status_indicator.setText("● Thinking")
        self.status_indicator.setStyleSheet("color: #ffa502; font-size: 11px;")

        self.worker = AgentWorker(
            self.llm, self.history,
            use_planning=self.use_planning,
            user_request=user_request
        )
        self.worker.message_ready.connect(self._on_message)
        self.worker.tool_called.connect(self._on_tool)
        self.worker.thinking.connect(self._on_thinking)
        self.worker.plan_ready.connect(self._on_plan_ready)
        self.worker.step_update.connect(self._on_step_update)
        self.worker.done.connect(self._on_done)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    # ── Agent event handlers ──────────────────────────────────────────────────
    def _on_message(self, role: str, content: str):
        self.chat_display.add_message(role, content)
        self.history.append({"role": role, "content": content})
        if session_manager.active_session:
            session_manager.active_session.add_message(role, content)
            session_manager.save_session()
        self._refresh_session_list()

    def _on_tool(self, tool_name: str, result: str):
        self.chat_display.add_message("tool", f"{tool_name}|||{result}")
        self.status_bar.showMessage(f"🔧 {tool_name}: {result[:80]}")
        self._update_usage_label()

    def _on_thinking(self, msg: str):
        self.chat_display.add_message("thinking", msg)
        self.status_bar.showMessage(msg)

    def _on_plan_ready(self, steps: list):
        """Display plan in the right panel."""
        html = ""
        for s in steps:
            html += f"""<div style="margin:4px 0; padding:6px 8px;
                         background:#1e1e28; border-radius:5px;
                         border-left:3px solid #6c63ff;">
                <span style="color:#6c63ff; font-weight:700;">Step {s['step']}</span><br>
                <span style="color:#ccc;">{s['action']}</span><br>
                <span style="color:#555; font-size:10px;">🔧 {s['tool']}</span>
            </div>"""
        self.plan_display.setHtml(html)
        self.plan_status_label.setText(f"📋 {len(steps)} steps")

    def _on_step_update(self, step_idx: int, status: str):
        """Update step status in plan panel."""
        icons = {"running": "🔄", "success": "✅", "failed": "❌", "skipped": "⏭"}
        colors = {"running": "#ffa502", "success": "#2ed573", "failed": "#ff4757", "skipped": "#888"}
        icon = icons.get(status, "⬜")
        color = colors.get(status, "#aaa")
        self.plan_status_label.setText(f"{icon} Step {step_idx + 1} {status}")
        self.plan_status_label.setStyleSheet(f"color: {color}; font-size: 11px;")

    def _on_done(self):
        self.send_btn.setEnabled(True)
        self.stop_btn.hide()
        self.progress.hide()
        self.status_indicator.setText("● Online")
        self.status_indicator.setStyleSheet("color: #2ed573; font-size: 11px;")
        self.status_bar.showMessage("Ready")
        self._update_usage_label()
        self._update_stats_panel()

    def _on_error(self, error: str):
        self.chat_display.add_message("error", error)
        self._on_done()

    def _stop_agent(self):
        if self.worker:
            self.worker.stop()
            self.worker.quit()
        self._on_done()
        self.chat_display.add_message("thinking", "⏹ Stopped by user")

    # ── Planning toggle ───────────────────────────────────────────────────────
    def _toggle_planning(self, checked: bool):
        self.use_planning = checked
        self.plan_toggle.setText("ON" if checked else "OFF")
        if checked:
            self.plan_status_label.setText("🧠 Planning enabled")
            self.chat_display.add_message("thinking",
                "🧠 Planning mode ON — agent will create a step-by-step plan before executing")
        else:
            self.plan_status_label.setText("")
            self.plan_display.clear()

    # ── Session management ────────────────────────────────────────────────────
    def _new_session(self):
        session = session_manager.create_session()
        self.history = []
        self.chat_display.clear()
        self._show_welcome()
        self._refresh_session_list()
        self.status_bar.showMessage(f"New chat created: {session.name}")

    def _refresh_session_list(self):
        sessions = session_manager.list_sessions()
        active_id = session_manager.active_session.id if session_manager.active_session else ""
        html = ""
        for s in sessions[:15]:
            is_active = s["id"] == active_id
            bg = "#6c63ff" if is_active else "#1e1e28"
            color = "white" if is_active else "#aaa"
            count = s.get("message_count", 0)
            name = s["name"][:22] + "…" if len(s["name"]) > 22 else s["name"]
            html += f"""<div style="background:{bg}; color:{color}; padding:6px 8px;
                         border-radius:6px; margin:2px 0; font-size:11px; cursor:pointer;">
                {name}<br>
                <span style="font-size:9px; opacity:0.6;">{count} messages</span>
            </div>"""
        self.sessions_list.setHtml(html)

    def _switch_session(self, session_id: str):
        session = session_manager.load_session(session_id)
        if not session:
            return
        self.history = session.get_llm_messages()
        self.chat_display.clear()
        # Replay messages in chat display
        for m in session.messages:
            if m["role"] in ("user", "assistant"):
                self.chat_display.add_message(m["role"], m["content"])
        self._refresh_session_list()
        self.status_bar.showMessage(f"Loaded: {session.name}")

    # ── Export ────────────────────────────────────────────────────────────────
    def _export_txt(self):
        if not session_manager.active_session:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Chat as TXT", str(Path.home() / "Desktop" /
            f"{session_manager.active_session.name}.txt"), "Text Files (*.txt)")
        if path:
            result = session_manager.export_txt(session_manager.active_session.id, path)
            self.status_bar.showMessage(result)

    def _export_pdf(self):
        if not session_manager.active_session:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Chat as PDF", str(Path.home() / "Desktop" /
            f"{session_manager.active_session.name}.pdf"), "PDF Files (*.pdf)")
        if path:
            result = session_manager.export_pdf(session_manager.active_session.id, path)
            self.status_bar.showMessage(result)

    # ── Stats & usage ─────────────────────────────────────────────────────────
    def _update_usage_label(self):
        try:
            stats = api_manager.get_stats()
            self.usage_label.setText(
                f"Plan: {stats['plan'].upper()} | "
                f"Requests: {stats['today_requests']}/{stats['limit_requests']}  "
            )
        except Exception:
            pass

    def _update_stats_panel(self):
        try:
            stats = api_manager.get_stats()
            tools = api_manager.get_tool_usage(7)
            text = (
                f"Plan: <b>{stats['plan'].upper()}</b><br>"
                f"Requests: {stats['today_requests']}/{stats['limit_requests']}<br>"
                f"Remaining: {stats['requests_left']}<br><br>"
                f"<b>Top Tools (7d):</b><br>"
            )
            for t in tools[:5]:
                text += f"  {t['tool']}: {t['count']}<br>"
            self.stats_display.setText(text)
        except Exception:
            pass

    # ── Misc ──────────────────────────────────────────────────────────────────
    def _quick_action(self, prompt: str):
        self.input_box.setText(prompt)
        self.input_box.setFocus()

    def _upload_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select File", str(Path.home()),
            "All Files (*);;Images (*.png *.jpg *.jpeg);;Documents (*.pdf *.docx *.txt)"
        )
        if path:
            self.uploaded_file = path
            self.file_label.setText(f"📎 {os.path.basename(path)}")
            self.file_bar.show()

    def _remove_file(self):
        self.uploaded_file = None
        self.file_bar.hide()

    def _open_settings(self):
        dlg = SettingsDialog(self.llm, self)
        if dlg.exec():
            # Save to new config manager
            try:
                from config.config_manager import set_value
                set_value("llm.provider", self.llm.provider)
                set_value("llm.groq_api_key", self.llm.groq_api_key)
                set_value("llm.groq_model", self.llm.groq_model)
                set_value("llm.ollama_url", self.llm.ollama_url)
                set_value("llm.ollama_model", self.llm.ollama_model)
            except Exception:
                pass
            self.status_bar.showMessage("Settings saved ✅")
            self.status_indicator.setText("● Ready")
            self.status_indicator.setStyleSheet("color: #2ed573; font-size: 11px;")

    def _clear_chat(self):
        self.chat_display.clear()
        self.history = []
        if session_manager.active_session:
            session_manager.active_session.messages = []
            session_manager.save_session()
        self._show_welcome()
        self.plan_display.clear()
        self.status_bar.showMessage("Chat cleared")
