# 🦚 PeacockAgent v2 — Production-Grade AI Desktop Agent

## What's New in v2

### 🧠 Agent Planning System
- **Planner** (`core/planner.py`) — LLM decomposes tasks into structured steps
- **Task Manager** (`core/task_manager.py`) — tracks step state (pending/running/success/failed)
- **Reflection** — on failure, agent reflects and decides: retry / fallback / skip / abort
- **Planning Mode toggle** in the UI (ON/OFF)

### 🔁 Error Recovery
- Retry failed tools up to 3 times with backoff
- Fallback logic (e.g. open_app fails -> run_command)
- Error classification: timeout / permission / invalid_input / network
- Full logging to logs/agent.log

### 🌐 Advanced Search Engine
- Multi-source: DuckDuckGo + Wikipedia
- Deduplication + relevance ranking
- Caching (24hr TTL)

### 💰 API Management
- Free / Plus / Pro plan system
- Daily request tracking via SQLite
- Rate limit enforcement

### 💬 Session Management
- Multi-session sidebar
- Auto-save every message
- Export chat to TXT or PDF

## Setup
1. Install Python 3.10+
2. Double-click RUN.bat
3. Settings -> add Groq API key (free: console.groq.com)

Built by PeacockAI
