"""
PeacockAgent - Configuration Manager
Loads config from config.json + environment variables
"""
import os
import json
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
CONFIG_PATH = BASE_DIR / "config" / "config.json"


def load_config() -> dict:
    """Load config from file, merge with env vars."""
    cfg = {}
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)

    # Override with environment variables if present
    if os.getenv("GROQ_API_KEY"):
        cfg.setdefault("llm", {})["groq_api_key"] = os.getenv("GROQ_API_KEY")
    if os.getenv("PEACOCK_PLAN"):
        cfg.setdefault("api", {})["plan"] = os.getenv("PEACOCK_PLAN")
    if os.getenv("OLLAMA_URL"):
        cfg.setdefault("llm", {})["ollama_url"] = os.getenv("OLLAMA_URL")

    return cfg


def save_config(cfg: dict):
    """Save config back to file."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def get(key_path: str, default=None):
    """
    Get a nested config value using dot notation.
    Example: get('llm.groq_api_key')
    """
    cfg = load_config()
    keys = key_path.split(".")
    val = cfg
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        else:
            return default
    return val if val is not None else default


def set_value(key_path: str, value):
    """Set a nested config value using dot notation."""
    cfg = load_config()
    keys = key_path.split(".")
    d = cfg
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    d[keys[-1]] = value
    save_config(cfg)
