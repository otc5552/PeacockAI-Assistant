"""
services/intent.py — Intent Detection Engine
Detects: chat | code | image | search | memory | complex | simple
Author: PeacockAI – Mostafa
"""
import re
from dataclasses import dataclass
from typing import Tuple
from core.config import (
    INTENT_CODE_KW, INTENT_SEARCH_KW, INTENT_IMAGE_KW,
    INTENT_MEMORY_KW, INTENT_COMPLEX_KW, INTENT_SIMPLE_KW,
)

INTENT_CHAT    = "chat"
INTENT_CODE    = "code"
INTENT_IMAGE   = "image"
INTENT_SEARCH  = "search"
INTENT_MEMORY  = "memory"
INTENT_COMPLEX = "complex"
INTENT_SIMPLE  = "simple"

@dataclass
class Intent:
    type:       str
    confidence: float
    signals:    list


def detect_intent(message: str) -> Intent:
    """
    Hybrid intent detection: rule-based keyword matching + heuristics.
    Returns Intent with type, confidence [0–1], and matched signals.
    """
    low     = message.lower()
    signals = []
    scores  = {
        INTENT_CODE:    0.0,
        INTENT_IMAGE:   0.0,
        INTENT_SEARCH:  0.0,
        INTENT_MEMORY:  0.0,
        INTENT_COMPLEX: 0.0,
        INTENT_SIMPLE:  0.0,
        INTENT_CHAT:    0.1,   # base score
    }

    # ── Rule 1: Keyword matching ──────────────────────────────
    for kw in INTENT_CODE_KW:
        if kw in low:
            scores[INTENT_CODE] += 0.25
            signals.append(f"code_kw:{kw}")

    for kw in INTENT_IMAGE_KW:
        if kw in low:
            scores[INTENT_IMAGE] += 0.5
            signals.append(f"image_kw:{kw}")

    for kw in INTENT_SEARCH_KW:
        if kw in low:
            scores[INTENT_SEARCH] += 0.3
            signals.append(f"search_kw:{kw}")

    for kw in INTENT_MEMORY_KW:
        if kw in low:
            scores[INTENT_MEMORY] += 0.3
            signals.append(f"memory_kw:{kw}")

    for kw in INTENT_COMPLEX_KW:
        if kw in low:
            scores[INTENT_COMPLEX] += 0.2
            signals.append(f"complex_kw:{kw}")

    for kw in INTENT_SIMPLE_KW:
        if kw in low:
            scores[INTENT_SIMPLE] += 0.4
            signals.append(f"simple_kw:{kw}")

    # ── Rule 2: Message length ────────────────────────────────
    msg_len = len(message)
    if msg_len < 20:
        scores[INTENT_SIMPLE]  += 0.2
    elif msg_len > 300:
        scores[INTENT_COMPLEX] += 0.25
        signals.append("long_message")

    # ── Rule 3: Code patterns (regex) ────────────────────────
    if re.search(r"```|def |class |import |function\s*\(|<[a-z]+>|SELECT\s", message):
        scores[INTENT_CODE] += 0.4
        signals.append("code_pattern")

    # ── Rule 4: Question marks and Arabic interrogatives ─────
    if re.search(r"\?|؟|كيف|لماذا|ما هو|ما هي|اشرح|وضّح", message):
        scores[INTENT_CHAT]    += 0.1
        scores[INTENT_COMPLEX] += 0.1

    # ── Rule 5: Direct image instruction ─────────────────────
    if re.search(r"(ارسم|أرسم|اعمل|أنشئ|صمم|generate|create)\s.*(صور|image|photo|picture)", low):
        scores[INTENT_IMAGE] += 0.5
        signals.append("image_instruction")

    # ── Rule 6: Personal info (memory) ───────────────────────
    if re.search(r"(أنا|اسمي|عمري|شغلتي|أعمل في|مجالي|بدرس)", message):
        scores[INTENT_MEMORY] += 0.4
        signals.append("personal_info")

    # ── Pick winner ───────────────────────────────────────────
    winner   = max(scores, key=lambda k: scores[k])
    conf     = min(scores[winner], 1.0)

    # Cap simple confidence — don't mistake code as simple
    if winner == INTENT_SIMPLE and scores[INTENT_CODE] > 0.2:
        winner = INTENT_CODE
        conf   = scores[INTENT_CODE]

    return Intent(type=winner, confidence=conf, signals=signals[:6])


def intent_to_model_key(intent: Intent, plan: str, user_id: str = "") -> str:
    """Map intent → best model key for the user's plan."""
    from core.config import PLANS, FALLBACK_CHAIN, FLAGS, AB_EXPERIMENTS
    import hashlib

    allowed = PLANS.get(plan, PLANS["free"])["models"]

    if intent.type == INTENT_CODE:
        preferred = "peacockgpt-5-code"
        return preferred if preferred in allowed else "peacockgpt-5"

    if intent.type in (INTENT_COMPLEX, INTENT_MEMORY):
        return "peacockgpt-5" if "peacockgpt-5" in allowed else "peacockgpt-5-fast"

    if intent.type == INTENT_SIMPLE:
        return "peacockgpt-5-fast"

    # A/B for chat on free plan
    if plan == "free" and FLAGS.get("ab_testing") and user_id:
        exp  = AB_EXPERIMENTS.get("model_selection", {})
        h    = int(hashlib.md5(f"model_selection:{user_id}".encode()).hexdigest(), 16)
        var  = "A" if (h % 100) / 100 < exp.get("split", 0.7) else "B"
        key  = exp.get("variants", {}).get(var, "peacockgpt-5-fast")
        return key if key in allowed else "peacockgpt-5-fast"

    return "peacockgpt-5-fast"
