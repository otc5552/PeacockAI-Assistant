"""
services/memory.py — User Memory Engine
Levels: short (current conv) | session | long (persistent)
Author: PeacockAI – Mostafa
"""
import re
from datetime import datetime
from typing import Dict, Optional
from core.config import FLAGS, log
from core.database import get_db, UserMemory


# ── Read ──────────────────────────────────────────────────────────
def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest":
        return {}
    with get_db() as db:
        rows = db.query(UserMemory).filter_by(
            user_id=user_id, scope=scope
        ).order_by(UserMemory.confidence.desc()).all()
    return {r.key: r.value for r in rows}


def mem_get_all(user_id: str) -> Dict[str, Dict[str, str]]:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


# ── Write ─────────────────────────────────────────────────────────
def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0):
    if not user_id or user_id == "guest":
        return
    mid = f"{user_id}:{scope}:{key}"
    with get_db() as db:
        existing = db.query(UserMemory).filter_by(id=mid).first()
        if existing:
            existing.value      = value[:500]
            existing.confidence = confidence
            existing.updated_at = datetime.now().isoformat()
        else:
            db.add(UserMemory(
                id=mid, user_id=user_id, scope=scope,
                key=key, value=value[:500],
                confidence=confidence,
                updated_at=datetime.now().isoformat()
            ))


# ── Delete ────────────────────────────────────────────────────────
def mem_delete(user_id: str, scope: Optional[str] = None,
               key: Optional[str] = None):
    with get_db() as db:
        q = db.query(UserMemory).filter_by(user_id=user_id)
        if scope:
            q = q.filter_by(scope=scope)
        if key:
            q = q.filter_by(key=key)
        q.delete()


# ── Extraction ────────────────────────────────────────────────────
_DOMAIN_MAP = {
    "برمجة":             "software",
    "تطوير":             "software",
    "كود":               "software",
    "python":            "software",
    "javascript":        "software",
    "طب":                "medicine",
    "دكتور":             "medicine",
    "مريض":              "medicine",
    "قانون":             "law",
    "محامي":             "law",
    "اقتصاد":            "economics",
    "مال":               "finance",
    "استثمار":           "finance",
    "تصميم":             "design",
    "ui":                "design",
    "ux":                "design",
    "تعليم":             "education",
    "دراسة":             "education",
    "بيزنس":             "business",
    "شركة":              "business",
    "ذكاء اصطناعي":      "ai",
    "ai":                "ai",
    "machine learning":  "ai",
}

_BEGINNER_SIGNALS = {
    "مبتدئ","مش فاهم","ازاي","ايه معنى","لا أعرف","مش عارف","للمبتدئين",
    "أول مرة","شرح بسيط","من الصفر",
}

_ADVANCED_SIGNALS = {
    "architecture","trade-off","complexity","production","deploy","ci/cd",
    "distributed","microservices","scalable","concurrency","async","thread",
    "optimization","benchmark","profiling","kubernetes","terraform",
}

_PREFER_CODE_SIGNALS = {
    "github","git commit","pull request","merge","branch","refactor",
    "اكتب كود","اعمل function","اعمل class","unit test","integration test",
}


def extract_and_update(user_id: str, message: str, response: str = ""):
    """
    Heuristic extraction of long-term facts from user message.
    Runs asynchronously after each response (via background job).
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return
    low = message.lower()

    # ── Domain detection ──────────────────────────────────────
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            mem_set(user_id, "long", "domain", domain, confidence=0.7)
            break   # first match wins

    # ── Expertise level ───────────────────────────────────────
    if any(w in low for w in _BEGINNER_SIGNALS):
        mem_set(user_id, "long", "level", "beginner", confidence=0.8)
    elif any(w in low for w in _ADVANCED_SIGNALS):
        mem_set(user_id, "long", "level", "advanced", confidence=0.9)

    # ── Prefers code model ────────────────────────────────────
    if any(w in low for w in _PREFER_CODE_SIGNALS):
        mem_set(user_id, "long", "prefers_code_model", "yes", confidence=0.75)

    # ── Language preference ───────────────────────────────────
    eng_words = re.findall(r"\b[a-zA-Z]{4,}\b", message)
    if len(eng_words) >= 4:
        mem_set(user_id, "long", "lang_pref", "bilingual", confidence=0.6)

    # ── Explicit name/role ────────────────────────────────────
    m = re.search(r"(اسمي|أنا|My name is|I am)\s+([A-Za-z\u0600-\u06FF]{2,25})", message)
    if m:
        name = m.group(2).strip()
        if len(name) > 1:
            mem_set(user_id, "long", "preferred_name", name, confidence=0.95)

    # ── Session: last topic ────────────────────────────────────
    if len(message) > 20:
        topic = message[:60].replace("\n", " ")
        mem_set(user_id, "session", "last_topic", topic, confidence=1.0)


# ── Context Builder ───────────────────────────────────────────────
def build_memory_context(user_id: str) -> str:
    """Serialise memory into a concise context string for the prompt."""
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return ""
    long    = mem_get(user_id, "long")
    session = mem_get(user_id, "session")
    parts   = []
    if long:
        parts.append("معلومات عن المستخدم: " + " | ".join(
            f"{k}: {v}" for k, v in long.items()
        ))
    if session:
        parts.append("اهتمامات هذه الجلسة: " + " | ".join(
            f"{k}: {v}" for k, v in session.items()
        ))
    return "\n".join(parts)
