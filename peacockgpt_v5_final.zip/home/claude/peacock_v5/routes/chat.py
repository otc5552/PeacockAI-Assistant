"""
routes/chat.py — Chat streaming endpoint
Author: PeacockAI – Mostafa
"""
import json, time, asyncio
from fastapi import APIRouter, HTTPException, Header, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, validator
from typing import Optional, List
from datetime import datetime

from core.config import MODELS, FLAGS, log
from core.security import verify_token
from core.database import get_db, User, Log
from services.intent import detect_intent, intent_to_model_key
from services.vector_cache import cache_get as vcache_get, cache_set as vcache_set
from services.memory import build_memory_context, extract_and_update
from services.search import hybrid_search, needs_search
from services.context import build_context, post_process
from services.llm import execute, track_cost
from services.usage import check_and_increment, get_adapter, check_rate
from workers.jobs import enqueue

router = APIRouter(tags=["chat"])

# ── Request schema ────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message:           str
    conversation_id:   Optional[str] = None
    model:             Optional[str] = None   # force model override
    user_id:           str = "guest"
    tone:              str = "friendly"
    enable_search:     bool = True
    enable_deep_think: bool = False
    history:           List[dict] = []

    @validator("message")
    def msg_valid(cls, v):
        v = v.strip()
        if not v:      raise ValueError("الرسالة فارغة")
        if len(v) > 8000: raise ValueError("الرسالة طويلة جداً")
        return v

# ── Analytics helper ──────────────────────────────────────────────
async def _track(user_id: str, event: str, meta: dict = None):
    await enqueue("track_analytics", {
        "user_id": user_id, "event": event, "meta": meta or {}
    })

# ── Log to DB ─────────────────────────────────────────────────────
def _log(user_id, model, tokens, cost, latency, cache_hit, success, error="", ab=""):
    try:
        with get_db() as db:
            db.add(Log(
                user_id=user_id, action="chat", model=model,
                tokens=tokens, cost_usd=cost, latency_ms=latency,
                cache_hit=cache_hit, success=success,
                error_msg=error[:300] if error else None,
                ab_variant=ab, created_at=datetime.now().isoformat()
            ))
    except Exception as e:
        log.error(f"Log write error: {e}")

# ── Main endpoint ─────────────────────────────────────────────────
@router.post("/chat/stream")
async def chat_stream(
    req:          ChatRequest,
    request:      Request,
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
    x_token:      Optional[str] = Header(None),
):
    t0 = time.time()
    adapter = get_adapter()
    adapter.record()

    # ── Kill switch ───────────────────────────────────────────
    if FLAGS.get("kill_switch"):
        raise HTTPException(503, "الخدمة متوقفة مؤقتاً للصيانة. عودوا قريباً! 🦚")

    # ── Rate limit ────────────────────────────────────────────
    if not check_rate(request.client.host):
        raise HTTPException(429, "طلبات كثيرة جداً. انتظر دقيقة.")

    # ── Resolve user ──────────────────────────────────────────
    user_id   = req.user_id
    user_plan = "free"
    user_tone = req.tone

    if user_id and user_id != "guest":
        # Verify JWT if provided
        if x_token:
            payload = verify_token(x_token)
            if payload:
                user_id   = payload.get("sub", user_id)
                user_plan = payload.get("plan", "free")

        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                user_plan = u.plan or "free"
                if req.tone == "friendly":
                    user_tone = u.tone or "friendly"

        # Usage enforcement
        ok, reason = check_and_increment(user_id, "msg")
        if not ok:
            raise HTTPException(429, reason)

    # ── 1. Semantic cache ─────────────────────────────────────
    cached_resp = vcache_get(req.message, "chat")
    if cached_resp:
        asyncio.create_task(_track(user_id, "cache_hit"))
        _log(user_id,"cache",0,0.0,int((time.time()-t0)*1000),True,True)

        async def _stream_cached():
            yield f"data: {json.dumps({'type':'meta','model':'PeacockGPT 5','cached':True})}\n\n"
            chunk = ""
            for word in cached_resp.split(" "):
                chunk += word + " "
                if len(chunk) >= 30:
                    yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
                    chunk = ""
                    await asyncio.sleep(0.008)
            if chunk:
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
            yield f"data: {json.dumps({'type':'done','model':'PeacockGPT 5'})}\n\n"

        return StreamingResponse(_stream_cached(), media_type="text/event-stream",
                                 headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

    # ── 2. Intent detection ───────────────────────────────────
    intent    = detect_intent(req.message)
    model_key = req.model or intent_to_model_key(intent, user_plan, user_id)
    model_key = adapter.adapt_model(model_key)    # rate adaptation
    max_tok   = adapter.adapt_tokens(MODELS[model_key].get("max_tokens", 4096))

    log.info(f"Intent: {intent.type} ({intent.confidence:.2f}) → {model_key}")

    # ── 3. Memory context ─────────────────────────────────────
    memory_ctx = build_memory_context(user_id)

    # ── 4. Web search ─────────────────────────────────────────
    search_ctx = ""
    do_search  = (req.enable_search and needs_search(req.message)
                  and not FLAGS.get("kill_search")
                  and intent.type != "code")
    if do_search:
        check_and_increment(user_id, "search")
        asyncio.create_task(_track(user_id, "search_used"))
        try:
            search_ctx = await hybrid_search(req.message)
        except Exception as e:
            log.warning(f"Search failed: {e}")

    # ── 5. Build messages ─────────────────────────────────────
    system, messages = build_context(
        req.message, req.history, user_tone,
        memory_ctx, search_ctx, req.enable_deep_think
    )

    # ── 6. Stream ─────────────────────────────────────────────
    async def generate():
        full_resp  = ""
        actual_key = model_key

        yield f"data: {json.dumps({'type':'meta','model':MODELS[model_key]['display'],'intent':intent.type,'search':bool(search_ctx)})}\n\n"

        try:
            async for chunk, used_key in execute(
                model_key, messages, system,
                x_groq_key or "", x_gemini_key or "",
                max_tok,
            ):
                full_resp  += chunk
                actual_key  = used_key
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"

            # Post-process
            processed = post_process(full_resp, user_tone)

            # Cache
            vcache_set(req.message, processed, actual_key, "chat")

            # Background tasks
            if user_id and user_id != "guest":
                extract_and_update(user_id, req.message, processed)
                await enqueue("analyse_user",       {"user_id": user_id},  delay_s=5)
                await enqueue("generate_suggestions",{"user_id": user_id}, delay_s=10)
                if req.conversation_id:
                    await enqueue("summarise_conv",
                                  {"conv_id": req.conversation_id, "user_id": user_id},
                                  delay_s=30)

            tokens  = len(full_resp.split())
            cost    = track_cost(user_id, actual_key, tokens)
            latency = int((time.time()-t0)*1000)
            _log(user_id, actual_key, tokens, cost, latency, False, True)
            asyncio.create_task(_track(user_id, "msg_sent",
                                       {"model": actual_key, "latency_ms": latency,
                                        "tokens": tokens, "intent": intent.type}))

            log.info(f"✅ Chat | model={actual_key} | user={user_id} | {latency}ms | ${cost:.5f}")
            yield f"data: {json.dumps({'type':'done','model':MODELS[actual_key]['display']})}\n\n"

        except Exception as e:
            latency = int((time.time()-t0)*1000)
            _log(user_id, model_key, 0, 0.0, latency, False, False, str(e))
            asyncio.create_task(_track(user_id,"error",{"err":str(e)[:100]}))
            log.error(f"❌ Chat error: {e}")
            if not full_resp:
                yield f"data: {json.dumps({'type':'error','content':'في مشكلة. تأكد من مفاتيح API في الإعدادات ⚙️'})}\n\n"
            yield f"data: {json.dumps({'type':'done','model':MODELS[model_key]['display']})}\n\n"

    return StreamingResponse(
        generate(), media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"},
    )
