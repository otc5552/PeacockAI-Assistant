"""
core/database.py — SQLAlchemy ORM, works with SQLite (dev) or PostgreSQL (prod)
Author: PeacockAI – Mostafa
"""
from sqlalchemy import (
    create_engine, Column, String, Integer, Float, Text,
    Boolean, ForeignKey, Index, UniqueConstraint, event
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from core.config import DATABASE_URL, USE_POSTGRES, log
import os

# ── Engine ────────────────────────────────────────────────────────
if USE_POSTGRES:
    engine = create_engine(
        DATABASE_URL,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=(os.getenv("SQL_ECHO","false") == "true"),
    )
else:
    # SQLite — enable WAL for concurrent reads
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(conn, _):
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA cache_size=-32000")
        conn.execute("PRAGMA synchronous=NORMAL")

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

@contextmanager
def get_db():
    db: Session = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

# ════════════════════════════════════════════════════════════════
# MODELS
# ════════════════════════════════════════════════════════════════

class User(Base):
    __tablename__ = "users"
    id            = Column(String(64),  primary_key=True)
    name          = Column(String(100), nullable=False)
    email         = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    plan          = Column(String(20),  default="free")
    tone          = Column(String(20),  default="friendly")
    region        = Column(String(20),  default="global")   # egypt | global
    msg_count     = Column(Integer,     default=0)
    img_count     = Column(Integer,     default=0)
    search_count  = Column(Integer,     default=0)
    token_cost    = Column(Float,       default=0.0)
    msg_reset_at  = Column(String(40))
    created_at    = Column(String(40),  nullable=False)
    last_seen     = Column(String(40))
    sub_expires   = Column(String(40))


class Session_(Base):
    __tablename__ = "sessions"
    token      = Column(String(64), primary_key=True)
    user_id    = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(String(40), nullable=False)
    expires_at = Column(String(40), nullable=False)
    __table_args__ = (Index("idx_session_user", "user_id"),)


class Conversation(Base):
    __tablename__ = "conversations"
    id         = Column(String(64), primary_key=True)
    user_id    = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title      = Column(String(200), default="محادثة جديدة")
    model_used = Column(String(50))
    created_at = Column(String(40), nullable=False)
    updated_at = Column(String(40), nullable=False)
    pinned     = Column(Integer,    default=0)
    __table_args__ = (Index("idx_conv_user", "user_id"),)


class Message(Base):
    __tablename__ = "messages"
    id         = Column(String(64), primary_key=True)
    conv_id    = Column(String(64), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role       = Column(String(20), nullable=False)
    content    = Column(Text,       nullable=False)
    model      = Column(String(50))
    tokens     = Column(Integer,    default=0)
    created_at = Column(String(40), nullable=False)
    __table_args__ = (Index("idx_msg_conv", "conv_id"),)


class SemCache(Base):
    __tablename__ = "sem_cache"
    id         = Column(String(32), primary_key=True)
    query_hash = Column(String(32), nullable=False, index=True)
    query_text = Column(String(600))
    response   = Column(Text,       nullable=False)
    embedding  = Column(Text)            # JSON float list
    model_used = Column(String(50))
    ttl        = Column(Float,      nullable=False)
    hits       = Column(Integer,    default=1)
    created_at = Column(Float,      nullable=False)


class UserMemory(Base):
    __tablename__ = "user_memory"
    id         = Column(String(100), primary_key=True)
    user_id    = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    scope      = Column(String(20),  nullable=False)   # short|session|long
    key        = Column(String(80),  nullable=False)
    value      = Column(String(500), nullable=False)
    confidence = Column(Float,       default=1.0)
    updated_at = Column(String(40),  nullable=False)
    __table_args__ = (
        UniqueConstraint("user_id","scope","key"),
        Index("idx_mem_user","user_id"),
    )


class CacheEntry(Base):
    __tablename__ = "cache"
    key        = Column(String(64), primary_key=True)
    value      = Column(Text,       nullable=False)
    hits       = Column(Integer,    default=1)
    created_at = Column(Float,      nullable=False)


class Log(Base):
    __tablename__ = "logs"
    id         = Column(Integer,    primary_key=True, autoincrement=True)
    user_id    = Column(String(64))
    action     = Column(String(40))
    model      = Column(String(50))
    tokens     = Column(Integer,    default=0)
    cost_usd   = Column(Float,      default=0.0)
    latency_ms = Column(Integer,    default=0)
    cache_hit  = Column(Boolean,    default=False)
    success    = Column(Boolean,    default=True)
    error_msg  = Column(Text)
    ab_variant = Column(String(10))
    created_at = Column(String(40), nullable=False)
    __table_args__ = (
        Index("idx_logs_user","user_id"),
        Index("idx_logs_ts","created_at"),
    )


class FeatureFlag(Base):
    __tablename__ = "feature_flags"
    name       = Column(String(50), primary_key=True)
    enabled    = Column(Boolean,    nullable=False, default=True)
    updated_at = Column(String(40), nullable=False)


class Version(Base):
    __tablename__ = "versions"
    id          = Column(Integer,    primary_key=True, autoincrement=True)
    version     = Column(String(20), nullable=False)
    description = Column(Text)
    deployed_at = Column(String(40), nullable=False)


class Analytics(Base):
    __tablename__ = "analytics"
    id         = Column(Integer,    primary_key=True, autoincrement=True)
    user_id    = Column(String(64))
    session_id = Column(String(64))
    event      = Column(String(50), nullable=False)
    meta       = Column(Text)
    created_at = Column(String(40), nullable=False)
    __table_args__ = (
        Index("idx_analytics_user","user_id"),
        Index("idx_analytics_evt","event"),
        Index("idx_analytics_ts","created_at"),
    )


class Job(Base):
    __tablename__ = "jobs"
    id         = Column(String(32),  primary_key=True)
    type       = Column(String(50),  nullable=False)
    payload    = Column(Text)
    status     = Column(String(20),  default="pending")
    attempts   = Column(Integer,     default=0)
    result     = Column(Text)
    created_at = Column(String(40),  nullable=False)
    run_at     = Column(String(40))
    done_at    = Column(String(40))
    __table_args__ = (Index("idx_jobs_status","status"),)


class Onboarding(Base):
    __tablename__ = "onboarding"
    user_id    = Column(String(64), primary_key=True)
    step       = Column(Integer,    default=0)
    completed  = Column(Boolean,    default=False)
    updated_at = Column(String(40), nullable=False)


class Suggestion(Base):
    __tablename__ = "suggestions"
    id         = Column(String(32),  primary_key=True)
    user_id    = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    text       = Column(String(300), nullable=False)
    icon       = Column(String(10),  default="💡")
    score      = Column(Float,       default=1.0)
    used       = Column(Boolean,     default=False)
    created_at = Column(String(40),  nullable=False)
    __table_args__ = (Index("idx_sug_user","user_id"),)


def init_db():
    """Create all tables and seed version."""
    Base.metadata.create_all(engine)
    from core.config import APP_VERSION
    from datetime import datetime
    with get_db() as db:
        existing = db.query(Version).filter_by(version=APP_VERSION).first()
        if not existing:
            db.add(Version(
                version=APP_VERSION,
                description="Production v5 – Modular Architecture + SQLAlchemy + Vector Cache + JWT",
                deployed_at=datetime.now().isoformat()
            ))
    log.info("✅ Database v5 ready")
