"""
core/config.py — Central configuration for PeacockGPT 5
Author: PeacockAI – Mostafa
"""
import os, secrets, logging
from typing import Dict, List

# ── App ───────────────────────────────────────────────────────────
APP_VERSION  = "5.0.0"
APP_NAME     = "PeacockGPT 5"
ENV          = os.getenv("ENV", "development")
SECRET_KEY   = os.getenv("SECRET_KEY", secrets.token_hex(32))
FRONTEND_URL = os.getenv("FRONTEND_URL", "*")

# ── Database ──────────────────────────────────────────────────────
DATABASE_URL  = os.getenv("DATABASE_URL", "sqlite:///peacock.db")   # swap to postgres://...
USE_POSTGRES  = DATABASE_URL.startswith("postgresql")

# ── Logging ───────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("peacock.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("PeacockGPT")

# ── AI Models ─────────────────────────────────────────────────────
MODELS: Dict[str, dict] = {
    "peacockgpt-5-fast": {
        "display":      "PeacockGPT 5 Flash",
        "provider":     "groq",
        "model_id":     "llama-3.1-8b-instant",
        "type":         "fast",
        "plan":         "free",
        "cost_per_1k":  0.00005,
        "max_tokens":   4096,
    },
    "peacockgpt-5": {
        "display":      "PeacockGPT 5",
        "provider":     "groq",
        "model_id":     "llama-3.3-70b-versatile",
        "type":         "powerful",
        "plan":         "free",
        "cost_per_1k":  0.00059,
        "max_tokens":   4096,
    },
    "peacockgpt-5-code": {
        "display":      "PeacockGPT 5 Code",
        "provider":     "groq",
        "model_id":     "qwen-qwq-32b",
        "type":         "code",
        "plan":         "plus",
        "cost_per_1k":  0.0009,
        "max_tokens":   8192,
    },
    "peacockgpt-5-pro": {
        "display":      "PeacockGPT 5 Pro",
        "provider":     "gemini",
        "model_id":     "gemini-2.0-flash",
        "type":         "powerful",
        "plan":         "pro",
        "cost_per_1k":  0.0003,
        "max_tokens":   8192,
    },
}

FALLBACK_CHAIN: Dict[str, str | None] = {
    "peacockgpt-5-pro":  "peacockgpt-5",
    "peacockgpt-5-code": "peacockgpt-5",
    "peacockgpt-5":      "peacockgpt-5-fast",
    "peacockgpt-5-fast": None,
}

# ── Plans & Limits ────────────────────────────────────────────────
PLANS: Dict[str, dict] = {
    "free": {
        "msg": 50,   "img": 5,   "search": 10,
        "max_file_mb": 5,  "reset_h": 24,
        "models": ["peacockgpt-5-fast", "peacockgpt-5"],
    },
    "plus": {
        "msg": 500,  "img": 50,  "search": 100,
        "max_file_mb": 20, "reset_h": 24,
        "models": ["peacockgpt-5-fast", "peacockgpt-5", "peacockgpt-5-code"],
    },
    "pro": {
        "msg": 5000, "img": 200, "search": 500,
        "max_file_mb": 50, "reset_h": 24,
        "models": list(MODELS.keys()),
    },
}

# ── Pricing (FIXED: Pro > Plus) ────────────────────────────────────
PRICING: Dict[str, dict] = {
    "free": {"egp": 0,    "usd": 0,   "label": "مجاني"},
    "plus": {"egp": 700,  "usd": 20,  "label": "Plus"},
    "pro":  {"egp": 1500, "usd": 35,  "label": "Pro"},   # Pro > Plus ✅
}

# ── Feature Flags (Kill Switch) ───────────────────────────────────
FLAGS: Dict[str, bool] = {
    # Core features
    "semantic_cache":    True,
    "user_memory":       True,
    "web_search":        True,
    "image_gen":         True,
    "ab_testing":        True,
    "cost_control":      True,
    "response_postproc": True,
    "prompt_optimizer":  True,
    "background_jobs":   True,
    "rate_adaptation":   True,
    "data_cleanup":      True,
    "analytics":         True,
    "onboarding":        True,
    "suggestion_engine": True,
    "warm_start":        True,
    # Kill switches (all off by default)
    "kill_switch":       False,   # block ALL AI
    "kill_search":       False,   # block web search
    "kill_images":       False,   # block image gen
    "kill_code":         False,   # block code model
}

# ── Cache TTL ────────────────────────────────────────────────────
CACHE_TTL_CHAT   = 1800    # 30 min
CACHE_TTL_SEARCH = 3600    # 1 hour
SIM_THRESHOLD    = 0.88    # cosine similarity minimum

# ── Rate Limits ──────────────────────────────────────────────────
RATE_WINDOW      = 60      # seconds
RATE_MAX_CALLS   = 30      # per window per IP

# ── A/B Experiments ──────────────────────────────────────────────
AB_EXPERIMENTS: Dict[str, dict] = {
    "model_selection": {
        "enabled":  True,
        "variants": {"A": "peacockgpt-5-fast", "B": "peacockgpt-5"},
        "split":    0.7,
    },
}

# ── Persona (Prompts) ─────────────────────────────────────────────
PERSONA: Dict[str, str] = {
    "friendly": """\
أنت PeacockGPT 5، مساعد ذكاء اصطناعي من PeacockAI.
بتتكلم عربي طبيعي وواضح — عامية مصرية خفيفة مع فصحى مبسطة.
شخصيتك: ذكي، ودود، مباشر، عملي.

قواعد المدح:
• مدح خفيف طبيعي فقط لما في فكرة فعلاً كويسة أو مجهود واضح.
• أمثلة: "سؤالك في حتة مهمة"، "فكرتك حلوة"، "دي نقطة دقيقة".
• ممنوع: مدح بدون سبب، تكرار المدح، مبالغة.

أسلوب الرد:
• مبتدئ → أمثلة بسيطة + خطوات واضحة.
• متقدم → عمق مباشر + trade-offs.
• لا تذكر GPT أو Gemini أو Groq أو Llama أو Meta أبداً. أنت PeacockGPT 5 فقط.\
""",
    "formal": """\
أنت PeacockGPT 5، مساعد ذكاء اصطناعي من PeacockAI.
تتحدث بالعربية الفصحى الرسمية المنظمة.
لا تذكر أي نماذج خارجية. أنت PeacockGPT 5.\
""",
    "technical": """\
أنت PeacockGPT 5 Code، مساعد تقني متخصص من PeacockAI.
دقة تقنية عالية، كود نظيف موثق، trade-offs واضحة، أمثلة عملية.
لا تذكر أي نماذج خارجية.\
""",
    "quick": """\
أنت PeacockGPT 5 من PeacockAI. ردود قصيرة مباشرة جداً بدون مقدمات.
لا تذكر أي نماذج خارجية.\
""",
}

# ── Intent Keywords ───────────────────────────────────────────────
INTENT_CODE_KW = {
    "كود","برمج","python","javascript","typescript","sql","debug","خطأ",
    "function","class","api","dockerfile","bash","script","code","regex",
    "خوارزمية","بايثون","جافا","algorithm","deploy","ci/cd","git","docker",
}
INTENT_SEARCH_KW = {
    "ابحث","اخبار","أخبار","طقس","سعر","الان","الآن","اليوم",
    "أحدث","2025","2026","اخر","آخر","جديد","حديث","latest","news",
}
INTENT_IMAGE_KW = {
    "صورة","ارسم","اعمل صورة","أنشئ صورة","generate image","image of",
}
INTENT_MEMORY_KW = {
    "تذكر","احفظ","أنا","مجالي","اسمي","عمري","شغلتي","اهتمامي",
}
INTENT_COMPLEX_KW = {
    "اشرح بالتفصيل","حلل","قارن بين","استراتيجية","خطة عمل",
    "ما الفرق","كيف يعمل","اكتب تقرير","مفصل","دراسة",
}
INTENT_SIMPLE_KW = {
    "شكراً","هلو","مرحباً","اهلاً","عامل ايه","hello","hi","thanks","ok","okay",
}
