"""
workers/jobs.py — Async Background Job Queue
No Redis/Celery needed. Pure asyncio queue.
Author: PeacockAI – Mostafa
"""
import asyncio, json, secrets, time
from datetime import datetime, timedelta
from typing import Callable, Dict
from core.config import FLAGS, log
from core.database import get_db, Job, CacheEntry, UserMemory, Log, Analytics

# ── Registry ──────────────────────────────────────────────────────
_handlers: Dict[str, Callable] = {}
_queue: asyncio.Queue = asyncio.Queue(maxsize=1000)

def handler(job_type: str):
    def decorator(fn):
        _handlers[job_type] = fn
        return fn
    return decorator

# ── Enqueue ───────────────────────────────────────────────────────
async def enqueue(job_type: str, payload: dict = None, delay_s: float = 0):
    if not FLAGS.get("background_jobs"):
        return
    jid    = secrets.token_hex(8)
    run_at = (datetime.now() + timedelta(seconds=delay_s)).isoformat()
    with get_db() as db:
        db.add(Job(
            id=jid, type=job_type,
            payload=json.dumps(payload or {}),
            status="pending", attempts=0,
            created_at=datetime.now().isoformat(),
            run_at=run_at,
        ))
    try:
        _queue.put_nowait({"id": jid, "type": job_type, "payload": payload or {}, "delay": delay_s})
    except asyncio.QueueFull:
        log.warning(f"Job queue full, dropping: {job_type}")

# ── Worker loop ───────────────────────────────────────────────────
async def worker_loop():
    log.info("🔧 Background job worker started")
    while True:
        try:
            job = await asyncio.wait_for(_queue.get(), timeout=30)
        except asyncio.TimeoutError:
            continue

        jid, jtype, payload = job["id"], job["type"], job["payload"]
        delay = job.get("delay", 0)
        if delay > 0:
            await asyncio.sleep(delay)

        with get_db() as db:
            j = db.query(Job).filter_by(id=jid).first()
            if j:
                j.status   = "running"
                j.attempts = (j.attempts or 0) + 1

        try:
            fn = _handlers.get(jtype)
            result = await fn(payload) if fn and asyncio.iscoroutinefunction(fn) \
                     else (fn(payload) if fn else f"no handler for {jtype}")
            with get_db() as db:
                j = db.query(Job).filter_by(id=jid).first()
                if j:
                    j.status  = "done"
                    j.result  = str(result)[:500]
                    j.done_at = datetime.now().isoformat()
            log.info(f"✅ Job done: {jtype}")
        except Exception as e:
            with get_db() as db:
                j = db.query(Job).filter_by(id=jid).first()
                if j:
                    j.status  = "failed"
                    j.result  = str(e)[:500]
                    j.done_at = datetime.now().isoformat()
            log.error(f"❌ Job failed: {jtype}: {e}")

        _queue.task_done()

# ── Scheduler ─────────────────────────────────────────────────────
async def scheduler_loop():
    await asyncio.sleep(15)
    while True:
        try:
            await enqueue("cleanup", {})
            log.info("⏰ Scheduled cleanup enqueued")
        except Exception as e:
            log.error(f"Scheduler error: {e}")
        await asyncio.sleep(3600)   # every 1 hour

# ════════════════════════════════════════════════════════════════
# JOB HANDLERS
# ════════════════════════════════════════════════════════════════

@handler("cleanup")
async def _cleanup(payload: dict):
    from services.vector_cache import cache_delete_expired
    now = time.time()
    with get_db() as db:
        # Expired sem_cache
        r1 = cache_delete_expired()
        # Old plain cache (>2h)
        old_cache = [r for r in db.query(CacheEntry).all() if time.time() - r.created_at > 7200]
        r2 = len(old_cache)
        for r in old_cache: db.delete(r)
        # Old logs (>7 days)
        cutoff7 = (datetime.now() - timedelta(days=7)).isoformat()
        old_logs = db.query(Log).filter(Log.created_at < cutoff7).all()
        r3 = len(old_logs)
        for r in old_logs: db.delete(r)
        # Old analytics (>30 days)
        cutoff30 = (datetime.now() - timedelta(days=30)).isoformat()
        old_an = db.query(Analytics).filter(Analytics.created_at < cutoff30).all()
        r4 = len(old_an)
        for r in old_an: db.delete(r)
        # Stale short-term memory (>24h)
        cutoff_mem = (datetime.now() - timedelta(hours=24)).isoformat()
        old_mem = db.query(UserMemory).filter(
            UserMemory.scope == "short",
            UserMemory.updated_at < cutoff_mem
        ).all()
        r5 = len(old_mem)
        for r in old_mem: db.delete(r)
        # Old done jobs (>3 days)
        cutoff_jobs = (datetime.now() - timedelta(days=3)).isoformat()
        old_jobs = db.query(Job).filter(
            Job.status.in_(["done","failed"]),
            Job.done_at < cutoff_jobs
        ).all()
        r6 = len(old_jobs)
        for r in old_jobs: db.delete(r)
    return f"cleanup: sem={r1} cache={r2} logs={r3} analytics={r4} mem={r5} jobs={r6}"


@handler("summarise_conv")
async def _summarise(payload: dict):
    from services.memory import mem_set
    from core.database import Message
    conv_id = payload.get("conv_id")
    user_id = payload.get("user_id")
    if not conv_id or not user_id:
        return "missing params"
    with get_db() as db:
        rows = db.query(Message).filter_by(conv_id=conv_id).limit(30).all()
    if len(rows) < 4:
        return "too short"
    all_text = " ".join(r.content for r in rows if r.role == "user")
    domain_kw = {
        "برمجة":"software","طب":"medicine","تصميم":"design","اقتصاد":"economics",
        "تعليم":"education","بيزنس":"business","ذكاء اصطناعي":"ai","قانون":"law",
    }
    for kw, domain in domain_kw.items():
        if kw in all_text:
            mem_set(user_id, "session", "last_conv_domain", domain)
            break
    return f"summarised {len(rows)} msgs"


@handler("analyse_user")
async def _analyse(payload: dict):
    from services.memory import mem_set
    user_id = payload.get("user_id")
    if not user_id or user_id == "guest":
        return "skip"
    with get_db() as db:
        rows = db.query(Log).filter(
            Log.user_id == user_id,
            Log.created_at >= (datetime.now() - timedelta(hours=24)).isoformat()
        ).limit(50).all()
    if not rows:
        return "no data"
    code_reqs  = sum(1 for r in rows if r.model and "code" in str(r.model))
    cache_hits = sum(1 for r in rows if r.cache_hit)
    if code_reqs > 5:
        mem_set(user_id, "long", "heavy_coder", "yes", 0.85)
    if cache_hits / max(len(rows),1) > 0.5:
        mem_set(user_id, "long", "repetitive_queries", "yes", 0.7)
    return f"analysed {len(rows)} events"


@handler("generate_suggestions")
async def _gen_suggestions(payload: dict):
    from services.memory import mem_get
    from core.database import Suggestion
    user_id = payload.get("user_id")
    if not user_id or user_id == "guest":
        return "skip"
    long   = mem_get(user_id, "long")
    domain = long.get("domain","")
    DOMAIN_SUGG = {
        "software":  [("💻","اكتب API بـ FastAPI","برمجة"),("🐛","ساعدني في debug","تحليل")],
        "ai":        [("🤖","ما أحدث نماذج AI؟","ذكاء اصطناعي"),("📊","اشرح Transformer","Deep Learning")],
        "medicine":  [("🏥","اشرح أعراض مرض","طب"),("💊","ما الفرق بين الأدوية؟","طب")],
        "business":  [("📈","كيف أبني خطة تسويقية؟","بيزنس"),("💰","اشرح KPIs","إدارة")],
    }
    sugs = DOMAIN_SUGG.get(domain, [
        ("🌐","ما أحدث أخبار التقنية؟","بحث"),
        ("💡","اقترح أفكار مشاريع","إبداع"),
        ("🖼️","أنشئ صورة إبداعية","صور"),
    ])
    with get_db() as db:
        db.query(Suggestion).filter_by(user_id=user_id).delete()
        for txt, icon, _ in sugs[:4]:
            db.add(Suggestion(
                id=secrets.token_hex(6), user_id=user_id,
                text=txt, icon=icon, score=1.0,
                created_at=datetime.now().isoformat()
            ))
    return f"generated {len(sugs)} suggestions"


@handler("track_analytics")
async def _track(payload: dict):
    from core.database import Analytics
    with get_db() as db:
        db.add(Analytics(
            user_id    = payload.get("user_id",""),
            session_id = payload.get("session_id",""),
            event      = payload.get("event",""),
            meta       = json.dumps(payload.get("meta",{})),
            created_at = datetime.now().isoformat(),
        ))
    return "tracked"
