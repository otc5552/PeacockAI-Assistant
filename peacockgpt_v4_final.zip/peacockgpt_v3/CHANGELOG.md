# CHANGELOG — PeacockGPT 5

## v3.0.0 — Final Production
### Added
- Semantic Cache (similarity search, cosine similarity, no external ML)
- User Memory Engine (short/session/long-term)
- Context Builder (assembles system prompt intelligently)
- Prompt Optimizer (compress history, trim long messages)
- Response Post-Processor (remove filler phrases, tone adaptation)
- Feature Flags (runtime toggle without redeploy)
- A/B Testing (deterministic per-user variant assignment)
- Cost Control Engine (degrade under high load, track $ per request)
- Pricing (EGP 700/3000 + USD 20/17 for Plus/Pro)
- Subscription expiry tracking (auto-downgrade)
- Offline indicator + client retry
- Versioning table (deployment history)
- Cache stats endpoint + manual clear
- Memory UI in settings panel
- Cached response badge in chat
- Region field (Egypt vs Global pricing)

## v2.0.0
- Sessions + Auth tokens
- Rate Limiting (sliding window)
- Model Fallback chain
- Logging to DB + file
- Admin dashboard
- Docker + Nginx
- Smart Search (DDG + Wikipedia)

## v1.0.0
- Initial release
- FastAPI backend + HTML frontend
- Basic chat, image gen, conversations
