"""
PeacockGPT 5 — Production Backend v4
Author : PeacockAI – Mostafa (Founder & Lead Developer)
v3 had: Semantic Cache, Memory Engine, Context Builder, Prompt Optimizer,
        Feature Flags, A/B Testing, Cost Control, Pricing EGP+USD.
v4 adds: Background Jobs Queue, Retry/Resilience, Rate Adaptation,
         Data Cleanup (TTL scheduler), Advanced Analytics, Onboarding,
         Suggestion Engine, Warm Start, Kill Switch system.
"""

# ════════════════════════════════════════════════════════════════
# IMPORTS
# ════════════════════════════════════════════════════════════════
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, validator
from typing import Optional, List, Dict, Any
import json, time, hashlib, sqlite3, os, asyncio, httpx
import logging, secrets, math, re
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Optional, List, Dict, Any, Callable
import threading, queue, traceback

# ════════════════════════════════════════════════════════════════
# CONFIG & LOGGING
# ════════════════════════════════════════════════════════════════
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("peacock.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("PeacockGPT")

DB_PATH      = os.getenv("DB_PATH", "peacock.db")
SECRET_KEY   = os.getenv("SECRET_KEY", secrets.token_hex(32))
FRONTEND_URL = os.getenv("FRONTEND_URL", "*")
ENV          = os.getenv("ENV", "development")
APP_VERSION  = "4.0.0"

# ════════════════════════════════════════════════════════════════
# FEATURE FLAGS  (toggle without redeploy)
# ════════════════════════════════════════════════════════════════
FLAGS: Dict[str, bool] = {
    # ── v3 flags ──────────────────────────────────────────────────
    "semantic_cache":    True,   # similarity-based cache lookup
    "user_memory":       True,   # long-term user memory
    "web_search":        True,   # hybrid web search
    "image_gen":         True,   # pollinations image gen
    "ab_testing":        True,   # A/B model experiments
    "cost_control":      True,   # degrade quality under pressure
    "response_postproc": True,   # clean/format AI response
    "offline_retry":     True,   # retry on transient errors
    "prompt_optimizer":  True,   # rewrite/compress prompt
    # ── v4 flags ──────────────────────────────────────────────────
    "background_jobs":   True,   # async background job queue
    "rate_adaptation":   True,   # dynamic quality under load
    "data_cleanup":      True,   # scheduled TTL cleanup
    "analytics":         True,   # advanced event tracking
    "onboarding":        True,   # first-use onboarding flow
    "suggestion_engine": True,   # personalised suggestions
    "warm_start":        True,   # preload cache on boot
    "kill_switch":       False,  # emergency: block all AI calls
    "kill_search":       False,  # emergency: block web search
    "kill_images":       False,  # emergency: block image gen
}

# ════════════════════════════════════════════════════════════════
# A/B TESTING CONFIG
# ════════════════════════════════════════════════════════════════
AB_EXPERIMENTS: Dict[str, dict] = {
    "greeting_style": {
        "enabled": True,
        "variants": {"A": "friendly", "B": "quick"},
        "split": 0.5,   # 50% A, 50% B
    },
    "model_selection": {
        "enabled": True,
        "variants": {"A": "peacockgpt-5-fast", "B": "peacockgpt-5"},
        "split": 0.7,   # 70% fast, 30% powerful
    },
}

def get_ab_variant(experiment: str, user_id: str) -> str:
    """Deterministic variant assignment per user."""
    exp = AB_EXPERIMENTS.get(experiment, {})
    if not exp.get("enabled") or not FLAGS["ab_testing"]:
        return "A"
    h = int(hashlib.md5(f"{experiment}:{user_id}".encode()).hexdigest(), 16)
    return "A" if (h % 100) / 100 < exp["split"] else "B"

# ════════════════════════════════════════════════════════════════
# PRICING  (EGP + USD)
# ════════════════════════════════════════════════════════════════
PRICING = {
    "free":  {"egp": 0,    "usd": 0},
    "plus":  {"egp": 700,  "usd": 20},
    "pro":   {"egp": 3000, "usd": 17},   # Pro cheaper outside Egypt (volume)
}

# ════════════════════════════════════════════════════════════════
# DATABASE
# ════════════════════════════════════════════════════════════════
def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA cache_size=-32000")   # 32 MB page cache
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        -- ── Users ──────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS users (
            id            TEXT PRIMARY KEY,
            name          TEXT NOT NULL,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            plan          TEXT DEFAULT 'free',
            tone          TEXT DEFAULT 'friendly',
            region        TEXT DEFAULT 'global',   -- 'egypt' | 'global'
            msg_count     INTEGER DEFAULT 0,
            img_count     INTEGER DEFAULT 0,
            search_count  INTEGER DEFAULT 0,
            token_cost    REAL    DEFAULT 0.0,     -- cumulative token cost $
            msg_reset_at  TEXT,
            created_at    TEXT NOT NULL,
            last_seen     TEXT,
            sub_expires   TEXT                    -- subscription expiry ISO
        );
        -- ── Sessions ───────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS sessions (
            token      TEXT PRIMARY KEY,
            user_id    TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        -- ── Conversations ──────────────────────────────────────
        CREATE TABLE IF NOT EXISTS conversations (
            id         TEXT PRIMARY KEY,
            user_id    TEXT NOT NULL,
            title      TEXT DEFAULT 'محادثة جديدة',
            model_used TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            pinned     INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        -- ── Messages ───────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS messages (
            id         TEXT PRIMARY KEY,
            conv_id    TEXT NOT NULL,
            role       TEXT NOT NULL,
            content    TEXT NOT NULL,
            model      TEXT,
            tokens     INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(conv_id) REFERENCES conversations(id) ON DELETE CASCADE
        );
        -- ── Semantic Cache ─────────────────────────────────────
        CREATE TABLE IF NOT EXISTS sem_cache (
            id          TEXT PRIMARY KEY,
            query_hash  TEXT NOT NULL,          -- exact MD5 for fast lookup
            query_text  TEXT NOT NULL,
            response    TEXT NOT NULL,
            embedding   TEXT,                   -- JSON float list (simple bag-of-words)
            model_used  TEXT,
            ttl         REAL NOT NULL,          -- unix expiry timestamp
            hits        INTEGER DEFAULT 1,
            created_at  REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sem_hash ON sem_cache(query_hash);
        -- ── User Memory ────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS user_memory (
            id         TEXT PRIMARY KEY,
            user_id    TEXT NOT NULL,
            scope      TEXT NOT NULL,           -- 'short'|'session'|'long'
            key        TEXT NOT NULL,           -- e.g. 'domain', 'level', 'interest'
            value      TEXT NOT NULL,
            confidence REAL DEFAULT 1.0,
            updated_at TEXT NOT NULL,
            UNIQUE(user_id, scope, key)
        );
        CREATE INDEX IF NOT EXISTS idx_mem_user ON user_memory(user_id);
        -- ── Legacy search cache ────────────────────────────────
        CREATE TABLE IF NOT EXISTS cache (
            key        TEXT PRIMARY KEY,
            value      TEXT NOT NULL,
            hits       INTEGER DEFAULT 1,
            created_at REAL NOT NULL
        );
        -- ── Logs ──────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS logs (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    TEXT,
            action     TEXT,
            model      TEXT,
            tokens     INTEGER DEFAULT 0,
            cost_usd   REAL    DEFAULT 0.0,
            latency_ms INTEGER DEFAULT 0,
            cache_hit  INTEGER DEFAULT 0,
            success    INTEGER DEFAULT 1,
            error_msg  TEXT,
            ab_variant TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id);
        CREATE INDEX IF NOT EXISTS idx_logs_ts   ON logs(created_at);
        -- ── Feature flags (runtime overrides) ─────────────────
        CREATE TABLE IF NOT EXISTS feature_flags (
            name       TEXT PRIMARY KEY,
            enabled    INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL
        );
        -- ── Versions ───────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS versions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            version     TEXT NOT NULL,
            description TEXT,
            deployed_at TEXT NOT NULL
        );
        -- ── Analytics Events (v4) ──────────────────────────────
        CREATE TABLE IF NOT EXISTS analytics (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     TEXT,
            session_id  TEXT,
            event       TEXT NOT NULL,     -- 'msg_sent','search_used','img_gen','copy','rate','drop'
            meta        TEXT,              -- JSON extra data
            created_at  TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_analytics_user ON analytics(user_id);
        CREATE INDEX IF NOT EXISTS idx_analytics_evt  ON analytics(event);
        CREATE INDEX IF NOT EXISTS idx_analytics_ts   ON analytics(created_at);
        -- ── Background Jobs Queue (v4) ─────────────────────────
        CREATE TABLE IF NOT EXISTS jobs (
            id          TEXT PRIMARY KEY,
            type        TEXT NOT NULL,     -- 'summarise_conv','update_cache','analyse_user','cleanup'
            payload     TEXT,              -- JSON
            status      TEXT DEFAULT 'pending',   -- pending|running|done|failed
            attempts    INTEGER DEFAULT 0,
            result      TEXT,
            created_at  TEXT NOT NULL,
            run_at      TEXT,
            done_at     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
        CREATE INDEX IF NOT EXISTS idx_jobs_type   ON jobs(type);
        -- ── Onboarding State (v4) ──────────────────────────────
        CREATE TABLE IF NOT EXISTS onboarding (
            user_id     TEXT PRIMARY KEY,
            step        INTEGER DEFAULT 0,
            completed   INTEGER DEFAULT 0,
            updated_at  TEXT NOT NULL
        );
        -- ── Suggestion Cache (v4) ──────────────────────────────
        CREATE TABLE IF NOT EXISTS suggestions (
            id          TEXT PRIMARY KEY,
            user_id     TEXT NOT NULL,
            text        TEXT NOT NULL,
            icon        TEXT DEFAULT '💡',
            score       REAL DEFAULT 1.0,
            used        INTEGER DEFAULT 0,
            created_at  TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sug_user ON suggestions(user_id);
    """)
    # Seed current version
    conn.execute(
        "INSERT OR IGNORE INTO versions(version,description,deployed_at) VALUES(?,?,?)",
        (APP_VERSION, "Production v4 – Jobs + Analytics + Onboarding + Kill-Switch", datetime.now().isoformat())
    )
    conn.commit()
    conn.close()
    log.info("✅ DB v4 ready")

init_db()

# ════════════════════════════════════════════════════════════════
# RUNTIME FLAG LOADER  (DB overrides in-memory flags)
# ════════════════════════════════════════════════════════════════
def load_flags():
    try:
        conn = get_db()
        rows = conn.execute("SELECT name, enabled FROM feature_flags").fetchall()
        conn.close()
        for r in rows:
            FLAGS[r["name"]] = bool(r["enabled"])
    except Exception:
        pass

load_flags()

def set_flag(name: str, enabled: bool):
    FLAGS[name] = enabled
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO feature_flags(name,enabled,updated_at) VALUES(?,?,?)",
        (name, int(enabled), datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

# ════════════════════════════════════════════════════════════════
# KILL SWITCH  (v4 — instant feature disable via flag)
# ════════════════════════════════════════════════════════════════
def kill_check(feature: str) -> bool:
    """Return True if feature is killed (blocked)."""
    return FLAGS.get(f"kill_{feature}", False) or FLAGS.get("kill_switch", False)

# ════════════════════════════════════════════════════════════════
# BACKGROUND JOBS QUEUE  (v4 — pure asyncio, no Redis needed)
# ════════════════════════════════════════════════════════════════
_job_queue: asyncio.Queue = asyncio.Queue(maxsize=500)
_job_running = False

JOB_HANDLERS: Dict[str, Callable] = {}

def job_handler(job_type: str):
    """Decorator to register a job handler."""
    def decorator(fn: Callable):
        JOB_HANDLERS[job_type] = fn
        return fn
    return decorator

async def enqueue_job(job_type: str, payload: dict = None, delay_s: float = 0):
    """Push a job onto the async queue (non-blocking)."""
    if not FLAGS["background_jobs"]:
        return
    job_id = secrets.token_hex(8)
    run_at = (datetime.now() + timedelta(seconds=delay_s)).isoformat()
    conn = get_db()
    conn.execute(
        "INSERT INTO jobs(id,type,payload,status,attempts,created_at,run_at) VALUES(?,?,?,?,0,?,?)",
        (job_id, job_type, json.dumps(payload or {}), "pending",
         datetime.now().isoformat(), run_at)
    )
    conn.commit()
    conn.close()
    try:
        _job_queue.put_nowait({"id": job_id, "type": job_type, "payload": payload or {}})
    except asyncio.QueueFull:
        log.warning("Job queue full, dropping job: " + job_type)

async def _job_worker():
    """Runs forever, processes jobs from queue one at a time."""
    global _job_running
    _job_running = True
    log.info("🔧 Background job worker started")
    while True:
        try:
            job = await asyncio.wait_for(_job_queue.get(), timeout=30)
        except asyncio.TimeoutError:
            continue
        jid, jtype, payload = job["id"], job["type"], job["payload"]
        conn = get_db()
        conn.execute("UPDATE jobs SET status='running', attempts=attempts+1 WHERE id=?", (jid,))
        conn.commit()
        conn.close()
        try:
            handler = JOB_HANDLERS.get(jtype)
            if handler:
                result = await handler(payload) if asyncio.iscoroutinefunction(handler) else handler(payload)
            else:
                result = f"No handler for {jtype}"
            conn = get_db()
            conn.execute("UPDATE jobs SET status='done', result=?, done_at=? WHERE id=?",
                         (str(result)[:500], datetime.now().isoformat(), jid))
            conn.commit()
            conn.close()
            log.info(f"✅ Job done: {jtype} ({jid})")
        except Exception as e:
            conn = get_db()
            conn.execute("UPDATE jobs SET status='failed', result=? WHERE id=?",
                         (str(e)[:500], jid))
            conn.commit()
            conn.close()
            log.error(f"❌ Job failed: {jtype} ({jid}): {e}")
        _job_queue.task_done()

# ── Job handlers ──────────────────────────────────────────────
@job_handler("summarise_conv")
async def _job_summarise(payload: dict):
    """Summarise old conversation and store as memory."""
    conv_id = payload.get("conv_id")
    user_id = payload.get("user_id")
    if not conv_id or not user_id:
        return "missing params"
    conn = get_db()
    rows = conn.execute(
        "SELECT role, content FROM messages WHERE conv_id=? ORDER BY created_at LIMIT 30",
        (conv_id,)
    ).fetchall()
    conn.close()
    if len(rows) < 4:
        return "too short to summarise"
    # Extract key topics from messages (heuristic, no LLM needed)
    all_text = " ".join(r["content"] for r in rows if r["role"] == "user")
    topics = []
    domain_kw = {"برمجة":"software","طب":"medicine","قانون":"law","تصميم":"design","اقتصاد":"economics","تعليم":"education"}
    for kw, domain in domain_kw.items():
        if kw in all_text:
            topics.append(domain)
    if topics:
        mem_set(user_id, "session", "last_conv_topics", ", ".join(topics[:3]))
    return f"summarised {len(rows)} messages"

@job_handler("update_cache")
async def _job_update_cache(payload: dict):
    """Pre-warm cache for a frequently asked query."""
    query = payload.get("query", "")
    if not query:
        return "no query"
    # Just ensure embedding exists in sem_cache
    existing = sem_cache_get(query, "chat")
    return "cache warm" if existing else "cache miss — will populate on next request"

@job_handler("analyse_user")
async def _job_analyse_user(payload: dict):
    """Analyse user behaviour and update long-term memory."""
    user_id = payload.get("user_id")
    if not user_id or user_id == "guest":
        return "skip guest"
    conn = get_db()
    rows = conn.execute(
        "SELECT action, model, cache_hit FROM logs WHERE user_id=? AND created_at>=? ORDER BY created_at DESC LIMIT 50",
        (user_id, (datetime.now()-timedelta(hours=24)).isoformat())
    ).fetchall()
    conn.close()
    if not rows:
        return "no data"
    cache_hits   = sum(1 for r in rows if r["cache_hit"])
    code_reqs    = sum(1 for r in rows if r["model"] and "code" in str(r["model"]))
    power_reqs   = sum(1 for r in rows if r["model"] and "peacockgpt-5" == str(r["model"]))
    if code_reqs > 5:
        mem_set(user_id, "long", "heavy_coder", "yes", 0.85)
    if power_reqs > 10:
        mem_set(user_id, "long", "prefers_powerful_model", "yes", 0.8)
    if cache_hits / max(len(rows),1) > 0.5:
        mem_set(user_id, "long", "repetitive_queries", "yes", 0.7)
    return f"analysed {len(rows)} events"

@job_handler("cleanup")
async def _job_cleanup(payload: dict):
    """Remove expired cache entries and old logs."""
    now = time.time()
    conn = get_db()
    # Expired semantic cache
    r1 = conn.execute("DELETE FROM sem_cache WHERE ttl<?", (now,)).rowcount
    # Expired plain cache (>2h)
    r2 = conn.execute("DELETE FROM cache WHERE created_at<?", (now - 7200,)).rowcount
    # Old logs (>7 days)
    cutoff = (datetime.now() - timedelta(days=7)).isoformat()
    r3 = conn.execute("DELETE FROM logs WHERE created_at<?", (cutoff,)).rowcount
    # Expired sessions
    r4 = conn.execute("DELETE FROM sessions WHERE expires_at<?", (datetime.now().isoformat(),)).rowcount
    # Old analytics (>30 days)
    old_analytics = (datetime.now() - timedelta(days=30)).isoformat()
    r5 = conn.execute("DELETE FROM analytics WHERE created_at<?", (old_analytics,)).rowcount
    # Stale short-term memory (>1 day)
    r6 = conn.execute(
        "DELETE FROM user_memory WHERE scope='short' AND updated_at<?",
        ((datetime.now()-timedelta(hours=24)).isoformat(),)
    ).rowcount
    # Done jobs (>3 days)
    r7 = conn.execute(
        "DELETE FROM jobs WHERE status IN ('done','failed') AND done_at<?",
        ((datetime.now()-timedelta(days=3)).isoformat(),)
    ).rowcount
    conn.commit()
    conn.close()
    return f"cleanup: sem_cache={r1}, cache={r2}, logs={r3}, sessions={r4}, analytics={r5}, mem={r6}, jobs={r7}"

@job_handler("generate_suggestions")
async def _job_suggestions(payload: dict):
    """Build personalised suggestions for a user based on memory."""
    user_id = payload.get("user_id")
    if not user_id or user_id == "guest":
        return "skip"
    long_mem = mem_get(user_id, "long")
    domain   = long_mem.get("domain", "")
    level    = long_mem.get("level", "")
    DOMAIN_SUGGESTIONS = {
        "software":               [("💻","اكتب API بـ FastAPI و PostgreSQL","برمجة خلفية"),
                                   ("🐛","ساعدني في debug مشكلة في كودي","تحليل أخطاء"),
                                   ("⚙️","اشرح Docker Compose بمثال عملي","DevOps")],
        "medicine":               [("🏥","اشرح أعراض مرض السكري","طب"),
                                   ("💊","ما الفرق بين المضادات الحيوية؟","طب")],
        "artificial intelligence":[("🤖","ما أحدث نماذج LLM في 2025؟","AI"),
                                   ("📊","اشرح Transformer architecture","Deep Learning")],
        "education":              [("📚","ساعدني أفهم المشتقات في الرياضيات","تعليم"),
                                   ("✍️","كيف أكتب خطة دراسية فعّالة؟","تعليم")],
        "business":               [("📈","كيف أبني خطة تسويقية لشركتي الناشئة؟","بيزنس"),
                                   ("💰","اشرح مؤشرات الأداء KPIs","إدارة")],
    }
    sugs = DOMAIN_SUGGESTIONS.get(domain, [
        ("🌐","ما أحدث أخبار التقنية؟","بحث"),
        ("💡","اقترح أفكار مشاريع مربحة","إبداع"),
        ("🖼️","أنشئ صورة فنية إبداعية","صور"),
    ])
    conn = get_db()
    # Remove old suggestions for user
    conn.execute("DELETE FROM suggestions WHERE user_id=?", (user_id,))
    for text, icon, _ in sugs[:5]:
        sid = secrets.token_hex(6)
        conn.execute(
            "INSERT INTO suggestions(id,user_id,text,icon,score,created_at) VALUES(?,?,?,?,?,?)",
            (sid, user_id, text if isinstance(text,str) else text, icon, 1.0, datetime.now().isoformat())
        )
    conn.commit()
    conn.close()
    return f"generated {len(sugs)} suggestions"

# ════════════════════════════════════════════════════════════════
# SCHEDULED CLEANUP  (v4 — runs every hour in background)
# ════════════════════════════════════════════════════════════════
async def _scheduler():
    """Periodic tasks: cleanup + analytics aggregation."""
    await asyncio.sleep(10)   # wait 10s after boot
    while True:
        try:
            await enqueue_job("cleanup", {})
            log.info("⏰ Scheduled cleanup job enqueued")
        except Exception as e:
            log.error(f"Scheduler error: {e}")
        await asyncio.sleep(3600)   # every hour

# ════════════════════════════════════════════════════════════════
# WARM START  (v4 — preload common queries into cache on boot)
# ════════════════════════════════════════════════════════════════
_WARM_QUERIES = [
    "ما هو PeacockGPT 5؟",
    "كيف أستخدم PeacockGPT؟",
    "ما الفرق بين الخطط؟",
    "كيف أنشئ صورة؟",
]

async def warm_start():
    """Pre-populate cache with stub answers for common questions."""
    if not FLAGS["warm_start"]:
        return
    WARM_ANSWERS = {
        "ما هو PeacockGPT 5؟":    "أنا PeacockGPT 5، مساعد ذكاء اصطناعي متطور من PeacockAI. اتصمّمت عشان تساعدك في أي حاجة — برمجة، بحث، تحليل، صور، وأكتر!",
        "كيف أستخدم PeacockGPT؟": "بسيطة! اكتب سؤالك في خانة الرسائل واضغط إرسال. ممكن كمان تستخدم زر ➕ لتوليد صور أو رفع ملفات.",
        "ما الفرق بين الخطط؟":    "الخطة المجانية: 50 رسالة يومياً. Plus: 500 رسالة + نماذج أقوى. Pro: 5000 رسالة + كل الميزات.",
        "كيف أنشئ صورة؟":         "اضغط زر ➕ في أسفل الشاشة ثم اختر 'إنشاء صورة'. اكتب وصف الصورة اللي عايزها وPeacockGPT هيعملها لك!",
    }
    for query, answer in WARM_ANSWERS.items():
        sem_cache_set(query, answer, "peacockgpt-5-fast", "chat")
    log.info(f"🔥 Warm start: {len(WARM_ANSWERS)} queries cached")

# ════════════════════════════════════════════════════════════════
# ADVANCED ANALYTICS  (v4)
# ════════════════════════════════════════════════════════════════
async def track_event(user_id: str, event: str, session_id: str = "",
                      meta: dict = None):
    """Non-blocking event tracking."""
    if not FLAGS["analytics"]:
        return
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO analytics(user_id,session_id,event,meta,created_at) VALUES(?,?,?,?,?)",
            (user_id, session_id, event, json.dumps(meta or {}), datetime.now().isoformat())
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.debug(f"Analytics error: {e}")

# ════════════════════════════════════════════════════════════════
# ONBOARDING SYSTEM  (v4)
# ════════════════════════════════════════════════════════════════
ONBOARDING_STEPS = [
    {"step": 1, "title": "أهلاً بك! 🦚", "body": "أنا PeacockGPT 5 — مساعدك الذكي العربي. اسألني أي حاجة!",
     "action": "اسأل سؤالاً", "suggestions": ["ما هو الذكاء الاصطناعي؟","كيف أكتب كود Python؟"]},
    {"step": 2, "title": "جرّب البحث 🔍", "body": "أقدر أبحث في الإنترنت تلقائياً لما تسأل عن أخبار أو معلومات حديثة.",
     "action": "ابحث الآن", "suggestions": ["ما أخبار التقنية اليوم؟","سعر الدولار الآن"]},
    {"step": 3, "title": "أنشئ صورة 🖼️", "body": "استخدم زر ➕ وأنشئ صور إبداعية بالذكاء الاصطناعي مجاناً!",
     "action": "إنشاء صورة", "suggestions": ["مدينة مستقبلية عربية","طبيعة خلابة في مصر"]},
    {"step": 4, "title": "خلصت! 🎉", "body": "أنت جاهز تستخدم PeacockGPT 5 بكل إمكانياته. ابدأ!",
     "action": "ابدأ الآن", "suggestions": []},
]

def get_onboarding(user_id: str) -> Optional[dict]:
    """Return current onboarding step data or None if completed."""
    if not FLAGS["onboarding"] or not user_id or user_id == "guest":
        return None
    conn = get_db()
    row = conn.execute("SELECT step, completed FROM onboarding WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    if not row:
        # First time — create record
        conn = get_db()
        conn.execute("INSERT OR IGNORE INTO onboarding(user_id,step,completed,updated_at) VALUES(?,1,0,?)",
                     (user_id, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        return ONBOARDING_STEPS[0]
    if row["completed"]:
        return None
    step_idx = min(row["step"] - 1, len(ONBOARDING_STEPS) - 1)
    return ONBOARDING_STEPS[step_idx]

def advance_onboarding(user_id: str):
    """Move user to next onboarding step."""
    if not user_id or user_id == "guest":
        return
    conn = get_db()
    row = conn.execute("SELECT step FROM onboarding WHERE user_id=?", (user_id,)).fetchone()
    if not row:
        conn.close()
        return
    next_step = row["step"] + 1
    completed = 1 if next_step > len(ONBOARDING_STEPS) else 0
    conn.execute("UPDATE onboarding SET step=?, completed=?, updated_at=? WHERE user_id=?",
                 (next_step, completed, datetime.now().isoformat(), user_id))
    conn.commit()
    conn.close()

# ════════════════════════════════════════════════════════════════
# SUGGESTION ENGINE  (v4 — personalised per user)
# ════════════════════════════════════════════════════════════════
DEFAULT_SUGGESTIONS = [
    {"icon":"🌐","text":"ما أحدث أخبار التقنية؟","sub":"بحث ذكي"},
    {"icon":"💻","text":"اكتب Todo App بـ HTML/CSS/JS","sub":"كود جاهز"},
    {"icon":"📝","text":"وضّح الفرق بين REST وGraphQL","sub":"شرح تقني"},
    {"icon":"🖼️","text":"أنشئ صورة مدينة عربية مستقبلية","sub":"توليد صورة"},
    {"icon":"🧠","text":"كيف أحسّن تركيزي وإنتاجيتي؟","sub":"تطوير ذات"},
    {"icon":"💰","text":"نصائح لادخار المال وبناء ثروة","sub":"مال وأعمال"},
]

def get_suggestions(user_id: str) -> List[dict]:
    """Return personalised suggestions or defaults."""
    if not FLAGS["suggestion_engine"]:
        return DEFAULT_SUGGESTIONS[:4]
    conn = get_db()
    rows = conn.execute(
        "SELECT text, icon FROM suggestions WHERE user_id=? AND used=0 ORDER BY score DESC LIMIT 4",
        (user_id,)
    ).fetchall()
    conn.close()
    if rows:
        return [{"text": r["text"], "icon": r["icon"], "sub": "مقترح لك"} for r in rows]
    return DEFAULT_SUGGESTIONS[:4]

# ════════════════════════════════════════════════════════════════
# RATE ADAPTATION  (v4 — dynamic quality degradation under load)
# ════════════════════════════════════════════════════════════════
class RateAdapter:
    """Tracks load and adapts model quality dynamically."""
    def __init__(self):
        self._window: List[float] = []
        self._lock = threading.Lock()

    def record(self):
        now = time.time()
        with self._lock:
            self._window = [t for t in self._window if now - t < 60]
            self._window.append(now)

    def rps(self) -> int:
        """Requests per minute in last window."""
        now = time.time()
        with self._lock:
            return len([t for t in self._window if now - t < 60])

    def adaptation_level(self) -> str:
        """none | light | medium | heavy"""
        r = self.rps()
        if r < 60:   return "none"
        if r < 120:  return "light"
        if r < 200:  return "medium"
        return "heavy"

    def adapt_model(self, model_key: str) -> str:
        """Downgrade model based on load level."""
        if not FLAGS["rate_adaptation"]:
            return model_key
        level = self.adaptation_level()
        if level == "none":
            return model_key
        if level == "light" and model_key == "peacockgpt-5-pro":
            return "peacockgpt-5"
        if level in ("medium","heavy"):
            return "peacockgpt-5-fast"
        return model_key

    def adapt_max_tokens(self, default: int = 4096) -> int:
        level = self.adaptation_level()
        if level == "light":   return 2048
        if level == "medium":  return 1024
        if level == "heavy":   return 512
        return default

_rate_adapter = RateAdapter()

# ════════════════════════════════════════════════════════════════
# RESILIENCE / RETRY WRAPPER  (v4 — upgraded from v3 inline retry)
# ════════════════════════════════════════════════════════════════
async def resilient_call(coro_fn: Callable, *args,
                         max_retries: int = 3,
                         base_delay: float = 0.5,
                         label: str = "") -> Any:
    """
    Generic resilient wrapper with exponential back-off.
    Returns result or raises after max_retries.
    """
    last_err = None
    for attempt in range(max_retries):
        try:
            return await coro_fn(*args)
        except Exception as e:
            last_err = e
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)
                log.warning(f"⚠️ Retry {attempt+1}/{max_retries} [{label}]: {e} — wait {delay:.1f}s")
                await asyncio.sleep(delay)
    raise last_err

# ════════════════════════════════════════════════════════════════
# RATE LIMITER
# ════════════════════════════════════════════════════════════════
_rate: Dict[str, List[float]] = defaultdict(list)

def check_rate(ip: str, max_calls: int = 30, window: int = 60) -> bool:
    now  = time.time()
    _rate[ip] = [t for t in _rate[ip] if now - t < window]
    if len(_rate[ip]) >= max_calls:
        return False
    _rate[ip].append(now)
    return True

# ════════════════════════════════════════════════════════════════
# MODELS & PLANS
# ════════════════════════════════════════════════════════════════
MODELS = {
    "peacockgpt-5-fast": {
        "display": "PeacockGPT 5 Flash", "provider": "groq",
        "model_id": "llama-3.1-8b-instant",  "type": "fast",
        "plan": "free",  "cost_per_1k": 0.00005,
    },
    "peacockgpt-5": {
        "display": "PeacockGPT 5",       "provider": "groq",
        "model_id": "llama-3.3-70b-versatile", "type": "powerful",
        "plan": "free",  "cost_per_1k": 0.00059,
    },
    "peacockgpt-5-code": {
        "display": "PeacockGPT 5 Code",  "provider": "groq",
        "model_id": "qwen-qwq-32b",      "type": "code",
        "plan": "plus",  "cost_per_1k": 0.0009,
    },
    "peacockgpt-5-pro": {
        "display": "PeacockGPT 5 Pro",   "provider": "gemini",
        "model_id": "gemini-2.0-flash",  "type": "powerful",
        "plan": "pro",   "cost_per_1k": 0.0003,
    },
}

FALLBACK_CHAIN = {
    "peacockgpt-5-pro":  "peacockgpt-5",
    "peacockgpt-5-code": "peacockgpt-5",
    "peacockgpt-5":      "peacockgpt-5-fast",
    "peacockgpt-5-fast": None,
}

PLANS = {
    "free":  {"msg":50,   "img":5,   "search":10,  "max_file_mb":5,  "reset_h":24,
              "models":["peacockgpt-5-fast","peacockgpt-5"]},
    "plus":  {"msg":500,  "img":50,  "search":100, "max_file_mb":20, "reset_h":24,
              "models":["peacockgpt-5-fast","peacockgpt-5","peacockgpt-5-code"]},
    "pro":   {"msg":5000, "img":200, "search":500, "max_file_mb":50, "reset_h":24,
              "models":list(MODELS.keys())},
}

# ════════════════════════════════════════════════════════════════
# PERSONA ENGINE  (v3 – dynamic level detection)
# ════════════════════════════════════════════════════════════════
PERSONA = {
    "friendly": """\
أنت PeacockGPT 5، مساعد ذكاء اصطناعي من PeacockAI.
بتتكلم عربي طبيعي وواضح — عامية مصرية خفيفة مع فصحى مبسطة.
شخصيتك: ذكي، ودود، مباشر، عملي.

قواعد المدح:
• مدح خفيف طبيعي فقط لما في فكرة فعلاً كويسة أو مجهود واضح.
• أمثلة مقبولة: "سؤالك في حتة مهمة"، "فكرتك حلوة"، "دي نقطة دقيقة".
• ممنوع: مدح بدون سبب، تكرار المدح، "سؤال رائع جداً"، "ممتاز!!" بدون سياق.

أسلوب الرد:
• مبتدئ → أمثلة بسيطة + دعم + خطوات واضحة.
• متقدم → ادخل في العمق مباشرة + trade-offs + best practices.
• معلومات موجودة في الذاكرة → استخدمها بهدوء بدون إعلان.

هوية صارمة: لا تذكر أبداً GPT أو Gemini أو Groq أو Llama أو Meta. أنت PeacockGPT 5 فقط.\
""",
    "formal": """\
أنت PeacockGPT 5، مساعد ذكاء اصطناعي من PeacockAI.
تتحدث بالعربية الفصحى، أسلوب رسمي ومنظم.
لا تذكر أي نماذج خارجية. أنت PeacockGPT 5.\
""",
    "technical": """\
أنت PeacockGPT 5 Code، مساعد تقني متخصص من PeacockAI.
ردودك: دقة تقنية عالية، كود نظيف موثق، trade-offs واضحة، أمثلة عملية.
لا تذكر أي نماذج خارجية.\
""",
    "quick": """\
أنت PeacockGPT 5 من PeacockAI. ردود قصيرة مباشرة جداً بدون مقدمات.
لا تذكر أي نماذج خارجية.\
""",
}

def build_system_prompt(tone: str, memory_ctx: str = "",
                        search_ctx: str = "", deep_think: bool = False) -> str:
    base = PERSONA.get(tone, PERSONA["friendly"])
    parts = [base]
    if memory_ctx:
        parts.append(f"\n\n[ذاكرة المستخدم]\n{memory_ctx}\n[/ذاكرة]")
    if search_ctx:
        parts.append(f"\n\n[معلومات من الإنترنت — استخدمها كمرجع]\n{search_ctx}\n[/بحث]")
    if deep_think:
        parts.append("\n\nفكّر بعمق قبل الإجابة، حلل من زوايا متعددة، اذكر أي تحفظات.")
    return "".join(parts)

# ════════════════════════════════════════════════════════════════
# AI ROUTER  (intent + cost-aware)
# ════════════════════════════════════════════════════════════════
_CODE_KW = {"كود","برمج","python","javascript","typescript","sql","debug",
            "خطأ","function","class","api","dockerfile","bash","script","code",
            "regex","algorithm","خوارزمية","بايثون","جافا"}
_COMPLEX_KW = {"اشرح بالتفصيل","حلل","قارن بين","فسر","استراتيجية","خطة عمل",
               "ما الفرق","كيف يعمل","اكتب تقرير","مفصل","ابحث عن","دراسة"}
_SIMPLE_KW  = {"شكراً","هلو","مرحباً","اهلاً","عامل ايه","hello","hi","thanks"}

def route_request(msg: str, override: Optional[str], plan: str,
                  user_id: str = "") -> str:
    # Respect explicit override if plan allows
    if override and override in MODELS:
        if override in PLANS.get(plan, PLANS["free"])["models"]:
            return override

    low = msg.lower()

    # Cost control: under heavy load degrade to fast model
    if FLAGS["cost_control"] and _system_load_high():
        return "peacockgpt-5-fast"

    # Simple greeting → fast
    if any(k in low for k in _SIMPLE_KW) and len(msg) < 30:
        return "peacockgpt-5-fast"

    # Code intent
    if any(k in low for k in _CODE_KW):
        return "peacockgpt-5-code" if plan in ("plus","pro") else "peacockgpt-5"

    # Complex / long
    if any(k in low for k in _COMPLEX_KW) or len(msg) > 350:
        # A/B: 70% fast / 30% powerful for non-pro users
        if plan == "free" and FLAGS["ab_testing"]:
            variant = get_ab_variant("model_selection", user_id)
            return AB_EXPERIMENTS["model_selection"]["variants"][variant]
        return "peacockgpt-5"

    return "peacockgpt-5-fast"

_load_counter = {"count": 0, "reset": time.time()}

def _system_load_high() -> bool:
    now = time.time()
    if now - _load_counter["reset"] > 60:
        _load_counter["count"] = 0
        _load_counter["reset"] = now
    return _load_counter["count"] > 200   # >200 req/min = high load

def _increment_load():
    _load_counter["count"] += 1

# ════════════════════════════════════════════════════════════════
# SIMPLE EMBEDDING  (no external ML lib needed)
# ════════════════════════════════════════════════════════════════
_STOP = {"من","في","إلى","على","هل","ما","هو","هي","أنا","أنت","كيف",
         "لماذا","ماذا","متى","أين","عن","مع","أو","لو","كان","يكون",
         "a","an","the","is","are","was","were","how","what","why","when","can","do"}

def simple_embed(text: str) -> List[float]:
    """Bag-of-words TF vector (top-50 terms, L2 normalised)."""
    text = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text.lower())
    words = [w for w in text.split() if w not in _STOP and len(w) > 2]
    freq: Dict[str, int] = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    top = sorted(freq.items(), key=lambda x: -x[1])[:50]
    if not top:
        return []
    # Convert to deterministic float vector via hash bucketing (512 dims)
    vec = [0.0] * 512
    for w, cnt in top:
        idx = int(hashlib.md5(w.encode()).hexdigest(), 16) % 512
        vec[idx] += cnt
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v / norm for v in vec]

def cosine_sim(a: List[float], b: List[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    return sum(x*y for x,y in zip(a,b))

# ════════════════════════════════════════════════════════════════
# SEMANTIC CACHE  (v3 – similarity search, not exact-match only)
# ════════════════════════════════════════════════════════════════
SEM_CACHE_TTL       = 7200    # 2 h  for search results
SEM_CACHE_TTL_CHAT  = 1800    # 30 min for AI responses
SEM_CACHE_THRESHOLD = 0.88    # minimum similarity to reuse

def sem_cache_get(query: str, scope: str = "chat") -> Optional[str]:
    if not FLAGS["semantic_cache"]:
        return None
    exact_key = hashlib.md5(f"{scope}:{query}".encode()).hexdigest()
    now = time.time()
    conn = get_db()
    try:
        # 1) Exact hash match (fastest path)
        row = conn.execute(
            "SELECT response, ttl FROM sem_cache WHERE query_hash=? AND ttl>?",
            (exact_key, now)
        ).fetchone()
        if row:
            conn.execute("UPDATE sem_cache SET hits=hits+1 WHERE query_hash=?", (exact_key,))
            conn.commit()
            log.info(f"⚡ SemCache EXACT hit: {query[:40]}")
            return row["response"]

        # 2) Similarity search (more expensive, skip for short queries)
        if len(query) < 15:
            return None
        q_emb = simple_embed(query)
        if not q_emb:
            return None

        candidates = conn.execute(
            "SELECT id, query_hash, embedding, response, ttl FROM sem_cache "
            "WHERE ttl>? ORDER BY created_at DESC LIMIT 200",
            (now,)
        ).fetchall()

        best_sim, best_resp, best_id = 0.0, None, None
        for c in candidates:
            if not c["embedding"]:
                continue
            try:
                c_emb = json.loads(c["embedding"])
                sim   = cosine_sim(q_emb, c_emb)
                if sim > best_sim:
                    best_sim, best_resp, best_id = sim, c["response"], c["id"]
            except Exception:
                pass

        if best_sim >= SEM_CACHE_THRESHOLD and best_resp:
            conn.execute("UPDATE sem_cache SET hits=hits+1 WHERE id=?", (best_id,))
            conn.commit()
            log.info(f"🔍 SemCache SIMILAR hit (sim={best_sim:.2f}): {query[:40]}")
            return best_resp
    except Exception as e:
        log.error(f"sem_cache_get: {e}")
    finally:
        conn.close()
    return None

def sem_cache_set(query: str, response: str, model: str = "", scope: str = "chat"):
    if not FLAGS["semantic_cache"]:
        return
    exact_key = hashlib.md5(f"{scope}:{query}".encode()).hexdigest()
    ttl       = time.time() + (SEM_CACHE_TTL if scope == "search" else SEM_CACHE_TTL_CHAT)
    emb       = simple_embed(query)
    eid       = secrets.token_hex(8)
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO sem_cache(id,query_hash,query_text,response,embedding,model_used,ttl,hits,created_at)"
            " VALUES(?,?,?,?,?,?,?,1,?)",
            (eid, exact_key, query[:500], response, json.dumps(emb), model, ttl, time.time())
        )
        conn.commit()
    except Exception as e:
        log.error(f"sem_cache_set: {e}")
    finally:
        conn.close()

# Legacy search cache (plain key-value)
def cache_get(key: str, ttl: int = 3600) -> Optional[str]:
    conn = get_db()
    try:
        row = conn.execute("SELECT value, created_at FROM cache WHERE key=?", (key,)).fetchone()
        if row and (time.time() - row["created_at"]) < ttl:
            conn.execute("UPDATE cache SET hits=hits+1 WHERE key=?", (key,))
            conn.commit()
            return row["value"]
    except Exception: pass
    finally: conn.close()
    return None

def cache_set(key: str, value: str):
    conn = get_db()
    try:
        conn.execute("INSERT OR REPLACE INTO cache(key,value,hits,created_at) VALUES(?,?,1,?)",
                     (key, value, time.time()))
        conn.commit()
    except Exception: pass
    finally: conn.close()

# ════════════════════════════════════════════════════════════════
# USER MEMORY ENGINE  (3 levels)
# ════════════════════════════════════════════════════════════════
def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    conn = get_db()
    rows = conn.execute(
        "SELECT key, value FROM user_memory WHERE user_id=? AND scope=? ORDER BY confidence DESC",
        (user_id, scope)
    ).fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}

def mem_set(user_id: str, scope: str, key: str, value: str, confidence: float = 1.0):
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO user_memory(id,user_id,scope,key,value,confidence,updated_at)"
        " VALUES(?,?,?,?,?,?,?)",
        (f"{user_id}:{scope}:{key}", user_id, scope, key, value[:500], confidence,
         datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def mem_delete(user_id: str, scope: str = None, key: str = None):
    conn = get_db()
    if key and scope:
        conn.execute("DELETE FROM user_memory WHERE user_id=? AND scope=? AND key=?",
                     (user_id, scope, key))
    elif scope:
        conn.execute("DELETE FROM user_memory WHERE user_id=? AND scope=?", (user_id, scope))
    else:
        conn.execute("DELETE FROM user_memory WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def extract_and_update_memory(user_id: str, message: str, response: str):
    """Heuristic extraction of long-term facts from conversation."""
    if not FLAGS["user_memory"] or user_id == "guest":
        return
    low = message.lower()
    # Domain / field
    domains = {
        "برمجة":    ("domain","software"),
        "طب":       ("domain","medicine"),
        "قانون":    ("domain","law"),
        "اقتصاد":   ("domain","economics"),
        "تصميم":    ("domain","design"),
        "تعليم":    ("domain","education"),
        "بيزنس":    ("domain","business"),
        "ai":       ("domain","artificial intelligence"),
        "ذكاء اصطناعي":("domain","artificial intelligence"),
    }
    for kw, (k, v) in domains.items():
        if kw in low:
            mem_set(user_id, "long", k, v, confidence=0.7)

    # Expertise level signals
    if any(w in low for w in ["مبتدئ","مش فاهم","ازاي","شرح","ايه معنى"]):
        mem_set(user_id, "long", "level", "beginner", 0.8)
    if any(w in low for w in ["architecture","trade-off","complexity","production","deploy","ci/cd"]):
        mem_set(user_id, "long", "level", "advanced", 0.9)

    # Language preference
    if re.search(r"[a-zA-Z]{10,}", message):
        mem_set(user_id, "long", "lang_pref", "bilingual", 0.6)

def build_memory_context(user_id: str) -> str:
    """Serialise all memory levels into a concise context string."""
    if not FLAGS["user_memory"] or user_id == "guest":
        return ""
    long  = mem_get(user_id, "long")
    session = mem_get(user_id, "session")
    parts = []
    if long:
        parts.append("معلومات عن المستخدم: " + " | ".join(f"{k}: {v}" for k,v in long.items()))
    if session:
        parts.append("اهتمامات هذه الجلسة: " + " | ".join(f"{k}: {v}" for k,v in session.items()))
    return "\n".join(parts)

# ════════════════════════════════════════════════════════════════
# PROMPT OPTIMIZER  (compress + rewrite)
# ════════════════════════════════════════════════════════════════
def optimize_prompt(message: str, history: list) -> tuple[str, list]:
    """Trim & rewrite prompt to reduce tokens while preserving intent."""
    if not FLAGS["prompt_optimizer"]:
        return message, history

    # Truncate very long message
    if len(message) > 4000:
        message = message[:4000] + "\n[... الرسالة طويلة جداً، تم اختصارها]"

    # Keep only last N messages from history (sliding window)
    MAX_HIST = 10
    if len(history) > MAX_HIST:
        # Keep first 2 (context anchor) + last (MAX_HIST-2)
        history = history[:2] + history[-(MAX_HIST-2):]

    # Summarise very old long messages (>800 chars) to save tokens
    trimmed = []
    for m in history:
        content = m.get("content", "")
        if len(content) > 800:
            content = content[:400] + " ... " + content[-200:]
        trimmed.append({"role": m["role"], "content": content})

    return message, trimmed

# ════════════════════════════════════════════════════════════════
# CONTEXT BUILDER  (assembles final prompt context)
# ════════════════════════════════════════════════════════════════
def build_context(
    message:    str,
    history:    list,
    tone:       str,
    memory_ctx: str,
    search_ctx: str,
    deep_think: bool,
) -> tuple[str, list]:
    """Builds (system_prompt, messages_list) ready to send to LLM."""
    system = build_system_prompt(tone, memory_ctx, search_ctx, deep_think)

    msg_opt, hist_opt = optimize_prompt(message, history)

    messages = [{"role": "system", "content": system}]
    for h in hist_opt:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            messages.append({"role": h["role"], "content": str(h["content"])[:3000]})
    messages.append({"role": "user", "content": msg_opt})
    return system, messages

# ════════════════════════════════════════════════════════════════
# RESPONSE POST-PROCESSOR
# ════════════════════════════════════════════════════════════════
_FILLER = re.compile(
    r"(بكل\s*تأكيد|وبالطبع|سأكون\s*سعيداً|يسعدني\s*مساعدتك|"
    r"بالتأكيد\s*يمكنني|دعني\s*أوضح لك|حسناً\s*دعني|"
    r"شكراً\s*لسؤالك|سؤال\s*ممتاز\s*جداً|سؤال\s*رائع)[،,!\s]*",
    re.IGNORECASE
)

def post_process(text: str, tone: str) -> str:
    """Remove filler phrases, normalise spacing."""
    if not FLAGS["response_postproc"]:
        return text
    text = _FILLER.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()
    # Quick mode: strip any block longer than 3 sentences if no code block
    if tone == "quick" and "```" not in text and len(text) > 500:
        sentences = re.split(r"(?<=[.؟!])\s+", text)
        text = " ".join(sentences[:4]).strip()
    return text

# ════════════════════════════════════════════════════════════════
# WEB SEARCH  (DuckDuckGo + Wikipedia fallback)
# ════════════════════════════════════════════════════════════════
_SEARCH_TRIGGERS = {
    "ابحث","search","اخبار","أخبار","طقس","سعر","الان","الآن",
    "اليوم","أحدث","2025","2026","اخر","آخر","جديد","حديث",
    "latest","news","current","breaking","تحديث","مباشر",
}

def needs_search(msg: str) -> bool:
    return any(t in msg.lower() for t in _SEARCH_TRIGGERS)

async def smart_search(query: str) -> str:
    if not FLAGS["web_search"]:
        return ""
    cache_key = "search:" + hashlib.md5(query.encode()).hexdigest()
    cached = cache_get(cache_key, 3600)
    if cached:
        log.info(f"Search cache HIT: {query[:40]}")
        return cached

    log.info(f"Search API: {query[:40]}")
    result = ""
    try:
        async with httpx.AsyncClient(timeout=8, follow_redirects=True) as client:
            # Primary: DuckDuckGo instant answers
            r = await client.get(
                "https://api.duckduckgo.com/",
                params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
                headers={"User-Agent": "PeacockGPT/3.0"},
            )
            d = r.json()
            parts = []
            if d.get("Answer"):
                parts.append(f"✅ {d['Answer']}")
            if d.get("Abstract"):
                parts.append(f"📌 {d['Abstract']}")
                if d.get("AbstractSource"):
                    parts.append(f"المصدر: {d['AbstractSource']}")
            for t in (d.get("RelatedTopics") or [])[:4]:
                if isinstance(t, dict) and t.get("Text"):
                    parts.append(f"• {t['Text'][:200]}")
            result = "\n".join(parts)

            # Fallback: Arabic Wikipedia
            if not result:
                r2 = await client.get(
                    f"https://ar.wikipedia.org/api/rest_v1/page/summary/{query.replace(' ','_')}",
                    headers={"User-Agent": "PeacockGPT/3.0"},
                )
                if r2.status_code == 200:
                    wiki = r2.json()
                    result = f"📚 {wiki.get('extract','')[:600]}"
    except Exception as e:
        log.warning(f"Search error: {e}")

    final = result or "لم أجد نتائج محددة. سأجيب من معرفتي."
    cache_set(cache_key, final)
    return final

# ════════════════════════════════════════════════════════════════
# LLM CALLS
# ════════════════════════════════════════════════════════════════
async def call_groq(model_id: str, messages: list, api_key: str, stream: bool = True):
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model": model_id, "messages": messages,
               "max_tokens": 4096, "temperature": 0.7, "stream": stream}
    async with httpx.AsyncClient(timeout=90) as client:
        if stream:
            async with client.stream(
                "POST", "https://api.groq.com/openai/v1/chat/completions",
                headers=headers, json=payload
            ) as r:
                if r.status_code != 200:
                    raise Exception(f"Groq {r.status_code}")
                async for line in r.aiter_lines():
                    if line.startswith("data: ") and line != "data: [DONE]":
                        try:
                            chunk = json.loads(line[6:])
                            delta = chunk["choices"][0]["delta"].get("content", "")
                            if delta:
                                yield delta
                        except Exception:
                            pass
        else:
            r = await client.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers=headers, json=payload
            )
            yield r.json()["choices"][0]["message"]["content"]

async def call_gemini(model_id: str, messages: list, api_key: str, system: str):
    contents = [
        {"role": "user" if m["role"] == "user" else "model",
         "parts": [{"text": m["content"]}]}
        for m in messages if m["role"] != "system"
    ]
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model_id}:generateContent?key={api_key}")
    payload = {
        "contents": contents,
        "systemInstruction": {"parts": [{"text": system}]},
        "generationConfig": {"maxOutputTokens": 4096, "temperature": 0.7},
    }
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(url, json=payload)
        if r.status_code != 200:
            raise Exception(f"Gemini {r.status_code}: {r.text[:200]}")
        yield r.json()["candidates"][0]["content"]["parts"][0]["text"]

# ════════════════════════════════════════════════════════════════
# FALLBACK EXECUTOR  (with offline retry)
# ════════════════════════════════════════════════════════════════
async def execute_with_fallback(
    model_key: str, messages: list, system: str,
    groq_key: str, gemini_key: str,
):
    current, attempts = model_key, 0
    while current and attempts < 4:
        cfg = MODELS.get(current)
        if not cfg:
            break
        retries = 2 if FLAGS["offline_retry"] else 1
        for attempt in range(retries):
            try:
                log.info(f"LLM: {current} (attempt {attempt+1})")
                if cfg["provider"] == "groq" and groq_key:
                    async for chunk in call_groq(cfg["model_id"], messages, groq_key, True):
                        yield chunk, current
                    return
                elif cfg["provider"] == "gemini" and gemini_key:
                    async for chunk in call_gemini(cfg["model_id"], messages, gemini_key, system):
                        yield chunk, current
                    return
                else:
                    raise Exception(f"No key for {cfg['provider']}")
            except Exception as e:
                log.warning(f"Model {current} attempt {attempt+1} failed: {e}")
                if attempt < retries - 1:
                    await asyncio.sleep(0.5 * (attempt + 1))
        current = FALLBACK_CHAIN.get(current)
        attempts += 1
        await asyncio.sleep(0.3)
    raise Exception("All models exhausted")

# ════════════════════════════════════════════════════════════════
# USAGE & COST CONTROL
# ════════════════════════════════════════════════════════════════
def check_usage(user_id: str, action: str) -> tuple[bool, str]:
    conn = get_db()
    row = conn.execute(
        "SELECT plan, msg_count, img_count, search_count, msg_reset_at, sub_expires FROM users WHERE id=?",
        (user_id,)
    ).fetchone()
    if not row:
        conn.close()
        return True, ""   # guest: no enforcement

    # Check subscription expiry
    if row["sub_expires"]:
        if datetime.now() > datetime.fromisoformat(row["sub_expires"]):
            # Downgrade to free silently
            conn.execute("UPDATE users SET plan='free' WHERE id=?", (user_id,))
            conn.commit()

    plan   = row["plan"]
    limits = PLANS.get(plan, PLANS["free"])
    now    = datetime.now()

    # Auto-reset every 24h
    if row["msg_reset_at"]:
        reset_dt = datetime.fromisoformat(row["msg_reset_at"])
        if now - reset_dt > timedelta(hours=limits["reset_h"]):
            conn.execute(
                "UPDATE users SET msg_count=0,img_count=0,search_count=0,msg_reset_at=? WHERE id=?",
                (now.isoformat(), user_id)
            )
            conn.commit()
            row = conn.execute(
                "SELECT plan,msg_count,img_count,search_count FROM users WHERE id=?",
                (user_id,)
            ).fetchone()

    col_map = {"msg":"msg_count","img":"img_count","search":"search_count"}
    lim_map = {"msg":"msg","img":"img","search":"search"}
    col = col_map.get(action)
    lim = limits.get(lim_map.get(action,"msg"), 9999)

    if col and row[col] >= lim:
        conn.close()
        prices = PRICING.get(plan, {})
        return False, (
            f"وصلت لحد {lim} {action} يومياً.\n"
            f"ترقية لـ Pro: {prices.get('egp',0)} جنيه / {prices.get('usd',0)}$"
        )

    update_map = {
        "msg":    "UPDATE users SET msg_count=msg_count+1, last_seen=? WHERE id=?",
        "img":    "UPDATE users SET img_count=img_count+1 WHERE id=?",
        "search": "UPDATE users SET search_count=search_count+1 WHERE id=?",
    }
    sql = update_map.get(action)
    if sql:
        if action == "msg":
            conn.execute(sql, (now.isoformat(), user_id))
        else:
            conn.execute(sql, (user_id,))
    conn.commit()
    conn.close()
    return True, ""

def track_cost(user_id: str, model_key: str, token_count: int):
    cfg = MODELS.get(model_key, {})
    cost = cfg.get("cost_per_1k", 0) * token_count / 1000
    conn = get_db()
    conn.execute("UPDATE users SET token_cost=token_cost+? WHERE id=?", (cost, user_id))
    conn.commit()
    conn.close()
    return cost

def do_log(user_id: str, action: str, model: str = "", tokens: int = 0,
           cost: float = 0.0, latency: int = 0, cache_hit: bool = False,
           success: bool = True, error: str = "", ab: str = ""):
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO logs(user_id,action,model,tokens,cost_usd,latency_ms,"
            "cache_hit,success,error_msg,ab_variant,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (user_id, action, model, tokens, cost, latency,
             int(cache_hit), int(success), error, ab, datetime.now().isoformat())
        )
        conn.commit()
        conn.close()
    except Exception as e:
        log.error(f"Log error: {e}")

# ════════════════════════════════════════════════════════════════
# SESSION MANAGER
# ════════════════════════════════════════════════════════════════
def create_session(user_id: str) -> str:
    token   = secrets.token_urlsafe(32)
    now     = datetime.now().isoformat()
    expires = (datetime.now() + timedelta(days=30)).isoformat()
    conn    = get_db()
    conn.execute("INSERT INTO sessions VALUES(?,?,?,?)", (token, user_id, now, expires))
    conn.commit()
    conn.close()
    return token

def get_session(token: str) -> Optional[dict]:
    if not token:
        return None
    conn = get_db()
    row = conn.execute(
        "SELECT s.user_id,u.name,u.plan,u.tone,u.email,u.region FROM sessions s "
        "JOIN users u ON s.user_id=u.id "
        "WHERE s.token=? AND s.expires_at>?",
        (token, datetime.now().isoformat())
    ).fetchone()
    conn.close()
    return dict(row) if row else None

# ════════════════════════════════════════════════════════════════
# FASTAPI APP
# ════════════════════════════════════════════════════════════════
app = FastAPI(
    title="PeacockGPT 5 API",
    version=APP_VERSION,
    docs_url="/docs" if ENV == "development" else None,
    redoc_url=None,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL] if FRONTEND_URL != "*" else ["*"],
    allow_methods=["GET","POST","DELETE","PATCH","PUT"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    """Launch background systems on boot."""
    asyncio.create_task(_job_worker())
    asyncio.create_task(_scheduler())
    asyncio.create_task(warm_start())
    log.info("🚀 PeacockGPT v4 started — jobs, scheduler, warm-start active")

# ════════════════════════════════════════════════════════════════
# SCHEMAS
# ════════════════════════════════════════════════════════════════
class ChatRequest(BaseModel):
    message:           str
    conversation_id:   Optional[str] = None
    model:             Optional[str] = None
    user_id:           str = "guest"
    tone:              str = "friendly"
    enable_search:     bool = True
    enable_deep_think: bool = False
    history:           List[dict] = []

    @validator("message")
    def msg_not_empty(cls, v):
        v = v.strip()
        if not v:             raise ValueError("الرسالة فارغة")
        if len(v) > 8000:     raise ValueError("الرسالة طويلة جداً (max 8000 حرف)")
        return v

class UserRegister(BaseModel):
    name:     str
    email:    str
    password: str
    region:   str = "global"     # 'egypt' | 'global'

    @validator("password")
    def pw_len(cls, v):
        if len(v) < 6: raise ValueError("كلمة المرور 6 أحرف على الأقل")
        return v

class UserLogin(BaseModel):
    email:    str
    password: str

class ConversationCreate(BaseModel):
    user_id: str
    title:   str = "محادثة جديدة"

class MemoryUpdate(BaseModel):
    user_id: str
    scope:   str
    key:     str
    value:   str

class FlagUpdate(BaseModel):
    name:    str
    enabled: bool

# ════════════════════════════════════════════════════════════════
# ROUTES — SYSTEM
# ════════════════════════════════════════════════════════════════
@app.get("/")
def root():
    return {"app": "PeacockGPT 5", "by": "PeacockAI", "version": APP_VERSION, "status": "ok"}

@app.get("/health")
def health():
    return {"status": "healthy", "ts": datetime.now().isoformat(), "flags": FLAGS}

@app.get("/version")
def get_version():
    conn = get_db()
    rows = conn.execute("SELECT * FROM versions ORDER BY id DESC LIMIT 5").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/models")
def get_models():
    return [{"id":k,"name":v["display"],"type":v["type"],"plan":v["plan"]}
            for k,v in MODELS.items()]

@app.get("/plans")
def get_plans():
    result = {}
    for plan, cfg in PLANS.items():
        result[plan] = {**cfg, "pricing": PRICING.get(plan, {})}
    return result

@app.get("/personas")
def get_personas():
    return [{"id": k, "label": {"friendly":"ودود","formal":"رسمي","technical":"تقني","quick":"سريع"}[k]}
            for k in PERSONA]

# ════════════════════════════════════════════════════════════════
# ROUTES — AUTH
# ════════════════════════════════════════════════════════════════
@app.post("/users/register", status_code=201)
def register(user: UserRegister):
    uid     = hashlib.md5(user.email.lower().encode()).hexdigest()
    pw_hash = hashlib.sha256(user.password.encode()).hexdigest()
    conn    = get_db()
    try:
        conn.execute(
            "INSERT INTO users(id,name,email,password_hash,plan,tone,region,created_at,msg_reset_at)"
            " VALUES(?,?,?,?,'free','friendly',?,?,?)",
            (uid, user.name.strip(), user.email.lower().strip(), pw_hash,
             user.region, datetime.now().isoformat(), datetime.now().isoformat())
        )
        conn.commit()
        token = create_session(uid)
        log.info(f"Register: {user.email}")
        return {"id":uid,"name":user.name,"plan":"free","tone":"friendly",
                "region":user.region,"token":token}
    except sqlite3.IntegrityError:
        raise HTTPException(400, "البريد الإلكتروني مستخدم بالفعل")
    finally:
        conn.close()

@app.post("/users/login")
def login(data: UserLogin):
    pw_hash = hashlib.sha256(data.password.encode()).hexdigest()
    conn    = get_db()
    row     = conn.execute(
        "SELECT id,name,plan,tone,region,msg_count,img_count,search_count FROM users "
        "WHERE email=? AND password_hash=?",
        (data.email.lower().strip(), pw_hash)
    ).fetchone()
    conn.close()
    if not row:
        raise HTTPException(401, "بيانات الدخول غلط")
    token = create_session(row["id"])
    log.info(f"Login: {data.email}")
    return dict(row) | {"token": token}

@app.post("/users/logout")
def logout(x_token: Optional[str] = Header(None)):
    if x_token:
        conn = get_db()
        conn.execute("DELETE FROM sessions WHERE token=?", (x_token,))
        conn.commit()
        conn.close()
    return {"ok": True}

@app.get("/users/me")
def get_me(x_token: Optional[str] = Header(None)):
    u = get_session(x_token)
    if not u:
        raise HTTPException(401, "غير مسجل")
    return u

@app.patch("/users/tone")
def update_tone(data: dict):
    tone = data.get("tone","friendly")
    uid  = data.get("user_id","")
    if tone not in PERSONA:
        raise HTTPException(400, "أسلوب غير صحيح")
    conn = get_db()
    conn.execute("UPDATE users SET tone=? WHERE id=?", (tone, uid))
    conn.commit()
    conn.close()
    return {"ok": True, "tone": tone}

@app.patch("/users/subscription")
def update_subscription(data: dict):
    """Called by payment webhook to activate plan."""
    uid     = data.get("user_id")
    plan    = data.get("plan","pro")
    months  = data.get("months", 1)
    expires = (datetime.now() + timedelta(days=30*months)).isoformat()
    conn    = get_db()
    conn.execute("UPDATE users SET plan=?, sub_expires=? WHERE id=?", (plan, expires, uid))
    conn.commit()
    conn.close()
    return {"ok": True, "plan": plan, "expires": expires}

# ════════════════════════════════════════════════════════════════
# ROUTES — CHAT (STREAMING)
# ════════════════════════════════════════════════════════════════
@app.post("/chat/stream")
async def chat_stream(
    req:          ChatRequest,
    request:      Request,
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
    x_token:      Optional[str] = Header(None),
):
    t0 = time.time()
    _increment_load()
    _rate_adapter.record()

    # ── Kill switch check ────────────────────────────────────
    if kill_check("ai"):
        raise HTTPException(503, "الخدمة متوقفة مؤقتاً للصيانة. عودوا قريباً! 🦚")

    # Rate limit
    if not check_rate(request.client.host, 30, 60):
        raise HTTPException(429, "طلبات كثيرة جداً، انتظر دقيقة.")

    # Usage enforcement
    user_id = req.user_id
    if user_id and user_id != "guest":
        ok, reason = check_usage(user_id, "msg")
        if not ok:
            raise HTTPException(429, reason)

    # Resolve user plan & tone
    user_plan = "free"
    if user_id and user_id != "guest":
        conn = get_db()
        row  = conn.execute("SELECT plan, tone FROM users WHERE id=?", (user_id,)).fetchone()
        conn.close()
        if row:
            user_plan = row["plan"]
            if req.tone == "friendly":
                req.tone = row["tone"] or "friendly"

    # ── 1. Semantic cache check ──────────────────────────────
    cache_resp = sem_cache_get(req.message, "chat")
    if cache_resp:
        asyncio.create_task(track_event(user_id, "cache_hit", meta={"query": req.message[:60]}))
        do_log(user_id, "chat", "cache", 0, 0.0,
               int((time.time()-t0)*1000), True, True)
        async def cached_gen():
            yield f"data: {json.dumps({'type':'meta','model':'PeacockGPT 5','cached':True})}\n\n"
            words = cache_resp.split(" ")
            chunk = ""
            for w in words:
                chunk += w + " "
                if len(chunk) > 30:
                    yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
                    chunk = ""
                    await asyncio.sleep(0.01)
            if chunk:
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
            yield f"data: {json.dumps({'type':'done','model':'PeacockGPT 5'})}\n\n"
        return StreamingResponse(cached_gen(), media_type="text/event-stream",
                                 headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

    # ── 2. Route model + Rate Adaptation ────────────────────
    model_key     = route_request(req.message, req.model, user_plan, user_id)
    model_key     = _rate_adapter.adapt_model(model_key)
    adapted_tokens = _rate_adapter.adapt_max_tokens(4096)

    # ── 3. Memory context ────────────────────────────────────
    memory_ctx = build_memory_context(user_id)

    # ── 4. Web search (with kill switch) ─────────────────────
    search_ctx = ""
    if req.enable_search and needs_search(req.message) and not kill_check("search"):
        if user_id and user_id != "guest":
            check_usage(user_id, "search")
        asyncio.create_task(track_event(user_id, "search_used", meta={"query": req.message[:60]}))
        try:
            search_ctx = await resilient_call(smart_search, req.message,
                                              max_retries=2, base_delay=0.3, label="search")
        except Exception as e:
            log.warning(f"Search failed after retries: {e}")

    # ── 5. Build context ─────────────────────────────────────
    system, messages = build_context(
        req.message, req.history, req.tone,
        memory_ctx, search_ctx, req.enable_deep_think
    )

    # ── 6. Advance onboarding if applicable ──────────────────
    if user_id and user_id != "guest":
        advance_onboarding(user_id)

    # A/B variant tracking
    ab_var = get_ab_variant("greeting_style", user_id)

    async def generate():
        full_resp   = ""
        actual_key  = model_key
        cost        = 0.0

        yield f"data: {json.dumps({'type':'meta','model':MODELS[model_key]['display'],'search':bool(search_ctx),'load':_rate_adapter.adaptation_level()})}\n\n"

        try:
            async for chunk, used_key in execute_with_fallback(
                model_key, messages, system,
                x_groq_key or "", x_gemini_key or ""
            ):
                full_resp  += chunk
                actual_key  = used_key
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"

            # Post-process
            processed = post_process(full_resp, req.tone)

            # Background: update memory + enqueue analysis job
            if user_id and user_id != "guest":
                extract_and_update_memory(user_id, req.message, processed)
                await enqueue_job("analyse_user",     {"user_id": user_id}, delay_s=5)
                await enqueue_job("generate_suggestions", {"user_id": user_id}, delay_s=10)
                if req.conversation_id:
                    await enqueue_job("summarise_conv",
                                      {"conv_id": req.conversation_id, "user_id": user_id},
                                      delay_s=30)

            # Cache the response
            sem_cache_set(req.message, processed, actual_key, "chat")

            tokens  = len(full_resp.split())
            cost    = track_cost(user_id, actual_key, tokens)
            latency = int((time.time()-t0)*1000)
            do_log(user_id,"chat",actual_key,tokens,cost,latency,False,True,"",ab_var)
            asyncio.create_task(track_event(user_id, "msg_sent",
                                            meta={"model": actual_key, "latency_ms": latency,
                                                  "tokens": tokens, "load": _rate_adapter.adaptation_level()}))

            log.info(f"Chat OK | model={actual_key} | user={user_id} | {latency}ms | ${cost:.5f} | load={_rate_adapter.rps()} rpm")
            yield f"data: {json.dumps({'type':'done','model':MODELS[actual_key]['display']})}\n\n"

        except Exception as e:
            latency = int((time.time()-t0)*1000)
            do_log(user_id,"chat",model_key,0,0.0,latency,False,False,str(e),ab_var)
            asyncio.create_task(track_event(user_id, "error", meta={"error": str(e)[:100]}))
            log.error(f"Chat ERROR: {e}")
            if not full_resp:
                yield f"data: {json.dumps({'type':'error','content':'في مشكلة في الاتصال. تأكد من مفاتيح API في الإعدادات ⚙️'})}\n\n"
            yield f"data: {json.dumps({'type':'done','model':MODELS[model_key]['display']})}\n\n"

    return StreamingResponse(
        generate(), media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"}
    )

# ════════════════════════════════════════════════════════════════
# ROUTES — IMAGE
# ════════════════════════════════════════════════════════════════
@app.post("/image/generate")
async def gen_image(req: dict):
    if not FLAGS["image_gen"]:
        raise HTTPException(503, "توليد الصور متوقف مؤقتاً")
    uid    = req.get("user_id","guest")
    prompt = req.get("prompt","").strip()
    if not prompt:
        raise HTTPException(400, "وصف الصورة مطلوب")
    if uid and uid != "guest":
        ok, reason = check_usage(uid, "img")
        if not ok:
            raise HTTPException(429, reason)
    seed = int(time.time())
    url  = (f"https://image.pollinations.ai/prompt/"
            f"{prompt.replace(' ','%20')},high_quality,detailed"
            f"?width=768&height=512&nologo=true&seed={seed}&model=flux")
    do_log(uid, "image", "pollinations")
    return {"url": url, "model": "PeacockGPT Image", "prompt": prompt}

# ════════════════════════════════════════════════════════════════
# ROUTES — CONVERSATIONS & MESSAGES
# ════════════════════════════════════════════════════════════════
@app.get("/conversations/{user_id}")
def get_conversations(user_id: str):
    conn = get_db()
    rows = conn.execute(
        "SELECT id,title,model_used,updated_at,pinned FROM conversations "
        "WHERE user_id=? ORDER BY pinned DESC, updated_at DESC LIMIT 100",
        (user_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/conversations", status_code=201)
def create_conversation(data: ConversationCreate):
    cid  = hashlib.md5(f"{data.user_id}{time.time()}".encode()).hexdigest()
    now  = datetime.now().isoformat()
    conn = get_db()
    conn.execute(
        "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
        (cid, data.user_id, data.title[:80], now, now)
    )
    conn.commit()
    conn.close()
    return {"id": cid, "title": data.title}

@app.patch("/conversations/{conv_id}")
def patch_conversation(conv_id: str, data: dict):
    conn = get_db()
    now  = datetime.now().isoformat()
    if "title"  in data: conn.execute("UPDATE conversations SET title=?,updated_at=? WHERE id=?",   (data["title"][:80], now, conv_id))
    if "pinned" in data: conn.execute("UPDATE conversations SET pinned=? WHERE id=?",               (int(data["pinned"]), conv_id))
    conn.commit(); conn.close()
    return {"ok": True}

@app.delete("/conversations/{conv_id}")
def delete_conversation(conv_id: str):
    conn = get_db()
    conn.execute("DELETE FROM conversations WHERE id=?", (conv_id,))
    conn.execute("DELETE FROM messages WHERE conv_id=?", (conv_id,))
    conn.commit(); conn.close()
    return {"ok": True}

@app.get("/messages/{conv_id}")
def get_messages(conv_id: str):
    conn = get_db()
    rows = conn.execute(
        "SELECT id,role,content,model,created_at FROM messages "
        "WHERE conv_id=? ORDER BY created_at",
        (conv_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/messages")
def save_message(data: dict):
    mid  = hashlib.md5(f"{data.get('conv_id')}{time.time()}".encode()).hexdigest()
    now  = datetime.now().isoformat()
    conn = get_db()
    conn.execute(
        "INSERT INTO messages(id,conv_id,role,content,model,created_at) VALUES(?,?,?,?,?,?)",
        (mid, data["conv_id"], data["role"], data["content"], data.get("model",""), now)
    )
    conn.execute(
        "UPDATE conversations SET updated_at=?,model_used=? WHERE id=?",
        (now, data.get("model",""), data["conv_id"])
    )
    conn.commit(); conn.close()
    return {"id": mid}

# ════════════════════════════════════════════════════════════════
# ROUTES — MEMORY
# ════════════════════════════════════════════════════════════════
@app.get("/memory/{user_id}")
def get_memory(user_id: str, scope: Optional[str] = None):
    if scope:
        return mem_get(user_id, scope)
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }

@app.post("/memory")
def update_memory(data: MemoryUpdate):
    if data.scope not in ("short","session","long"):
        raise HTTPException(400, "scope غير صحيح")
    mem_set(data.user_id, data.scope, data.key, data.value)
    return {"ok": True}

@app.delete("/memory/{user_id}")
def clear_memory(user_id: str, scope: Optional[str] = None, key: Optional[str] = None):
    mem_delete(user_id, scope, key)
    return {"ok": True}

# ════════════════════════════════════════════════════════════════
# ROUTES — STATS & DASHBOARD
# ════════════════════════════════════════════════════════════════
@app.get("/stats/{user_id}")
def get_stats(user_id: str):
    conn = get_db()
    row  = conn.execute(
        "SELECT msg_count,img_count,search_count,plan,msg_reset_at,token_cost,sub_expires "
        "FROM users WHERE id=?", (user_id,)
    ).fetchone()
    logs = conn.execute(
        "SELECT action,model,latency_ms,cache_hit,success,created_at "
        "FROM logs WHERE user_id=? ORDER BY created_at DESC LIMIT 20",
        (user_id,)
    ).fetchall()
    mem  = conn.execute(
        "SELECT scope,key,value FROM user_memory WHERE user_id=? ORDER BY scope",
        (user_id,)
    ).fetchall()
    conn.close()
    if not row:
        return {"plan":"free","limits":PLANS["free"],"logs":[],"memory":[]}
    plan  = row["plan"]
    lims  = PLANS.get(plan, PLANS["free"])
    reset = row["msg_reset_at"]
    next_reset = None
    if reset:
        next_reset = (datetime.fromisoformat(reset) + timedelta(hours=lims["reset_h"])).isoformat()
    return {
        "msg_count":    row["msg_count"],
        "img_count":    row["img_count"],
        "search_count": row["search_count"],
        "token_cost_usd": round(row["token_cost"] or 0, 5),
        "plan":         plan,
        "limits":       lims,
        "pricing":      PRICING.get(plan, {}),
        "next_reset":   next_reset,
        "sub_expires":  row["sub_expires"],
        "logs":         [dict(l) for l in logs],
        "memory":       [dict(m) for m in mem],
    }

@app.get("/admin/dashboard")
def admin_dashboard():
    conn = get_db()
    total_users  = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    total_msgs   = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    total_convs  = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
    cache_entries= conn.execute("SELECT COUNT(*),COALESCE(SUM(hits),0) FROM sem_cache").fetchone()
    cost_today   = conn.execute(
        "SELECT COALESCE(SUM(cost_usd),0) FROM logs WHERE created_at>=?",
        ((datetime.now()-timedelta(hours=24)).isoformat(),)
    ).fetchone()[0]
    errors_24h   = conn.execute(
        "SELECT COUNT(*) FROM logs WHERE success=0 AND created_at>=?",
        ((datetime.now()-timedelta(hours=24)).isoformat(),)
    ).fetchone()[0]
    active_24h   = conn.execute(
        "SELECT COUNT(DISTINCT user_id) FROM logs WHERE created_at>=?",
        ((datetime.now()-timedelta(hours=24)).isoformat(),)
    ).fetchone()[0]
    cache_hit_rate = conn.execute(
        "SELECT ROUND(100.0*SUM(cache_hit)/MAX(COUNT(*),1),1) FROM logs WHERE action='chat'"
    ).fetchone()[0]
    by_plan = conn.execute(
        "SELECT plan, COUNT(*) as cnt FROM users GROUP BY plan"
    ).fetchall()
    conn.close()
    return {
        "total_users":    total_users,
        "total_msgs":     total_msgs,
        "total_convs":    total_convs,
        "cache_entries":  cache_entries[0],
        "cache_hits":     cache_entries[1],
        "cache_hit_rate": f"{cache_hit_rate or 0}%",
        "cost_today_usd": round(cost_today or 0, 4),
        "errors_24h":     errors_24h,
        "active_users_24h": active_24h,
        "users_by_plan":  {r["plan"]: r["cnt"] for r in by_plan},
        "flags":          FLAGS,
        "version":        APP_VERSION,
        "ts":             datetime.now().isoformat(),
        "load":           _rate_adapter.adaptation_level(),
        "job_queue":      _job_queue.qsize(),
    }

# ════════════════════════════════════════════════════════════════
# ROUTES — FEATURE FLAGS
# ════════════════════════════════════════════════════════════════
@app.get("/flags")
def get_flags():
    return FLAGS

@app.post("/flags")
def update_flag(data: FlagUpdate):
    # TODO: add admin auth here in production
    set_flag(data.name, data.enabled)
    return {"ok": True, "name": data.name, "enabled": data.enabled}

# ════════════════════════════════════════════════════════════════
# ROUTES — CACHE MANAGEMENT
# ════════════════════════════════════════════════════════════════
@app.delete("/cache/clear")
def clear_cache():
    conn = get_db()
    conn.execute("DELETE FROM sem_cache")
    conn.execute("DELETE FROM cache")
    conn.commit(); conn.close()
    return {"ok": True}

@app.get("/cache/stats")
def cache_stats():
    conn = get_db()
    total  = conn.execute("SELECT COUNT(*) FROM sem_cache").fetchone()[0]
    valid  = conn.execute("SELECT COUNT(*) FROM sem_cache WHERE ttl>?", (time.time(),)).fetchone()[0]
    top    = conn.execute("SELECT query_text,hits FROM sem_cache ORDER BY hits DESC LIMIT 10").fetchall()
    conn.close()
    return {"total": total, "valid": valid, "top_queries": [dict(r) for r in top]}

# ════════════════════════════════════════════════════════════════
# ROUTES — BACKGROUND JOBS  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/jobs")
def list_jobs(status: Optional[str] = None, limit: int = 20):
    conn = get_db()
    if status:
        rows = conn.execute(
            "SELECT id,type,status,attempts,result,created_at,done_at FROM jobs "
            "WHERE status=? ORDER BY created_at DESC LIMIT ?", (status, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id,type,status,attempts,result,created_at,done_at FROM jobs "
            "ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/jobs/enqueue")
async def manual_enqueue(data: dict):
    """Manually trigger a background job (admin use)."""
    await enqueue_job(data.get("type","cleanup"), data.get("payload",{}))
    return {"ok": True}

@app.get("/jobs/stats")
def job_stats():
    conn = get_db()
    by_status = conn.execute(
        "SELECT status, COUNT(*) as cnt FROM jobs GROUP BY status"
    ).fetchall()
    by_type = conn.execute(
        "SELECT type, COUNT(*) as cnt, AVG(attempts) as avg_attempts FROM jobs GROUP BY type"
    ).fetchall()
    conn.close()
    return {
        "by_status": {r["status"]: r["cnt"] for r in by_status},
        "by_type":   [dict(r) for r in by_type],
    }

# ════════════════════════════════════════════════════════════════
# ROUTES — ANALYTICS  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/analytics/summary")
def analytics_summary(hours: int = 24):
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()
    conn   = get_db()
    events = conn.execute(
        "SELECT event, COUNT(*) as cnt FROM analytics WHERE created_at>=? GROUP BY event ORDER BY cnt DESC",
        (cutoff,)
    ).fetchall()
    dau = conn.execute(
        "SELECT COUNT(DISTINCT user_id) FROM analytics WHERE created_at>=?", (cutoff,)
    ).fetchone()[0]
    top_users = conn.execute(
        "SELECT user_id, COUNT(*) as cnt FROM analytics WHERE created_at>=? AND event='msg_sent' "
        "GROUP BY user_id ORDER BY cnt DESC LIMIT 10", (cutoff,)
    ).fetchall()
    # Drop-off: users who started but didn't send a message
    drop = conn.execute(
        "SELECT COUNT(DISTINCT user_id) FROM analytics WHERE event='drop' AND created_at>=?",
        (cutoff,)
    ).fetchone()[0]
    conn.close()
    return {
        "period_hours":  hours,
        "dau":           dau,
        "drop_offs":     drop,
        "events":        {r["event"]: r["cnt"] for r in events},
        "top_users":     [dict(r) for r in top_users],
    }

@app.post("/analytics/event")
async def log_event(data: dict):
    """Frontend can post events (copy, rate, drop-off, etc.)."""
    await track_event(
        data.get("user_id","guest"),
        data.get("event","unknown"),
        data.get("session_id",""),
        data.get("meta",{})
    )
    return {"ok": True}

# ════════════════════════════════════════════════════════════════
# ROUTES — ONBOARDING  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/onboarding/{user_id}")
def get_onboarding_state(user_id: str):
    step = get_onboarding(user_id)
    return {"step": step, "completed": step is None}

@app.post("/onboarding/{user_id}/advance")
def advance_onboarding_route(user_id: str):
    advance_onboarding(user_id)
    step = get_onboarding(user_id)
    return {"step": step, "completed": step is None}

@app.delete("/onboarding/{user_id}/reset")
def reset_onboarding(user_id: str):
    conn = get_db()
    conn.execute("DELETE FROM onboarding WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()
    return {"ok": True}

# ════════════════════════════════════════════════════════════════
# ROUTES — SUGGESTIONS  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/suggestions/{user_id}")
def user_suggestions(user_id: str):
    return get_suggestions(user_id)

@app.post("/suggestions/{user_id}/used")
def mark_suggestion_used(user_id: str, data: dict):
    """Mark a suggestion as used so it won't repeat."""
    text = data.get("text","")
    conn = get_db()
    conn.execute("UPDATE suggestions SET used=1 WHERE user_id=? AND text=?", (user_id, text))
    conn.commit()
    conn.close()
    return {"ok": True}

# ════════════════════════════════════════════════════════════════
# ROUTES — KILL SWITCH  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/kill-switch")
def get_kill_switches():
    """Return all kill-switch states."""
    return {k: v for k, v in FLAGS.items() if k.startswith("kill")}

@app.post("/kill-switch")
def set_kill_switch(data: dict):
    """Activate/deactivate a kill switch instantly."""
    name    = data.get("name","")
    enabled = bool(data.get("enabled", False))
    if not name.startswith("kill"):
        raise HTTPException(400, "Only kill_* flags allowed here")
    set_flag(name, enabled)
    log.warning(f"🚨 Kill switch {name} → {enabled}")
    return {"ok": True, "name": name, "enabled": enabled}

# ════════════════════════════════════════════════════════════════
# ROUTES — RATE ADAPTATION STATUS  (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/system/load")
def system_load():
    return {
        "rps":             _rate_adapter.rps(),
        "level":           _rate_adapter.adaptation_level(),
        "adapted_tokens":  _rate_adapter.adapt_max_tokens(),
        "job_queue_size":  _job_queue.qsize(),
        "flags_active":    {k:v for k,v in FLAGS.items() if v},
        "ts":              datetime.now().isoformat(),
    }

# ════════════════════════════════════════════════════════════════
# ROUTES — IMAGE (with kill switch)
# ════════════════════════════════════════════════════════════════
# Override existing image endpoint to add kill_images check
# (existing /image/generate already defined above — add wrapper below)

@app.get("/image/status")
def image_status():
    return {"available": not kill_check("images"), "flags": {
        "kill_images": FLAGS.get("kill_images", False),
        "kill_switch": FLAGS.get("kill_switch", False),
    }}

# ════════════════════════════════════════════════════════════════
# ROUTES — EMPTY STATE (v4)
# ════════════════════════════════════════════════════════════════
@app.get("/empty-state/{user_id}")
def empty_state(user_id: str):
    """Smart empty state: personalised suggestions + onboarding."""
    sug   = get_suggestions(user_id)
    ob    = get_onboarding(user_id)
    long  = mem_get(user_id, "long")
    domain = long.get("domain", "")
    greeting = {
        "software":               "اهلاً! شايف إنك بتشتغل في البرمجة — عندك كود تحتاج مساعدة فيه؟",
        "artificial intelligence":"هلا! شايف اهتمامك بالذكاء الاصطناعي — محتاج شرح لأي مفهوم؟",
        "medicine":               "أهلاً! معاك في أي سؤال طبي.",
    }.get(domain, "أهلاً! اسألني أي حاجة — أنا هنا أساعدك! 🦚")
    return {
        "greeting":     greeting,
        "suggestions":  sug,
        "onboarding":   ob,
        "has_memory":   bool(long),
    }

