"""
routes/auth.py — Authentication Routes v7
JWT auth, PBKDF2 passwords, rate limiting, input validation.
Author: PeacockAI – Mostafa
"""
from fastapi import APIRouter, HTTPException, Header, Request
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
import hashlib

from core.database import get_db, User, Session_
from core.security import (
    hash_password, verify_password,
    create_token, verify_token,
    check_rate_limit, validate_email, validate_password,
    sanitize_string, write_security_event_safe,
)
from core.config import log, PERSONA

router = APIRouter(prefix="/users", tags=["auth"])


# ══════════════════════════════════════════════════════════════════
# SCHEMAS
# ══════════════════════════════════════════════════════════════════

class RegisterRequest(BaseModel):
    name:     str
    email:    str
    password: str
    region:   str = "global"

    @validator("email")
    def email_valid(cls, v):
        from core.security import validate_email
        if not validate_email(v):
            raise ValueError("البريد الإلكتروني غير صالح")
        return v.lower().strip()

    @validator("password")
    def pw_strength(cls, v):
        ok, msg = validate_password(v)
        if not ok:
            raise ValueError(msg)
        return v

    @validator("name")
    def name_clean(cls, v):
        v = sanitize_string(v.strip(), max_len=100)
        if not v:
            raise ValueError("الاسم مطلوب")
        if len(v) < 2:
            raise ValueError("الاسم قصير جداً")
        return v

    @validator("region")
    def region_valid(cls, v):
        if v not in ("egypt", "global", ""):
            return "global"
        return v


class LoginRequest(BaseModel):
    email:    str
    password: str

    @validator("email")
    def email_clean(cls, v):
        return v.lower().strip()


# ══════════════════════════════════════════════════════════════════
# REGISTER
# ══════════════════════════════════════════════════════════════════

@router.post("/register", status_code=201)
def register(req: RegisterRequest, request: Request):
    # Rate limit by IP
    ip = request.client.host if request.client else "unknown"
    allowed, _ = check_rate_limit(f"register:{ip}", max_calls=10, window_s=3600)
    if not allowed:
        raise HTTPException(429, "محاولات تسجيل كثيرة جداً. حاول بعد ساعة.")

    uid = hashlib.md5(req.email.encode()).hexdigest()
    with get_db() as db:
        if db.query(User).filter_by(email=req.email).first():
            raise HTTPException(400, "البريد الإلكتروني مستخدم بالفعل")
        now = datetime.now().isoformat()
        db.add(User(
            id            = uid,
            name          = req.name,
            email         = req.email,
            password_hash = hash_password(req.password),
            plan          = "free",
            tone          = "friendly",
            region        = req.region,
            created_at    = now,
            msg_reset_at  = now,
        ))

    token = create_token(uid, "free")
    log.info(f"✅ Register: {req.email} from {ip}")
    return {"id": uid, "name": req.name, "plan": "free",
            "tone": "friendly", "region": req.region, "token": token}


# ══════════════════════════════════════════════════════════════════
# LOGIN
# ══════════════════════════════════════════════════════════════════

@router.post("/login")
def login(req: LoginRequest, request: Request):
    ip = request.client.host if request.client else "unknown"

    # Rate limit login attempts per IP (brute force protection)
    allowed, _ = check_rate_limit(f"login:{ip}", max_calls=20, window_s=300)
    if not allowed:
        log.warning(f"[Security] Login rate limit: {ip}")
        raise HTTPException(429, "محاولات كثيرة جداً. انتظر 5 دقائق.")

    with get_db() as db:
        user = db.query(User).filter_by(email=req.email).first()
        if not user or not verify_password(req.password, user.password_hash):
            # Log failed attempt
            log.warning(f"[Security] Failed login: {req.email} from {ip}")
            raise HTTPException(401, "البريد الإلكتروني أو كلمة المرور غلط")
        user.last_seen = datetime.now().isoformat()
        token = create_token(user.id, user.plan or "free")
        log.info(f"✅ Login: {req.email} from {ip}")
        return {
            "id":           user.id,
            "name":         user.name,
            "plan":         user.plan,
            "tone":         user.tone,
            "region":       user.region,
            "msg_count":    user.msg_count,
            "img_count":    user.img_count,
            "search_count": user.search_count,
            "sub_expires":  user.sub_expires,
            "token":        token,
        }


# ══════════════════════════════════════════════════════════════════
# LOGOUT
# ══════════════════════════════════════════════════════════════════

@router.post("/logout")
def logout(x_token: Optional[str] = Header(None)):
    # Stateless JWT — client discards token
    # In production: add to a blocklist or use short-lived tokens
    return {"ok": True}


# ══════════════════════════════════════════════════════════════════
# ME
# ══════════════════════════════════════════════════════════════════

@router.get("/me")
def get_me(x_token: Optional[str] = Header(None)):
    payload = verify_token(x_token)
    if not payload:
        raise HTTPException(401, "غير مصادق — سجل دخولك")
    with get_db() as db:
        user = db.query(User).filter_by(id=payload["sub"]).first()
        if not user:
            raise HTTPException(404, "المستخدم غير موجود")
        return {
            "id":     user.id,
            "name":   user.name,
            "plan":   user.plan,
            "tone":   user.tone,
            "region": user.region,
        }


# ══════════════════════════════════════════════════════════════════
# UPDATE TONE
# ══════════════════════════════════════════════════════════════════

@router.patch("/tone")
def update_tone(data: dict, x_token: Optional[str] = Header(None)):
    payload = verify_token(x_token)
    if not payload:
        raise HTTPException(401, "غير مصادق")

    tone    = sanitize_string(data.get("tone", "friendly"), max_len=20)
    user_id = payload["sub"]

    if tone not in PERSONA:
        raise HTTPException(400, f"الأسلوب غير صحيح. الخيارات: {list(PERSONA.keys())}")

    with get_db() as db:
        user = db.query(User).filter_by(id=user_id).first()
        if user:
            user.tone = tone
    return {"ok": True, "tone": tone}


# ══════════════════════════════════════════════════════════════════
# SUBSCRIPTION ACTIVATION
# ══════════════════════════════════════════════════════════════════

@router.patch("/subscription")
def activate_subscription(data: dict, x_token: Optional[str] = Header(None)):
    """Called by payment webhook — requires valid admin token in production."""
    payload = verify_token(x_token)
    if not payload:
        raise HTTPException(401, "غير مصادق")

    from datetime import timedelta
    uid     = sanitize_string(data.get("user_id", ""), max_len=64)
    plan    = sanitize_string(data.get("plan", "pro"), max_len=20)
    months  = int(data.get("months", 1))

    if plan not in ("free", "plus", "pro"):
        raise HTTPException(400, "خطة غير صالحة")

    expires = (datetime.now() + timedelta(days=30 * months)).isoformat()
    with get_db() as db:
        user = db.query(User).filter_by(id=uid).first()
        if not user:
            raise HTTPException(404, "المستخدم غير موجود")
        user.plan        = plan
        user.sub_expires = expires
    log.info(f"✅ Subscription activated: {uid} → {plan} until {expires}")
    return {"ok": True, "plan": plan, "expires": expires}


# Helper for security module compatibility
def write_security_event_safe(user_id: str, event: str, ip: str = "", detail: str = ""):
    try:
        from repositories.log_repo import write_security_event
        write_security_event(user_id, event, ip, detail)
    except Exception:
        pass
