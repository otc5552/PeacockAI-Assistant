"""
routes/conversations.py — Conversations & Messages CRUD
routes/admin.py       — Dashboard, flags, kill-switch, analytics
routes/misc.py        — Image gen, suggestions, onboarding, stats
Author: PeacockAI – Mostafa
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
import hashlib, secrets, time, json

from core.config import MODELS, PLANS, PRICING, PERSONA, FLAGS, APP_VERSION, log
from core.database import (
    get_db, Conversation, Message, User, SemCache,
    FeatureFlag, Analytics, Job, Log, Suggestion, Onboarding, CacheEntry
)
from services.usage import get_user_stats
from services.vector_cache import cache_stats as vcache_stats
from workers.jobs import enqueue, _queue

# ════════════════════════════════════════════════════════════════
# CONVERSATIONS
# ════════════════════════════════════════════════════════════════
conv_router = APIRouter(tags=["conversations"])

class ConvCreate(BaseModel):
    user_id: str
    title:   str = "محادثة جديدة"

@conv_router.get("/conversations/{user_id}")
def list_conversations(user_id: str):
    with get_db() as db:
        rows = db.query(Conversation).filter_by(user_id=user_id)\
                 .order_by(Conversation.pinned.desc(), Conversation.updated_at.desc())\
                 .limit(100).all()
    return [{"id":r.id,"title":r.title,"model_used":r.model_used,
             "updated_at":r.updated_at,"pinned":bool(r.pinned)} for r in rows]

@conv_router.post("/conversations", status_code=201)
def create_conversation(data: ConvCreate):
    cid = hashlib.md5(f"{data.user_id}{time.time()}".encode()).hexdigest()
    now = datetime.now().isoformat()
    with get_db() as db:
        db.add(Conversation(id=cid, user_id=data.user_id,
                            title=data.title[:80], created_at=now, updated_at=now))
    return {"id": cid, "title": data.title}

@conv_router.patch("/conversations/{conv_id}")
def patch_conversation(conv_id: str, data: dict):
    with get_db() as db:
        c = db.query(Conversation).filter_by(id=conv_id).first()
        if not c: raise HTTPException(404, "المحادثة غير موجودة")
        if "title"  in data: c.title  = data["title"][:80]
        if "pinned" in data: c.pinned = int(data["pinned"])
        c.updated_at = datetime.now().isoformat()
    return {"ok": True}

@conv_router.delete("/conversations/{conv_id}")
def delete_conversation(conv_id: str):
    with get_db() as db:
        c = db.query(Conversation).filter_by(id=conv_id).first()
        if c: db.delete(c)
    return {"ok": True}

@conv_router.get("/messages/{conv_id}")
def get_messages(conv_id: str):
    with get_db() as db:
        rows = db.query(Message).filter_by(conv_id=conv_id)\
                 .order_by(Message.created_at).all()
    return [{"id":r.id,"role":r.role,"content":r.content,
             "model":r.model,"created_at":r.created_at} for r in rows]

@conv_router.post("/messages")
def save_message(data: dict):
    mid = hashlib.md5(f"{data.get('conv_id')}{time.time()}".encode()).hexdigest()
    now = datetime.now().isoformat()
    with get_db() as db:
        db.add(Message(id=mid, conv_id=data["conv_id"], role=data["role"],
                       content=data["content"], model=data.get("model",""),
                       created_at=now))
        c = db.query(Conversation).filter_by(id=data["conv_id"]).first()
        if c:
            c.updated_at  = now
            c.model_used  = data.get("model","")
    return {"id": mid}

# ════════════════════════════════════════════════════════════════
# USER MEMORY (exposed as route)
# ════════════════════════════════════════════════════════════════
mem_router = APIRouter(tags=["memory"])

@mem_router.get("/memory/{user_id}")
def get_memory(user_id: str, scope: Optional[str] = None):
    from services.memory import mem_get, mem_get_all
    if scope:
        return mem_get(user_id, scope)
    return mem_get_all(user_id)

@mem_router.post("/memory")
def set_memory(data: dict):
    from services.memory import mem_set
    mem_set(data["user_id"], data["scope"], data["key"], data["value"],
            float(data.get("confidence", 1.0)))
    return {"ok": True}

@mem_router.delete("/memory/{user_id}")
def clear_memory(user_id: str, scope: Optional[str] = None, key: Optional[str] = None):
    from services.memory import mem_delete
    mem_delete(user_id, scope, key)
    return {"ok": True}

# ════════════════════════════════════════════════════════════════
# MISC (image, stats, suggestions, onboarding)
# ════════════════════════════════════════════════════════════════
misc_router = APIRouter(tags=["misc"])

@misc_router.post("/image/generate")
async def gen_image(req: dict):
    if FLAGS.get("kill_images") or not FLAGS.get("image_gen"):
        raise HTTPException(503, "توليد الصور متوقف مؤقتاً")
    uid    = req.get("user_id","guest")
    prompt = req.get("prompt","").strip()
    if not prompt: raise HTTPException(400, "وصف الصورة مطلوب")
    from services.usage import check_and_increment
    if uid and uid != "guest":
        ok, reason = check_and_increment(uid, "img")
        if not ok: raise HTTPException(429, reason)
    seed = int(time.time())
    url  = (f"https://image.pollinations.ai/prompt/"
            f"{prompt.replace(' ','%20')},high_quality,detailed,artistic"
            f"?width=768&height=512&nologo=true&seed={seed}&model=flux")
    return {"url": url, "model": "PeacockGPT Image", "prompt": prompt}

@misc_router.get("/stats/{user_id}")
def get_stats(user_id: str):
    stats = get_user_stats(user_id)
    if not stats:
        return {"plan":"free","limits":PLANS["free"]}
    with get_db() as db:
        logs = db.query(Log).filter_by(user_id=user_id)\
                 .order_by(Log.created_at.desc()).limit(20).all()
    stats["recent_logs"] = [
        {"action":r.action,"model":r.model,"latency_ms":r.latency_ms,
         "cache_hit":r.cache_hit,"success":r.success,"created_at":r.created_at}
        for r in logs
    ]
    return stats

@misc_router.get("/suggestions/{user_id}")
def get_suggestions(user_id: str):
    with get_db() as db:
        rows = db.query(Suggestion).filter_by(user_id=user_id, used=False)\
                 .order_by(Suggestion.score.desc()).limit(4).all()
    if rows:
        return [{"text":r.text,"icon":r.icon} for r in rows]
    return [
        {"text":"ما أحدث أخبار التقنية؟","icon":"🌐"},
        {"text":"اكتب Todo App بـ HTML","icon":"💻"},
        {"text":"وضّح الفرق بين REST وGraphQL","icon":"📝"},
        {"text":"أنشئ صورة مدينة عربية مستقبلية","icon":"🖼️"},
    ]

@misc_router.get("/onboarding/{user_id}")
def get_onboarding(user_id: str):
    STEPS = [
        {"step":1,"title":"أهلاً! 🦚","body":"أنا PeacockGPT 5. اسألني أي حاجة!",
         "suggestions":["ما هو الذكاء الاصطناعي؟","كيف أكتب كود Python؟"]},
        {"step":2,"title":"جرّب البحث 🔍","body":"أبحث في الإنترنت تلقائياً عند الحاجة.",
         "suggestions":["ما أخبار التقنية اليوم؟","سعر الدولار الآن"]},
        {"step":3,"title":"أنشئ صورة 🖼️","body":"اضغط ➕ وأنشئ صور بالذكاء الاصطناعي!",
         "suggestions":["مدينة مستقبلية عربية","غروب شمس على النيل"]},
        {"step":4,"title":"خلصت! 🎉","body":"أنت جاهز. ابدأ!","suggestions":[]},
    ]
    with get_db() as db:
        row = db.query(Onboarding).filter_by(user_id=user_id).first()
        if not row:
            db.add(Onboarding(user_id=user_id, step=0, completed=False,
                              updated_at=datetime.now().isoformat()))
            return {"step": STEPS[0], "completed": False}
        if row.completed:
            return {"step": None, "completed": True}
        idx = min(row.step, len(STEPS)-1)
    return {"step": STEPS[idx], "completed": False}

@misc_router.post("/onboarding/{user_id}/advance")
def advance_onboarding(user_id: str):
    STEP_COUNT = 4
    with get_db() as db:
        row = db.query(Onboarding).filter_by(user_id=user_id).first()
        if not row:
            row = Onboarding(user_id=user_id, step=0, completed=False,
                             updated_at=datetime.now().isoformat())
            db.add(row)
        row.step      = (row.step or 0) + 1
        row.completed = row.step >= STEP_COUNT
        row.updated_at = datetime.now().isoformat()
    return {"ok": True, "step": row.step, "completed": row.completed}

# ════════════════════════════════════════════════════════════════
# ADMIN
# ════════════════════════════════════════════════════════════════
admin_router = APIRouter(prefix="/admin", tags=["admin"])

@admin_router.get("/performance")
def performance_report(hours: int = 24):
    """Self-improvement analysis + recommendations."""
    from services.self_improvement import analyse_performance
    return analyse_performance(hours)


@admin_router.post("/optimise")
def trigger_optimise():
    """Manually trigger auto-optimiser."""
    from services.self_improvement import auto_optimise
    return auto_optimise()


@admin_router.get("/dashboard")
def dashboard():
    from services.usage import get_adapter
    adapter = get_adapter()
    with get_db() as db:
        total_users  = db.query(User).count()
        total_msgs   = db.query(Message).count()
        total_convs  = db.query(Conversation).count()
        errors_24h   = db.query(Log).filter(
            Log.success == False,
            Log.created_at >= (datetime.now()-timedelta(hours=24)).isoformat()
        ).count()
        active_24h   = db.query(Log.user_id).filter(
            Log.created_at >= (datetime.now()-timedelta(hours=24)).isoformat()
        ).distinct().count()
        cost_24h     = db.query(Log.cost_usd).filter(
            Log.created_at >= (datetime.now()-timedelta(hours=24)).isoformat()
        ).all()
        by_plan      = {}
        for u in db.query(User).all():
            by_plan[u.plan or "free"] = by_plan.get(u.plan or "free",0)+1
    total_cost = sum(r[0] or 0 for r in cost_24h)
    cs = vcache_stats()
    return {
        "total_users":    total_users,
        "total_msgs":     total_msgs,
        "total_convs":    total_convs,
        "errors_24h":     errors_24h,
        "active_24h":     active_24h,
        "cost_24h_usd":   round(total_cost, 4),
        "users_by_plan":  by_plan,
        "cache":          cs,
        "load":           adapter.level(),
        "rpm":            adapter.rpm(),
        "job_queue_size": _queue.qsize(),
        "flags":          FLAGS,
        "version":        APP_VERSION,
        "ts":             datetime.now().isoformat(),
    }

@admin_router.get("/flags")
def get_flags():
    return FLAGS

@admin_router.post("/flags")
def set_flag(data: dict):
    name    = data.get("name","")
    enabled = bool(data.get("enabled", False))
    if name not in FLAGS:
        raise HTTPException(400, f"Flag '{name}' غير موجود")
    FLAGS[name] = enabled
    with get_db() as db:
        ff = db.query(FeatureFlag).filter_by(name=name).first()
        if ff:
            ff.enabled    = enabled
            ff.updated_at = datetime.now().isoformat()
        else:
            db.add(FeatureFlag(name=name, enabled=enabled,
                               updated_at=datetime.now().isoformat()))
    log.warning(f"🚨 Flag: {name} → {enabled}")
    return {"ok": True, "name": name, "enabled": enabled}

@admin_router.get("/kill-switches")
def kill_switches():
    return {k:v for k,v in FLAGS.items() if k.startswith("kill")}

@admin_router.post("/kill-switches")
def set_kill(data: dict):
    name    = data.get("name","")
    enabled = bool(data.get("enabled", False))
    if not name.startswith("kill"):
        raise HTTPException(400, "يجب أن يبدأ الاسم بـ kill_")
    FLAGS[name] = enabled
    log.warning(f"🚨 Kill switch: {name} → {enabled}")
    return {"ok": True}

@admin_router.get("/analytics")
def analytics(hours: int = 24):
    cutoff = (datetime.now()-timedelta(hours=hours)).isoformat()
    with get_db() as db:
        events = {}
        for a in db.query(Analytics).filter(Analytics.created_at >= cutoff).all():
            events[a.event] = events.get(a.event,0)+1
        dau = db.query(Analytics.user_id).filter(
            Analytics.created_at >= cutoff
        ).distinct().count()
    return {"hours": hours, "dau": dau, "events": events}

@admin_router.get("/jobs")
def list_jobs(status: Optional[str] = None, limit: int = 20):
    with get_db() as db:
        q = db.query(Job)
        if status: q = q.filter_by(status=status)
        rows = q.order_by(Job.created_at.desc()).limit(limit).all()
    return [{"id":r.id,"type":r.type,"status":r.status,
             "attempts":r.attempts,"result":r.result,
             "created_at":r.created_at,"done_at":r.done_at} for r in rows]

@admin_router.post("/jobs/enqueue")
async def manual_job(data: dict):
    await enqueue(data.get("type","cleanup"), data.get("payload",{}))
    return {"ok": True}

@admin_router.get("/cache")
def cache_info():
    return vcache_stats()

@admin_router.delete("/cache")
def clear_cache():
    with get_db() as db:
        db.query(SemCache).delete()
        db.query(CacheEntry).delete()
    return {"ok": True}

@admin_router.get("/load")
def load_status():
    from services.usage import get_adapter
    a = get_adapter()
    return {"rpm": a.rpm(), "level": a.level(),
            "adapted_tokens": a.adapt_tokens(), "job_queue": _queue.qsize()}
