"""
routes/agent_routes.py — Agent, File Manager, PDF endpoints v7 Ultimate
Human-Control: plan → confirm → execute
Author: PeacockAI – Mostafa
"""
import json
from fastapi import APIRouter, HTTPException, Header, Request, UploadFile, File
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel, validator
from typing import Optional

from core.config import FLAGS, PLANS, log
from core.security import verify_token, check_rate_limit
from core.database import get_db, User
from services.agent import (
    run_agent, is_agent_request, classify_intent,
    plan_and_request_confirmation, execute_confirmed_action,
    get_pending_action, get_pending_for_user, resolve_pending_action,
    IntentClass, is_explicit_execute,
)
from services.file_manager import (
    list_files, read_file, write_file, create_file,
    delete_file, rename_file, get_project_tree,
    export_zip, import_zip, FileManagerError
)
from services.pdf_service import (
    generate_pdf, get_pdf_records, get_pdf_count, check_pdf_quota
)
from repositories.log_repo import write_security_event

router = APIRouter(tags=["agent"])


# ══════════════════════════════════════════════════════════════════
# AUTH HELPERS
# ══════════════════════════════════════════════════════════════════

def _get_user(x_token: Optional[str]) -> Optional[dict]:
    if not x_token:
        return None
    payload = verify_token(x_token)
    if not payload:
        return None
    try:
        with get_db() as db:
            u = db.query(User).filter_by(id=payload["sub"]).first()
            if u:
                return {"id": u.id, "plan": u.plan or "free", "name": u.name}
    except Exception:
        pass
    return None


def _require_auth(x_token: Optional[str]) -> dict:
    user = _get_user(x_token)
    if not user:
        raise HTTPException(401, "سجل دخولك أولاً")
    return user


def _require_pro(x_token: Optional[str]) -> dict:
    user = _require_auth(x_token)
    if user["plan"] != "pro":
        raise HTTPException(403,
            "🔒 هذه الميزة متاحة فقط لمستخدمي Pro.\n"
            "ترقية: 1500 جنيه / $35 شهرياً")
    return user


# ══════════════════════════════════════════════════════════════════
# AGENT ROUTES
# ══════════════════════════════════════════════════════════════════

class AgentRequest(BaseModel):
    goal:    str
    context: str = ""

    @validator("goal")
    def goal_valid(cls, v):
        v = v.strip()
        if not v:          raise ValueError("الهدف مطلوب")
        if len(v) > 2000:  raise ValueError("الهدف طويل جداً")
        return v


class ConfirmRequest(BaseModel):
    action_id: str
    decision:  str   # "confirm" | "reject"

    @validator("decision")
    def decision_valid(cls, v):
        if v not in ("confirm", "reject"):
            raise ValueError("القرار يجب أن يكون confirm أو reject")
        return v


# ── POST /agent/plan  (Stage 1: plan + ask confirmation) ──────────
@router.post("/agent/plan")
async def agent_plan(
    req:          AgentRequest,
    request:      Request,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """
    Stage 1 — Human Control:
    Analyze goal → Generate plan → Ask user to confirm.
    Nothing is executed until user says yes.
    """
    if FLAGS.get("kill_agent"):
        raise HTTPException(503, "Agent Mode متوقف مؤقتاً")

    user = _require_pro(x_token)

    # Rate limit agent plan requests
    ip = request.client.host if request.client else "unknown"
    allowed, _ = check_rate_limit(f"agent_plan:{user['id']}", max_calls=20, window_s=3600)
    if not allowed:
        raise HTTPException(429, "تجاوزت حد طلبات Agent. انتظر ساعة.")

    return StreamingResponse(
        plan_and_request_confirmation(
            goal       = req.goal,
            user_id    = user["id"],
            user_plan  = user["plan"],
            groq_key   = x_groq_key   or "",
            gemini_key = x_gemini_key or "",
            context    = req.context,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── POST /agent/confirm  (Stage 2: user confirms → execute) ───────
@router.post("/agent/confirm")
async def agent_confirm(
    req:          ConfirmRequest,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """
    Stage 2 — Execute after user confirmation.
    Only runs if valid pending action exists and user said confirm.
    """
    user = _require_pro(x_token)

    if req.decision == "reject":
        resolve_pending_action(req.action_id, user["id"], "rejected")
        log.info(f"[Agent] Action rejected: {req.action_id} by {user['id']}")
        return {"ok": True, "message": "تم إلغاء التنفيذ."}

    return StreamingResponse(
        execute_confirmed_action(
            action_id  = req.action_id,
            user_id    = user["id"],
            user_plan  = user["plan"],
            groq_key   = x_groq_key   or "",
            gemini_key = x_gemini_key or "",
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── POST /agent/run  (legacy / direct run — read-only auto, write requires confirm) ──
@router.post("/agent/run")
async def agent_run(
    req:          AgentRequest,
    request:      Request,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """
    Smart router: classify intent and route appropriately.
    Read-only → direct execution.
    Write/Delete → redirect to plan+confirm flow.
    """
    if FLAGS.get("kill_agent"):
        raise HTTPException(503, "Agent Mode متوقف مؤقتاً")

    user   = _require_pro(x_token)
    intent = classify_intent(req.goal)

    # Read-only tasks run directly
    if intent == IntentClass.READ:
        return StreamingResponse(
            run_agent(
                goal=req.goal, user_id=user["id"], user_plan=user["plan"],
                groq_key=x_groq_key or "", gemini_key=x_gemini_key or "",
                context=req.context, skip_confirmation=True,
            ),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # Write/Delete tasks → force confirmation flow
    return StreamingResponse(
        plan_and_request_confirmation(
            goal=req.goal, user_id=user["id"], user_plan=user["plan"],
            groq_key=x_groq_key or "", gemini_key=x_gemini_key or "",
            context=req.context,
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── GET /agent/pending  (check if user has a pending confirmation) ─
@router.get("/agent/pending")
def agent_pending(x_token: Optional[str] = Header(None)):
    """Return the user's latest pending action (if any)."""
    user    = _require_pro(x_token)
    pending = get_pending_for_user(user["id"])
    return {"pending": pending}


# ── GET /agent/tasks/{user_id} ─────────────────────────────────────
@router.get("/agent/tasks/{user_id}")
def list_agent_tasks(user_id: str, x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    from core.database import AgentTask
    try:
        with get_db() as db:
            rows = db.query(AgentTask).filter_by(user_id=user_id)\
                     .order_by(AgentTask.created_at.desc()).limit(20).all()
        return [{
            "id": r.id, "goal": r.goal[:80], "status": r.status,
            "steps_done": r.steps_done, "elapsed_s": r.elapsed_s,
            "created_at": r.created_at,
        } for r in rows]
    except Exception as e:
        raise HTTPException(500, str(e))


# ── GET /agent/check ───────────────────────────────────────────────
@router.get("/agent/check")
def agent_check(message: str = "", x_token: Optional[str] = Header(None)):
    user   = _get_user(x_token)
    is_pro = user and user.get("plan") == "pro"
    intent = classify_intent(message) if message else "unknown"
    return {
        "is_agent_request":  is_agent_request(message) and is_pro,
        "agent_available":   is_pro and FLAGS.get("agent_mode"),
        "intent":            intent,
        "needs_confirmation": intent in (IntentClass.WRITE, IntentClass.DELETE),
    }


# ══════════════════════════════════════════════════════════════════
# FILE MANAGER ROUTES (Pro only)
# ══════════════════════════════════════════════════════════════════

@router.get("/files/{user_id}")
def fm_list(user_id: str, x_token: Optional[str] = Header(None)):
    _require_pro(x_token)
    try:
        return {"files": list_files(user_id), "tree": get_project_tree(user_id)}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.get("/files/{user_id}/read")
def fm_read(user_id: str, filename: str, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ لا يمكنك الوصول لملفات مستخدم آخر")
    try:
        content, size = read_file(user_id, filename)
        return {"filename": filename, "content": content, "size_bytes": size}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


class WriteRequest(BaseModel):
    filename:  str
    content:   str
    overwrite: bool = True


@router.post("/files/{user_id}/write")
def fm_write(user_id: str, req: WriteRequest, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ لا يمكنك تعديل ملفات مستخدم آخر")
    try:
        meta = write_file(user_id, req.filename, req.content, req.overwrite)
        return {"ok": True, **meta}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/create")
def fm_create(user_id: str, data: dict, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ غير مسموح")
    try:
        meta = create_file(user_id, data.get("filename",""), data.get("content",""))
        return {"ok": True, **meta}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.delete("/files/{user_id}/delete")
def fm_delete(user_id: str, filename: str, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ غير مسموح")
    try:
        delete_file(user_id, filename)
        log.info(f"[AUDIT][File] DELETE user={user_id} file='{filename}'")
        return {"ok": True}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/rename")
def fm_rename(user_id: str, data: dict, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ غير مسموح")
    try:
        rename_file(user_id, data.get("old_name",""), data.get("new_name",""))
        return {"ok": True}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.get("/files/{user_id}/export")
def fm_export(user_id: str, x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ غير مسموح")
    try:
        zip_bytes = export_zip(user_id)
        return Response(
            content=zip_bytes, media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=peacock_project_{user_id[:8]}.zip"}
        )
    except FileManagerError as e:
        raise HTTPException(400, str(e))


@router.post("/files/{user_id}/import")
async def fm_import(user_id: str, file: UploadFile = File(...),
                    x_token: Optional[str] = Header(None)):
    user = _require_pro(x_token)
    if user["id"] != user_id:
        raise HTTPException(403, "⛔ غير مسموح")
    if not file.filename.endswith(".zip"):
        raise HTTPException(400, "الملف يجب أن يكون ZIP")
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(413, "الملف كبير جداً (max 10MB)")
    try:
        extracted = import_zip(user_id, content)
        return {"ok": True, "extracted": extracted, "count": len(extracted)}
    except FileManagerError as e:
        raise HTTPException(400, str(e))


# ══════════════════════════════════════════════════════════════════
# PDF ROUTES
# ══════════════════════════════════════════════════════════════════

class PdfRequest(BaseModel):
    content:   str
    title:     str = "PeacockGPT Export"
    user_id:   str = "guest"
    user_plan: str = "free"

    @validator("content")
    def content_not_empty(cls, v):
        if not v.strip(): raise ValueError("المحتوى مطلوب")
        return v


@router.post("/pdf/generate")
async def pdf_generate(req: PdfRequest, x_token: Optional[str] = Header(None)):
    if FLAGS.get("kill_pdf"):
        raise HTTPException(503, "تصدير PDF متوقف مؤقتاً")

    user_id   = req.user_id
    user_plan = req.user_plan
    user_name = ""
    if x_token:
        payload = verify_token(x_token)
        if payload:
            user_id = payload.get("sub", user_id)
            try:
                with get_db() as db:
                    u = db.query(User).filter_by(id=user_id).first()
                    if u:
                        user_plan = u.plan or "free"
                        user_name = u.name or ""
            except Exception:
                pass

    try:
        pdf_bytes, record_id = generate_pdf(
            content=req.content, user_id=user_id, user_plan=user_plan,
            title=req.title, user_name=user_name, save=True,
        )
    except PermissionError as e:
        raise HTTPException(403, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))

    safe_title = req.title[:30].replace(" ", "_")
    return Response(
        content=pdf_bytes, media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="peacock_{safe_title}.pdf"',
            "X-Record-Id": record_id,
        }
    )


@router.get("/pdf/quota/{user_id}")
def pdf_quota(user_id: str, x_token: Optional[str] = Header(None)):
    user_plan = "free"
    if x_token:
        payload = verify_token(x_token)
        if payload:
            try:
                with get_db() as db:
                    u = db.query(User).filter_by(id=payload["sub"]).first()
                    if u: user_plan = u.plan or "free"
            except Exception:
                pass
    limit     = PLANS.get(user_plan, PLANS["free"]).get("pdf", 1)
    used      = get_pdf_count(user_id)
    ok, reason = check_pdf_quota(user_id, user_plan)
    return {
        "used": used, "limit": limit if limit != -1 else "unlimited",
        "available": ok, "reason": reason if not ok else "", "plan": user_plan,
    }


@router.get("/pdf/history/{user_id}")
def pdf_history(user_id: str, x_token: Optional[str] = Header(None)):
    _require_auth(x_token)
    return {"records": get_pdf_records(user_id)}
