"""
services/search.py — Hybrid Web Search
Priority: Cache → DuckDuckGo → Wikipedia Arabic
Author: PeacockAI – Mostafa
"""
import hashlib, asyncio
from typing import Optional
import httpx
from core.config import FLAGS, log
from core.database import get_db, CacheEntry
import time

SEARCH_TTL = 3600    # 1 hour cache

# ── Plain key-value search cache ──────────────────────────────────
def _cache_get(query: str) -> Optional[str]:
    key = "search:" + hashlib.md5(query.encode()).hexdigest()
    with get_db() as db:
        row = db.query(CacheEntry).filter_by(key=key).first()
        if row and (time.time() - row.created_at) < SEARCH_TTL:
            row.hits += 1
            return row.value
    return None

def _cache_set(query: str, result: str):
    key = "search:" + hashlib.md5(query.encode()).hexdigest()
    with get_db() as db:
        existing = db.query(CacheEntry).filter_by(key=key).first()
        if existing:
            existing.value      = result
            existing.created_at = time.time()
        else:
            db.add(CacheEntry(key=key, value=result, hits=1, created_at=time.time()))

# ── DuckDuckGo ────────────────────────────────────────────────────
async def _ddg(query: str) -> str:
    async with httpx.AsyncClient(timeout=8, follow_redirects=True) as client:
        r = await client.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            headers={"User-Agent": "PeacockGPT/5.0"},
        )
        d     = r.json()
        parts = []
        if d.get("Answer"):
            parts.append(f"✅ {d['Answer']}")
        if d.get("Abstract"):
            parts.append(f"📌 {d['Abstract']}")
            if d.get("AbstractSource"):
                parts.append(f"المصدر: {d['AbstractSource']}")
        for t in (d.get("RelatedTopics") or [])[:4]:
            if isinstance(t, dict) and t.get("Text"):
                parts.append(f"• {t['Text'][:220]}")
        return "\n".join(parts)

# ── Wikipedia Arabic fallback ─────────────────────────────────────
async def _wikipedia(query: str) -> str:
    async with httpx.AsyncClient(timeout=6) as client:
        r = await client.get(
            f"https://ar.wikipedia.org/api/rest_v1/page/summary/{query.replace(' ','_')}",
            headers={"User-Agent": "PeacockGPT/5.0"},
        )
        if r.status_code == 200:
            return f"📚 {r.json().get('extract','')[:600]}"
    return ""

# ── Public interface ──────────────────────────────────────────────
async def hybrid_search(query: str) -> str:
    """
    Hybrid search: Cache → DuckDuckGo → Wikipedia.
    Returns cleaned text ready to inject into prompt.
    """
    if not FLAGS.get("web_search") or FLAGS.get("kill_search"):
        return ""

    # 1. Cache
    cached = _cache_get(query)
    if cached:
        log.info(f"Search cache HIT: {query[:40]}")
        return cached

    log.info(f"Search API: {query[:40]}")
    result = ""

    # 2. DuckDuckGo
    try:
        result = await _ddg(query)
    except Exception as e:
        log.warning(f"DDG failed: {e}")

    # 3. Wikipedia fallback
    if not result:
        try:
            result = await _wikipedia(query)
        except Exception as e:
            log.warning(f"Wikipedia failed: {e}")

    # 4. Summarise: strip if too long
    if len(result) > 1200:
        result = result[:1200] + "…"

    final = result if result else "لم أجد نتائج واضحة. سأجيب من معرفتي."
    _cache_set(query, final)
    return final


def needs_search(message: str) -> bool:
    from core.config import INTENT_SEARCH_KW
    low = message.lower()
    return any(t in low for t in INTENT_SEARCH_KW)
