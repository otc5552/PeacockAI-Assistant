"""
services/pdf_service.py — PDF Generation Service
Limits: Free=1, Plus=10, Pro=unlimited
Author: PeacockAI – Mostafa
"""
import os, re, secrets, textwrap
from datetime import datetime
from typing import Optional
from pathlib import Path

from core.config import PDF_OUTPUT_DIR, PLANS, FLAGS, log
from core.database import get_db, PdfRecord, User

MAX_CONTENT_CHARS = 50_000   # 50K chars max per PDF
MAX_TITLE_LEN     = 150

# ── Ensure output dir exists ──────────────────────────────────────
Path(PDF_OUTPUT_DIR).mkdir(parents=True, exist_ok=True)


# ════════════════════════════════════════════════════════════════
# QUOTA CHECK
# ════════════════════════════════════════════════════════════════

def check_pdf_quota(user_id: str, user_plan: str) -> tuple[bool, str]:
    """Returns (allowed, reason)."""
    if not FLAGS.get("pdf_export"):
        return False, "ميزة PDF متوقفة مؤقتاً"
    if FLAGS.get("kill_pdf"):
        return False, "تصدير PDF متوقف مؤقتاً"

    limit = PLANS.get(user_plan, PLANS["free"]).get("pdf", 1)
    if limit == -1:   # unlimited (pro)
        return True, ""

    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        count = u.pdf_count or 0 if u else 0

    if count >= limit:
        return False, (
            f"تم استهلاك الحد المسموح لإنشاء PDF ({limit} ملف).\n"
            f"ترقية لـ {'Plus' if user_plan=='free' else 'Pro'} للحصول على المزيد."
        )
    return True, ""


def _increment_pdf_count(user_id: str):
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.pdf_count = (u.pdf_count or 0) + 1


# ════════════════════════════════════════════════════════════════
# PDF GENERATION  (pure Python, no external lib required)
# ════════════════════════════════════════════════════════════════

def _escape_pdf_text(text: str) -> str:
    """Escape special chars for PDF string literals."""
    return (text.replace("\\","\\\\")
                .replace("(","\\(")
                .replace(")","\\)")
                .replace("\r",""))


def _arabic_aware_wrap(text: str, width: int = 80) -> list:
    """
    Simple line wrapper. Arabic PDFs need special handling;
    for now we just wrap at word boundaries.
    """
    lines = []
    for paragraph in text.split("\n"):
        if not paragraph.strip():
            lines.append("")
            continue
        wrapped = textwrap.wrap(paragraph, width=width) or [""]
        lines.extend(wrapped)
    return lines


def generate_pdf_bytes(
    content: str,
    title:   str = "PeacockGPT Export",
    user_name: str = "",
) -> bytes:
    """
    Generate a valid PDF file from text content using raw PDF syntax.
    No external libraries (reportlab/fpdf) needed.
    Returns raw PDF bytes.
    """
    # Truncate
    content  = content[:MAX_CONTENT_CHARS]
    title    = title[:MAX_TITLE_LEN]
    now_str  = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Clean markdown syntax for plain text PDF
    clean = re.sub(r"#{1,6}\s?", "", content)
    clean = re.sub(r"\*\*(.+?)\*\*", r"\1", clean)
    clean = re.sub(r"\*(.+?)\*",   r"\1", clean)
    clean = re.sub(r"`(.+?)`",     r"\1", clean)
    clean = re.sub(r"```.*?```",   "",    clean, flags=re.DOTALL)
    clean = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", clean)

    lines = _arabic_aware_wrap(clean, width=85)

    # ── Build PDF objects ─────────────────────────────────────
    objects  = []
    xref_pos = []

    def add_obj(content_str: str) -> int:
        obj_num = len(objects) + 1
        objects.append(content_str)
        return obj_num

    # Obj 1: Catalog
    add_obj("<< /Type /Catalog /Pages 2 0 R >>")

    # Pages will be obj 2 (updated later)
    add_obj("")  # placeholder

    # Font obj 3 — Helvetica (built-in, no embedding needed)
    add_obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")

    # ── Layout constants ──────────────────────────────────────
    PAGE_W, PAGE_H = 595, 842   # A4
    MARGIN_L, MARGIN_R = 50, 50
    MARGIN_T, MARGIN_B = 80, 60
    FONT_SIZE_H    = 14
    FONT_SIZE_BODY = 11
    LINE_H_BODY    = 16
    content_width  = PAGE_W - MARGIN_L - MARGIN_R
    y_start        = PAGE_H - MARGIN_T
    y_end          = MARGIN_B

    # ── Split lines into pages ────────────────────────────────
    lines_per_page = int((y_start - y_end - 40) / LINE_H_BODY)
    pages_data     = [lines[i:i+lines_per_page]
                      for i in range(0, max(len(lines),1), lines_per_page)]

    page_obj_nums   = []
    content_obj_nums = []

    for page_idx, page_lines in enumerate(pages_data):
        # Build page content stream
        stream_parts = []
        stream_parts.append("BT")
        stream_parts.append(f"/F1 {FONT_SIZE_H} Tf")
        stream_parts.append(f"{MARGIN_L} {y_start} Td")

        # Header: title + metadata
        header = f"PeacockGPT 5  |  {title}"
        stream_parts.append(f"({_escape_pdf_text(header)}) Tj")
        stream_parts.append(f"0 -{LINE_H_BODY + 6} Td")
        stream_parts.append(f"/F1 8 Tf")
        meta = f"Generated: {now_str}" + (f"  |  User: {user_name}" if user_name else "") + f"  |  Page {page_idx+1}/{len(pages_data)}"
        stream_parts.append(f"({_escape_pdf_text(meta)}) Tj")
        stream_parts.append(f"0 -{10} Td")

        # Separator line
        stream_parts.append("ET")
        stream_parts.append(f"{MARGIN_L} {y_start - 36} m {PAGE_W - MARGIN_R} {y_start - 36} l S")
        stream_parts.append("BT")
        stream_parts.append(f"/F1 {FONT_SIZE_BODY} Tf")
        stream_parts.append(f"{MARGIN_L} {y_start - 46} Td")
        stream_parts.append(f"0 -{LINE_H_BODY} TL")

        # Body text
        for line in page_lines:
            safe_line = _escape_pdf_text(line)
            # Simple RTL hint: just output as-is (PDF RTL needs more work)
            stream_parts.append(f"({safe_line}) Tj T*")

        stream_parts.append("ET")
        stream = "\n".join(stream_parts)
        stream_bytes = stream.encode("latin-1", errors="replace")

        # Content stream object
        c_num = add_obj(
            f"<< /Length {len(stream_bytes)} >>\nstream\n"
            + stream.replace("é","e")
            + "\nendstream"
        )
        content_obj_nums.append(c_num)

        # Page object
        p_num = add_obj(
            f"<< /Type /Page /Parent 2 0 R "
            f"/MediaBox [0 0 {PAGE_W} {PAGE_H}] "
            f"/Contents {c_num} 0 R "
            f"/Resources << /Font << /F1 3 0 R >> >> >>"
        )
        page_obj_nums.append(p_num)

    # Fix pages object (obj 2)
    kids = " ".join(f"{n} 0 R" for n in page_obj_nums)
    objects[1] = (f"<< /Type /Pages /Kids [{kids}] "
                  f"/Count {len(page_obj_nums)} >>")

    # ── Assemble PDF bytes ────────────────────────────────────
    out  = [b"%PDF-1.4\n"]
    xref_pos = []

    for i, obj_content in enumerate(objects, start=1):
        xref_pos.append(sum(len(b) for b in out))
        obj_bytes = f"{i} 0 obj\n{obj_content}\nendobj\n".encode("latin-1", errors="replace")
        out.append(obj_bytes)

    # Cross-reference table
    xref_start = sum(len(b) for b in out)
    n_objs     = len(objects)
    xref_lines = [f"xref\n0 {n_objs+1}\n",
                  "0000000000 65535 f \n"]
    for pos in xref_pos:
        xref_lines.append(f"{pos:010d} 00000 n \n")

    out.append("".join(xref_lines).encode("latin-1"))
    out.append(
        f"trailer\n<< /Size {n_objs+1} /Root 1 0 R >>\n"
        f"startxref\n{xref_start}\n%%EOF\n".encode("latin-1")
    )

    return b"".join(out)


# ════════════════════════════════════════════════════════════════
# PUBLIC API
# ════════════════════════════════════════════════════════════════

def generate_pdf(
    content:   str,
    user_id:   str,
    user_plan: str,
    title:     str = "PeacockGPT Export",
    user_name: str = "",
    save:      bool = True,
) -> tuple[bytes, str]:
    """
    Generate PDF and return (bytes, record_id).
    Checks quota, increments counter, optionally saves file.
    """
    ok, reason = check_pdf_quota(user_id, user_plan)
    if not ok:
        raise PermissionError(reason)

    if len(content) > MAX_CONTENT_CHARS:
        raise ValueError(f"المحتوى طويل جداً (max {MAX_CONTENT_CHARS//1000}K حرف)")

    pdf_bytes = generate_pdf_bytes(content, title, user_name)
    record_id = secrets.token_hex(10)

    # Increment counter
    if user_id != "guest":
        _increment_pdf_count(user_id)

    # Save to disk (optional)
    file_path = ""
    if save and user_id != "guest":
        safe_title  = re.sub(r"[^\w\-_]", "_", title)[:40]
        filename    = f"{record_id}_{safe_title}.pdf"
        file_path   = os.path.join(PDF_OUTPUT_DIR, filename)
        with open(file_path, "wb") as f:
            f.write(pdf_bytes)

        # Log to DB
        with get_db() as db:
            db.add(PdfRecord(
                id=record_id, user_id=user_id,
                title=title[:200], content_len=len(content),
                file_path=file_path,
                created_at=datetime.now().isoformat()
            ))

    log.info(f"[PDF] Generated: user={user_id} title={title[:40]} "
             f"size={len(pdf_bytes)//1024}KB")
    return pdf_bytes, record_id


def get_pdf_records(user_id: str) -> list:
    """List user's generated PDFs."""
    with get_db() as db:
        rows = db.query(PdfRecord).filter_by(user_id=user_id)\
                 .order_by(PdfRecord.created_at.desc()).limit(50).all()
    return [{"id":r.id,"title":r.title,"content_len":r.content_len,
             "created_at":r.created_at} for r in rows]


def get_pdf_count(user_id: str) -> int:
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        return u.pdf_count or 0 if u else 0
