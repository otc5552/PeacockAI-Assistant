"""
services/usage.py — Usage Enforcement + Cost Control + Rate Adaptation
Author: PeacockAI – Mostafa
"""
import time, threading
from datetime import datetime, timedelta
from typing import Tuple, Dict, List
from collections import defaultdict
from core.config import PLANS, PRICING, FLAGS, MODELS, log
from core.database import get_db, User

# ════════════════════════════════════════════════════════════════
# USAGE ENFORCEMENT
# ════════════════════════════════════════════════════════════════
def check_and_increment(user_id: str, action: str) -> Tuple[bool, str]:
    """
    Enforce daily limits.
    Auto-resets counters after reset_h hours.
    Returns (allowed, reason_if_blocked).
    """
    if not user_id or user_id == "guest":
        return True, ""

    with get_db() as db:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            return True, ""

        # Check subscription expiry → downgrade
        if user.sub_expires:
            if datetime.now() > datetime.fromisoformat(user.sub_expires):
                user.plan = "free"

        plan   = user.plan or "free"
        limits = PLANS.get(plan, PLANS["free"])
        now    = datetime.now()

        # Auto-reset counters
        if user.msg_reset_at:
            reset_dt = datetime.fromisoformat(user.msg_reset_at)
            if now - reset_dt > timedelta(hours=limits["reset_h"]):
                user.msg_count    = 0
                user.img_count    = 0
                user.search_count = 0
                user.msg_reset_at = now.isoformat()

        pricing = PRICING.get(plan, {})
        egp = pricing.get("egp", 0)
        usd = pricing.get("usd", 0)

        def _upgrade_msg():
            if plan == "free":
                return f"وصلت للحد اليومي. ترقية لـ Plus: {PRICING['plus']['egp']} جنيه / ${PRICING['plus']['usd']}"
            return f"وصلت للحد اليومي. ترقية لـ Pro: {PRICING['pro']['egp']} جنيه / ${PRICING['pro']['usd']}"

        if action == "msg":
            if user.msg_count >= limits["msg"]:
                return False, _upgrade_msg()
            user.msg_count += 1
            user.last_seen  = now.isoformat()

        elif action == "img":
            if user.img_count >= limits["img"]:
                return False, f"وصلت لحد {limits['img']} صورة يومياً."
            user.img_count += 1

        elif action == "search":
            if user.search_count >= limits["search"]:
                return False, "وصلت لحد البحث اليومي."
            user.search_count += 1

        return True, ""


def get_user_stats(user_id: str) -> dict:
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if not u:
            return {}
        plan   = u.plan or "free"
        limits = PLANS.get(plan, PLANS["free"])
        return {
            "msg_count":     u.msg_count,
            "img_count":     u.img_count,
            "search_count":  u.search_count,
            "token_cost_usd":round(u.token_cost or 0, 5),
            "plan":          plan,
            "limits":        limits,
            "pricing":       PRICING.get(plan, {}),
            "sub_expires":   u.sub_expires,
        }

# ════════════════════════════════════════════════════════════════
# RATE LIMITER  (per IP, sliding window)
# ════════════════════════════════════════════════════════════════
_rate_store: Dict[str, List[float]] = defaultdict(list)

def check_rate(ip: str, max_calls: int = 30, window: int = 60) -> bool:
    now = time.time()
    _rate_store[ip] = [t for t in _rate_store[ip] if now - t < window]
    if len(_rate_store[ip]) >= max_calls:
        return False
    _rate_store[ip].append(now)
    return True

# ════════════════════════════════════════════════════════════════
# RATE ADAPTER  (dynamic quality degradation under load)
# ════════════════════════════════════════════════════════════════
class RateAdapter:
    def __init__(self):
        self._window: List[float] = []
        self._lock   = threading.Lock()

    def record(self):
        now = time.time()
        with self._lock:
            self._window = [t for t in self._window if now - t < 60]
            self._window.append(now)

    def rpm(self) -> int:
        now = time.time()
        with self._lock:
            return len([t for t in self._window if now - t < 60])

    def level(self) -> str:
        r = self.rpm()
        if r < 60:   return "normal"
        if r < 120:  return "light"
        if r < 200:  return "medium"
        return "heavy"

    def adapt_model(self, model_key: str) -> str:
        if not FLAGS.get("rate_adaptation"):
            return model_key
        lvl = self.level()
        if lvl == "normal":
            return model_key
        if lvl == "light" and model_key == "peacockgpt-5-pro":
            return "peacockgpt-5"
        if lvl in ("medium", "heavy"):
            return "peacockgpt-5-fast"
        return model_key

    def adapt_tokens(self, default: int = 4096) -> int:
        lvl = self.level()
        if lvl == "light":   return 2048
        if lvl == "medium":  return 1024
        if lvl == "heavy":   return 512
        return default


_adapter = RateAdapter()

def get_adapter() -> RateAdapter:
    return _adapter
