"""
services/self_improvement.py — Self-Improvement & Performance Analysis
Analyzes system performance, detects issues, suggests optimizations.
Author: PeacockAI – Mostafa
"""
import json
from datetime import datetime, timedelta
from typing import List, Dict
from core.config import log
from core.database import get_db, Log, Analytics, SemCache


# ════════════════════════════════════════════════════════════════
# PERFORMANCE ANALYSER
# ════════════════════════════════════════════════════════════════

def analyse_performance(hours: int = 24) -> dict:
    """
    Analyse system performance over the last N hours.
    Returns metrics + detected issues + recommendations.
    """
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    with get_db() as db:
        logs = db.query(Log).filter(Log.created_at >= cutoff).all()

    if not logs:
        return {"status": "no_data", "issues": [], "recommendations": []}

    # ── Core metrics ──────────────────────────────────────────
    total       = len(logs)
    errors      = [l for l in logs if not l.success]
    cache_hits  = [l for l in logs if l.cache_hit]
    latencies   = [l.latency_ms for l in logs if l.latency_ms and l.latency_ms > 0]
    costs       = [l.cost_usd   for l in logs if l.cost_usd   and l.cost_usd   > 0]

    error_rate   = round(len(errors) / total * 100, 1)
    cache_rate   = round(len(cache_hits) / total * 100, 1)
    avg_latency  = round(sum(latencies) / len(latencies), 0) if latencies else 0
    p95_latency  = round(sorted(latencies)[int(len(latencies)*0.95)], 0) if latencies else 0
    total_cost   = round(sum(costs), 4)
    avg_cost     = round(total_cost / max(total,1), 5)

    # ── Model distribution ────────────────────────────────────
    model_counts: Dict[str, int] = {}
    for l in logs:
        m = l.model or "unknown"
        model_counts[m] = model_counts.get(m, 0) + 1

    # ── Common errors ─────────────────────────────────────────
    error_types: Dict[str, int] = {}
    for l in errors:
        if l.error_msg:
            key = l.error_msg[:60]
            error_types[key] = error_types.get(key, 0) + 1
    top_errors = sorted(error_types.items(), key=lambda x: -x[1])[:5]

    # ── Issue detection ───────────────────────────────────────
    issues: List[dict] = []
    recommendations: List[dict] = []

    if error_rate > 10:
        issues.append({
            "type":     "high_error_rate",
            "severity": "critical" if error_rate > 25 else "warning",
            "value":    f"{error_rate}%",
            "message":  f"معدل الأخطاء مرتفع: {error_rate}%",
        })
        recommendations.append({
            "action": "check_api_keys",
            "detail": "تحقق من مفاتيح API — قد تكون منتهية الصلاحية",
            "priority": "high",
        })

    if cache_rate < 20 and total > 50:
        issues.append({
            "type":     "low_cache_rate",
            "severity": "info",
            "value":    f"{cache_rate}%",
            "message":  f"معدل الكاش منخفض: {cache_rate}% — تكلفة أعلى",
        })
        recommendations.append({
            "action": "lower_similarity_threshold",
            "detail": "خفّض SIM_THRESHOLD من 0.88 إلى 0.82 لزيادة Cache Hits",
            "priority": "medium",
        })

    if avg_latency > 5000:
        issues.append({
            "type":     "high_latency",
            "severity": "warning",
            "value":    f"{avg_latency}ms",
            "message":  f"متوسط زمن الاستجابة مرتفع: {avg_latency}ms",
        })
        recommendations.append({
            "action": "enable_rate_adaptation",
            "detail": "فعّل rate_adaptation لخفض النماذج الثقيلة تحت الضغط",
            "priority": "high",
        })

    if total_cost > 5.0:
        issues.append({
            "type":     "high_cost",
            "severity": "warning",
            "value":    f"${total_cost}",
            "message":  f"التكلفة اليومية مرتفعة: ${total_cost}",
        })
        recommendations.append({
            "action": "increase_cache_ttl",
            "detail": "زيادة CACHE_TTL_CHAT من 1800 إلى 3600 ثانية",
            "priority": "medium",
        })
        recommendations.append({
            "action": "review_heavy_model_usage",
            "detail": f"النموذج الأغلى يُستخدم {model_counts.get('peacockgpt-5',0)} مرة — قيّم إذا كان ضرورياً",
            "priority": "low",
        })

    if p95_latency > 10000:
        issues.append({
            "type":     "p95_latency_spike",
            "severity": "warning",
            "value":    f"{p95_latency}ms",
            "message":  f"P95 latency مرتفع جداً: {p95_latency}ms",
        })

    return {
        "period_hours":   hours,
        "total_requests": total,
        "metrics": {
            "error_rate":   f"{error_rate}%",
            "cache_rate":   f"{cache_rate}%",
            "avg_latency_ms": avg_latency,
            "p95_latency_ms": p95_latency,
            "total_cost_usd": total_cost,
            "avg_cost_usd":   avg_cost,
        },
        "model_distribution": model_counts,
        "top_errors":     [{"error": e[0], "count": e[1]} for e in top_errors],
        "issues":         issues,
        "recommendations":recommendations,
        "health_score":   _health_score(error_rate, cache_rate, avg_latency),
    }


def _health_score(error_rate: float, cache_rate: float, avg_latency: float) -> int:
    """
    Overall system health 0-100.
    100 = perfect, <50 = needs attention.
    """
    score = 100
    score -= min(error_rate * 2, 40)          # error rate penalty
    score -= max(0, (20 - cache_rate) * 0.5)  # low cache penalty
    score -= min(max(0, avg_latency - 2000) / 100, 20)  # latency penalty
    return max(0, int(score))


# ════════════════════════════════════════════════════════════════
# AUTO-OPTIMISER (applies safe changes automatically)
# ════════════════════════════════════════════════════════════════

def auto_optimise():
    """
    Apply safe automatic optimisations based on performance data.
    Called by background scheduler.
    """
    from core.config import FLAGS, SIM_THRESHOLD
    import core.config as cfg

    report = analyse_performance(hours=6)
    applied = []

    for rec in report.get("recommendations", []):
        action = rec.get("action","")

        if action == "enable_rate_adaptation":
            if not FLAGS.get("rate_adaptation"):
                FLAGS["rate_adaptation"] = True
                applied.append("enabled rate_adaptation")

        elif action == "lower_similarity_threshold":
            if cfg.SIM_THRESHOLD > 0.80:
                cfg.SIM_THRESHOLD = max(0.80, cfg.SIM_THRESHOLD - 0.03)
                applied.append(f"SIM_THRESHOLD → {cfg.SIM_THRESHOLD:.2f}")

    if applied:
        log.info(f"[SelfImprovement] Auto-optimised: {applied}")

    return {"applied": applied, "health": report.get("health_score", 100)}
