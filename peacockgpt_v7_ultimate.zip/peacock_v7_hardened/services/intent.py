"""
services/intent.py — Advanced Intent Detection Engine v2
Multi-signal hybrid: keyword rules + regex patterns + length heuristics + recency
Detects: chat | code | image | search | memory | complex | simple
Author: PeacockAI – Mostafa
"""
import re
from dataclasses import dataclass, field
from typing import List, Dict
from core.config import (
    INTENT_CODE_KW, INTENT_SEARCH_KW, INTENT_IMAGE_KW,
    INTENT_MEMORY_KW, INTENT_COMPLEX_KW, INTENT_SIMPLE_KW,
)

INTENT_CHAT    = "chat"
INTENT_CODE    = "code"
INTENT_IMAGE   = "image"
INTENT_SEARCH  = "search"
INTENT_MEMORY  = "memory"
INTENT_COMPLEX = "complex"
INTENT_SIMPLE  = "simple"

# ── Regex patterns (stronger signal than keyword) ──────────────
_RE_CODE       = re.compile(
    r"```|def\s+\w|class\s+\w|import\s+\w|function\s*\(|"
    r"SELECT\s+|INSERT\s+|<\w+>|#!\s*/usr|#!/bin|"
    r"@app\.|@router\.|async def|await\s|\.then\(|=>",
    re.IGNORECASE
)
_RE_IMAGE      = re.compile(
    r"(ارسم|أرسم|اعمل|أنشئ|صمم|generate|create|draw|design)\s*"
    r".{0,30}(صورة|صور|image|photo|picture|artwork|illustration)",
    re.IGNORECASE
)
_RE_PERSONAL   = re.compile(
    r"(اسمي|أنا\s+\w|عمري|شغلتي|أعمل\s+في|مجالي|بدرس|"
    r"my\s+name|i\s+am\s+a|i\s+work\s+as)",
    re.IGNORECASE
)
_RE_QUESTION   = re.compile(r"\?|؟|كيف\s|لماذا\s|ما\s+هو|اشرح|وضّح|علّم")
_RE_URL        = re.compile(r"https?://\S+|www\.\S+")
_RE_NUMBERS    = re.compile(r"\b\d{4}\b")   # years → search signal


@dataclass
class Intent:
    type:       str
    confidence: float
    signals:    List[str]
    scores:     Dict[str, float] = field(default_factory=dict)


def detect_intent(message: str) -> Intent:
    """
    Advanced hybrid intent detection.
    Combines: keyword frequency, regex patterns, structural heuristics.
    Returns Intent with confidence [0-1] and full score breakdown.
    """
    low     = message.lower()
    signals: List[str] = []

    scores: Dict[str, float] = {
        INTENT_CHAT:    0.15,   # base bias
        INTENT_CODE:    0.0,
        INTENT_IMAGE:   0.0,
        INTENT_SEARCH:  0.0,
        INTENT_MEMORY:  0.0,
        INTENT_COMPLEX: 0.0,
        INTENT_SIMPLE:  0.0,
    }

    # ── Signal 1: Keyword matching (weighted by count) ────────
    code_hits = sum(1 for kw in INTENT_CODE_KW if kw in low)
    if code_hits:
        scores[INTENT_CODE] += min(code_hits * 0.22, 0.88)
        signals.append(f"code_kw×{code_hits}")

    img_hits = sum(1 for kw in INTENT_IMAGE_KW if kw in low)
    if img_hits:
        scores[INTENT_IMAGE] += min(img_hits * 0.4, 0.9)
        signals.append(f"image_kw×{img_hits}")

    srch_hits = sum(1 for kw in INTENT_SEARCH_KW if kw in low)
    if srch_hits:
        scores[INTENT_SEARCH] += min(srch_hits * 0.28, 0.84)
        signals.append(f"search_kw×{srch_hits}")

    mem_hits = sum(1 for kw in INTENT_MEMORY_KW if kw in low)
    if mem_hits:
        scores[INTENT_MEMORY] += min(mem_hits * 0.28, 0.84)
        signals.append(f"memory_kw×{mem_hits}")

    cplx_hits = sum(1 for kw in INTENT_COMPLEX_KW if kw in low)
    if cplx_hits:
        scores[INTENT_COMPLEX] += min(cplx_hits * 0.18, 0.72)
        signals.append(f"complex_kw×{cplx_hits}")

    simp_hits = sum(1 for kw in INTENT_SIMPLE_KW if kw in low)
    if simp_hits:
        scores[INTENT_SIMPLE] += min(simp_hits * 0.35, 0.7)
        signals.append(f"simple_kw×{simp_hits}")

    # ── Signal 2: Regex patterns (strong) ────────────────────
    if _RE_CODE.search(message):
        scores[INTENT_CODE] += 0.45
        signals.append("code_pattern")

    if _RE_IMAGE.search(message):
        scores[INTENT_IMAGE] += 0.55
        signals.append("image_pattern")

    if _RE_PERSONAL.search(message):
        scores[INTENT_MEMORY] += 0.45
        signals.append("personal_pattern")

    if _RE_URL.search(message):
        scores[INTENT_SEARCH] += 0.3
        signals.append("url_present")

    if _RE_NUMBERS.search(message):
        scores[INTENT_SEARCH] += 0.15
        signals.append("year_number")

    # ── Signal 3: Structural heuristics ──────────────────────
    msg_len = len(message)

    if msg_len < 15:
        scores[INTENT_SIMPLE]  += 0.3
        signals.append("very_short")
    elif msg_len < 40 and not code_hits:
        scores[INTENT_SIMPLE]  += 0.1
    elif msg_len > 250:
        scores[INTENT_COMPLEX] += 0.2
        signals.append("long_message")
    elif msg_len > 500:
        scores[INTENT_COMPLEX] += 0.35

    # ── Signal 4: Questions → complex or chat ────────────────
    if _RE_QUESTION.search(message):
        scores[INTENT_CHAT]    += 0.08
        scores[INTENT_COMPLEX] += 0.08

    # ── Signal 5: Multi-line usually = code or complex ────────
    if message.count("\n") >= 3:
        scores[INTENT_CODE]    += 0.15
        scores[INTENT_COMPLEX] += 0.1
        signals.append("multiline")

    # ── Signal 6: Arabic-heavy → chat bias ───────────────────
    arabic_chars = len(re.findall(r"[\u0600-\u06FF]", message))
    if arabic_chars > len(message) * 0.5:
        scores[INTENT_CHAT] += 0.05

    # ── Conflict resolution rules ─────────────────────────────
    # Don't let 'simple' win when strong code signal exists
    if scores[INTENT_SIMPLE] > scores[INTENT_CODE] and code_hits >= 2:
        scores[INTENT_SIMPLE] = scores[INTENT_CODE] * 0.4

    # Image always wins over simple
    if scores[INTENT_IMAGE] > 0.4:
        scores[INTENT_SIMPLE] = 0.0
        scores[INTENT_CHAT]   = min(scores[INTENT_CHAT], 0.1)

    # ── Pick winner ───────────────────────────────────────────
    winner = max(scores, key=lambda k: scores[k])
    conf   = round(min(scores[winner], 1.0), 3)

    return Intent(type=winner, confidence=conf,
                  signals=signals[:8], scores=scores)


def intent_to_model_key(intent: Intent, plan: str, user_id: str = "") -> str:
    """Map intent → optimal model key for the user's plan."""
    from core.config import PLANS, FLAGS, AB_EXPERIMENTS
    import hashlib

    allowed = PLANS.get(plan, PLANS["free"])["models"]

    if intent.type == INTENT_CODE:
        preferred = "peacockgpt-5-code"
        return preferred if preferred in allowed else "peacockgpt-5"

    if intent.type in (INTENT_COMPLEX, INTENT_MEMORY):
        return "peacockgpt-5" if "peacockgpt-5" in allowed else "peacockgpt-5-fast"

    if intent.type == INTENT_IMAGE:
        return "peacockgpt-5-fast"   # image gen doesn't need heavy model for prompt

    if intent.type == INTENT_SIMPLE:
        return "peacockgpt-5-fast"

    if intent.type == INTENT_SEARCH:
        # Search results are injected into context → fast model is fine
        return "peacockgpt-5-fast" if intent.confidence < 0.6 else "peacockgpt-5"

    # CHAT: A/B test on free plan
    if plan == "free" and FLAGS.get("ab_testing") and user_id:
        exp = AB_EXPERIMENTS.get("model_selection", {})
        h   = int(hashlib.md5(f"model_selection:{user_id}".encode()).hexdigest(), 16)
        var = "A" if (h % 100) / 100 < exp.get("split", 0.7) else "B"
        key = exp.get("variants", {}).get(var, "peacockgpt-5-fast")
        return key if key in allowed else "peacockgpt-5-fast"

    return "peacockgpt-5-fast"

import re
from dataclasses import dataclass
from typing import Tuple
from core.config import (
    INTENT_CODE_KW, INTENT_SEARCH_KW, INTENT_IMAGE_KW,
    INTENT_MEMORY_KW, INTENT_COMPLEX_KW, INTENT_SIMPLE_KW,
)

INTENT_CHAT    = "chat"
INTENT_CODE    = "code"
INTENT_IMAGE   = "image"
INTENT_SEARCH  = "search"
INTENT_MEMORY  = "memory"
INTENT_COMPLEX = "complex"
INTENT_SIMPLE  = "simple"

@dataclass
class Intent:
    type:       str
    confidence: float
    signals:    list


def detect_intent(message: str) -> Intent:
    """
    Hybrid intent detection: rule-based keyword matching + heuristics.
    Returns Intent with type, confidence [0–1], and matched signals.
    """
    low     = message.lower()
    signals = []
    scores  = {
        INTENT_CODE:    0.0,
        INTENT_IMAGE:   0.0,
        INTENT_SEARCH:  0.0,
        INTENT_MEMORY:  0.0,
        INTENT_COMPLEX: 0.0,
        INTENT_SIMPLE:  0.0,
        INTENT_CHAT:    0.1,   # base score
    }

    # ── Rule 1: Keyword matching ──────────────────────────────
    for kw in INTENT_CODE_KW:
        if kw in low:
            scores[INTENT_CODE] += 0.25
            signals.append(f"code_kw:{kw}")

    for kw in INTENT_IMAGE_KW:
        if kw in low:
            scores[INTENT_IMAGE] += 0.5
            signals.append(f"image_kw:{kw}")

    for kw in INTENT_SEARCH_KW:
        if kw in low:
            scores[INTENT_SEARCH] += 0.3
            signals.append(f"search_kw:{kw}")

    for kw in INTENT_MEMORY_KW:
        if kw in low:
            scores[INTENT_MEMORY] += 0.3
            signals.append(f"memory_kw:{kw}")

    for kw in INTENT_COMPLEX_KW:
        if kw in low:
            scores[INTENT_COMPLEX] += 0.2
            signals.append(f"complex_kw:{kw}")

    for kw in INTENT_SIMPLE_KW:
        if kw in low:
            scores[INTENT_SIMPLE] += 0.4
            signals.append(f"simple_kw:{kw}")

    # ── Rule 2: Message length ────────────────────────────────
    msg_len = len(message)
    if msg_len < 20:
        scores[INTENT_SIMPLE]  += 0.2
    elif msg_len > 300:
        scores[INTENT_COMPLEX] += 0.25
        signals.append("long_message")

    # ── Rule 3: Code patterns (regex) ────────────────────────
    if re.search(r"```|def |class |import |function\s*\(|<[a-z]+>|SELECT\s", message):
        scores[INTENT_CODE] += 0.4
        signals.append("code_pattern")

    # ── Rule 4: Question marks and Arabic interrogatives ─────
    if re.search(r"\?|؟|كيف|لماذا|ما هو|ما هي|اشرح|وضّح", message):
        scores[INTENT_CHAT]    += 0.1
        scores[INTENT_COMPLEX] += 0.1

    # ── Rule 5: Direct image instruction ─────────────────────
    if re.search(r"(ارسم|أرسم|اعمل|أنشئ|صمم|generate|create)\s.*(صور|image|photo|picture)", low):
        scores[INTENT_IMAGE] += 0.5
        signals.append("image_instruction")

    # ── Rule 6: Personal info (memory) ───────────────────────
    if re.search(r"(أنا|اسمي|عمري|شغلتي|أعمل في|مجالي|بدرس)", message):
        scores[INTENT_MEMORY] += 0.4
        signals.append("personal_info")

    # ── Pick winner ───────────────────────────────────────────
    winner   = max(scores, key=lambda k: scores[k])
    conf     = min(scores[winner], 1.0)

    # Cap simple confidence — don't mistake code as simple
    if winner == INTENT_SIMPLE and scores[INTENT_CODE] > 0.2:
        winner = INTENT_CODE
        conf   = scores[INTENT_CODE]

    return Intent(type=winner, confidence=conf, signals=signals[:6])


def intent_to_model_key(intent: Intent, plan: str, user_id: str = "") -> str:
    """Map intent → best model key for the user's plan."""
    from core.config import PLANS, FALLBACK_CHAIN, FLAGS, AB_EXPERIMENTS
    import hashlib

    allowed = PLANS.get(plan, PLANS["free"])["models"]

    if intent.type == INTENT_CODE:
        preferred = "peacockgpt-5-code"
        return preferred if preferred in allowed else "peacockgpt-5"

    if intent.type in (INTENT_COMPLEX, INTENT_MEMORY):
        return "peacockgpt-5" if "peacockgpt-5" in allowed else "peacockgpt-5-fast"

    if intent.type == INTENT_SIMPLE:
        return "peacockgpt-5-fast"

    # A/B for chat on free plan
    if plan == "free" and FLAGS.get("ab_testing") and user_id:
        exp  = AB_EXPERIMENTS.get("model_selection", {})
        h    = int(hashlib.md5(f"model_selection:{user_id}".encode()).hexdigest(), 16)
        var  = "A" if (h % 100) / 100 < exp.get("split", 0.7) else "B"
        key  = exp.get("variants", {}).get(var, "peacockgpt-5-fast")
        return key if key in allowed else "peacockgpt-5-fast"

    return "peacockgpt-5-fast"
