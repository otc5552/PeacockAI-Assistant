"""
services/orchestrator.py — Ultimate Smart Pipeline v7
Request → Intent → Memory → Cache → Router → Agent/Model → Post-process
Added: agent intent detection + cost per request tracking
Author: PeacockAI – Mostafa
"""
import time, asyncio
from dataclasses import dataclass, field
from typing import Optional, AsyncGenerator, Tuple
from core.config import MODELS, FLAGS, log
from services.intent import detect_intent, intent_to_model_key, Intent
from services.vector_cache import cache_get, cache_set
from services.memory import build_memory_context, extract_and_update
from services.search import hybrid_search, needs_search
from services.context import build_context, post_process
from services.llm import execute, track_cost
from services.usage import get_adapter
from repositories.user_repo import increment_usage
from repositories.log_repo import write_log, write_event
from workers.jobs import enqueue


# ════════════════════════════════════════════════════════════════
# Pipeline context object
# ════════════════════════════════════════════════════════════════
@dataclass
class PipelineCtx:
    message:        str
    user_id:        str
    user_plan:      str
    user_tone:      str
    history:        list
    conv_id:        Optional[str]
    enable_search:  bool
    deep_think:     bool
    model_override: Optional[str]
    groq_key:       str
    gemini_key:     str
    # Derived
    intent:         Optional[Intent]  = None
    model_key:      str               = "peacockgpt-5-fast"
    max_tokens:     int               = 4096
    memory_ctx:     str               = ""
    search_ctx:     str               = ""
    system_prompt:  str               = ""
    messages:       list              = field(default_factory=list)
    cached_resp:    Optional[str]     = None
    t0:             float             = field(default_factory=time.time)
    request_cost:   float             = 0.0   # NEW: per-request cost tracking


# ════════════════════════════════════════════════════════════════
# STAGES
# ════════════════════════════════════════════════════════════════

def stage_analyse(ctx: PipelineCtx) -> PipelineCtx:
    ctx.intent = detect_intent(ctx.message)
    log.info(f"[Orchestrator] Intent: {ctx.intent.type} "
             f"({ctx.intent.confidence:.2f}) signals={ctx.intent.signals[:3]}")
    return ctx


def stage_cache(ctx: PipelineCtx) -> PipelineCtx:
    ctx.cached_resp = cache_get(ctx.message, "chat")
    if ctx.cached_resp:
        log.info(f"[Orchestrator] Cache HIT: {ctx.message[:40]}")
    return ctx


def stage_route(ctx: PipelineCtx) -> PipelineCtx:
    adapter = get_adapter()
    key     = ctx.model_override or intent_to_model_key(
        ctx.intent, ctx.user_plan, ctx.user_id
    )
    key            = adapter.adapt_model(key)
    ctx.model_key  = key
    ctx.max_tokens = adapter.adapt_tokens(MODELS[key].get("max_tokens", 4096))
    log.info(f"[Orchestrator] Routed → {key} "
             f"(tokens={ctx.max_tokens}, load={adapter.level()})")
    return ctx


def stage_memory(ctx: PipelineCtx) -> PipelineCtx:
    ctx.memory_ctx = build_memory_context(ctx.user_id)
    return ctx


async def stage_search(ctx: PipelineCtx) -> PipelineCtx:
    do_search = (
        ctx.enable_search
        and ctx.intent.type in ("search", "chat", "complex")
        and needs_search(ctx.message)
        and not FLAGS.get("kill_search")
    )
    if do_search:
        increment_usage(ctx.user_id, "search")
        asyncio.create_task(
            _fire_event(ctx.user_id, "search_used", {"query": ctx.message[:60]})
        )
        try:
            ctx.search_ctx = await hybrid_search(ctx.message)
        except Exception as e:
            log.warning(f"[Orchestrator] Search failed: {e}")
    return ctx


def stage_prompt(ctx: PipelineCtx) -> PipelineCtx:
    ctx.system_prompt, ctx.messages = build_context(
        ctx.message, ctx.history, ctx.user_tone,
        ctx.memory_ctx, ctx.search_ctx, ctx.deep_think
    )
    return ctx


async def stage_execute(ctx: PipelineCtx) -> AsyncGenerator[Tuple[str, str], None]:
    async for chunk, used_key in execute(
        ctx.model_key, ctx.messages, ctx.system_prompt,
        ctx.groq_key, ctx.gemini_key, ctx.max_tokens,
    ):
        yield chunk, used_key


async def stage_post(ctx: PipelineCtx, full_resp: str,
                     actual_key: str, latency_ms: int):
    processed = post_process(full_resp, ctx.user_tone)
    cache_set(ctx.message, processed, actual_key, "chat")
    extract_and_update(ctx.user_id, ctx.message, processed)

    tokens          = len(full_resp.split())
    cost            = track_cost(ctx.user_id, actual_key, tokens)
    ctx.request_cost = cost   # store for logging

    write_log(ctx.user_id, "chat", actual_key, tokens, cost, latency_ms, False, True)
    asyncio.create_task(
        _fire_event(ctx.user_id, "msg_sent", {
            "model":      actual_key,
            "latency_ms": latency_ms,
            "tokens":     tokens,
            "intent":     ctx.intent.type,
            "cost_usd":   round(cost, 5),
        })
    )

    if ctx.user_id and ctx.user_id != "guest":
        await enqueue("analyse_user",        {"user_id": ctx.user_id}, delay_s=5)
        await enqueue("generate_suggestions",{"user_id": ctx.user_id}, delay_s=12)
        if ctx.conv_id:
            await enqueue("summarise_conv",
                          {"conv_id": ctx.conv_id, "user_id": ctx.user_id}, delay_s=30)

    log.info(f"[Orchestrator] Done | model={actual_key} | "
             f"{latency_ms}ms | ${cost:.5f} | tokens={tokens}")
    return processed


# ════════════════════════════════════════════════════════════════
# FULL PIPELINE
# ════════════════════════════════════════════════════════════════

async def run_pipeline(ctx: PipelineCtx):
    """
    Full pipeline. Yields SSE strings.
    Now includes: agent intent check, cost-per-request in done event.
    """
    import json

    # Stage 1-2: analyse + cache
    ctx = stage_analyse(ctx)
    ctx = stage_cache(ctx)

    # Cache hit
    if ctx.cached_resp:
        yield f"data: {json.dumps({'type':'meta','model':'PeacockGPT','cached':True})}\n\n"
        chunk = ""
        for word in ctx.cached_resp.split(" "):
            chunk += word + " "
            if len(chunk) >= 30:
                yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
                chunk = ""
                await asyncio.sleep(0.008)
        if chunk:
            yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"
        yield f"data: {json.dumps({'type':'done','model':'PeacockGPT','cost_usd':0.0,'cached':True})}\n\n"
        write_log(ctx.user_id, "chat", "cache", 0, 0.0,
                  int((time.time()-ctx.t0)*1000), True, True)
        asyncio.create_task(_fire_event(ctx.user_id, "cache_hit"))
        return

    # Stage 3-6
    ctx = stage_route(ctx)
    ctx = stage_memory(ctx)
    ctx = await stage_search(ctx)
    ctx = stage_prompt(ctx)

    yield f"data: {json.dumps({'type':'meta','model':MODELS[ctx.model_key]['display'],'intent':ctx.intent.type,'search':bool(ctx.search_ctx)})}\n\n"

    full_resp  = ""
    actual_key = ctx.model_key

    try:
        async for chunk, used_key in stage_execute(ctx):
            full_resp  += chunk
            actual_key  = used_key
            yield f"data: {json.dumps({'type':'chunk','content':chunk})}\n\n"

        latency = int((time.time() - ctx.t0) * 1000)
        await stage_post(ctx, full_resp, actual_key, latency)
        yield f"data: {json.dumps({'type':'done','model':MODELS[actual_key]['display'],'cost_usd':round(ctx.request_cost,5)})}\n\n"

    except Exception as e:
        latency = int((time.time() - ctx.t0) * 1000)
        write_log(ctx.user_id, "chat", ctx.model_key, 0, 0.0, latency, False, False, str(e))
        asyncio.create_task(_fire_event(ctx.user_id, "error", {"err": str(e)[:100]}))
        log.error(f"[Orchestrator] Error: {e}")
        if not full_resp:
            yield f"data: {json.dumps({'type':'error','content':'في مشكلة. تأكد من مفاتيح API ⚙️'})}\n\n"
        yield f"data: {json.dumps({'type':'done','model':MODELS[ctx.model_key]['display'],'cost_usd':0.0})}\n\n"


async def _fire_event(user_id: str, event: str, meta: dict = None):
    await enqueue("track_analytics",
                  {"user_id": user_id, "event": event, "meta": meta or {}})
