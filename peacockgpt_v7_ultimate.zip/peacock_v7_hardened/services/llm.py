"""
services/llm.py — Hardened LLM Service v7
Unified interface: generate(prompt, model="auto")
Router + model calls fully separated.
Exponential backoff retry, timeout handling, fallback chain, cost tracking.
Author: PeacockAI – Mostafa
"""
import asyncio, json, time
from typing import AsyncGenerator, Tuple, Optional
from core.config import MODELS, FALLBACK_CHAIN, FLAGS, log
from core.database import get_db, User
import httpx

# ══════════════════════════════════════════════════════════════════
# RETRY & RESILIENCE CONFIG
# ══════════════════════════════════════════════════════════════════
MAX_RETRIES     = 3       # per model before falling back
BASE_BACKOFF    = 0.5     # seconds, doubles each retry
REQUEST_TIMEOUT = 90      # seconds per API call
FALLBACK_DELAY  = 0.3     # seconds between model switches


# ══════════════════════════════════════════════════════════════════
# COST TRACKING
# ══════════════════════════════════════════════════════════════════
def track_cost(user_id: str, model_key: str, token_count: int) -> float:
    cfg  = MODELS.get(model_key, {})
    cost = cfg.get("cost_per_1k", 0) * token_count / 1000
    if user_id and user_id != "guest" and cost > 0:
        try:
            with get_db() as db:
                u = db.query(User).filter_by(id=user_id).first()
                if u:
                    u.token_cost = (u.token_cost or 0) + cost
        except Exception as e:
            log.warning(f"[LLM] Cost track failed: {e}")
    return cost


# ══════════════════════════════════════════════════════════════════
# PROVIDER CALLS (pure, no retry logic here)
# ══════════════════════════════════════════════════════════════════

async def _call_groq(model_id: str, messages: list, api_key: str,
                     max_tokens: int = 4096) -> AsyncGenerator[str, None]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/json",
    }
    payload = {
        "model":       model_id,
        "messages":    messages,
        "max_tokens":  max_tokens,
        "temperature": 0.7,
        "stream":      True,
    }
    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        async with client.stream(
            "POST",
            "https://api.groq.com/openai/v1/chat/completions",
            headers=headers,
            json=payload,
        ) as r:
            if r.status_code == 429:
                raise RuntimeError(f"Groq rate-limited (429)")
            if r.status_code == 401:
                raise RuntimeError(f"Groq invalid API key (401)")
            if r.status_code != 200:
                body = await r.aread()
                raise RuntimeError(f"Groq {r.status_code}: {body[:200]}")
            async for line in r.aiter_lines():
                if line.startswith("data: ") and line != "data: [DONE]":
                    try:
                        delta = json.loads(line[6:])["choices"][0]["delta"].get("content", "")
                        if delta:
                            yield delta
                    except Exception:
                        pass


async def _call_gemini(model_id: str, messages: list, api_key: str,
                       system: str = "", max_tokens: int = 4096) -> AsyncGenerator[str, None]:
    contents = [
        {"role": "user" if m["role"] == "user" else "model",
         "parts": [{"text": m["content"]}]}
        for m in messages if m["role"] != "system"
    ]
    url     = (f"https://generativelanguage.googleapis.com/v1beta/"
               f"models/{model_id}:generateContent?key={api_key}")
    payload = {
        "contents": contents,
        "systemInstruction": {"parts": [{"text": system}]},
        "generationConfig": {"maxOutputTokens": max_tokens, "temperature": 0.7},
    }
    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        r = await client.post(url, json=payload)
        if r.status_code == 429:
            raise RuntimeError(f"Gemini rate-limited (429)")
        if r.status_code == 401:
            raise RuntimeError(f"Gemini invalid API key (401)")
        if r.status_code != 200:
            raise RuntimeError(f"Gemini {r.status_code}: {r.text[:200]}")
        text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        yield text


# ══════════════════════════════════════════════════════════════════
# ROUTER — picks correct provider call
# ══════════════════════════════════════════════════════════════════

async def _route(model_key: str, messages: list, system: str,
                 groq_key: str, gemini_key: str,
                 max_tokens: int) -> AsyncGenerator[str, None]:
    cfg = MODELS.get(model_key)
    if not cfg:
        raise RuntimeError(f"Unknown model key: {model_key}")

    provider = cfg["provider"]

    if provider == "groq":
        if not groq_key:
            raise RuntimeError("مفتاح Groq غير موجود")
        async for chunk in _call_groq(cfg["model_id"], messages, groq_key, max_tokens):
            yield chunk

    elif provider == "gemini":
        if not gemini_key:
            raise RuntimeError("مفتاح Gemini غير موجود")
        async for chunk in _call_gemini(cfg["model_id"], messages, gemini_key, system, max_tokens):
            yield chunk

    else:
        raise RuntimeError(f"Provider غير معروف: {provider}")


# ══════════════════════════════════════════════════════════════════
# EXECUTE — retry + fallback chain (main entry point)
# ══════════════════════════════════════════════════════════════════

async def execute(
    model_key:  str,
    messages:   list,
    system:     str,
    groq_key:   str,
    gemini_key: str,
    max_tokens: int = 4096,
) -> AsyncGenerator[Tuple[str, str], None]:
    """
    Tries model_key → FALLBACK_CHAIN on failure.
    Each model gets MAX_RETRIES attempts with exponential backoff.
    Yields (chunk, actual_model_key).
    Never crashes — always attempts to return something.
    """
    current      = model_key
    chain_steps  = 0
    max_chain    = 4  # max fallback hops

    while current and chain_steps <= max_chain:
        cfg = MODELS.get(current)
        if not cfg:
            log.warning(f"[LLM] Unknown model in chain: {current}")
            current = FALLBACK_CHAIN.get(current)
            chain_steps += 1
            continue

        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                log.info(
                    f"[LLM] → {current} ({cfg['model_id']}) "
                    f"attempt {attempt+1}/{MAX_RETRIES}"
                )
                got_any = False
                async for chunk in _route(
                    current, messages, system,
                    groq_key, gemini_key, max_tokens
                ):
                    got_any = True
                    yield chunk, current

                if got_any:
                    return  # success

                # Empty response — treat as soft failure
                raise RuntimeError("Empty response from model")

            except asyncio.TimeoutError:
                last_error = f"Timeout after {REQUEST_TIMEOUT}s"
                log.warning(f"[LLM] {current} timeout (attempt {attempt+1})")
            except RuntimeError as e:
                last_error = str(e)
                log.warning(f"[LLM] {current} error: {e} (attempt {attempt+1})")
            except Exception as e:
                last_error = str(e)
                log.warning(f"[LLM] {current} unexpected: {e} (attempt {attempt+1})")

            # Exponential backoff before retry
            if attempt < MAX_RETRIES - 1:
                wait = BASE_BACKOFF * (2 ** attempt)
                log.info(f"[LLM] Waiting {wait:.1f}s before retry…")
                await asyncio.sleep(wait)

        # All retries failed for this model — try next in chain
        next_model = FALLBACK_CHAIN.get(current)
        log.warning(f"[LLM] {current} exhausted ({last_error}). Fallback → {next_model}")
        current     = next_model
        chain_steps += 1

        if current:
            await asyncio.sleep(FALLBACK_DELAY)

    # Entire chain exhausted
    raise RuntimeError(
        "⚠️ جميع النماذج غير متاحة الآن. تأكد من مفاتيح API وحاول مرة أخرى."
    )


# ══════════════════════════════════════════════════════════════════
# SIMPLE UNIFIED INTERFACE  generate(prompt, model="auto")
# ══════════════════════════════════════════════════════════════════

async def generate(
    prompt:     str,
    groq_key:   str = "",
    gemini_key: str = "",
    model:      str = "auto",
    system:     str = "",
    max_tokens: int = 1024,
) -> str:
    """
    Simplified non-streaming interface.
    model="auto" picks the cheapest available model.
    Returns full response string.
    """
    if model == "auto":
        model = "peacockgpt-5-fast" if groq_key else "peacockgpt-5-pro"

    messages = [{"role": "user", "content": prompt}]
    if system:
        messages.insert(0, {"role": "system", "content": system})

    result = ""
    async for chunk, _ in execute(model, messages, system, groq_key, gemini_key, max_tokens):
        result += chunk
    return result
