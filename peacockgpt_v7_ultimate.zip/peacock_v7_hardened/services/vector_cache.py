"""
services/vector_cache.py — Semantic Cache v7
Embeddings + cosine similarity + TTL + ranking + per-scope limits.
Author: PeacockAI – Mostafa
"""
import json, math, hashlib, secrets, time
from typing import Optional, List, Tuple
from core.config import SIM_THRESHOLD, CACHE_TTL_CHAT, CACHE_TTL_SEARCH, FLAGS, log
from core.database import get_db, SemCache

# ══════════════════════════════════════════════════════════════════
# STOP WORDS
# ══════════════════════════════════════════════════════════════════

_STOP = frozenset({
    "من","في","إلى","على","هل","ما","هو","هي","أنا","أنت","كيف","لماذا",
    "ماذا","متى","أين","عن","مع","أو","لو","كان","يكون","وهو","وهي",
    "a","an","the","is","are","was","were","how","what","why","when",
    "can","do","did","will","would","could","should","please",
})

# ══════════════════════════════════════════════════════════════════
# EMBEDDING — deterministic bag-of-words, L2-normalised
# ══════════════════════════════════════════════════════════════════

def embed(text: str, dims: int = 512) -> List[float]:
    """
    Fast deterministic BoW embedding.
    No external ML lib. Each term → hash-bucketed dimension.
    Returns L2-normalised vector.
    """
    import re
    text  = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text.lower())
    words = [w for w in text.split() if w not in _STOP and len(w) > 1]
    freq: dict = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1

    top = sorted(freq.items(), key=lambda x: -x[1])[:60]
    if not top:
        return []

    vec = [0.0] * dims
    for w, cnt in top:
        i1 = int(hashlib.md5(w.encode()).hexdigest(), 16) % dims
        i2 = int(hashlib.sha1(w.encode()).hexdigest(), 16) % dims
        vec[i1] += cnt * 1.0
        vec[i2] += cnt * 0.5

    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def cosine(a: List[float], b: List[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    return sum(x * y for x, y in zip(a, b))


# ══════════════════════════════════════════════════════════════════
# PUBLIC INTERFACE
# ══════════════════════════════════════════════════════════════════

def cache_get(query: str, scope: str = "chat") -> Optional[str]:
    """
    Lookup cache:
    1. Exact MD5 hash match (O(1))
    2. Cosine similarity over recent entries
    Returns response string or None.
    """
    if not FLAGS.get("semantic_cache"):
        return None

    exact_key = _make_key(query, scope)
    now       = time.time()

    try:
        with get_db() as db:
            # 1. Exact match
            row = db.query(SemCache).filter(
                SemCache.query_hash == exact_key,
                SemCache.ttl > now
            ).first()
            if row:
                row.hits += 1
                log.debug(f"⚡ Cache EXACT: {query[:40]}")
                return row.response

            # 2. Similarity search (only for longer queries)
            if len(query) < 10:
                return None

            q_emb = embed(query)
            if not q_emb:
                return None

            candidates = db.query(SemCache).filter(
                SemCache.ttl > now,
                SemCache.embedding.isnot(None),
                SemCache.scope == scope,      # scope-aware lookup
            ).order_by(SemCache.hits.desc(), SemCache.created_at.desc()).limit(200).all()

            best_sim, best_row = 0.0, None
            for c in candidates:
                try:
                    c_emb = json.loads(c.embedding)
                    sim   = cosine(q_emb, c_emb)
                    if sim > best_sim:
                        best_sim, best_row = sim, c
                except Exception:
                    pass

            if best_sim >= SIM_THRESHOLD and best_row:
                best_row.hits += 1
                log.info(f"🔍 Cache SIMILAR sim={best_sim:.2f}: {query[:40]}")
                return best_row.response

    except Exception as e:
        log.warning(f"[Cache] cache_get error: {e}")

    return None


def cache_set(query: str, response: str, model: str = "",
              scope: str = "chat") -> None:
    """Store query → response with embedding and TTL."""
    if not FLAGS.get("semantic_cache"):
        return
    if not query or not response:
        return

    ttl = time.time() + (CACHE_TTL_SEARCH if scope == "search" else CACHE_TTL_CHAT)
    emb = embed(query)
    key = _make_key(query, scope)

    try:
        with get_db() as db:
            existing = db.query(SemCache).filter_by(query_hash=key).first()
            if existing:
                existing.response   = response[:5000]
                existing.embedding  = json.dumps(emb) if emb else None
                existing.ttl        = ttl
                existing.model_used = model
                existing.scope      = scope
            else:
                db.add(SemCache(
                    id         = secrets.token_hex(12),
                    query_hash = key,
                    query_text = query[:500],
                    response   = response[:5000],
                    embedding  = json.dumps(emb) if emb else None,
                    model_used = model,
                    scope      = scope,
                    ttl        = ttl,
                    hits       = 1,
                    created_at = time.time(),
                ))
    except Exception as e:
        log.warning(f"[Cache] cache_set error: {e}")


def cache_delete_expired() -> int:
    """Remove all expired entries. Returns count deleted."""
    try:
        with get_db() as db:
            rows = db.query(SemCache).filter(SemCache.ttl < time.time()).all()
            count = len(rows)
            for r in rows:
                db.delete(r)
        return count
    except Exception as e:
        log.warning(f"[Cache] cache_delete_expired error: {e}")
        return 0


def cache_stats() -> dict:
    try:
        with get_db() as db:
            total = db.query(SemCache).count()
            valid = db.query(SemCache).filter(SemCache.ttl > time.time()).count()
            top   = db.query(SemCache).order_by(SemCache.hits.desc()).limit(10).all()
        return {
            "total":       total,
            "valid":       valid,
            "expired":     total - valid,
            "hit_rate":    round(valid / max(total, 1) * 100, 1),
            "top_queries": [{"q": r.query_text[:60], "hits": r.hits} for r in top],
        }
    except Exception as e:
        log.warning(f"[Cache] cache_stats error: {e}")
        return {"total": 0, "valid": 0, "expired": 0}


def _make_key(query: str, scope: str) -> str:
    return hashlib.md5(f"{scope}:{query}".encode()).hexdigest()
