"""
services/file_manager.py — Hardened Sandboxed File Manager v7
ALL operations confined to AGENT_SANDBOX. Zero path-escape possible.
Audit log on every operation. Allowlist-only extensions.
Author: PeacockAI – Mostafa
"""
import os, re, json, zipfile, shutil, secrets, time
from pathlib import Path
from typing import List, Optional, Tuple
from datetime import datetime
from core.config import AGENT_SANDBOX, log

# ══════════════════════════════════════════════════════════════════
# SECURITY CONSTANTS
# ══════════════════════════════════════════════════════════════════

ALLOWED_EXTENSIONS = frozenset({
    ".py", ".txt", ".md", ".json", ".yaml", ".yml", ".toml",
    ".js", ".ts", ".jsx", ".tsx", ".html", ".css", ".scss",
    ".example", ".sh", ".sql", ".csv", ".ini", ".cfg", ".rst",
})

_BLOCKED_PATTERNS = [
    re.compile(r"\.\.", re.IGNORECASE),
    re.compile(r"^[/\\~]"),
    re.compile(r"[\x00-\x1f]"),
    re.compile(r"(^|[/\\])\.env$", re.IGNORECASE),
    re.compile(r"\.(exe|dll|so|bin|elf|bat|cmd|ps1|msi|deb|rpm)$", re.IGNORECASE),
    re.compile(r"(^|[/\\])(etc|sys|proc|dev|root|boot|var|tmp|usr)[/\\]", re.IGNORECASE),
    re.compile(r"\.(ssh|aws|gnupg)[/\\]", re.IGNORECASE),
    re.compile(r"(passwd|shadow|sudoers|crontab|authorized_keys)", re.IGNORECASE),
]

MAX_FILE_SIZE   = 2 * 1024 * 1024
MAX_ZIP_SIZE    = 10 * 1024 * 1024
MAX_FILES_USER  = 100
MAX_FILE_NAME   = 100


class FileManagerError(Exception):
    pass


def _sandbox(user_id: str) -> Path:
    if not user_id or user_id == "guest":
        raise FileManagerError("مستخدم غير صالح")
    safe_uid = re.sub(r"[^a-zA-Z0-9_\-]", "_", user_id)[:64]
    p = Path(AGENT_SANDBOX).resolve() / safe_uid
    p.mkdir(parents=True, exist_ok=True)
    return p


def _validate_filename(filename: str) -> str:
    if not filename or not filename.strip():
        raise FileManagerError("اسم الملف لا يمكن أن يكون فارغاً")
    filename = filename.strip()
    if len(filename) > MAX_FILE_NAME:
        raise FileManagerError(f"اسم الملف طويل جداً (الحد {MAX_FILE_NAME} حرف)")
    for pat in _BLOCKED_PATTERNS:
        if pat.search(filename):
            raise FileManagerError(f"⛔ اسم الملف غير مسموح به: '{filename}'")
    ext = Path(filename).suffix.lower()
    if ext and ext not in ALLOWED_EXTENSIONS:
        raise FileManagerError(
            f"⛔ نوع الملف غير مدعوم: '{ext}'\n"
            f"الأنواع المسموحة: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        )
    basename = Path(filename).name
    if basename.startswith(".") and not ext:
        raise FileManagerError("⛔ ملفات مخفية بدون امتداد غير مسموح بها")
    return filename


def _safe_path(user_id: str, filename: str) -> Path:
    filename = _validate_filename(filename)
    sandbox  = _sandbox(user_id)
    full     = (sandbox / filename).resolve()
    try:
        full.relative_to(sandbox)
    except ValueError:
        log.warning(
            f"[SECURITY] Path escape attempt! user={user_id} "
            f"filename='{filename}' resolved='{full}'"
        )
        raise FileManagerError("⛔ محاولة الوصول خارج منطقة الأمان مرفوضة!")
    return full


def _audit(user_id: str, op: str, filename: str, success: bool = True, detail: str = ""):
    status = "OK" if success else "FAIL"
    log.info(
        f"[AUDIT][FileManager] op={op} user={user_id[:12]} "
        f"file='{filename}' status={status}"
        + (f" {detail}" if detail else "")
    )


def _check_quota(user_id: str):
    files = list_files(user_id)
    if len(files) >= MAX_FILES_USER:
        raise FileManagerError(
            f"⛔ تجاوزت حد الملفات ({MAX_FILES_USER}). احذف بعض الملفات أولاً."
        )


# ══════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════

def list_files(user_id: str, subdir: str = "") -> List[dict]:
    try:
        sandbox = _sandbox(user_id)
        base    = sandbox
        if subdir:
            base = _safe_path(user_id, subdir)
            if not base.is_dir():
                return []
        files = []
        for p in sorted(base.rglob("*")):
            if p.is_file():
                try:
                    rel = str(p.relative_to(sandbox))
                    files.append({
                        "name":     p.name,
                        "path":     rel,
                        "size_kb":  round(p.stat().st_size / 1024, 1),
                        "ext":      p.suffix,
                        "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(),
                    })
                except Exception:
                    pass
        return files
    except FileManagerError:
        raise
    except Exception as e:
        raise FileManagerError(f"خطأ في قراءة قائمة الملفات: {e}")


def read_file(user_id: str, filename: str) -> Tuple[str, int]:
    full = _safe_path(user_id, filename)
    if not full.exists():
        _audit(user_id, "READ", filename, False, "not_found")
        raise FileManagerError(f"الملف غير موجود: {filename}")
    if not full.is_file():
        _audit(user_id, "READ", filename, False, "not_a_file")
        raise FileManagerError(f"المسار ليس ملفاً: {filename}")
    size = full.stat().st_size
    if size > MAX_FILE_SIZE:
        _audit(user_id, "READ", filename, False, f"too_large")
        raise FileManagerError(f"الملف كبير جداً ({size//1024}KB). الحد 2MB")
    try:
        content = full.read_text(encoding="utf-8", errors="replace")
    except PermissionError:
        _audit(user_id, "READ", filename, False, "permission_denied")
        raise FileManagerError(f"⛔ رفض الوصول: {filename}")
    _audit(user_id, "READ", filename, True, f"{size}B")
    return content, size


def write_file(user_id: str, filename: str, content: str, overwrite: bool = True) -> dict:
    _check_quota(user_id)
    full = _safe_path(user_id, filename)
    if not overwrite and full.exists():
        _audit(user_id, "WRITE", filename, False, "already_exists")
        raise FileManagerError(f"الملف موجود بالفعل: {filename}")
    encoded = content.encode("utf-8", errors="replace")
    if len(encoded) > MAX_FILE_SIZE:
        _audit(user_id, "WRITE", filename, False, "too_large")
        raise FileManagerError("المحتوى كبير جداً (الحد 2MB)")
    full.parent.mkdir(parents=True, exist_ok=True)
    try:
        full.write_text(content, encoding="utf-8")
    except PermissionError:
        _audit(user_id, "WRITE", filename, False, "permission_denied")
        raise FileManagerError(f"⛔ رفض الكتابة: {filename}")
    size = full.stat().st_size
    _audit(user_id, "WRITE", filename, True, f"{size}B overwrite={overwrite}")
    return {"path": filename, "size_kb": round(size/1024, 2), "created": datetime.now().isoformat()}


def create_file(user_id: str, filename: str, content: str = "") -> dict:
    return write_file(user_id, filename, content, overwrite=False)


def delete_file(user_id: str, filename: str) -> bool:
    full = _safe_path(user_id, filename)
    if not full.exists():
        _audit(user_id, "DELETE", filename, False, "not_found")
        raise FileManagerError(f"الملف غير موجود: {filename}")
    if not full.is_file():
        _audit(user_id, "DELETE", filename, False, "not_a_file")
        raise FileManagerError("⛔ يُسمح بحذف الملفات فقط، لا المجلدات")
    try:
        full.unlink()
    except PermissionError:
        _audit(user_id, "DELETE", filename, False, "permission_denied")
        raise FileManagerError(f"⛔ رفض الحذف: {filename}")
    _audit(user_id, "DELETE", filename, True)
    return True


def rename_file(user_id: str, old_name: str, new_name: str) -> bool:
    old_path = _safe_path(user_id, old_name)
    new_path = _safe_path(user_id, new_name)
    if not old_path.exists():
        _audit(user_id, "RENAME", old_name, False, "src_not_found")
        raise FileManagerError(f"الملف غير موجود: {old_name}")
    if new_path.exists():
        _audit(user_id, "RENAME", old_name, False, f"dst_exists:{new_name}")
        raise FileManagerError(f"الاسم الجديد موجود بالفعل: {new_name}")
    old_path.rename(new_path)
    _audit(user_id, "RENAME", f"{old_name}→{new_name}", True)
    return True


def get_project_tree(user_id: str) -> str:
    files = list_files(user_id)
    if not files:
        return "المشروع فارغ."
    lines = [f"📁 sandbox/{user_id[:8]}…/"]
    for f in files:
        depth  = f["path"].count("/")
        indent = "  " * depth
        lines.append(f"{indent}├── {f['name']} ({f['size_kb']}KB)")
    return "\n".join(lines)


def export_zip(user_id: str) -> bytes:
    import io
    buf  = io.BytesIO()
    base = _sandbox(user_id)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in base.rglob("*"):
            if p.is_file() and p.suffix.lower() in ALLOWED_EXTENSIONS:
                zf.write(p, p.relative_to(base))
    _audit(user_id, "EXPORT_ZIP", "*", True)
    return buf.getvalue()


def import_zip(user_id: str, zip_bytes: bytes) -> List[str]:
    if len(zip_bytes) > MAX_ZIP_SIZE:
        raise FileManagerError("الملف المضغوط كبير جداً (max 10MB)")
    _check_quota(user_id)
    base      = _sandbox(user_id)
    extracted = []
    import io
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            total_size = sum(e.file_size for e in zf.infolist())
            if total_size > 50 * 1024 * 1024:
                raise FileManagerError("⛔ حماية Zip-bomb: المحتوى كبير جداً")
            for entry in zf.infolist():
                name = entry.filename
                if name.endswith("/"):
                    continue
                try:
                    _validate_filename(name)
                except FileManagerError:
                    log.warning(f"[IMPORT_ZIP] Skipped unsafe: {name}")
                    continue
                if entry.file_size > MAX_FILE_SIZE:
                    log.warning(f"[IMPORT_ZIP] Skipped large: {name}")
                    continue
                dest = (base / name).resolve()
                try:
                    dest.relative_to(base)
                except ValueError:
                    log.warning(f"[IMPORT_ZIP] Path escape in zip: {name}")
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                extracted.append(name)
    except zipfile.BadZipFile:
        raise FileManagerError("الملف المرفق ليس ZIP صالحاً")
    _audit(user_id, "IMPORT_ZIP", f"{len(extracted)} files", True)
    return extracted


def clear_sandbox(user_id: str):
    p = Path(AGENT_SANDBOX) / re.sub(r"[^a-zA-Z0-9_\-]", "_", user_id)[:64]
    if p.exists():
        shutil.rmtree(p)
    _audit(user_id, "CLEAR_SANDBOX", "*", True)
