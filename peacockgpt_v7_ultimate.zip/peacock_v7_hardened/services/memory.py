"""
services/memory.py — Smart Memory Engine v7
Pipeline: message → analyze → extract → structure → store
Levels: short | session | long (persistent)
Priority system + summarization + auto-update
Author: PeacockAI – Mostafa
"""
import re
from datetime import datetime
from typing import Dict, Optional, List
from core.config import FLAGS, log
from core.database import get_db, UserMemory


# ══════════════════════════════════════════════════════════════════
# CORE READ / WRITE / DELETE
# ══════════════════════════════════════════════════════════════════

def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest":
        return {}
    try:
        with get_db() as db:
            rows = db.query(UserMemory).filter_by(
                user_id=user_id, scope=scope
            ).order_by(UserMemory.confidence.desc()).all()
        return {r.key: r.value for r in rows}
    except Exception as e:
        log.warning(f"[Memory] mem_get error: {e}")
        return {}


def mem_get_all(user_id: str) -> Dict[str, Dict[str, str]]:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0, priority: str = "normal"):
    """
    Store a memory fact.
    Priority: 'high' | 'normal' | 'low'
    Only updates if new confidence >= existing (never downgrades high-conf facts).
    """
    if not user_id or user_id == "guest":
        return
    mid = f"{user_id}:{scope}:{key}"
    now = datetime.now().isoformat()
    try:
        with get_db() as db:
            existing = db.query(UserMemory).filter_by(id=mid).first()
            if existing:
                # Never downgrade high-priority facts with low-confidence signals
                if priority == "low" and (existing.confidence or 0) > 0.8:
                    return
                if confidence >= (existing.confidence or 0):
                    existing.value      = value[:500]
                    existing.confidence = confidence
                    existing.updated_at = now
            else:
                db.add(UserMemory(
                    id=mid, user_id=user_id, scope=scope,
                    key=key, value=value[:500],
                    confidence=confidence,
                    updated_at=now
                ))
    except Exception as e:
        log.warning(f"[Memory] mem_set error: {e}")


def mem_delete(user_id: str, scope: Optional[str] = None, key: Optional[str] = None):
    try:
        with get_db() as db:
            q = db.query(UserMemory).filter_by(user_id=user_id)
            if scope: q = q.filter_by(scope=scope)
            if key:   q = q.filter_by(key=key)
            q.delete()
    except Exception as e:
        log.warning(f"[Memory] mem_delete error: {e}")


# ══════════════════════════════════════════════════════════════════
# EXTRACTION PIPELINE
# ══════════════════════════════════════════════════════════════════

# Domain taxonomy
_DOMAIN_MAP: Dict[str, str] = {
    "برمجة": "software", "تطوير": "software", "كود": "software",
    "python": "software", "javascript": "software", "typescript": "software",
    "react": "software", "nodejs": "software", "backend": "software",
    "frontend": "software", "fullstack": "software", "devops": "software",
    "طب": "medicine", "دكتور": "medicine", "مريض": "medicine", "صيدلة": "medicine",
    "قانون": "law", "محامي": "law", "حقوق": "law",
    "اقتصاد": "finance", "مال": "finance", "استثمار": "finance",
    "بورصة": "finance", "تداول": "finance",
    "تصميم": "design", "ui": "design", "ux": "design",
    "figma": "design", "photoshop": "design",
    "تعليم": "education", "دراسة": "education", "جامعة": "education",
    "بيزنس": "business", "شركة": "business", "تسويق": "business",
    "ريادة": "business", "startup": "business",
    "ذكاء اصطناعي": "ai", "ai": "ai", "machine learning": "ai",
    "deep learning": "ai", "llm": "ai", "neural": "ai",
    "كتابة": "writing", "مقال": "writing", "محتوى": "writing",
}

_BEGINNER_RE = re.compile(
    r"مبتدئ|مش\s*فاهم|ازاي|ايه\s*معنى|لا\s*أعرف|مش\s*عارف|"
    r"للمبتدئين|أول\s*مرة|شرح\s*بسيط|من\s*الصفر|explain\s*simply|"
    r"i\s*don.t\s*know|for\s*beginners|step\s*by\s*step",
    re.IGNORECASE
)

_ADVANCED_RE = re.compile(
    r"architecture|trade.off|complexity|production\s*deploy|ci/cd|"
    r"distributed|microservices|scalable|concurrency|async\s+await|"
    r"optimization|benchmark|profiling|kubernetes|terraform|"
    r"design\s*pattern|system\s*design|low.level|internals",
    re.IGNORECASE
)

_NAME_RE = re.compile(
    r"(?:اسمي|أنا|my\s+name\s+is|i\s+am)\s+([A-Za-z\u0600-\u06FF]{2,25})",
    re.IGNORECASE
)

_ROLE_RE = re.compile(
    r"(?:أنا|i\s+am|i\s+work\s+as|شغلتي)\s+"
    r"(مطور|مهندس|دكتور|طبيب|محامي|مصمم|معلم|طالب|"
    r"developer|engineer|doctor|lawyer|designer|student|teacher)\b",
    re.IGNORECASE
)

_INTEREST_RE = re.compile(
    r"(?:اهتمامي|أحب|بحب|interested\s+in|i\s+like|i\s+love)\s+"
    r"([A-Za-z\u0600-\u06FF\s]{3,40}?)(?:\.|،|$)",
    re.IGNORECASE
)


def _extract_facts(message: str) -> List[dict]:
    """
    Extract structured facts from a message.
    Returns list of {key, value, scope, confidence, priority} dicts.
    """
    low   = message.lower()
    facts = []

    # ── Domain (vote-based, top domain wins) ─────────────────
    domain_votes: Dict[str, float] = {}
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            domain_votes[domain] = domain_votes.get(domain, 0) + 1
    if domain_votes:
        top_domain = max(domain_votes, key=domain_votes.get)  # type: ignore
        score = min(domain_votes[top_domain] * 0.25, 0.9)
        facts.append({"key": "domain", "value": top_domain,
                      "scope": "long", "confidence": score, "priority": "normal"})

    # ── Expertise level ───────────────────────────────────────
    if _BEGINNER_RE.search(message):
        facts.append({"key": "level", "value": "beginner",
                      "scope": "long", "confidence": 0.8, "priority": "normal"})
    elif _ADVANCED_RE.search(message):
        facts.append({"key": "level", "value": "advanced",
                      "scope": "long", "confidence": 0.9, "priority": "high"})

    # ── Name (high priority — explicit) ──────────────────────
    m = _NAME_RE.search(message)
    if m:
        name = m.group(1).strip()
        if 2 <= len(name) <= 25:
            facts.append({"key": "preferred_name", "value": name,
                          "scope": "long", "confidence": 0.95, "priority": "high"})

    # ── Role ─────────────────────────────────────────────────
    r = _ROLE_RE.search(message)
    if r:
        facts.append({"key": "role", "value": r.group(1).lower(),
                      "scope": "long", "confidence": 0.85, "priority": "normal"})

    # ── Interests ────────────────────────────────────────────
    interests = _INTEREST_RE.findall(message)
    if interests:
        top_interest = interests[0].strip()[:60]
        facts.append({"key": "interest", "value": top_interest,
                      "scope": "long", "confidence": 0.7, "priority": "low"})

    # ── Language preference ───────────────────────────────────
    eng_words = len(re.findall(r"\b[a-zA-Z]{4,}\b", message))
    ar_chars  = len(re.findall(r"[\u0600-\u06FF]", message))
    if eng_words >= 5 and ar_chars < 10:
        facts.append({"key": "lang_pref", "value": "english",
                      "scope": "long", "confidence": 0.7, "priority": "low"})
    elif eng_words >= 3 and ar_chars > 10:
        facts.append({"key": "lang_pref", "value": "bilingual",
                      "scope": "long", "confidence": 0.6, "priority": "low"})

    # ── Session topic ─────────────────────────────────────────
    if len(message) > 20:
        topic = message[:70].replace("\n", " ").strip()
        facts.append({"key": "last_topic", "value": topic,
                      "scope": "session", "confidence": 1.0, "priority": "normal"})

    return facts


def extract_and_update(user_id: str, message: str, response: str = ""):
    """
    Full extraction pipeline: analyze → extract → store.
    Safe to call after every AI response (silently skips on errors).
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return
    try:
        facts = _extract_facts(message)
        for f in facts:
            mem_set(
                user_id, f["scope"], f["key"], f["value"],
                f["confidence"], f.get("priority", "normal")
            )
        if facts:
            log.debug(f"[Memory] Extracted {len(facts)} facts for {user_id[:12]}")
    except Exception as e:
        log.warning(f"[Memory] extract_and_update error: {e}")


# ══════════════════════════════════════════════════════════════════
# CONTEXT BUILDER
# ══════════════════════════════════════════════════════════════════

def build_memory_context(user_id: str) -> str:
    """
    Assemble memory into a concise, prompt-ready string.
    Ordered by priority: name > role > domain > level > interests > other.
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest":
        return ""
    try:
        long    = mem_get(user_id, "long")
        session = mem_get(user_id, "session")

        parts: List[str] = []

        if long:
            summary_parts = []
            # Priority order
            for key, label in [
                ("preferred_name", "اسم المستخدم"),
                ("role",           "مهنته"),
                ("domain",         "مجاله"),
                ("level",          "مستواه"),
                ("interest",       "اهتمامه"),
                ("lang_pref",      "يفضل"),
            ]:
                if key in long:
                    val = long[key]
                    if key == "level":
                        val = {"beginner": "مبتدئ", "advanced": "متقدم"}.get(val, val)
                    summary_parts.append(f"{label}: {val}")
            # Any extra keys
            known = {"preferred_name","role","domain","level","interest","lang_pref"}
            for k, v in long.items():
                if k not in known:
                    summary_parts.append(f"{k}: {v}")
            if summary_parts:
                parts.append("معلومات المستخدم: " + " | ".join(summary_parts))

        if session:
            sess_parts = [f"{k}: {v}" for k, v in session.items()]
            if sess_parts:
                parts.append("الجلسة الحالية: " + " | ".join(sess_parts))

        return "\n".join(parts)
    except Exception as e:
        log.warning(f"[Memory] build_memory_context error: {e}")
        return ""


# ══════════════════════════════════════════════════════════════════
# CONVERSATION SUMMARIZER
# ══════════════════════════════════════════════════════════════════

def summarize_conversation(user_id: str, messages: list) -> str:
    """
    Generate a compact summary of conversation messages.
    Stores as session memory: 'conv_summary'.
    """
    if not messages:
        return ""
    try:
        user_msgs = [m["content"] for m in messages if m.get("role") == "user"]
        if len(user_msgs) < 2:
            return ""
        combined  = " ".join(user_msgs[-10:])[:600]
        # Domain detection
        low = combined.lower()
        for kw, domain in _DOMAIN_MAP.items():
            if kw in low:
                mem_set(user_id, "session", "last_conv_domain", domain,
                        confidence=0.8, priority="normal")
                break
        # Store topic summary
        snippet = user_msgs[-1][:100].replace("\n", " ").strip()
        mem_set(user_id, "session", "conv_summary", snippet,
                confidence=1.0, priority="normal")
        return snippet
    except Exception as e:
        log.warning(f"[Memory] summarize_conversation error: {e}")
        return ""
