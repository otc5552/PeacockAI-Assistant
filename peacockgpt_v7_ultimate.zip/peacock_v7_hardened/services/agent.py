"""
services/agent.py — Ultimate Pro Agent v7 (Human-Control Edition)
Pipeline: Request → Intent Verify → Plan → CONFIRM → Execute → Audit
Key principle: "لا تنفيذ بدون أمر صريح من المستخدم"
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time, re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, AsyncGenerator
from core.config import MODELS, FLAGS, PLANS, log
from core.database import get_db, AgentTask, PendingAction
from services.file_manager import (
    write_file, read_file, list_files, create_file,
    get_project_tree, FileManagerError
)
from services.llm import execute


# ══════════════════════════════════════════════════════════════════
# CONSTANTS
# ══════════════════════════════════════════════════════════════════

MAX_STEPS            = 15
CONFIRM_EXPIRE_MIN   = 10       # pending action expires after 10 min
MAX_CTX_CHARS        = 4000
STEP_TIMEOUT_S       = 60


# ══════════════════════════════════════════════════════════════════
# PERMISSION GUARDS
# ══════════════════════════════════════════════════════════════════

def require_pro(user_plan: str):
    if user_plan != "pro" or not PLANS["pro"].get("agent"):
        raise PermissionError(
            "🔒 Agent Mode متاح فقط لمستخدمي Pro.\n"
            "ترقية لـ Pro: 1500 جنيه أو $35/شهر"
        )


def check_agent_ops(user_id: str, user_plan: str) -> tuple:
    limit = PLANS.get(user_plan, {}).get("agent_ops", 0)
    if limit == 0:
        return False, "Agent Mode غير متاح في خطتك"
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u and (u.agent_ops or 0) >= limit:
                return False, f"تجاوزت حد {limit} عملية وكيل يومياً"
    except Exception as e:
        log.warning(f"[Agent] Quota check error: {e}")
    return True, ""


def increment_agent_ops(user_id: str):
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                u.agent_ops = (u.agent_ops or 0) + 1
    except Exception as e:
        log.warning(f"[Agent] Increment ops error: {e}")


# ══════════════════════════════════════════════════════════════════
# INTENT CLASSIFICATION  (read-only vs mutating)
# ══════════════════════════════════════════════════════════════════

# Read-only keywords → no confirmation needed
_READ_ONLY = {
    "اشرح", "explain", "اقرأ", "read file", "افتح ملف", "open file",
    "اعرض", "show", "list files", "اعرض الملفات", "قائمة",
    "حلل", "analyze", "review", "فحص", "افحص", "راجع",
    "ما هو", "what is", "كيف يعمل", "how does",
}

# Mutating keywords → need confirmation
_WRITE_OPS = {
    "اعمل", "ابني", "أنشئ", "build", "create",
    "عدل", "modify", "refactor", "edit", "اكتب",
    "احذف", "delete", "remove", "امسح",
    "غيّر", "change", "update", "بدّل",
    "اضف", "add", "أضف",
}


class IntentClass:
    READ     = "read"       # قراءة فقط — بدون تأكيد
    WRITE    = "write"      # كتابة / تعديل — يحتاج تأكيد
    DELETE   = "delete"     # حذف — يحتاج تأكيد عالي
    AMBIGUOUS = "ambiguous" # غير واضح — اسأل المستخدم


def classify_intent(message: str) -> str:
    """Classify message as read-only, write, delete, or ambiguous."""
    low = message.lower()

    # Delete is highest risk — check first
    delete_kw = {"احذف", "delete", "remove", "امسح", "ازل"}
    if any(k in low for k in delete_kw):
        return IntentClass.DELETE

    if any(k in low for k in _WRITE_OPS):
        return IntentClass.WRITE

    if any(k in low for k in _READ_ONLY):
        return IntentClass.READ

    # Short message without clear intent
    if len(message.strip()) < 15:
        return IntentClass.AMBIGUOUS

    return IntentClass.AMBIGUOUS


def is_agent_request(message: str) -> bool:
    """Check if message is an agent request (not plain chat)."""
    low = message.lower()
    all_triggers = _READ_ONLY | _WRITE_OPS
    return any(t in low for t in all_triggers)


def is_explicit_execute(message: str) -> bool:
    """Check if user explicitly confirmed/approved execution."""
    low = message.lower()
    confirm_words = {
        "نعم", "اوكي", "موافق", "تمام", "ابدأ", "نفذ",
        "yes", "ok", "okay", "confirm", "proceed", "go ahead",
        "اتفضل", "يلا", "كمّل",
    }
    return any(w in low for w in confirm_words)


# ══════════════════════════════════════════════════════════════════
# RISK ASSESSMENT
# ══════════════════════════════════════════════════════════════════

def assess_risk(steps: list) -> dict:
    """
    Assess risk level of a plan.
    Returns {level: low|medium|high, reasons: [], file_count: int, has_delete: bool}
    """
    file_count  = sum(1 for s in steps if s.get("type") in ("create_file", "write_file"))
    delete_count = sum(1 for s in steps if "delete" in s.get("type", ""))
    has_delete   = delete_count > 0

    reasons = []
    if file_count > 5:
        reasons.append(f"سيتم إنشاء/تعديل {file_count} ملفات")
    if has_delete:
        reasons.append(f"سيتم حذف {delete_count} ملف")
    if len(steps) > 8:
        reasons.append(f"خطة كبيرة: {len(steps)} خطوة")

    if has_delete or file_count > 8:
        level = "high"
    elif file_count > 3 or len(steps) > 5:
        level = "medium"
    else:
        level = "low"

    return {
        "level":       level,
        "reasons":     reasons,
        "file_count":  file_count,
        "has_delete":  has_delete,
        "step_count":  len(steps),
    }


def build_confirmation_message(goal: str, steps: list, risk: dict) -> str:
    """Build a human-readable confirmation message for the user."""
    risk_emoji = {"low": "🟢", "medium": "🟡", "high": "🔴"}.get(risk["level"], "🟡")
    lines = [
        f"📋 **خطة التنفيذ** — {goal[:60]}",
        "",
        f"{risk_emoji} مستوى الخطورة: **{risk['level'].upper()}**",
    ]
    if risk["reasons"]:
        lines.append("⚠️ ملاحظات: " + " | ".join(risk["reasons"]))

    lines += ["", "**الخطوات:**"]
    for i, step in enumerate(steps, 1):
        type_icons = {
            "create_file": "📄 إنشاء",
            "write_file":  "✏️ كتابة",
            "read_file":   "👁️ قراءة",
            "list_files":  "📂 عرض",
            "think":       "🧠 تحليل",
            "summarise":   "📝 تلخيص",
            "delete_file": "🗑️ حذف",
        }
        stype = step.get("type", "")
        icon  = type_icons.get(stype, "⚡")
        fname = f" → `{step['filename']}`" if step.get("filename") else ""
        lines.append(f"  {i}. {icon}{fname}: {step.get('description','')[:60]}")

    lines += [
        "",
        "💬 **هل تريد التنفيذ؟**",
        "اكتب **نعم** أو **موافق** للبدء، أو **لا** للإلغاء.",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════
# PENDING ACTIONS STORE
# ══════════════════════════════════════════════════════════════════

def save_pending_action(user_id: str, task_id: str,
                        action_type: str, summary: str,
                        plan: list, risk_level: str) -> str:
    """Save pending action awaiting user confirmation. Returns action_id."""
    action_id  = secrets.token_hex(12)
    now        = datetime.now()
    expires_at = (now + timedelta(minutes=CONFIRM_EXPIRE_MIN)).isoformat()
    try:
        with get_db() as db:
            db.add(PendingAction(
                id          = action_id,
                user_id     = user_id,
                task_id     = task_id,
                action_type = action_type,
                summary     = summary[:2000],
                plan_json   = json.dumps(plan, ensure_ascii=False),
                risk_level  = risk_level,
                status      = "pending",
                expires_at  = expires_at,
                created_at  = now.isoformat(),
            ))
    except Exception as e:
        log.warning(f"[Agent] save_pending_action error: {e}")
    return action_id


def get_pending_action(action_id: str, user_id: str) -> Optional[dict]:
    """Retrieve a pending action (validates ownership + expiry)."""
    try:
        with get_db() as db:
            row = db.query(PendingAction).filter_by(
                id=action_id, user_id=user_id, status="pending"
            ).first()
            if not row:
                return None
            # Check expiry
            if datetime.now() > datetime.fromisoformat(row.expires_at):
                row.status = "expired"
                return None
            return {
                "id":          row.id,
                "task_id":     row.task_id,
                "action_type": row.action_type,
                "summary":     row.summary,
                "plan":        json.loads(row.plan_json),
                "risk_level":  row.risk_level,
            }
    except Exception as e:
        log.warning(f"[Agent] get_pending_action error: {e}")
        return None


def get_pending_for_user(user_id: str) -> Optional[dict]:
    """Get the latest pending action for a user (for auto-detect confirm flow)."""
    try:
        with get_db() as db:
            row = db.query(PendingAction).filter_by(
                user_id=user_id, status="pending"
            ).order_by(PendingAction.created_at.desc()).first()
            if not row:
                return None
            if datetime.now() > datetime.fromisoformat(row.expires_at):
                row.status = "expired"
                return None
            return {
                "id":          row.id,
                "task_id":     row.task_id,
                "action_type": row.action_type,
                "summary":     row.summary,
                "plan":        json.loads(row.plan_json),
                "risk_level":  row.risk_level,
            }
    except Exception as e:
        log.warning(f"[Agent] get_pending_for_user error: {e}")
        return None


def resolve_pending_action(action_id: str, user_id: str, decision: str):
    """Mark pending action as confirmed/rejected."""
    try:
        with get_db() as db:
            row = db.query(PendingAction).filter_by(
                id=action_id, user_id=user_id
            ).first()
            if row:
                row.status     = decision  # confirmed | rejected
                row.decided_at = datetime.now().isoformat()
    except Exception as e:
        log.warning(f"[Agent] resolve_pending_action error: {e}")


# ══════════════════════════════════════════════════════════════════
# TASK PLANNER
# ══════════════════════════════════════════════════════════════════

PLAN_SYSTEM = """أنت PeacockGPT Agent، مخطط مهام ذكي من PeacockAI.
مهمتك: تحليل طلب المستخدم وإنشاء خطة تنفيذ مفصلة.

أعد JSON فقط بهذا الشكل:
{
  "goal": "وصف مختصر للهدف",
  "steps": [
    {"id": 1, "type": "think",       "description": "..."},
    {"id": 2, "type": "create_file", "filename": "...", "description": "..."},
    {"id": 3, "type": "write_file",  "filename": "...", "description": "..."},
    {"id": 4, "type": "read_file",   "filename": "...", "description": "..."},
    {"id": 5, "type": "summarise",   "description": "..."}
  ],
  "estimated_files": 3
}

أنواع الخطوات: think | create_file | write_file | read_file | list_files | summarise
قواعد: الخطوات منطقية ومرتبة | لا أكثر من 10 ملفات | JSON فقط"""


async def plan_task(goal: str, context: str, groq_key: str, gemini_key: str) -> dict:
    messages = [
        {"role": "system", "content": PLAN_SYSTEM},
        {"role": "user",   "content": f"الطلب: {goal}\n\nالسياق: {context[:500]}"}
    ]
    full = ""
    try:
        async for chunk, _ in execute(
            "peacockgpt-5", messages, PLAN_SYSTEM,
            groq_key, gemini_key, max_tokens=1500
        ):
            full += chunk
    except Exception as e:
        log.warning(f"[Agent] Plan LLM error: {e}")
        return _fallback_plan(goal)

    try:
        clean = full.strip()
        if "```" in clean:
            for part in clean.split("```"):
                stripped = part.strip().lstrip("json").strip()
                try:
                    return json.loads(stripped)
                except Exception:
                    pass
        return json.loads(clean)
    except Exception:
        return _fallback_plan(goal)


def _fallback_plan(goal: str) -> dict:
    return {
        "goal": goal,
        "steps": [
            {"id": 1, "type": "think",      "description": f"تحليل: {goal}"},
            {"id": 2, "type": "write_file", "filename": "output.md", "description": "كتابة النتيجة"},
            {"id": 3, "type": "summarise",  "description": "تلخيص النتيجة"},
        ],
        "estimated_files": 1,
    }


# ══════════════════════════════════════════════════════════════════
# STEP EXECUTOR
# ══════════════════════════════════════════════════════════════════

STEP_SYSTEM = """أنت PeacockGPT Agent من PeacockAI.
تنفذ الخطوة: {step_desc}
كجزء من مهمة: {goal}
{file_context}
{extra}
أجب مباشرة بالمحتوى المطلوب فقط."""


async def execute_step(step: dict, goal: str, user_id: str,
                       file_context: str, groq_key: str, gemini_key: str) -> dict:
    step_type = step.get("type", "think")
    step_desc = step.get("description", "")
    filename  = step.get("filename", "")
    result    = {"step_id": step["id"], "type": step_type,
                 "status": "done", "output": "", "filename": ""}

    try:
        if step_type == "list_files":
            files = list_files(user_id)
            result["output"] = json.dumps([f["path"] for f in files], ensure_ascii=False)

        elif step_type == "read_file":
            if not filename:
                result["status"] = "skipped"; result["output"] = "لا يوجد اسم ملف"; return result
            content, _ = read_file(user_id, filename)
            result["output"] = content[:3000]; result["filename"] = filename

        elif step_type in ("create_file", "write_file"):
            extra = (f"اكتب محتوى الملف `{filename}` كاملاً وجاهزاً للتشغيل."
                     if filename.endswith((".py",".js",".ts",".html"))
                     else f"اكتب محتوى الملف `{filename}`.")
            prompt = STEP_SYSTEM.format(goal=goal, step_desc=step_desc,
                                        file_context=file_context[:800], extra=extra)
            messages = [{"role":"system","content":prompt},
                        {"role":"user","content":f"انشئ: {filename}"}]
            content = ""
            try:
                async for chunk, _ in execute("peacockgpt-5", messages, prompt,
                                              groq_key, gemini_key, max_tokens=3000):
                    content += chunk
            except Exception as e:
                result["status"] = "error"; result["output"] = f"فشل توليد المحتوى: {e}"; return result

            write_file(user_id, filename, content, overwrite=True)
            result["output"]   = content[:500] + ("…" if len(content) > 500 else "")
            result["filename"] = filename

        elif step_type in ("think", "summarise"):
            prompt = STEP_SYSTEM.format(goal=goal, step_desc=step_desc,
                                        file_context=file_context[:600], extra="")
            messages = [{"role":"system","content":prompt},
                        {"role":"user","content":step_desc}]
            out = ""
            try:
                async for chunk, _ in execute("peacockgpt-5-fast", messages, prompt,
                                              groq_key, gemini_key, max_tokens=800):
                    out += chunk
            except Exception as e:
                out = f"(تعذّر التحليل: {e})"
            result["output"] = out

        else:
            result["status"] = "skipped"; result["output"] = f"نوع خطوة غير معروف: {step_type}"

    except FileManagerError as e:
        result["status"] = "error"; result["output"] = f"⛔ خطأ في الملفات: {e}"
        log.warning(f"[Agent] FileManagerError step {step['id']}: {e}")
    except Exception as e:
        result["status"] = "error"; result["output"] = f"خطأ غير متوقع: {e}"
        log.error(f"[Agent] Step {step['id']} unexpected error: {e}")

    return result


# ══════════════════════════════════════════════════════════════════
# STAGE 1: PLAN-ONLY (returns plan for confirmation, NO execution)
# ══════════════════════════════════════════════════════════════════

async def plan_and_request_confirmation(
    goal:       str,
    user_id:    str,
    user_plan:  str,
    groq_key:   str,
    gemini_key: str,
    context:    str = "",
) -> AsyncGenerator[str, None]:
    """
    Stage 1: Analyze goal → Generate plan → Ask for confirmation.
    Does NOT execute anything. Returns SSE stream.
    Human-Control: user must confirm before any file is touched.
    """
    t0 = time.time()

    # Guards
    try:
        require_pro(user_plan)
    except PermissionError as e:
        yield _sse({"type": "error", "content": str(e)}); return

    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok:
        yield _sse({"type": "error", "content": reason}); return

    if FLAGS.get("kill_agent"):
        yield _sse({"type": "error", "content": "⚠️ Agent Mode متوقف مؤقتاً."}); return

    # Classify intent
    intent = classify_intent(goal)

    # READ-ONLY: skip confirmation, execute directly
    if intent == IntentClass.READ:
        yield _sse({"type": "agent_info",
                    "content": "👁️ طلب قراءة فقط — سيتم التنفيذ مباشرة بدون تأكيد."})
        async for chunk in run_agent(
            goal=goal, user_id=user_id, user_plan=user_plan,
            groq_key=groq_key, gemini_key=gemini_key,
            context=context, skip_confirmation=True
        ):
            yield chunk
        return

    # AMBIGUOUS: clarify
    if intent == IntentClass.AMBIGUOUS:
        yield _sse({
            "type":    "agent_clarify",
            "content": (
                "🤔 لم أفهم ما تريد تنفيذه بدقة.\n"
                "هل تريد:\n"
                "• **قراءة / تحليل** الملفات؟ → قل: 'اقرأ' / 'حلل'\n"
                "• **تعديل / إنشاء** ملفات؟ → قل: 'اعمل' / 'عدل' / 'أنشئ'\n"
                "• **حذف** ملفات؟ → قل: 'احذف'"
            )
        })
        return

    # CREATE DB task record
    task_id = secrets.token_hex(10)
    now     = datetime.now().isoformat()
    try:
        with get_db() as db:
            db.add(AgentTask(
                id=task_id, user_id=user_id, goal=goal,
                status="planning", created_at=now, updated_at=now
            ))
    except Exception as e:
        log.warning(f"[Agent] DB task create: {e}")

    yield _sse({"type": "agent_start", "task_id": task_id,
                "message": f"🤖 تحليل الطلب: {goal[:60]}"})

    # Generate plan
    yield _sse({"type": "agent_phase", "phase": "planning",
                "message": "📋 جارٍ إنشاء خطة التنفيذ…"})

    plan_data = await plan_task(goal, context, groq_key, gemini_key)
    steps     = plan_data.get("steps", [])[:MAX_STEPS]
    risk      = assess_risk(steps)

    # Build confirmation message
    confirm_msg = build_confirmation_message(goal, steps, risk)

    # Save pending action
    action_id = save_pending_action(
        user_id     = user_id,
        task_id     = task_id,
        action_type = intent,
        summary     = confirm_msg,
        plan        = steps,
        risk_level  = risk["level"],
    )

    # Update task status
    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.plan       = json.dumps(steps, ensure_ascii=False)
                t.status     = "awaiting_confirm"
                t.updated_at = datetime.now().isoformat()
    except Exception as e:
        log.warning(f"[Agent] DB plan save: {e}")

    log.info(f"[Agent] Plan ready task={task_id} steps={len(steps)} "
             f"risk={risk['level']} action_id={action_id}")

    yield _sse({
        "type":        "agent_awaiting_confirm",
        "task_id":     task_id,
        "action_id":   action_id,
        "steps":       steps,
        "risk":        risk,
        "message":     confirm_msg,
        "expires_min": CONFIRM_EXPIRE_MIN,
    })


# ══════════════════════════════════════════════════════════════════
# STAGE 2: EXECUTE (after user confirmation)
# ══════════════════════════════════════════════════════════════════

async def execute_confirmed_action(
    action_id:  str,
    user_id:    str,
    user_plan:  str,
    groq_key:   str,
    gemini_key: str,
) -> AsyncGenerator[str, None]:
    """
    Stage 2: User confirmed → execute the saved plan.
    Called explicitly after user says yes.
    """
    # Retrieve and validate pending action
    pending = get_pending_action(action_id, user_id)
    if not pending:
        yield _sse({"type": "error",
                    "content": "⚠️ الطلب انتهت صلاحيته أو غير موجود. أرسل طلبك من جديد."})
        return

    steps   = pending["plan"]
    task_id = pending["task_id"]

    # Mark as confirmed
    resolve_pending_action(action_id, user_id, "confirmed")

    yield _sse({"type": "agent_confirmed", "task_id": task_id,
                "message": f"✅ تم التأكيد — بدء التنفيذ ({len(steps)} خطوة)"})

    # Execute
    async for chunk in _execute_steps(
        steps=steps, task_id=task_id, goal=pending["summary"][:80],
        user_id=user_id, groq_key=groq_key, gemini_key=gemini_key
    ):
        yield chunk


# ══════════════════════════════════════════════════════════════════
# MAIN AGENT RUNNER (full pipeline, optional skip_confirmation)
# ══════════════════════════════════════════════════════════════════

async def run_agent(
    goal:              str,
    user_id:           str,
    user_plan:         str,
    groq_key:          str,
    gemini_key:        str,
    context:           str = "",
    skip_confirmation: bool = False,
) -> AsyncGenerator[str, None]:
    """
    Full pipeline.
    skip_confirmation=True → used for read-only tasks internally.
    """
    t0 = time.time()

    # Guards
    try:
        require_pro(user_plan)
    except PermissionError as e:
        yield _sse({"type": "error", "content": str(e)}); return

    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok:
        yield _sse({"type": "error", "content": reason}); return

    if FLAGS.get("kill_agent"):
        yield _sse({"type": "error", "content": "⚠️ Agent Mode متوقف مؤقتاً."}); return

    task_id = secrets.token_hex(10)
    now     = datetime.now().isoformat()
    try:
        with get_db() as db:
            db.add(AgentTask(
                id=task_id, user_id=user_id, goal=goal,
                status="running", created_at=now, updated_at=now
            ))
    except Exception as e:
        log.warning(f"[Agent] DB create: {e}")

    yield _sse({"type": "agent_start", "task_id": task_id,
                "message": f"🤖 بدء التنفيذ: {goal[:60]}"})

    yield _sse({"type": "agent_phase", "phase": "planning",
                "message": "📋 جارٍ إنشاء الخطة…"})

    plan_data = await plan_task(goal, context, groq_key, gemini_key)
    steps     = plan_data.get("steps", [])[:MAX_STEPS]

    yield _sse({"type": "agent_plan", "steps": steps,
                "message": f"✅ {len(steps)} خطوات"})

    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.plan = json.dumps(steps, ensure_ascii=False)
                t.status = "running"; t.updated_at = datetime.now().isoformat()
    except Exception:
        pass

    async for chunk in _execute_steps(steps, task_id, goal, user_id, groq_key, gemini_key):
        yield chunk


# ══════════════════════════════════════════════════════════════════
# INTERNAL: EXECUTE STEPS (shared by both paths)
# ══════════════════════════════════════════════════════════════════

async def _execute_steps(
    steps:      list,
    task_id:    str,
    goal:       str,
    user_id:    str,
    groq_key:   str,
    gemini_key: str,
) -> AsyncGenerator[str, None]:
    """Internal: execute a list of steps and stream results."""
    t0               = time.time()
    file_ops_log     = []
    accumulated_ctx  = ""

    for step in steps:
        yield _sse({
            "type":      "agent_step",
            "step_id":   step["id"],
            "step_type": step.get("type", ""),
            "message":   f"⚡ خطوة {step['id']}: {step.get('description','')[:60]}"
        })

        result = await execute_step(step, goal, user_id, accumulated_ctx, groq_key, gemini_key)

        # Build rolling context
        if result.get("output"):
            accumulated_ctx += f"\n[خطوة {step['id']}]: {result['output'][:400]}"
            if len(accumulated_ctx) > MAX_CTX_CHARS:
                accumulated_ctx = accumulated_ctx[-MAX_CTX_CHARS + 500:]

        if result.get("filename"):
            op_record = {
                "step":   step["id"],
                "type":   step.get("type"),
                "file":   result["filename"],
                "status": result["status"],
                "ts":     datetime.now().isoformat(),
            }
            file_ops_log.append(op_record)
            # AUDIT: every file operation
            log.info(
                f"[AUDIT][Agent] task={task_id} user={user_id[:12]} "
                f"step={step['id']} op={step.get('type')} "
                f"file='{result['filename']}' status={result['status']}"
            )

        yield _sse({
            "type":     "agent_step_done",
            "step_id":  result["step_id"],
            "status":   result["status"],
            "output":   result.get("output", "")[:300],
            "filename": result.get("filename", ""),
        })

        increment_agent_ops(user_id)
        await asyncio.sleep(0.05)

    # Summary
    elapsed = round(time.time() - t0, 1)
    try:
        files = list_files(user_id)
    except Exception:
        files = []

    summary_lines = [f"✅ اكتملت المهمة ({elapsed}s)", f"📁 ملفات منشأة/معدّلة: {len(file_ops_log)}"]
    for op in file_ops_log:
        icon = "✅" if op["status"] == "done" else "❌"
        summary_lines.append(f"  {icon} {op['file']} ({op['type']})")
    summary_lines.append(f"📂 إجمالي الملفات: {len(files)}")
    summary = "\n".join(summary_lines)

    yield _sse({
        "type":      "agent_done",
        "task_id":   task_id,
        "summary":   summary,
        "files":     [f["path"] for f in files],
        "ops_count": len(file_ops_log),
        "elapsed_s": elapsed,
    })

    # Update DB
    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.status     = "done"
                t.result     = summary[:1000]
                t.file_ops   = json.dumps(file_ops_log, ensure_ascii=False)
                t.steps_done = len(steps)
                t.elapsed_s  = elapsed
                t.updated_at = datetime.now().isoformat()
    except Exception as e:
        log.warning(f"[Agent] DB final update: {e}")

    log.info(f"[AUDIT][Agent] task={task_id} user={user_id[:12]} "
             f"goal='{goal[:50]}' steps={len(steps)} files={len(file_ops_log)} elapsed={elapsed}s")


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
