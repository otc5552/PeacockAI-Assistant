"""
services/context.py — Prompt Optimizer + Context Builder + Response Post-Processor
Author: PeacockAI – Mostafa
"""
import re
from typing import Tuple
from core.config import PERSONA, FLAGS

# ═══════════════════════════════════════════════════════════════
# SYSTEM PROMPT BUILDER
# ═══════════════════════════════════════════════════════════════
def build_system_prompt(
    tone:        str   = "friendly",
    memory_ctx:  str   = "",
    search_ctx:  str   = "",
    deep_think:  bool  = False,
) -> str:
    base  = PERSONA.get(tone, PERSONA["friendly"])
    parts = [base]
    if memory_ctx:
        parts.append(f"\n\n[ذاكرة المستخدم — استخدمها ضمنياً]\n{memory_ctx}\n[/ذاكرة]")
    if search_ctx:
        parts.append(f"\n\n[معلومات من الإنترنت — استخدمها كمرجع]\n{search_ctx}\n[/بحث]")
    if deep_think:
        parts.append("\n\nفكّر بعمق، حلل من زوايا متعددة، اذكر أي تحفظات مهمة.")
    return "".join(parts)

# ═══════════════════════════════════════════════════════════════
# PROMPT OPTIMIZER
# ═══════════════════════════════════════════════════════════════
MAX_HIST_MESSAGES = 12
MAX_MSG_CHARS     = 800
MAX_USER_MSG      = 4000

def optimize_prompt(message: str, history: list) -> Tuple[str, list]:
    """
    Compress prompt to reduce token usage:
    - Truncate very long user message
    - Sliding window on history
    - Trim old long messages
    """
    if not FLAGS.get("prompt_optimizer"):
        return message, history

    # 1. Truncate user message
    if len(message) > MAX_USER_MSG:
        message = message[:MAX_USER_MSG] + "\n[... اختُصرت الرسالة الطويلة]"

    # 2. Sliding window
    if len(history) > MAX_HIST_MESSAGES:
        history = history[:2] + history[-(MAX_HIST_MESSAGES - 2):]

    # 3. Trim old long messages
    trimmed = []
    for m in history:
        content = m.get("content", "")
        if len(content) > MAX_MSG_CHARS:
            content = content[:400] + " … " + content[-200:]
        trimmed.append({"role": m["role"], "content": content})

    return message, trimmed

# ═══════════════════════════════════════════════════════════════
# CONTEXT BUILDER  (assembles final messages list)
# ═══════════════════════════════════════════════════════════════
def build_context(
    message:    str,
    history:    list,
    tone:       str,
    memory_ctx: str,
    search_ctx: str,
    deep_think: bool,
) -> Tuple[str, list]:
    """
    Returns (system_prompt, messages_list) ready to send to LLM.
    """
    system = build_system_prompt(tone, memory_ctx, search_ctx, deep_think)
    msg_opt, hist_opt = optimize_prompt(message, history)

    messages = [{"role": "system", "content": system}]
    for h in hist_opt:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            messages.append({
                "role":    h["role"],
                "content": str(h["content"])[:3000],
            })
    messages.append({"role": "user", "content": msg_opt})
    return system, messages

# ═══════════════════════════════════════════════════════════════
# RESPONSE POST-PROCESSOR
# ═══════════════════════════════════════════════════════════════
_FILLER_RE = re.compile(
    r"(بكل\s*تأكيد|وبالطبع|سأكون\s*سعيداً\s*بمساعدتك|يسعدني\s*مساعدتك|"
    r"بالتأكيد\s*يمكنني|دعني\s*أوضح\s*لك|حسناً\s*دعني|"
    r"شكراً\s*لسؤالك|سؤال\s*ممتاز\s*جداً|سؤال\s*رائع|"
    r"سعيد\s*للإجابة|يمكنني\s*مساعدتك|هذا\s*سؤال\s*جيد\s*جداً)[،,!\s]*",
    re.IGNORECASE,
)

def post_process(text: str, tone: str = "friendly") -> str:
    """
    Clean AI response:
    - Remove filler/sycophantic openers
    - Normalise whitespace
    - For 'quick' tone: strip to first 4 sentences
    """
    if not FLAGS.get("response_postproc"):
        return text

    # Remove filler phrases
    text = _FILLER_RE.sub("", text)

    # Normalise multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()

    # Quick mode: keep only first 4 sentences if no code block
    if tone == "quick" and "```" not in text and len(text) > 500:
        sentences = re.split(r"(?<=[.؟!])\s+", text)
        text = " ".join(sentences[:4]).strip()

    return text
