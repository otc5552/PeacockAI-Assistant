# PeacockGPT v7 — Hardening & Fix Changelog
**Author: PeacockAI – Mostafa**

---

## 🛡️ 1. AGENT SANDBOX (CRITICAL FIX)
**file: `services/file_manager.py`**

### المشاكل المُصلَحة:
- ✅ `_sandbox()`: تنظيف `user_id` من أي أحرف خطرة قبل بناء المسار
- ✅ `_validate_filename()`: فحص كامل بـ 8 regex patterns قبل أي عملية
- ✅ `_safe_path()`: استخدام `.resolve()` + `.relative_to()` — لو escape حصل يُرفض فوراً
- ✅ `_audit()`: تسجيل **كل** عملية (read/write/delete/rename/zip) مع user_id + filename + status
- ✅ حماية zip-bomb: فحص uncompressed size قبل استخراج أي zip
- ✅ Allowlist extensions فقط — كل امتداد غير مسموح يُرفض
- ✅ رسائل خطأ عربية واضحة بدون كشف مسارات النظام

---

## 🧠 2. MEMORY SYSTEM UPGRADE
**file: `services/memory.py`**

### الإضافات:
- ✅ `priority` system: `high / normal / low` — الذكريات عالية الأهمية لا تُدهور أبداً
- ✅ `_INTEREST_RE`: استخراج الاهتمامات (اهتمامي / أحب / interested in)
- ✅ `summarize_conversation()`: تلخيص المحادثة وحفظ domain + snippet تلقائياً
- ✅ `build_memory_context()`: ترتيب أولوي (الاسم > المهنة > المجال > المستوى)
- ✅ كل الدوال محاطة بـ try/except — لا crash من الذاكرة أبداً
- ✅ استخراج متعدد الاهتمامات بدلاً من first-match واحد فقط

---

## 🧠 3. SEMANTIC CACHE
**file: `services/vector_cache.py`**

### التحسينات:
- ✅ **Scope-aware lookup**: البحث داخل نفس الـ scope فقط (chat ≠ search)
- ✅ **Ranking by hits + recency**: الأكثر استخداماً والأحدث تأتي أولاً في البحث
- ✅ **TTL hard-enforced**: الانتهاء يُفحص في DB query نفسه
- ✅ **Error isolation**: كل عملية cache محاطة بـ try/except
- ✅ **cache_stats()**: إضافة `hit_rate %`
- ✅ Response truncated to 5000 chars لحماية DB

---

## ⚡ 4. FALLBACK & RETRY SYSTEM
**file: `services/llm.py`**

### التحسينات الجوهرية:
- ✅ **Exponential backoff**: 0.5s → 1s → 2s بين المحاولات
- ✅ **MAX_RETRIES=3** لكل model قبل الانتقال للتالي
- ✅ **Empty response detection**: response فارغ = soft failure → retry
- ✅ **429 handling**: Rate limit error مُعرَّف بشكل صريح
- ✅ **401 handling**: API key خطأ يُسجَّل بوضوح
- ✅ **asyncio.TimeoutError** caught بشكل منفصل
- ✅ رسالة نهائية واضحة بالعربية إذا انتهت كل النماذج

---

## 🧠 5. COST CONTROL
**file: `services/llm.py` + `repositories/log_repo.py`**

### الإضافات:
- ✅ `generate()`: واجهة موحدة `model="auto"` تختار أرخص نموذج
- ✅ `track_cost()`: محاط بـ try/except لا يكسر الـ request
- ✅ `get_user_cost_summary()`: ملخص cost + tokens + cache_hits + errors لكل مستخدم
- ✅ تسجيل cost per request في كل log entry

---

## 🧠 6. AGENT ORCHESTRATOR
**file: `services/agent.py`**

### التحسينات:
- ✅ **Steps cap**: الخطوات محدودة بـ 15 لمنع infinite agent loops
- ✅ **Context cap**: accumulated_context لا يتجاوز 4000 حرف (ثم يُختصر)
- ✅ **Resilient LLM calls**: كل LLM call داخل step محاط بـ try/except
- ✅ **Fallback plan**: إذا فشل plan_task يُستخدم fallback بدلاً من crash
- ✅ **Audit per step**: كل file operation يُسجَّل في audit log
- ✅ **elapsed_s**: وقت التنفيذ الكلي في النتيجة النهائية
- ✅ **DB operations**: كل DB call محاط بـ try/except

---

## 🔐 7. SECURITY HARDENING
**files: `core/security.py`, `routes/auth.py`, `main.py`**

### الإضافات:
- ✅ **PBKDF2-HMAC-SHA256** بدلاً من SHA-256 البسيط (100,000 iteration)
- ✅ **Rate limiter** sliding window لكل IP: `check_rate_limit()`
- ✅ **JWT anti-replay**: إضافة `jti` (JWT ID) للـ token
- ✅ **Login brute-force protection**: 20 محاولة كل 5 دقائق لكل IP
- ✅ **Register flood protection**: 10 تسجيلات كل ساعة لكل IP
- ✅ **Input sanitization**: `sanitize_string()` تحذف XSS chars
- ✅ **Email validation**: regex صارم + max length
- ✅ **Security headers middleware**: X-Frame-Options, X-XSS-Protection, HSTS
- ✅ **Rate cleaner**: task دورية تنظف rate store كل 5 دقائق
- ✅ **`validate_message()`**: فحص الرسائل قبل المعالجة

---

## 📊 8. LOGGING & AUDIT SYSTEM
**file: `repositories/log_repo.py`**

### الإضافات:
- ✅ `write_log()`: تسجيل كل request (model, tokens, cost, latency, success)
- ✅ `write_event()`: تسجيل كل حدث analytics
- ✅ `write_agent_audit()`: تسجيل خاص لكل file operation في Agent
- ✅ `write_security_event()`: تسجيل محاولات أمنية (failed login, rate limit, sandbox escape)
- ✅ `get_user_cost_summary()`: ملخص تكلفة كل مستخدم
- ✅ كل دالة محاطة بـ try/except — الـ logging لا يكسر requests أبداً

---

## 🧠 9. MODEL SERVICE
**file: `services/llm.py`**

### التحسينات:
- ✅ **Router مستقل** `_route()`: منفصل تماماً عن retry logic
- ✅ **Provider calls مستقلة**: `_call_groq()` و `_call_gemini()` مستقلان
- ✅ **`generate()` unified interface**: `generate(prompt, model="auto")` بسيط ونظيف
- ✅ فصل كامل: provider call → router → executor → fallback chain

---

## ⚡ 10. RESILIENCE
**files: `services/llm.py`, `services/agent.py`, `services/memory.py`, `services/vector_cache.py`**

### التحسينات الشاملة:
- ✅ **Zero crash guarantee**: كل خدمة محاطة بـ try/except
- ✅ **Timeout handling**: REQUEST_TIMEOUT=90s مع asyncio.TimeoutError handling
- ✅ **DB resilience**: كل DB call مستقل — فشل واحد لا يأخذ الكل
- ✅ **Memory resilience**: فشل الذاكرة = تجاهل صامت + warning
- ✅ **Cache resilience**: فشل الـ cache = fallback للـ LLM مباشرة

---

## 📦 ملفات مُعدَّلة

| ملف | التغيير |
|-----|---------|
| `services/file_manager.py` | Sandbox hardening كامل + audit |
| `services/llm.py` | Retry + fallback + unified interface |
| `services/agent.py` | Steps cap + resilience + audit |
| `services/memory.py` | Priority system + summarizer |
| `services/vector_cache.py` | Scope-aware + error isolation |
| `core/security.py` | PBKDF2 + rate limiter + validation |
| `routes/auth.py` | Rate limiting + input validation |
| `repositories/log_repo.py` | Audit + security events + cost |
| `main.py` | Security middleware + security headers |

## ملفات لم تتغير
- `core/config.py` — لا تغيير
- `core/database.py` — لا تغيير  
- `routes/chat.py` — لا تغيير
- `routes/all_routes.py` — لا تغيير
- `routes/agent_routes.py` — لا تغيير
- `services/orchestrator.py` — لا تغيير
- `workers/jobs.py` — لا تغيير
- `frontend/index.html` — لا تغيير

---

# PeacockGPT v7 Ultimate — Human-Control Agent Edition

## 🧠 12. STRICT HUMAN CONTROL AGENT MODE (NEW)

### Architecture: Plan → Confirm → Execute

**الجديد الجوهري**: Agent لا ينفذ أي شيء بدون موافقة صريحة من المستخدم.

#### `services/agent.py` — التغييرات الكاملة:

**Intent Classification (`classify_intent`)**:
- `READ` → قراءة / تحليل / عرض = تنفيذ مباشر بدون تأكيد
- `WRITE` → تعديل / إنشاء = يحتاج تأكيد
- `DELETE` → حذف = يحتاج تأكيد عالي الخطورة
- `AMBIGUOUS` → يسأل المستخدم أولاً

**Risk Assessment (`assess_risk`)**:
- `low` 🟢: أقل من 3 ملفات، أقل من 5 خطوات
- `medium` 🟡: 3-8 ملفات أو 5-8 خطوات
- `high` 🔴: أكثر من 8 ملفات أو أي حذف

**Human-Control Pipeline**:
1. `/agent/plan` → تحليل + خطة + طلب تأكيد (لا تنفيذ)
2. `/agent/confirm` → تنفيذ بعد موافقة المستخدم
3. `/agent/run` → smart router (read=direct, write=confirm flow)
4. `/agent/pending` → فحص هل هناك تأكيد منتظر

**PendingAction Table (جديد في DB)**:
- حفظ الخطة مؤقتاً (10 دقائق expiry)
- ربطها بـ user_id + task_id
- status: pending | confirmed | rejected | expired

**Confirmation Message**:
- عرض الخطة كاملة بالعربي
- مستوى الخطورة مرئي (🟢🟡🔴)
- عدد الملفات + الخطوات
- تعليمات واضحة: "اكتب نعم للتنفيذ أو لا للإلغاء"

**`is_explicit_execute()`**: التعرف على كلمات التأكيد (نعم/موافق/ok/confirm...)
**`is_explicit_execute()`** False عند: "اشرح" / "explain" / "قرأ"

#### `core/database.py`:
- جدول `PendingAction` جديد
- `AgentTask.elapsed_s` column
- `AgentTask.status` = awaiting_confirm إضافي
- `Log.type` + `Log.cost` موحّدَين

#### `routes/agent_routes.py`:
- `POST /agent/plan` — Stage 1 الجديد
- `POST /agent/confirm` — Stage 2 الجديد
- `GET  /agent/pending` — فحص التأكيد المنتظر
- `/agent/check` → يُعيد `needs_confirmation` الآن
- حماية مضاعفة: `user["id"] != user_id` في كل file endpoint

#### `services/orchestrator.py`:
- `cost_usd` في done event للـ frontend
- `request_cost` في PipelineCtx
