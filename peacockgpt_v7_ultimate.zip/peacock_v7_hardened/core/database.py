"""
core/database.py — Database Models v7 Ultimate
Added: PendingAction (Human-Control confirmation table)
      SemCache.scope column, Log unified fields
Author: PeacockAI – Mostafa
"""
from sqlalchemy import (
    create_engine, Column, String, Integer, Float, Text,
    Boolean, ForeignKey, Index
)
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from core.config import DATABASE_URL, USE_POSTGRES, log

Base = declarative_base()

# ── Engine ────────────────────────────────────────────────────────
if USE_POSTGRES:
    engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_size=10)
else:
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=True)


@contextmanager
def get_db():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# ════════════════════════════════════════════════════════════════
# MODELS
# ════════════════════════════════════════════════════════════════

class User(Base):
    __tablename__ = "users"
    id            = Column(String(64),  primary_key=True)
    name          = Column(String(100), nullable=False)
    email         = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    plan          = Column(String(20),  default="free")
    tone          = Column(String(20),  default="friendly")
    region        = Column(String(20),  default="global")
    msg_count     = Column(Integer,     default=0)
    img_count     = Column(Integer,     default=0)
    search_count  = Column(Integer,     default=0)
    pdf_count     = Column(Integer,     default=0)
    agent_ops     = Column(Integer,     default=0)
    token_cost    = Column(Float,       default=0.0)
    msg_reset_at  = Column(String(40))
    created_at    = Column(String(40),  nullable=False)
    last_seen     = Column(String(40))
    sub_expires   = Column(String(40))


class Session_(Base):
    __tablename__ = "sessions"
    token      = Column(String(64), primary_key=True)
    user_id    = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(String(40), nullable=False)
    expires_at = Column(String(40), nullable=False)


class Conversation(Base):
    __tablename__ = "conversations"
    id         = Column(String(64), primary_key=True)
    user_id    = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title      = Column(String(200), default="محادثة جديدة")
    model_used = Column(String(50))
    created_at = Column(String(40), nullable=False)
    updated_at = Column(String(40), nullable=False)
    pinned     = Column(Integer,    default=0)
    __table_args__ = (Index("idx_conv_user", "user_id"),)


class Message(Base):
    __tablename__ = "messages"
    id         = Column(String(64), primary_key=True)
    conv_id    = Column(String(64), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role       = Column(String(20), nullable=False)
    content    = Column(Text,       nullable=False)
    model      = Column(String(50))
    tokens     = Column(Integer,    default=0)
    created_at = Column(String(40), nullable=False)
    __table_args__ = (Index("idx_msg_conv", "conv_id"),)


class SemCache(Base):
    __tablename__ = "sem_cache"
    id         = Column(String(32), primary_key=True)
    query_hash = Column(String(32), nullable=False, index=True)
    query_text = Column(String(600))
    response   = Column(Text,       nullable=False)
    embedding  = Column(Text)
    model_used = Column(String(50))
    scope      = Column(String(20), default="chat")   # chat | search
    ttl        = Column(Float,      nullable=False)
    hits       = Column(Integer,    default=1)
    created_at = Column(Float,      nullable=False)


class UserMemory(Base):
    __tablename__ = "user_memory"
    id         = Column(String(100), primary_key=True)
    user_id    = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    scope      = Column(String(20),  nullable=False)
    key        = Column(String(80),  nullable=False)
    value      = Column(String(500), nullable=False)
    confidence = Column(Float,       default=1.0)
    updated_at = Column(String(40),  nullable=False)
    __table_args__ = (Index("idx_mem_user_scope", "user_id", "scope"),)


class CacheEntry(Base):
    __tablename__ = "cache_entries"
    key        = Column(String(64), primary_key=True)
    value      = Column(Text,       nullable=False)
    hits       = Column(Integer,    default=1)
    created_at = Column(Float,      nullable=False)


class Log(Base):
    __tablename__ = "logs"
    id         = Column(Integer,    primary_key=True, autoincrement=True)
    user_id    = Column(String(64), index=True)
    type       = Column(String(40), default="chat")     # unified: chat|agent|security|cost
    action     = Column(String(40))                     # legacy compat
    model      = Column(String(50))
    tokens     = Column(Integer,    default=0)
    cost       = Column(Float,      default=0.0)
    cost_usd   = Column(Float,      default=0.0)        # legacy compat
    latency_ms = Column(Integer,    default=0)
    cache_hit  = Column(Boolean,    default=False)
    success    = Column(Boolean,    default=True)
    error      = Column(Text)
    error_msg  = Column(Text)                           # legacy compat
    ab_variant = Column(String(10))
    created_at = Column(String(40), nullable=False)
    __table_args__ = (Index("idx_log_user", "user_id"),)


class FeatureFlag(Base):
    __tablename__ = "feature_flags"
    name       = Column(String(50), primary_key=True)
    enabled    = Column(Boolean,    nullable=False, default=True)
    updated_at = Column(String(40), nullable=False)


class Version(Base):
    __tablename__ = "versions"
    id          = Column(Integer,    primary_key=True, autoincrement=True)
    version     = Column(String(20), nullable=False)
    description = Column(Text)
    deployed_at = Column(String(40), nullable=False)


class Analytics(Base):
    __tablename__ = "analytics"
    id         = Column(Integer,    primary_key=True, autoincrement=True)
    user_id    = Column(String(64), index=True)
    session_id = Column(String(64))
    event      = Column(String(50), nullable=False)
    meta       = Column(Text)
    created_at = Column(String(40), nullable=False)


class Job(Base):
    __tablename__ = "jobs"
    id         = Column(String(32),  primary_key=True)
    type       = Column(String(50),  nullable=False)
    payload    = Column(Text)
    status     = Column(String(20),  default="pending")
    attempts   = Column(Integer,     default=0)
    result     = Column(Text)
    created_at = Column(String(40),  nullable=False)
    run_at     = Column(String(40))
    done_at    = Column(String(40))


class Onboarding(Base):
    __tablename__ = "onboarding"
    user_id    = Column(String(64), primary_key=True)
    step       = Column(Integer,    default=0)
    completed  = Column(Boolean,    default=False)
    updated_at = Column(String(40), nullable=False)


class Suggestion(Base):
    __tablename__ = "suggestions"
    id         = Column(String(32),  primary_key=True)
    user_id    = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    text       = Column(String(300), nullable=False)
    icon       = Column(String(10),  default="💡")
    score      = Column(Float,       default=1.0)
    used       = Column(Boolean,     default=False)
    created_at = Column(String(40),  nullable=False)


class AgentTask(Base):
    __tablename__ = "agent_tasks"
    id             = Column(String(32),  primary_key=True)
    user_id        = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    goal           = Column(Text,        nullable=False)
    plan           = Column(Text)        # JSON list of steps
    status         = Column(String(20),  default="planning")
    # planning | awaiting_confirm | running | done | failed | cancelled
    steps_done     = Column(Integer,     default=0)
    result         = Column(Text)
    file_ops       = Column(Text)        # JSON list of file operations log
    elapsed_s      = Column(Float,       default=0.0)
    created_at     = Column(String(40),  nullable=False)
    updated_at     = Column(String(40),  nullable=False)
    __table_args__ = (Index("idx_agent_user", "user_id"),)


# ── NEW: PendingAction — Human-Control confirmation table ─────────
class PendingAction(Base):
    """
    Stores agent plans awaiting user confirmation before execution.
    Status: pending | confirmed | rejected | expired
    """
    __tablename__ = "pending_actions"
    id          = Column(String(32),  primary_key=True)
    user_id     = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    task_id     = Column(String(32),  ForeignKey("agent_tasks.id", ondelete="CASCADE"), nullable=False)
    action_type = Column(String(40),  nullable=False)   # create_project | edit_files | delete | bulk_write
    summary     = Column(Text,        nullable=False)   # human-readable summary shown to user
    plan_json   = Column(Text,        nullable=False)   # full plan JSON
    risk_level  = Column(String(10),  default="medium") # low | medium | high
    status      = Column(String(20),  default="pending")
    expires_at  = Column(String(40),  nullable=False)   # auto-expire after 10 min
    created_at  = Column(String(40),  nullable=False)
    decided_at  = Column(String(40))
    __table_args__ = (Index("idx_pending_user", "user_id"),)


class PdfRecord(Base):
    __tablename__ = "pdf_records"
    id          = Column(String(32),  primary_key=True)
    user_id     = Column(String(64),  ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title       = Column(String(200), default="PeacockGPT Export")
    content_len = Column(Integer,     default=0)
    file_path   = Column(String(300))
    created_at  = Column(String(40),  nullable=False)
    __table_args__ = (Index("idx_pdf_user", "user_id"),)


# ── Init ──────────────────────────────────────────────────────────
def init_db():
    Base.metadata.create_all(bind=engine)
    log.info("✅ Database initialized (all tables ready)")
