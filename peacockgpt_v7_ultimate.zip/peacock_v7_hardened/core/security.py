"""
core/security.py — Security v7
JWT tokens, PBKDF2 password hashing, rate limiter, input validation.
Author: PeacockAI – Mostafa
"""
import hashlib, secrets, time, re
import base64, hmac, json as _json
from typing import Optional, Dict, Tuple
from collections import defaultdict
from core.config import SECRET_KEY, RATE_WINDOW, RATE_MAX_CALLS, log

# ══════════════════════════════════════════════════════════════════
# JWT
# ══════════════════════════════════════════════════════════════════

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64d(s: str) -> bytes:
    pad = 4 - len(s) % 4
    return base64.urlsafe_b64decode(s + "=" * (pad % 4))

def create_token(user_id: str, plan: str = "free", expires_h: int = 720) -> str:
    header  = _b64(_json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    payload = _b64(_json.dumps({
        "sub":  user_id,
        "plan": plan,
        "iat":  int(time.time()),
        "exp":  int(time.time()) + expires_h * 3600,
        "jti":  secrets.token_hex(8),
    }).encode())
    sig = _b64(hmac.new(
        SECRET_KEY.encode(), f"{header}.{payload}".encode(), "sha256"
    ).digest())
    return f"{header}.{payload}.{sig}"

def verify_token(token: str) -> Optional[dict]:
    if not token:
        return None
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header, payload, sig = parts
        expected_sig = _b64(hmac.new(
            SECRET_KEY.encode(), f"{header}.{payload}".encode(), "sha256"
        ).digest())
        if not hmac.compare_digest(sig, expected_sig):
            return None
        data = _json.loads(_b64d(payload))
        if data.get("exp", 0) < time.time():
            return None
        return data
    except Exception as e:
        log.debug(f"[Security] Token verify error: {e}")
        return None

# ══════════════════════════════════════════════════════════════════
# PASSWORD HASHING  (PBKDF2-HMAC-SHA256)
# ══════════════════════════════════════════════════════════════════

_PBKDF2_ITERS = 100_000

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h    = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode(), _PBKDF2_ITERS
    ).hex()
    return f"pbkdf2${salt}${h}"

def verify_password(password: str, hashed: str) -> bool:
    try:
        if hashed.startswith("pbkdf2$"):
            _, salt, stored_h = hashed.split("$", 2)
            h = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"), salt.encode(), _PBKDF2_ITERS
            ).hex()
            return hmac.compare_digest(h, stored_h)
        # Legacy SHA-256 + salt
        if ":" in hashed:
            salt, stored_h = hashed.split(":", 1)
            h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
            return hmac.compare_digest(h, stored_h)
        return hmac.compare_digest(
            hashlib.sha256(password.encode()).hexdigest(), hashed
        )
    except Exception:
        return False

# ══════════════════════════════════════════════════════════════════
# RATE LIMITER  (sliding window)
# ══════════════════════════════════════════════════════════════════

_rate_store: Dict[str, list] = defaultdict(list)

def check_rate_limit(identifier: str,
                     max_calls: int = RATE_MAX_CALLS,
                     window_s: int = RATE_WINDOW) -> Tuple[bool, int]:
    now    = time.time()
    window = now - window_s
    _rate_store[identifier] = [t for t in _rate_store[identifier] if t > window]
    remaining = max_calls - len(_rate_store[identifier])
    if remaining <= 0:
        log.warning(f"[Security] Rate limit: {identifier}")
        return False, 0
    _rate_store[identifier].append(now)
    return True, remaining - 1

def cleanup_rate_store():
    now   = time.time()
    stale = [k for k, ts in _rate_store.items()
             if not ts or now - max(ts) > RATE_WINDOW * 2]
    for k in stale:
        del _rate_store[k]

# ══════════════════════════════════════════════════════════════════
# INPUT VALIDATION
# ══════════════════════════════════════════════════════════════════

_EMAIL_RE   = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
_SAFE_RE    = re.compile(r"[<>\"'`]")

def validate_email(email: str) -> bool:
    return bool(email and _EMAIL_RE.match(email.strip()) and len(email) <= 255)

def validate_password(password: str) -> Tuple[bool, str]:
    if not password:
        return False, "كلمة المرور مطلوبة"
    if len(password) < 8:
        return False, "كلمة المرور يجب أن تكون 8 أحرف على الأقل"
    if len(password) > 128:
        return False, "كلمة المرور طويلة جداً"
    return True, ""

def sanitize_string(s: str, max_len: int = 1000) -> str:
    if not s:
        return ""
    return _SAFE_RE.sub("", s)[:max_len].strip()

def validate_message(message: str) -> Tuple[bool, str]:
    if not message or not message.strip():
        return False, "الرسالة فارغة"
    if len(message) > 32_000:
        return False, "الرسالة طويلة جداً (الحد 32,000 حرف)"
    return True, ""

# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def mask_key(key: str) -> str:
    if len(key) < 8:
        return "***"
    return key[:6] + "..." + key[-4:]

def write_security_event_safe(user_id: str, event: str, ip: str = "", detail: str = ""):
    try:
        from repositories.log_repo import write_security_event
        write_security_event(user_id, event, ip, detail)
    except Exception:
        pass
