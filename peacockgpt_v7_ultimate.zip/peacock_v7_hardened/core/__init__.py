# PeacockGPT 5 – core package
