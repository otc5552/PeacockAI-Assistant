"""
repositories/conv_repo.py — Conversations & Messages data layer
repositories/log_repo.py  — Logs & Analytics data layer
Author: PeacockAI – Mostafa
"""
import hashlib, time, json
from datetime import datetime, timedelta
from typing import List, Optional
from core.database import get_db, Conversation, Message, Log, Analytics


# ════════════════════════════════════════════════════════════════
# CONVERSATIONS
# ════════════════════════════════════════════════════════════════

def list_conversations(user_id: str, limit: int = 100) -> List[dict]:
    with get_db() as db:
        rows = db.query(Conversation).filter_by(user_id=user_id)\
                 .order_by(Conversation.pinned.desc(),
                           Conversation.updated_at.desc())\
                 .limit(limit).all()
    return [{"id": r.id, "title": r.title, "model_used": r.model_used,
             "updated_at": r.updated_at, "pinned": bool(r.pinned)} for r in rows]


def create_conversation(user_id: str, title: str = "محادثة جديدة") -> dict:
    cid = hashlib.md5(f"{user_id}{time.time()}".encode()).hexdigest()
    now = datetime.now().isoformat()
    with get_db() as db:
        db.add(Conversation(id=cid, user_id=user_id,
                            title=title[:80],
                            created_at=now, updated_at=now))
    return {"id": cid, "title": title}


def update_conversation(conv_id: str, **kwargs):
    with get_db() as db:
        c = db.query(Conversation).filter_by(id=conv_id).first()
        if not c:
            return False
        if "title"  in kwargs: c.title  = kwargs["title"][:80]
        if "pinned" in kwargs: c.pinned = int(kwargs["pinned"])
        c.updated_at = datetime.now().isoformat()
    return True


def delete_conversation(conv_id: str):
    with get_db() as db:
        c = db.query(Conversation).filter_by(id=conv_id).first()
        if c:
            db.delete(c)   # CASCADE deletes messages


def get_messages(conv_id: str) -> List[dict]:
    with get_db() as db:
        rows = db.query(Message).filter_by(conv_id=conv_id)\
                 .order_by(Message.created_at).all()
    return [{"id": r.id, "role": r.role, "content": r.content,
             "model": r.model, "created_at": r.created_at} for r in rows]


def save_message(conv_id: str, role: str, content: str,
                 model: str = "") -> str:
    mid = hashlib.md5(f"{conv_id}{time.time()}".encode()).hexdigest()
    now = datetime.now().isoformat()
    with get_db() as db:
        db.add(Message(id=mid, conv_id=conv_id, role=role,
                       content=content, model=model, created_at=now))
        c = db.query(Conversation).filter_by(id=conv_id).first()
        if c:
            c.updated_at = now
            c.model_used = model
    return mid


# ════════════════════════════════════════════════════════════════
# LOGS
# ════════════════════════════════════════════════════════════════

def write_log(user_id: str, action: str, model: str = "",
              tokens: int = 0, cost: float = 0.0,
              latency_ms: int = 0, cache_hit: bool = False,
              success: bool = True, error: str = "",
              ab_variant: str = ""):
    try:
        with get_db() as db:
            db.add(Log(
                user_id    = user_id,
                action     = action,
                model      = model,
                tokens     = tokens,
                cost_usd   = cost,
                latency_ms = latency_ms,
                cache_hit  = cache_hit,
                success    = success,
                error_msg  = error[:300] if error else None,
                ab_variant = ab_variant,
                created_at = datetime.now().isoformat(),
            ))
    except Exception:
        pass   # Never crash on log failure


def get_recent_logs(user_id: str, limit: int = 20) -> List[dict]:
    with get_db() as db:
        rows = db.query(Log).filter_by(user_id=user_id)\
                 .order_by(Log.created_at.desc()).limit(limit).all()
    return [{"action": r.action, "model": r.model,
             "latency_ms": r.latency_ms, "cache_hit": r.cache_hit,
             "success": r.success, "cost_usd": r.cost_usd,
             "created_at": r.created_at} for r in rows]


# ── Analytics ─────────────────────────────────────────────────────
def write_event(user_id: str, event: str,
                session_id: str = "", meta: dict = None):
    try:
        with get_db() as db:
            db.add(Analytics(
                user_id    = user_id,
                session_id = session_id,
                event      = event,
                meta       = json.dumps(meta or {}),
                created_at = datetime.now().isoformat(),
            ))
    except Exception:
        pass


def get_analytics_summary(hours: int = 24) -> dict:
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()
    with get_db() as db:
        events: dict = {}
        for a in db.query(Analytics)\
                   .filter(Analytics.created_at >= cutoff).all():
            events[a.event] = events.get(a.event, 0) + 1
        dau = db.query(Analytics.user_id)\
                .filter(Analytics.created_at >= cutoff)\
                .distinct().count()
        cost_rows = db.query(Log.cost_usd)\
                      .filter(Log.created_at >= cutoff).all()
        errors    = db.query(Log)\
                      .filter(Log.created_at >= cutoff,
                              Log.success == False).count()
        cache_hits = db.query(Log)\
                       .filter(Log.created_at >= cutoff,
                               Log.cache_hit == True).count()
        total_reqs = db.query(Log)\
                       .filter(Log.created_at >= cutoff).count()
    total_cost = sum(r[0] or 0 for r in cost_rows)
    cache_rate  = round(cache_hits / max(total_reqs, 1) * 100, 1)
    return {
        "hours":       hours,
        "dau":         dau,
        "events":      events,
        "errors":      errors,
        "cost_usd":    round(total_cost, 4),
        "cache_rate":  f"{cache_rate}%",
        "total_reqs":  total_reqs,
    }
