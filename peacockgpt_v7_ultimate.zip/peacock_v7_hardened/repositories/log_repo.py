"""
repositories/log_repo.py — Audit & Request Logging v7
Logs: every request, error, cost, agent operation, file operation.
Author: PeacockAI – Mostafa
"""
import json, secrets
from datetime import datetime
from typing import Optional
from core.config import log
from core.database import get_db, Log, Analytics


def write_log(
    user_id:    str,
    log_type:   str,
    model:      str,
    tokens:     int,
    cost:       float,
    latency_ms: int,
    cache_hit:  bool,
    success:    bool,
    error:      str = "",
):
    """Write a request log entry. Silently ignores DB failures."""
    try:
        with get_db() as db:
            db.add(Log(
                id          = secrets.token_hex(10),
                user_id     = user_id or "guest",
                type        = log_type,
                model       = model,
                tokens      = tokens,
                cost        = round(cost, 6),
                latency_ms  = latency_ms,
                cache_hit   = cache_hit,
                success     = success,
                error       = error[:500] if error else "",
                created_at  = datetime.now().isoformat(),
            ))
    except Exception as e:
        log.warning(f"[LogRepo] write_log failed: {e}")


def write_event(user_id: str, event: str, meta: dict = None):
    """Write an analytics event. Fire-and-forget."""
    try:
        with get_db() as db:
            db.add(Analytics(
                user_id    = user_id or "guest",
                session_id = "",
                event      = event,
                meta       = json.dumps(meta or {}),
                created_at = datetime.now().isoformat(),
            ))
    except Exception as e:
        log.warning(f"[LogRepo] write_event failed: {e}")


def write_agent_audit(
    task_id:  str,
    user_id:  str,
    op:       str,
    filename: str = "",
    status:   str = "ok",
    detail:   str = "",
):
    """
    Write an agent file operation audit entry.
    Stored in Analytics table with event='agent_audit'.
    """
    write_event(user_id, "agent_audit", {
        "task_id":  task_id,
        "op":       op,
        "filename": filename,
        "status":   status,
        "detail":   detail[:200],
    })


def write_security_event(
    user_id:    str,
    event_type: str,
    ip:         str = "",
    detail:     str = "",
):
    """Log security events: failed auth, rate limit hit, sandbox escape attempt."""
    log.warning(
        f"[SECURITY_AUDIT] event={event_type} user={user_id} "
        f"ip={ip} detail={detail[:200]}"
    )
    write_event(user_id, f"security_{event_type}", {
        "ip":     ip,
        "detail": detail[:200],
    })


def get_user_cost_summary(user_id: str) -> dict:
    """Get cost and token summary for a user."""
    try:
        from core.database import Log as LogModel
        with get_db() as db:
            rows = db.query(LogModel).filter_by(user_id=user_id).all()
        if not rows:
            return {"total_cost": 0.0, "total_tokens": 0, "total_requests": 0}
        return {
            "total_cost":     round(sum(r.cost or 0 for r in rows), 5),
            "total_tokens":   sum(r.tokens or 0 for r in rows),
            "total_requests": len(rows),
            "cache_hits":     sum(1 for r in rows if r.cache_hit),
            "errors":         sum(1 for r in rows if not r.success),
        }
    except Exception as e:
        log.warning(f"[LogRepo] get_user_cost_summary error: {e}")
        return {"total_cost": 0.0, "total_tokens": 0, "total_requests": 0}
