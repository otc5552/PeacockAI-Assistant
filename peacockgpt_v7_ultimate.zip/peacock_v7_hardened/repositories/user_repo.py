"""
repositories/user_repo.py — User data access layer
Author: PeacockAI – Mostafa
"""
from datetime import datetime, timedelta
from typing import Optional
from core.database import get_db, User, Session_
from core.config import PLANS, PRICING


def get_by_id(user_id: str) -> Optional[User]:
    with get_db() as db:
        return db.query(User).filter_by(id=user_id).first()


def get_by_email(email: str) -> Optional[User]:
    with get_db() as db:
        return db.query(User).filter_by(email=email.lower().strip()).first()


def create(uid: str, name: str, email: str, pw_hash: str,
           region: str = "global") -> User:
    now = datetime.now().isoformat()
    with get_db() as db:
        u = User(id=uid, name=name.strip(), email=email.lower().strip(),
                 password_hash=pw_hash, plan="free", tone="friendly",
                 region=region, created_at=now, msg_reset_at=now)
        db.add(u)
    return u


def update_last_seen(user_id: str):
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.last_seen = datetime.now().isoformat()


def update_tone(user_id: str, tone: str):
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.tone = tone


def update_plan(user_id: str, plan: str, months: int = 1):
    expires = (datetime.now() + timedelta(days=30 * months)).isoformat()
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.plan        = plan
            u.sub_expires = expires
    return expires


def check_sub_expiry(user_id: str):
    """Downgrade to free if subscription expired."""
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u and u.sub_expires:
            if datetime.now() > datetime.fromisoformat(u.sub_expires):
                u.plan = "free"


def get_stats(user_id: str) -> dict:
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if not u:
            return {}
        plan  = u.plan or "free"
        lims  = PLANS.get(plan, PLANS["free"])
        now   = datetime.now()
        reset_at = u.msg_reset_at
        next_reset = None
        if reset_at:
            next_reset = (datetime.fromisoformat(reset_at) +
                          timedelta(hours=lims["reset_h"])).isoformat()
        return {
            "msg_count":     u.msg_count,
            "img_count":     u.img_count,
            "search_count":  u.search_count,
            "token_cost_usd":round(u.token_cost or 0, 5),
            "plan":          plan,
            "limits":        lims,
            "pricing":       PRICING.get(plan, {}),
            "sub_expires":   u.sub_expires,
            "next_reset":    next_reset,
        }


def increment_usage(user_id: str, action: str) -> tuple[bool, str]:
    """Enforce limits + auto-reset. Returns (allowed, reason)."""
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if not u:
            return True, ""

        # Subscription expiry check
        if u.sub_expires and datetime.now() > datetime.fromisoformat(u.sub_expires):
            u.plan = "free"

        plan  = u.plan or "free"
        lims  = PLANS.get(plan, PLANS["free"])
        now   = datetime.now()

        # Auto-reset counters
        if u.msg_reset_at:
            reset_dt = datetime.fromisoformat(u.msg_reset_at)
            if now - reset_dt > timedelta(hours=lims["reset_h"]):
                u.msg_count    = 0
                u.img_count    = 0
                u.search_count = 0
                u.msg_reset_at = now.isoformat()

        def _upgrade_hint():
            from core.config import PRICING
            return (f"وصلت للحد اليومي. "
                    f"ترقية لـ Plus: {PRICING['plus']['egp']} جنيه / ${PRICING['plus']['usd']}")

        if action == "msg":
            if u.msg_count >= lims["msg"]:
                return False, _upgrade_hint()
            u.msg_count += 1
            u.last_seen  = now.isoformat()
        elif action == "img":
            if u.img_count >= lims["img"]:
                return False, f"وصلت لحد {lims['img']} صورة يومياً."
            u.img_count += 1
        elif action == "search":
            if u.search_count >= lims["search"]:
                return False, "وصلت لحد البحث اليومي."
            u.search_count += 1

        return True, ""


def add_token_cost(user_id: str, cost: float):
    if user_id == "guest" or cost <= 0:
        return
    with get_db() as db:
        u = db.query(User).filter_by(id=user_id).first()
        if u:
            u.token_cost = (u.token_cost or 0) + cost
