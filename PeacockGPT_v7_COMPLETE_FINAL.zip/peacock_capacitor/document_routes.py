"""
routes/document_routes.py — Documents, Workflows, Build Agent v7
Author: PeacockAI – Mostafa
"""
import json
from fastapi import APIRouter, HTTPException, Header, Request
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel, validator
from typing import Optional, List, Dict, Any

from core.config import FLAGS, log
from core.security import verify_token, check_rate_limit
from core.database import get_db, User

router = APIRouter(tags=["documents"])


# ── Auth helper ───────────────────────────────────────────────────
def _auth(x_token: Optional[str]) -> dict:
    if not x_token:
        raise HTTPException(401, "سجل دخولك أولاً")
    payload = verify_token(x_token)
    if not payload:
        raise HTTPException(401, "Token غير صالح")
    try:
        with get_db() as db:
            u = db.query(User).filter_by(id=payload["sub"]).first()
            if u:
                return {"id": u.id, "plan": u.plan or "free", "name": u.name}
    except Exception:
        pass
    raise HTTPException(401, "مستخدم غير موجود")

def _require_pro(x_token: Optional[str]) -> dict:
    user = _auth(x_token)
    if user["plan"] != "pro":
        raise HTTPException(403, "🔒 هذه الميزة للـ Pro فقط")
    return user


# ══════════════════════════════════════════════════════════════════
# DOCUMENT GENERATION ROUTES
# ══════════════════════════════════════════════════════════════════

class DocxRequest(BaseModel):
    content: str
    title:   str = "PeacockGPT Document"

    @validator("content")
    def not_empty(cls, v):
        if not v.strip(): raise ValueError("المحتوى مطلوب")
        return v

class PptxRequest(BaseModel):
    content: str
    title:   str = "PeacockGPT Presentation"

class SlidesRequest(BaseModel):
    slides: List[Dict]
    title:  str = "PeacockGPT Presentation"


@router.post("/documents/docx")
async def create_docx(req: DocxRequest, x_token: Optional[str] = Header(None)):
    """Generate a Word .docx file from content."""
    user = _auth(x_token)
    try:
        from services.document_service import content_to_docx
        docx_bytes = content_to_docx(req.content, req.title)
        safe_title = req.title[:30].replace(" ", "_")
        return Response(
            content=docx_bytes,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{safe_title}.docx"'}
        )
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        log.error(f"[DocRoute] DOCX error: {e}")
        raise HTTPException(500, f"خطأ في إنشاء DOCX: {e}")


@router.post("/documents/pptx")
async def create_pptx(req: PptxRequest, x_token: Optional[str] = Header(None)):
    """Generate a PowerPoint .pptx from content."""
    user = _auth(x_token)
    try:
        from services.document_service import content_to_pptx
        pptx_bytes = content_to_pptx(req.content, req.title)
        safe_title = req.title[:30].replace(" ", "_")
        return Response(
            content=pptx_bytes,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition": f'attachment; filename="{safe_title}.pptx"'}
        )
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        log.error(f"[DocRoute] PPTX error: {e}")
        raise HTTPException(500, f"خطأ في إنشاء PPTX: {e}")


@router.post("/documents/pptx/slides")
async def create_pptx_from_slides(req: SlidesRequest, x_token: Optional[str] = Header(None)):
    """Generate PPTX from structured slides data."""
    user = _auth(x_token)
    try:
        from services.document_service import generate_pptx
        pptx_bytes = generate_pptx(req.slides, req.title)
        safe_title = req.title[:30].replace(" ", "_")
        return Response(
            content=pptx_bytes,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition": f'attachment; filename="{safe_title}.pptx"'}
        )
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/documents/download/{doc_id}")
def download_document(doc_id: str, x_token: Optional[str] = Header(None)):
    """Download a generated document by ID."""
    user = _auth(x_token)
    from services.workflow_service import get_output_file
    entry = get_output_file(doc_id, user["id"])
    if not entry:
        raise HTTPException(404, "الملف غير موجود أو انتهت صلاحيته")

    ext        = entry["ext"]
    media_types = {
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "pdf":  "application/pdf",
        "zip":  "application/zip",
    }
    media_type = media_types.get(ext, "application/octet-stream")
    return Response(
        content=entry["data"],
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="peacock_{doc_id[:8]}.{ext}"'}
    )


# ══════════════════════════════════════════════════════════════════
# WORKFLOW ROUTES
# ══════════════════════════════════════════════════════════════════

class WorkflowRunRequest(BaseModel):
    workflow:   Dict
    input_data: Dict = {}

class WorkflowTemplateRunRequest(BaseModel):
    template_id: str
    input_data:  Dict = {}


@router.get("/workflows/templates")
def get_workflow_templates(x_token: Optional[str] = Header(None)):
    """Get available workflow templates."""
    _auth(x_token)
    from services.workflow_service import DEFAULT_TEMPLATES
    return {"templates": DEFAULT_TEMPLATES}


@router.post("/workflows/run")
async def run_workflow(
    req:          WorkflowRunRequest,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """Execute a custom workflow."""
    user = _auth(x_token)
    try:
        from services.workflow_service import execute_workflow
        result = await execute_workflow(
            workflow   = req.workflow,
            user_id    = user["id"],
            input_data = req.input_data,
            groq_key   = x_groq_key   or "",
            gemini_key = x_gemini_key or "",
        )
        return result
    except Exception as e:
        log.error(f"[WorkflowRoute] Error: {e}")
        raise HTTPException(500, str(e))


@router.post("/workflows/template/{template_id}")
async def run_template(
    template_id:  str,
    req:          WorkflowTemplateRunRequest,
    x_token:      Optional[str] = Header(None),
    x_groq_key:   Optional[str] = Header(None),
    x_gemini_key: Optional[str] = Header(None),
):
    """Run a built-in workflow template."""
    user = _auth(x_token)
    from services.workflow_service import DEFAULT_TEMPLATES, execute_workflow
    tmpl = next((t for t in DEFAULT_TEMPLATES if t["id"] == template_id), None)
    if not tmpl:
        raise HTTPException(404, f"Template '{template_id}' غير موجود")
    try:
        result = await execute_workflow(
            workflow   = tmpl,
            user_id    = user["id"],
            input_data = {**req.input_data, "user_id": user["id"]},
            groq_key   = x_groq_key   or "",
            gemini_key = x_gemini_key or "",
        )
        return result
    except Exception as e:
        raise HTTPException(500, str(e))


# ══════════════════════════════════════════════════════════════════
# REMOTE BUILD AGENT ROUTES  (Pro only)
# ══════════════════════════════════════════════════════════════════

class BuildRequest(BaseModel):
    app_name:     str
    package_name: str = "com.example.myapp"
    api_url:      str = "http://YOUR_SERVER:8000"
    version:      str = "1.0"
    description:  str = ""
    html_content: str = ""

    @validator("app_name")
    def name_valid(cls, v):
        v = v.strip()
        if not v: raise ValueError("اسم التطبيق مطلوب")
        if len(v) > 50: raise ValueError("الاسم طويل جداً")
        return v

    @validator("package_name")
    def pkg_valid(cls, v):
        import re
        if not re.match(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,4}$', v):
            raise ValueError("Package name غير صالح. مثال: com.mycompany.myapp")
        return v


@router.post("/build/create")
async def create_build(
    req:     BuildRequest,
    request: Request,
    x_token: Optional[str] = Header(None),
):
    """Create a new Android build job. Pro only."""
    user = _require_pro(x_token)

    # Rate limit: 5 builds per day per user
    allowed, _ = check_rate_limit(f"build:{user['id']}", max_calls=5, window_s=86400)
    if not allowed:
        raise HTTPException(429, "تجاوزت حد 5 builds يومياً للـ Pro")

    from services.remote_build_service import create_build_job
    spec   = req.dict()
    job_id = create_build_job(user["id"], spec, "android_apk")
    return {"job_id": job_id, "status": "pending",
            "message": "تم إنشاء مهمة البناء. ابدأ التنفيذ عبر /build/run/{job_id}"}


@router.post("/build/run/{job_id}")
async def run_build(
    job_id:  str,
    x_token: Optional[str] = Header(None),
):
    """Execute a build job (streaming SSE)."""
    user = _require_pro(x_token)
    from services.remote_build_service import run_build_job, get_build_job

    job = get_build_job(job_id, user["id"])
    if not job:
        raise HTTPException(404, "Job غير موجود")
    if job["status"] == "running":
        raise HTTPException(409, "Job يعمل بالفعل")

    return StreamingResponse(
        run_build_job(job_id, user["id"]),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/build/status/{job_id}")
def build_status(job_id: str, x_token: Optional[str] = Header(None)):
    """Get build job status."""
    user = _auth(x_token)
    from services.remote_build_service import get_build_job
    job = get_build_job(job_id, user["id"])
    if not job:
        raise HTTPException(404, "Job غير موجود")
    return {
        "id":          job["id"],
        "status":      job["status"],
        "progress":    job["progress"],
        "result_url":  job.get("result_url"),
        "error":       job.get("error"),
        "log":         job["log"][-10:],  # last 10 log lines
        "created_at":  job["created_at"],
    }


@router.get("/build/list")
def list_builds(x_token: Optional[str] = Header(None)):
    """List all build jobs for current user."""
    user = _auth(x_token)
    from services.remote_build_service import list_build_jobs
    jobs = list_build_jobs(user["id"])
    return {"jobs": [
        {"id": j["id"], "status": j["status"], "progress": j["progress"],
         "result_url": j.get("result_url"), "created_at": j["created_at"]}
        for j in jobs
    ]}
