"""
services/remote_build_service.py — Remote Build Agent v7
Manages build jobs sent to a Worker server (VPS/PC with Android SDK).
Mobile → Backend → Worker → APK → Download
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time
from datetime import datetime, timedelta
from typing import Dict, Optional, AsyncGenerator
from core.config import log, FLAGS
from core.database import get_db

# ══════════════════════════════════════════════════════════════════
# BUILD JOB STATUS
# ══════════════════════════════════════════════════════════════════
class BuildStatus:
    PENDING   = "pending"
    RUNNING   = "running"
    DONE      = "done"
    FAILED    = "failed"
    CANCELLED = "cancelled"


# ══════════════════════════════════════════════════════════════════
# IN-MEMORY JOB STORE  (use Redis in production)
# ══════════════════════════════════════════════════════════════════
_build_jobs: Dict[str, Dict] = {}


def create_build_job(user_id: str, spec: Dict, job_type: str = "android_apk") -> str:
    """Create a new build job. Returns job_id."""
    job_id = secrets.token_hex(14)
    now    = datetime.now().isoformat()
    _build_jobs[job_id] = {
        "id":         job_id,
        "user_id":    user_id,
        "type":       job_type,      # android_apk | zip_project
        "spec":       spec,          # project specification
        "status":     BuildStatus.PENDING,
        "progress":   0,
        "log":        [],
        "result_url": None,
        "error":      None,
        "created_at": now,
        "updated_at": now,
        "expires_at": (datetime.now() + timedelta(hours=24)).isoformat(),
    }
    log.info(f"[BuildAgent] Job created: {job_id} type={job_type} user={user_id[:12]}")
    return job_id


def get_build_job(job_id: str, user_id: str) -> Optional[Dict]:
    """Get job status. Validates ownership."""
    job = _build_jobs.get(job_id)
    if not job:
        return None
    if job["user_id"] != user_id:
        return None
    return job


def list_build_jobs(user_id: str) -> list:
    """List all build jobs for a user."""
    return [j for j in _build_jobs.values() if j["user_id"] == user_id]


# ══════════════════════════════════════════════════════════════════
# LOCAL BUILDER (runs on the same server — no external worker needed)
# Executes inside a restricted sandbox using only Python
# ══════════════════════════════════════════════════════════════════

async def run_build_job(job_id: str, user_id: str) -> AsyncGenerator[str, None]:
    """
    Execute a build job locally (Python-only, no shell execution).
    Generates the project files and returns a downloadable ZIP.
    Yields SSE-formatted progress updates.
    """
    job = _build_jobs.get(job_id)
    if not job or job["user_id"] != user_id:
        yield _sse({"type": "error", "content": "Job غير موجود"})
        return

    job["status"]   = BuildStatus.RUNNING
    job["updated_at"] = datetime.now().isoformat()

    def log_step(msg: str, progress: int = None):
        job["log"].append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
        if progress is not None:
            job["progress"] = progress
        job["updated_at"] = datetime.now().isoformat()

    try:
        spec     = job["spec"]
        app_name = spec.get("app_name", "MyApp")
        pkg_name = spec.get("package_name", "com.example.myapp")
        api_url  = spec.get("api_url", "http://YOUR_SERVER:8000")

        yield _sse({"type": "build_start", "job_id": job_id,
                    "message": f"🔨 بدء بناء مشروع: {app_name}"})
        log_step("بدء البناء...", 5)

        # ── Step 1: Generate Android project files ────────────────
        yield _sse({"type": "build_step", "step": "generate",
                    "message": "📁 إنشاء ملفات المشروع..."})
        log_step("إنشاء ملفات Android...", 20)
        await asyncio.sleep(0.5)

        zip_bytes = await _generate_android_project(spec)
        log_step("ملفات المشروع جاهزة", 60)

        yield _sse({"type": "build_step", "step": "package",
                    "message": "📦 تجهيز الحزمة..."})
        await asyncio.sleep(0.3)
        log_step("تجهيز ZIP...", 80)

        # ── Step 2: Save output ───────────────────────────────────
        from services.workflow_service import _save_output_file, get_output_file
        doc_id = secrets.token_hex(12)
        _save_output_file(user_id, doc_id, zip_bytes, "zip")

        job["status"]     = BuildStatus.DONE
        job["progress"]   = 100
        job["result_url"] = f"/documents/download/{doc_id}"
        job["result_doc_id"] = doc_id
        log_step("اكتمل البناء ✅", 100)

        yield _sse({
            "type":        "build_done",
            "job_id":      job_id,
            "download_url": job["result_url"],
            "message": (
                f"✅ تم بناء مشروع **{app_name}** بنجاح!\n"
                f"📦 افتحه في Android Studio لبناء APK نهائي.\n"
                f"📥 تحميل: {job['result_url']}"
            ),
        })

    except Exception as e:
        job["status"] = BuildStatus.FAILED
        job["error"]  = str(e)
        log_step(f"❌ فشل البناء: {e}")
        log.error(f"[BuildAgent] Job {job_id} failed: {e}")
        yield _sse({"type": "build_error", "error": str(e),
                    "message": f"❌ فشل البناء: {e}"})


async def _generate_android_project(spec: Dict) -> bytes:
    """
    Generate a complete Android Studio project as ZIP bytes.
    Pure Python — no shell commands.
    """
    import io, zipfile

    app_name  = spec.get("app_name", "MyApp")
    pkg_name  = spec.get("package_name", "com.example.myapp").replace("-", ".")
    api_url   = spec.get("api_url", "http://YOUR_SERVER:8000")
    version   = spec.get("version", "1.0")
    desc      = spec.get("description", "")
    html_content = spec.get("html_content", "")  # custom UI if provided

    pkg_path  = pkg_name.replace(".", "/")
    buf       = io.BytesIO()

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:

        # ── settings.gradle ──────────────────────────────────────
        zf.writestr("settings.gradle",
            f'rootProject.name = "{app_name}"\ninclude ":app"\n')

        # ── build.gradle (project) ────────────────────────────────
        zf.writestr("build.gradle",
            'plugins { id "com.android.application" version "8.2.1" apply false }\n')

        # ── gradle.properties ────────────────────────────────────
        zf.writestr("gradle.properties",
            "org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\n"
            "android.enableJetifier=true\n")

        # ── local.properties ─────────────────────────────────────
        zf.writestr("local.properties",
            "## Set your Android SDK path:\n"
            "## Windows: sdk.dir=C\\:\\\\Users\\\\YourName\\\\AppData\\\\Local\\\\Android\\\\Sdk\n"
            "## Mac:     sdk.dir=/Users/YourName/Library/Android/sdk\n"
            "sdk.dir=C\\:\\\\Users\\\\YourName\\\\AppData\\\\Local\\\\Android\\\\Sdk\n")

        # ── gradle wrapper ────────────────────────────────────────
        zf.writestr("gradle/wrapper/gradle-wrapper.properties",
            "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip\n"
            "distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\n")

        # ── app/build.gradle ──────────────────────────────────────
        zf.writestr("app/build.gradle", f"""
plugins {{ id 'com.android.application' }}
android {{
    namespace '{pkg_name}'
    compileSdk 34
    defaultConfig {{
        applicationId "{pkg_name}"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "{version}"
    }}
    buildTypes {{
        release {{ minifyEnabled false }}
        debug   {{ debuggable true }}
    }}
    compileOptions {{
        sourceCompatibility JavaVersion.VERSION_11
        targetCompatibility JavaVersion.VERSION_11
    }}
}}
dependencies {{
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.webkit:webkit:1.8.0'
    implementation 'com.google.android.material:material:1.11.0'
}}
""")

        # ── AndroidManifest.xml ───────────────────────────────────
        zf.writestr(f"app/src/main/AndroidManifest.xml", f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="{app_name}"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="true"
        android:theme="@style/AppTheme">
        <activity android:name=".MainActivity" android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|keyboardHidden|screenSize|uiMode"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
""")

        # ── MainActivity.java ─────────────────────────────────────
        zf.writestr(f"app/src/main/java/{pkg_path}/MainActivity.java", f"""
package {pkg_name};

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.FrameLayout;

public class MainActivity extends Activity {{
    private static final String API_BASE = "{api_url}";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {{
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.parseColor("#08080F"));
        getWindow().setNavigationBarColor(Color.parseColor("#08080F"));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#08080F"));
        setContentView(root);

        WebView wv = new WebView(this);
        root.addView(wv, new FrameLayout.LayoutParams(-1, -1));

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        wv.setWebViewClient(new WebViewClient() {{
            @Override
            public void onPageFinished(WebView v, String u) {{
                v.evaluateJavascript("window.PEACOCK_API_BASE='" + API_BASE + "';", null);
            }}
        }});

        wv.loadUrl("file:///android_asset/public/index.html");
    }}
}}
""")

        # ── strings.xml ───────────────────────────────────────────
        zf.writestr("app/src/main/res/values/strings.xml",
            f'<?xml version="1.0" encoding="utf-8"?><resources>'
            f'<string name="app_name">{app_name}</string></resources>\n')

        # ── styles.xml ────────────────────────────────────────────
        zf.writestr("app/src/main/res/values/styles.xml", """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowBackground">#08080F</item>
        <item name="android:statusBarColor">#08080F</item>
        <item name="android:navigationBarColor">#08080F</item>
    </style>
</resources>
""")

        # ── Web assets ────────────────────────────────────────────
        index_html = html_content if html_content else _default_html(app_name, api_url, desc)
        zf.writestr("app/src/main/assets/public/index.html", index_html)

        # ── README ────────────────────────────────────────────────
        zf.writestr("README.md", f"""# {app_name} — Android Project
Generated by PeacockGPT Build Agent

## Build Steps
1. Open Android Studio
2. File → Open → this folder
3. Edit `local.properties` with your SDK path
4. Build → Build APK(s)

## API URL
Currently set to: {api_url}
Change in MainActivity.java line: `private static final String API_BASE = ...`

## Package: {pkg_name}
## Version: {version}
""")

    return buf.getvalue()


def _default_html(app_name: str, api_url: str, desc: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>{app_name}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#08080f;color:#e2e2f0;font-family:'Cairo',system-ui,sans-serif;
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      min-height:100vh;padding:20px;text-align:center}}
.logo{{font-size:64px;margin-bottom:20px}}
h1{{font-size:28px;font-weight:900;color:#7060ff;margin-bottom:12px}}
p{{font-size:15px;color:#8888b0;max-width:300px;line-height:1.7}}
.badge{{margin-top:30px;padding:8px 20px;background:rgba(112,96,255,.15);
         border:1px solid rgba(112,96,255,.3);border-radius:20px;
         font-size:12px;color:#9b8fff}}
</style>
</head>
<body>
<div class="logo">🦚</div>
<h1>{app_name}</h1>
<p>{desc or 'تطبيق ذكاء اصطناعي من PeacockAI'}</p>
<div class="badge">Powered by PeacockGPT v7</div>
<script>window.PEACOCK_API_BASE = '{api_url}';</script>
</body>
</html>"""


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
