"""
services/workflow_service.py — Workflow & Integration Engine v7
Allows users to create n8n-style workflows: Trigger → Actions → Result
Supports HTTP connectors, document generation, webhooks.
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time
from datetime import datetime
from typing import List, Dict, Optional, Any
from core.config import log
from core.database import get_db
import httpx

# ══════════════════════════════════════════════════════════════════
# WORKFLOW DATA MODELS  (stored as JSON in DB)
# ══════════════════════════════════════════════════════════════════

SUPPORTED_TRIGGERS = {
    "manual":    "تشغيل يدوي",
    "schedule":  "جدولة زمنية",
    "message":   "عند إرسال رسالة",
}

SUPPORTED_ACTIONS = {
    "ai_generate":    "توليد نص بالذكاء الاصطناعي",
    "generate_pdf":   "إنشاء PDF",
    "generate_docx":  "إنشاء Word",
    "generate_pptx":  "إنشاء PowerPoint",
    "http_request":   "طلب HTTP API",
    "send_webhook":   "إرسال Webhook",
    "save_to_memory": "حفظ في الذاكرة",
    "ai_summarize":   "تلخيص النص",
}

# ══════════════════════════════════════════════════════════════════
# WORKFLOW EXECUTOR
# ══════════════════════════════════════════════════════════════════

async def execute_workflow(
    workflow:    Dict,
    user_id:     str,
    input_data:  Dict,
    groq_key:    str = "",
    gemini_key:  str = "",
) -> Dict:
    """
    Execute a workflow step by step.
    Returns {success, outputs, errors, elapsed_s}
    """
    t0      = time.time()
    outputs = {}
    errors  = []
    context = {**input_data}  # carries data between steps

    steps = workflow.get("steps", [])
    log.info(f"[Workflow] Starting '{workflow.get('name')}' for user {user_id[:12]}")

    for step in steps:
        step_id   = step.get("id", secrets.token_hex(4))
        step_type = step.get("type", "")
        step_cfg  = step.get("config", {})

        log.info(f"[Workflow] Step {step_id}: {step_type}")

        try:
            result = await _execute_step(
                step_type, step_cfg, context,
                user_id, groq_key, gemini_key
            )
            outputs[step_id] = result
            # Merge result into context for next steps
            if isinstance(result, dict):
                context.update(result)
            elif isinstance(result, str):
                context["last_output"] = result

        except Exception as e:
            error_msg = f"خطأ في الخطوة {step_id} ({step_type}): {e}"
            errors.append(error_msg)
            log.warning(f"[Workflow] {error_msg}")
            if step.get("stop_on_error", False):
                break

    elapsed = round(time.time() - t0, 2)
    success = len(errors) == 0

    log.info(f"[Workflow] Done '{workflow.get('name')}' "
             f"success={success} elapsed={elapsed}s errors={len(errors)}")

    return {
        "success":   success,
        "outputs":   outputs,
        "errors":    errors,
        "elapsed_s": elapsed,
        "context":   context,
    }


async def _execute_step(
    step_type: str, cfg: Dict, context: Dict,
    user_id: str, groq_key: str, gemini_key: str
) -> Any:
    """Execute a single workflow step. Returns result."""

    # ── Resolve template variables in config ────────────────────
    # e.g. config: {"prompt": "{{last_output}}"} → replaces with context value
    resolved_cfg = _resolve_templates(cfg, context)

    # ── AI Generate ─────────────────────────────────────────────
    if step_type == "ai_generate":
        from services.llm import generate
        prompt = resolved_cfg.get("prompt", context.get("message", ""))
        model  = resolved_cfg.get("model", "auto")
        system = resolved_cfg.get("system", "أنت مساعد ذكي من PeacockAI.")
        result = await generate(prompt, groq_key, gemini_key, model, system, max_tokens=2000)
        return {"text": result, "last_output": result}

    # ── AI Summarize ─────────────────────────────────────────────
    elif step_type == "ai_summarize":
        from services.llm import generate
        text   = resolved_cfg.get("text", context.get("last_output", ""))
        prompt = f"لخّص النص التالي بشكل مختصر:\n\n{text[:3000]}"
        result = await generate(prompt, groq_key, gemini_key, "peacockgpt-5-fast",
                                max_tokens=500)
        return {"summary": result, "last_output": result}

    # ── Generate PDF ─────────────────────────────────────────────
    elif step_type == "generate_pdf":
        from services.pdf_service import generate_pdf
        content = resolved_cfg.get("content", context.get("last_output", ""))
        title   = resolved_cfg.get("title", "PeacockGPT Document")
        pdf_bytes, record_id = generate_pdf(
            content=content, user_id=user_id,
            user_plan="pro", title=title, save=True
        )
        return {
            "file_type": "pdf",
            "record_id": record_id,
            "size_bytes": len(pdf_bytes),
            "download_url": f"/pdf/download/{record_id}",
        }

    # ── Generate DOCX ────────────────────────────────────────────
    elif step_type == "generate_docx":
        from services.document_service import content_to_docx
        content = resolved_cfg.get("content", context.get("last_output", ""))
        title   = resolved_cfg.get("title", "PeacockGPT Document")
        docx_bytes = content_to_docx(content, title)
        doc_id  = secrets.token_hex(12)
        _save_output_file(user_id, doc_id, docx_bytes, "docx")
        return {
            "file_type": "docx",
            "doc_id": doc_id,
            "size_bytes": len(docx_bytes),
            "download_url": f"/documents/download/{doc_id}",
        }

    # ── Generate PPTX ────────────────────────────────────────────
    elif step_type == "generate_pptx":
        from services.document_service import content_to_pptx
        content = resolved_cfg.get("content", context.get("last_output", ""))
        title   = resolved_cfg.get("title", "PeacockGPT Presentation")
        pptx_bytes = content_to_pptx(content, title)
        doc_id  = secrets.token_hex(12)
        _save_output_file(user_id, doc_id, pptx_bytes, "pptx")
        return {
            "file_type": "pptx",
            "doc_id": doc_id,
            "size_bytes": len(pptx_bytes),
            "download_url": f"/documents/download/{doc_id}",
        }

    # ── HTTP Request ─────────────────────────────────────────────
    elif step_type == "http_request":
        url     = resolved_cfg.get("url", "")
        method  = resolved_cfg.get("method", "GET").upper()
        headers = resolved_cfg.get("headers", {})
        body    = resolved_cfg.get("body")

        if not url or not url.startswith("http"):
            raise ValueError("URL غير صالح")

        # Block internal IPs (SSRF protection)
        _check_url_safety(url)

        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.request(method, url, headers=headers, json=body)
        try:
            resp_data = r.json()
        except Exception:
            resp_data = r.text[:2000]
        return {"status_code": r.status_code, "response": resp_data,
                "last_output": str(resp_data)[:500]}

    # ── Send Webhook ─────────────────────────────────────────────
    elif step_type == "send_webhook":
        url     = resolved_cfg.get("url", "")
        payload = resolved_cfg.get("payload", context)
        _check_url_safety(url)
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(url, json=payload)
        return {"webhook_status": r.status_code, "ok": r.status_code < 400}

    # ── Save to Memory ────────────────────────────────────────────
    elif step_type == "save_to_memory":
        from services.memory import mem_set
        key   = resolved_cfg.get("key", "workflow_result")
        value = resolved_cfg.get("value", context.get("last_output", ""))
        scope = resolved_cfg.get("scope", "long")
        mem_set(user_id, scope, key, str(value)[:500], confidence=0.9)
        return {"saved": True, "key": key}

    else:
        raise ValueError(f"نوع خطوة غير معروف: {step_type}")


# ══════════════════════════════════════════════════════════════════
# TEMPLATE VARIABLES RESOLVER
# ══════════════════════════════════════════════════════════════════

def _resolve_templates(cfg: Dict, context: Dict) -> Dict:
    """Replace {{variable}} in config values with context values."""
    result = {}
    for k, v in cfg.items():
        if isinstance(v, str):
            for ctx_k, ctx_v in context.items():
                v = v.replace(f"{{{{{ctx_k}}}}}", str(ctx_v))
            result[k] = v
        else:
            result[k] = v
    return result


# ══════════════════════════════════════════════════════════════════
# SECURITY: SSRF PROTECTION
# ══════════════════════════════════════════════════════════════════

_BLOCKED_HOSTS = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1",
    "169.254.169.254",  # AWS metadata
    "metadata.google.internal",
}

def _check_url_safety(url: str):
    """Block requests to internal/sensitive hosts."""
    import urllib.parse
    try:
        parsed = urllib.parse.urlparse(url)
        host   = parsed.hostname or ""
        if host in _BLOCKED_HOSTS:
            raise ValueError(f"⛔ URL محظور لأسباب أمنية: {host}")
        # Block private IP ranges
        import ipaddress
        try:
            ip = ipaddress.ip_address(host)
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                raise ValueError("⛔ IPs الداخلية محظورة")
        except ValueError as e:
            if "محظور" in str(e):
                raise
            pass  # not an IP, hostname is fine
    except Exception as e:
        if "محظور" in str(e):
            raise
        pass


# ══════════════════════════════════════════════════════════════════
# FILE OUTPUT MANAGER
# ══════════════════════════════════════════════════════════════════

_OUTPUT_STORE: Dict[str, Dict] = {}  # in-memory store (use DB in production)

def _save_output_file(user_id: str, doc_id: str, data: bytes, ext: str):
    """Save generated file in memory store for download."""
    _OUTPUT_STORE[doc_id] = {
        "user_id":    user_id,
        "data":       data,
        "ext":        ext,
        "created_at": datetime.now().isoformat(),
    }

def get_output_file(doc_id: str, user_id: str) -> Optional[Dict]:
    """Retrieve a generated file for download."""
    entry = _OUTPUT_STORE.get(doc_id)
    if not entry:
        return None
    if entry["user_id"] != user_id:
        return None  # ownership check
    return entry


# ══════════════════════════════════════════════════════════════════
# TASK TEMPLATES
# ══════════════════════════════════════════════════════════════════

DEFAULT_TEMPLATES = [
    {
        "id":          "tpl_word_doc",
        "name":        "📄 إنشاء مستند Word",
        "description": "يأخذ نصاً ويحوّله لملف Word احترافي",
        "steps": [
            {"id": "s1", "type": "ai_generate",
             "config": {"prompt": "اكتب محتوى احترافي عن: {{message}}", "model": "auto"}},
            {"id": "s2", "type": "generate_docx",
             "config": {"content": "{{text}}", "title": "{{message}}"}},
        ]
    },
    {
        "id":          "tpl_pptx",
        "name":        "📊 إنشاء عرض PowerPoint",
        "description": "يولّد عرض تقديمي من فكرتك",
        "steps": [
            {"id": "s1", "type": "ai_generate",
             "config": {"prompt": "أنشئ محتوى عرض تقديمي عن: {{message}}. استخدم ## للعناوين و- للنقاط.", "model": "peacockgpt-5"}},
            {"id": "s2", "type": "generate_pptx",
             "config": {"content": "{{text}}", "title": "{{message}}"}},
        ]
    },
    {
        "id":          "tpl_pdf_summary",
        "name":        "📋 تلخيص وتصدير PDF",
        "description": "يلخّص النص ويصدّره كـ PDF",
        "steps": [
            {"id": "s1", "type": "ai_summarize",
             "config": {"text": "{{message}}"}},
            {"id": "s2", "type": "generate_pdf",
             "config": {"content": "{{summary}}", "title": "ملخص — {{message}}"}},
        ]
    },
    {
        "id":          "tpl_research",
        "name":        "🔍 بحث وتقرير",
        "description": "يبحث ويكتب تقريراً مفصلاً",
        "steps": [
            {"id": "s1", "type": "ai_generate",
             "config": {"prompt": "اكتب تقريراً شاملاً ومنظماً عن: {{message}}. اشمل مقدمة وعدة أقسام وخلاصة.",
                        "model": "peacockgpt-5", "system": "أنت كاتب أكاديمي متخصص من PeacockAI."}},
            {"id": "s2", "type": "generate_docx",
             "config": {"content": "{{text}}", "title": "تقرير: {{message}}"}},
        ]
    },
    {
        "id":          "tpl_webhook_notify",
        "name":        "🔔 إشعار Webhook",
        "description": "يرسل نتيجة AI لـ Webhook URL",
        "steps": [
            {"id": "s1", "type": "ai_generate",
             "config": {"prompt": "{{message}}", "model": "auto"}},
            {"id": "s2", "type": "send_webhook",
             "config": {"url": "{{webhook_url}}", "payload": {"result": "{{text}}", "user": "{{user_id}}"}}},
        ]
    },
]
