"""
routes/admin_dashboard.py — Full Admin Control Panel v7
Owner-only: full system visibility + control
Author: PeacockAI – Mostafa
"""
import json, time
from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException, Header, Request, Depends
from fastapi.responses import HTMLResponse
from typing import Optional
from core.config import FLAGS, MODELS, PLANS, PRICING, APP_VERSION, ENV, log
from core.security import verify_token
from core.database import get_db, User, Log, Analytics, AgentTask, SemCache, Job, UserMemory

router = APIRouter(prefix="/admin", tags=["admin"])

# ── Admin auth (server-side token check) ─────────────────────────
import os
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "peacockai_admin_2025_secret")

def _require_admin(x_admin_token: Optional[str] = Header(None)):
    if not x_admin_token or x_admin_token != ADMIN_TOKEN:
        raise HTTPException(403, "⛔ Admin access denied")
    return True


# ══════════════════════════════════════════════════════════════════
# ADMIN DASHBOARD HTML
# ══════════════════════════════════════════════════════════════════

@router.get("/", response_class=HTMLResponse)
def admin_dashboard_ui():
    """Serve the admin dashboard HTML."""
    return HTMLResponse(content=_build_dashboard_html())


# ══════════════════════════════════════════════════════════════════
# STATS API
# ══════════════════════════════════════════════════════════════════

@router.get("/stats")
def admin_stats(auth=Depends(_require_admin)):
    """Complete system statistics."""
    try:
        with get_db() as db:
            total_users  = db.query(User).count()
            free_users   = db.query(User).filter_by(plan="free").count()
            plus_users   = db.query(User).filter_by(plan="plus").count()
            pro_users    = db.query(User).filter_by(plan="pro").count()
            total_logs   = db.query(Log).count()
            total_cost   = db.query(User).with_entities(
                           db.query(User).statement.c.token_cost).all()
            # Active today
            today = datetime.now().strftime("%Y-%m-%d")
            active_today = db.query(Log).filter(
                Log.created_at.like(f"{today}%")).count()
            # Agent tasks
            total_agents = db.query(AgentTask).count()
            done_agents  = db.query(AgentTask).filter_by(status="done").count()
            # Cache
            cache_total  = db.query(SemCache).count()
            cache_valid  = db.query(SemCache).filter(
                SemCache.ttl > time.time()).count()
            # Jobs
            pending_jobs = db.query(Job).filter_by(status="pending").count()
            failed_jobs  = db.query(Job).filter_by(status="failed").count()
            # Revenue estimate
            revenue_egp  = (plus_users * PRICING["plus"]["egp"] +
                            pro_users  * PRICING["pro"]["egp"])
            revenue_usd  = (plus_users * PRICING["plus"]["usd"] +
                            pro_users  * PRICING["pro"]["usd"])
            # Total cost
            all_users  = db.query(User).all()
            total_cost_usd = sum(u.token_cost or 0 for u in all_users)

        return {
            "app_version": APP_VERSION,
            "env":         ENV,
            "timestamp":   datetime.now().isoformat(),
            "users": {
                "total": total_users,
                "free":  free_users,
                "plus":  plus_users,
                "pro":   pro_users,
            },
            "activity": {
                "total_requests": total_logs,
                "active_today":   active_today,
            },
            "agent": {
                "total_tasks": total_agents,
                "completed":   done_agents,
            },
            "cache": {
                "total":   cache_total,
                "valid":   cache_valid,
                "hit_rate": f"{round(cache_valid/max(cache_total,1)*100,1)}%",
            },
            "jobs": {
                "pending": pending_jobs,
                "failed":  failed_jobs,
            },
            "financials": {
                "estimated_mrr_egp": revenue_egp,
                "estimated_mrr_usd": revenue_usd,
                "total_api_cost_usd": round(total_cost_usd, 4),
            },
            "flags": FLAGS,
        }
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/users")
def admin_users(limit: int = 50, plan: Optional[str] = None,
                auth=Depends(_require_admin)):
    """List all users with details."""
    try:
        with get_db() as db:
            q = db.query(User)
            if plan: q = q.filter_by(plan=plan)
            users = q.order_by(User.created_at.desc()).limit(limit).all()
        return {"users": [{
            "id":           u.id[:12]+"…",
            "name":         u.name,
            "email":        u.email[:4]+"…"+u.email[-10:] if len(u.email)>14 else "…",
            "plan":         u.plan,
            "msg_count":    u.msg_count,
            "agent_ops":    u.agent_ops,
            "token_cost":   round(u.token_cost or 0, 4),
            "sub_expires":  u.sub_expires,
            "last_seen":    u.last_seen,
            "created_at":   u.created_at,
        } for u in users]}
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/logs")
def admin_logs(limit: int = 100, log_type: Optional[str] = None,
               auth=Depends(_require_admin)):
    """Recent request logs."""
    try:
        with get_db() as db:
            q = db.query(Log)
            if log_type: q = q.filter_by(type=log_type)
            logs = q.order_by(Log.id.desc()).limit(limit).all()
        return {"logs": [{
            "user_id":    (l.user_id or "")[:12],
            "type":       l.type,
            "model":      l.model,
            "tokens":     l.tokens,
            "cost":       round(l.cost or 0, 5),
            "latency_ms": l.latency_ms,
            "cache_hit":  l.cache_hit,
            "success":    l.success,
            "error":      (l.error or "")[:100],
            "created_at": l.created_at,
        } for l in logs]}
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/agents")
def admin_agents(limit: int = 50, auth=Depends(_require_admin)):
    """Recent agent tasks."""
    try:
        with get_db() as db:
            tasks = db.query(AgentTask).order_by(
                AgentTask.created_at.desc()).limit(limit).all()
        return {"tasks": [{
            "id":          t.id,
            "user_id":     t.user_id[:12]+"…",
            "goal":        t.goal[:80],
            "status":      t.status,
            "steps_done":  t.steps_done,
            "elapsed_s":   t.elapsed_s,
            "created_at":  t.created_at,
        } for t in tasks]}
    except Exception as e:
        raise HTTPException(500, str(e))


# ══════════════════════════════════════════════════════════════════
# CONTROL ENDPOINTS
# ══════════════════════════════════════════════════════════════════

@router.post("/flags/{flag_name}")
def toggle_flag(flag_name: str, data: dict, auth=Depends(_require_admin)):
    """Toggle a feature flag."""
    if flag_name not in FLAGS:
        raise HTTPException(404, f"Flag '{flag_name}' غير موجود")
    value = data.get("enabled", not FLAGS[flag_name])
    FLAGS[flag_name] = bool(value)
    # Persist to DB
    try:
        from core.database import FeatureFlag
        with get_db() as db:
            ff = db.query(FeatureFlag).filter_by(name=flag_name).first()
            if ff: ff.enabled = value; ff.updated_at = datetime.now().isoformat()
            else:  db.add(FeatureFlag(name=flag_name,enabled=value,updated_at=datetime.now().isoformat()))
    except Exception: pass
    log.info(f"[Admin] Flag '{flag_name}' → {value}")
    return {"flag": flag_name, "enabled": FLAGS[flag_name]}


@router.post("/kill-switch")
def kill_switch(data: dict, auth=Depends(_require_admin)):
    """Emergency kill switch."""
    enabled = data.get("enabled", True)
    FLAGS["kill_switch"] = enabled
    log.warning(f"[Admin] KILL SWITCH → {enabled}")
    return {"kill_switch": enabled}


@router.post("/upgrade-user")
def upgrade_user(data: dict, auth=Depends(_require_admin)):
    """Upgrade user plan."""
    email  = data.get("email","")
    plan   = data.get("plan","plus")
    months = int(data.get("months",1))
    if plan not in ("free","plus","pro"):
        raise HTTPException(400, "خطة غير صالحة")
    expires = (datetime.now() + timedelta(days=30*months)).isoformat()
    try:
        with get_db() as db:
            u = db.query(User).filter_by(email=email.lower()).first()
            if not u: raise HTTPException(404, "المستخدم غير موجود")
            u.plan = plan; u.sub_expires = expires
        log.info(f"[Admin] Upgraded {email} → {plan}")
        return {"ok": True, "email": email, "plan": plan, "expires": expires}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))


@router.delete("/user/{user_id}")
def delete_user(user_id: str, auth=Depends(_require_admin)):
    """Delete a user account."""
    try:
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if not u: raise HTTPException(404, "المستخدم غير موجود")
            db.delete(u)
        from services.file_manager import clear_sandbox
        try: clear_sandbox(user_id)
        except Exception: pass
        log.info(f"[Admin] Deleted user: {user_id}")
        return {"ok": True}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))


@router.post("/broadcast")
def broadcast_message(data: dict, auth=Depends(_require_admin)):
    """Store a broadcast message shown to all users."""
    msg = data.get("message","")
    if not msg: raise HTTPException(400, "الرسالة مطلوبة")
    FLAGS["_broadcast"] = msg
    log.info(f"[Admin] Broadcast: {msg[:80]}")
    return {"ok": True, "message": msg}


@router.get("/broadcast")
def get_broadcast():
    """Get current broadcast message (public endpoint for frontend)."""
    return {"message": FLAGS.get("_broadcast","")}


@router.delete("/cache")
def clear_cache(auth=Depends(_require_admin)):
    """Clear semantic cache."""
    try:
        from services.vector_cache import cache_delete_expired
        deleted = cache_delete_expired()
        # Also clear all
        with get_db() as db:
            db.query(SemCache).delete()
        log.info(f"[Admin] Cache cleared")
        return {"ok": True, "deleted": deleted}
    except Exception as e: raise HTTPException(500, str(e))


# ══════════════════════════════════════════════════════════════════
# ADMIN DASHBOARD HTML
# ══════════════════════════════════════════════════════════════════

def _build_dashboard_html() -> str:
    return """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>🦚 PeacockGPT — لوحة التحكم</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#08080f;--bg2:#0e0e18;--sur:#131320;--sur2:#1a1a2e;--bd:#242436;
      --tx:#e2e2f0;--tx2:#8888b0;--tx3:#55557a;--ac:#7060ff;--ac2:#9b8fff;
      --gn:#1ed9a0;--rd:#ff4a6a;--or:#ff8c40;--gold:#f5c640}
body{background:var(--bg);color:var(--tx);font-family:system-ui,sans-serif;min-height:100vh}
.topbar{background:var(--bg2);border-bottom:1px solid var(--bd);padding:14px 24px;
        display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.logo{display:flex;align-items:center;gap:10px;font-size:17px;font-weight:800}
.logo-ic{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--ac),#5040d0);
         display:flex;align-items:center;justify-content:center;font-size:18px}
.badge{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;
       background:rgba(255,74,106,.12);color:var(--rd)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;gap:16px}
.grid-4{grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}
.grid-2{grid-template-columns:repeat(auto-fit,minmax(450px,1fr))}
.card{background:var(--sur);border:1px solid var(--bd);border-radius:14px;padding:20px}
.card-title{font-size:12px;color:var(--tx3);font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:14px;display:flex;align-items:center;gap:7px}
.stat-val{font-size:32px;font-weight:900;margin-bottom:4px}
.stat-sub{font-size:12px;color:var(--tx2)}
.green{color:var(--gn)} .red{color:var(--rd)} .gold{color:var(--gold)} .purple{color:var(--ac2)}
.table-wrap{overflow-x:auto;margin-top:12px}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:right;padding:8px 12px;background:var(--sur2);color:var(--tx3);font-weight:700;border-bottom:1px solid var(--bd)}
td{padding:8px 12px;border-bottom:1px solid var(--bd);color:var(--tx2)}
tr:hover td{background:var(--sur2)}
.flag-row{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--bd)}
.flag-row:last-child{border-bottom:none}
.flag-name{font-size:13px}
.toggle{width:44px;height:24px;background:var(--bd);border:none;border-radius:12px;cursor:pointer;position:relative;transition:background .2s}
.toggle.on{background:var(--ac)}
.toggle::after{content:'';width:18px;height:18px;background:#fff;border-radius:50%;position:absolute;top:3px;left:3px;transition:left .2s}
.toggle.on::after{left:23px}
.btn{padding:8px 16px;border:none;border-radius:9px;cursor:pointer;font-size:13px;font-weight:700;transition:opacity .15s}
.btn:hover{opacity:.85}
.btn-primary{background:linear-gradient(135deg,var(--ac),#5040d0);color:#fff}
.btn-danger{background:rgba(255,74,106,.15);color:var(--rd);border:1px solid rgba(255,74,106,.3)}
.btn-success{background:rgba(30,217,160,.12);color:var(--gn);border:1px solid rgba(30,217,160,.25)}
.input-row{display:flex;gap:8px;margin-top:10px}
.inp{flex:1;padding:9px 13px;background:var(--sur2);border:1px solid var(--bd);border-radius:9px;color:var(--tx);font-size:13px;outline:none}
.inp:focus{border-color:var(--ac)}
.tabs{display:flex;gap:3px;margin-bottom:20px;background:var(--sur);padding:4px;border-radius:10px;width:fit-content}
.tab{padding:7px 16px;border:none;background:none;color:var(--tx2);cursor:pointer;border-radius:8px;font-size:13px;font-weight:600;transition:all .15s}
.tab.on{background:var(--ac);color:#fff}
.section{display:none}
.section.on{display:block}
.kill-panel{background:rgba(255,74,106,.06);border:1px solid rgba(255,74,106,.2);border-radius:12px;padding:16px;margin-bottom:16px}
.revenue-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
#toast{position:fixed;bottom:24px;right:24px;background:var(--gn);color:#000;padding:12px 20px;border-radius:10px;font-weight:700;opacity:0;transition:opacity .3s;pointer-events:none;z-index:999}
#toast.on{opacity:1}
.refresh-btn{background:none;border:1px solid var(--bd);color:var(--tx2);padding:6px 14px;border-radius:8px;cursor:pointer;font-size:12px}
.loading{text-align:center;padding:40px;color:var(--tx3)}
</style>
</head>
<body>
<div class="topbar">
  <div class="logo"><div class="logo-ic">🦚</div>PeacockGPT Admin <div class="badge">OWNER</div></div>
  <div style="display:flex;gap:10px;align-items:center">
    <span id="env-badge" style="font-size:12px;color:var(--tx3)"></span>
    <button class="refresh-btn" onclick="loadAll()">🔄 تحديث</button>
  </div>
</div>

<div class="container">
  <!-- Auth Gate -->
  <div id="auth-gate" style="max-width:400px;margin:80px auto">
    <div class="card">
      <div class="card-title">🔐 تسجيل دخول المالك</div>
      <input class="inp" id="admin-token-inp" type="password" placeholder="Admin Token" style="width:100%;margin-bottom:10px">
      <button class="btn btn-primary" onclick="adminLogin()" style="width:100%">دخول</button>
      <div id="auth-err" style="color:var(--rd);font-size:12px;margin-top:8px;display:none"></div>
    </div>
  </div>

  <!-- Dashboard -->
  <div id="dashboard" style="display:none">
    <!-- Tabs -->
    <div class="tabs">
      <button class="tab on" onclick="switchTab('overview')">📊 Overview</button>
      <button class="tab" onclick="switchTab('users')">👥 Users</button>
      <button class="tab" onclick="switchTab('logs')">📋 Logs</button>
      <button class="tab" onclick="switchTab('agents')">🤖 Agents</button>
      <button class="tab" onclick="switchTab('control')">⚙️ Control</button>
    </div>

    <!-- OVERVIEW -->
    <div class="section on" id="tab-overview">
      <div class="grid grid-4" id="stats-cards">
        <div class="loading">⏳ جارٍ التحميل…</div>
      </div>
      <div class="grid grid-2" style="margin-top:16px" id="stats-details"></div>
    </div>

    <!-- USERS -->
    <div class="section" id="tab-users">
      <div class="card">
        <div class="card-title">👥 المستخدمون
          <select id="plan-filter" onchange="loadUsers()" style="margin-right:auto;background:var(--sur2);border:1px solid var(--bd);color:var(--tx);padding:4px 8px;border-radius:6px;font-size:12px">
            <option value="">الكل</option><option value="free">Free</option>
            <option value="plus">Plus</option><option value="pro">Pro</option>
          </select>
        </div>
        <div class="table-wrap"><table id="users-table"><tr><td class="loading">⏳</td></tr></table></div>
      </div>
      <div class="card" style="margin-top:16px">
        <div class="card-title">⬆️ ترقية مستخدم</div>
        <div class="input-row">
          <input class="inp" id="upg-email" placeholder="البريد الإلكتروني">
          <select id="upg-plan" style="background:var(--sur2);border:1px solid var(--bd);color:var(--tx);padding:9px;border-radius:9px">
            <option value="plus">Plus</option><option value="pro">Pro</option><option value="free">Free</option>
          </select>
          <input class="inp" id="upg-months" type="number" value="1" placeholder="أشهر" style="max-width:80px">
          <button class="btn btn-success" onclick="upgradeUser()">ترقية</button>
        </div>
      </div>
    </div>

    <!-- LOGS -->
    <div class="section" id="tab-logs">
      <div class="card">
        <div class="card-title">📋 السجلات الأخيرة</div>
        <div class="table-wrap"><table id="logs-table"><tr><td class="loading">⏳</td></tr></table></div>
      </div>
    </div>

    <!-- AGENTS -->
    <div class="section" id="tab-agents">
      <div class="card">
        <div class="card-title">🤖 مهام Agent</div>
        <div class="table-wrap"><table id="agents-table"><tr><td class="loading">⏳</td></tr></table></div>
      </div>
    </div>

    <!-- CONTROL -->
    <div class="section" id="tab-control">
      <div class="kill-panel">
        <div style="font-size:14px;font-weight:700;color:var(--rd);margin-bottom:10px">🚨 Kill Switches</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-danger" onclick="killSwitch(true)">🔴 إيقاف الكل</button>
          <button class="btn btn-success" onclick="killSwitch(false)">🟢 تشغيل الكل</button>
          <button class="btn btn-danger" onclick="toggleFlag('kill_agent',true)">🛑 وقف Agent</button>
          <button class="btn btn-danger" onclick="toggleFlag('kill_search',true)">🛑 وقف Search</button>
          <button class="btn btn-danger" onclick="clearCache()">🗑️ مسح Cache</button>
        </div>
      </div>
      <div class="grid grid-2">
        <div class="card">
          <div class="card-title">🚩 Feature Flags</div>
          <div id="flags-list"><div class="loading">⏳</div></div>
        </div>
        <div class="card">
          <div class="card-title">📢 Broadcast رسالة لكل المستخدمين</div>
          <textarea class="inp" id="bc-msg" rows="3" placeholder="اكتب رسالة…" style="width:100%;margin-bottom:10px;resize:vertical"></textarea>
          <button class="btn btn-primary" onclick="sendBroadcast()">إرسال</button>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="toast"></div>

<script>
let ADMIN_TOKEN = '';
const API = window.PEACOCK_API_BASE || '';

function adminLogin(){
  const tok = document.getElementById('admin-token-inp').value.trim();
  if(!tok){ showErr('أدخل الـ Token'); return; }
  ADMIN_TOKEN = tok;
  // Test auth
  fetch(`${API}/admin/stats`,{headers:{'x-admin-token':tok}})
    .then(r=>{
      if(!r.ok){ showErr('Token خاطئ'); ADMIN_TOKEN=''; return; }
      document.getElementById('auth-gate').style.display='none';
      document.getElementById('dashboard').style.display='block';
      loadAll();
    }).catch(()=>showErr('تعذر الاتصال'));
}

function showErr(msg){
  const el=document.getElementById('auth-err');
  el.textContent=msg; el.style.display='block';
  setTimeout(()=>el.style.display='none',3000);
}

function hdrs(){ return {'x-admin-token':ADMIN_TOKEN,'Content-Type':'application/json'}; }

async function loadAll(){
  loadStats();
  loadUsers();
  loadLogs();
  loadAgents();
  loadFlags();
}

async function loadStats(){
  try{
    const r = await fetch(`${API}/admin/stats`,{headers:hdrs()});
    const d = await r.json();
    document.getElementById('env-badge').textContent = `v${d.app_version} [${d.env}]`;
    document.getElementById('stats-cards').innerHTML = `
      <div class="card"><div class="card-title">👥 إجمالي المستخدمين</div>
        <div class="stat-val purple">${d.users.total}</div>
        <div class="stat-sub">Free: ${d.users.free} | Plus: ${d.users.plus} | Pro: ${d.users.pro}</div></div>
      <div class="card"><div class="card-title">📊 طلبات اليوم</div>
        <div class="stat-val green">${d.activity.active_today}</div>
        <div class="stat-sub">إجمالي: ${d.activity.total_requests.toLocaleString()}</div></div>
      <div class="card"><div class="card-title">💰 دخل شهري متوقع</div>
        <div class="stat-val gold">${d.financials.estimated_mrr_egp.toLocaleString()} EGP</div>
        <div class="stat-sub">$${d.financials.estimated_mrr_usd}/شهر | Cost: $${d.financials.total_api_cost_usd}</div></div>
      <div class="card"><div class="card-title">🤖 Agent Tasks</div>
        <div class="stat-val">${d.agent.total_tasks}</div>
        <div class="stat-sub">مكتمل: ${d.agent.completed}</div></div>
      <div class="card"><div class="card-title">⚡ Semantic Cache</div>
        <div class="stat-val green">${d.cache.hit_rate}</div>
        <div class="stat-sub">صالح: ${d.cache.valid} / ${d.cache.total}</div></div>
      <div class="card"><div class="card-title">🔴 Kill Switch</div>
        <div class="stat-val ${d.flags.kill_switch?'red':'green'}">${d.flags.kill_switch?'ON':'OFF'}</div>
        <div class="stat-sub">Agent: ${d.flags.kill_agent?'⛔':'✅'}</div></div>
    `;
  }catch(e){ console.error(e); }
}

async function loadUsers(){
  const plan = document.getElementById('plan-filter')?.value||'';
  try{
    const r = await fetch(`${API}/admin/users?limit=50${plan?'&plan='+plan:''}`,{headers:hdrs()});
    const d = await r.json();
    const t = document.getElementById('users-table');
    t.innerHTML=`<tr><th>الاسم</th><th>الخطة</th><th>الرسائل</th><th>Agent Ops</th><th>التكلفة</th><th>آخر ظهور</th></tr>`;
    d.users.forEach(u=>{ const tr=document.createElement('tr');
      tr.innerHTML=`<td>${u.name}</td><td><span style="color:${u.plan==='pro'?'var(--gold)':u.plan==='plus'?'var(--gn)':'var(--tx2)'}">${u.plan}</span></td>
        <td>${u.msg_count}</td><td>${u.agent_ops}</td><td>$${u.token_cost}</td><td>${u.last_seen?.substring(0,16)||'-'}</td>`;
      t.appendChild(tr); });
  }catch(e){ console.error(e); }
}

async function loadLogs(){
  try{
    const r = await fetch(`${API}/admin/logs?limit=100`,{headers:hdrs()});
    const d = await r.json();
    const t = document.getElementById('logs-table');
    t.innerHTML=`<tr><th>User</th><th>Type</th><th>Model</th><th>Tokens</th><th>Cost</th><th>Latency</th><th>Status</th><th>Time</th></tr>`;
    d.logs.forEach(l=>{ const tr=document.createElement('tr');
      tr.innerHTML=`<td>${l.user_id}</td><td>${l.type||'-'}</td><td>${l.model||'-'}</td>
        <td>${l.tokens}</td><td>$${l.cost}</td><td>${l.latency_ms}ms</td>
        <td>${l.success?'<span style="color:var(--gn)">✅</span>':'<span style="color:var(--rd)">❌</span>'}</td>
        <td>${(l.created_at||'').substring(0,16)}</td>`;
      t.appendChild(tr); });
  }catch(e){ console.error(e); }
}

async function loadAgents(){
  try{
    const r = await fetch(`${API}/admin/agents`,{headers:hdrs()});
    const d = await r.json();
    const t = document.getElementById('agents-table');
    t.innerHTML=`<tr><th>ID</th><th>User</th><th>Goal</th><th>Status</th><th>Steps</th><th>Time</th></tr>`;
    d.tasks.forEach(a=>{ const tr=document.createElement('tr');
      const sc=a.status==='done'?'var(--gn)':a.status==='failed'?'var(--rd)':'var(--or)';
      tr.innerHTML=`<td>${a.id.substring(0,8)}</td><td>${a.user_id}</td><td>${a.goal}</td>
        <td><span style="color:${sc}">${a.status}</span></td>
        <td>${a.steps_done}</td><td>${(a.created_at||'').substring(0,16)}</td>`;
      t.appendChild(tr); });
  }catch(e){ console.error(e); }
}

async function loadFlags(){
  try{
    const r = await fetch(`${API}/admin/stats`,{headers:hdrs()});
    const d = await r.json();
    const el = document.getElementById('flags-list');
    el.innerHTML = Object.entries(d.flags).filter(([k])=>!k.startsWith('_')).map(([k,v])=>`
      <div class="flag-row">
        <span class="flag-name">${k}</span>
        <button class="toggle ${v?'on':''}" onclick="toggleFlag('${k}',${!v})" title="${k}"></button>
      </div>`).join('');
  }catch(e){ console.error(e); }
}

async function toggleFlag(name, val){
  try{
    await fetch(`${API}/admin/flags/${name}`,{method:'POST',headers:hdrs(),body:JSON.stringify({enabled:val})});
    showToast(`✅ ${name} → ${val}`); loadFlags(); loadStats();
  }catch(e){ showToast('❌ '+e.message); }
}

async function killSwitch(on){
  try{
    await fetch(`${API}/admin/kill-switch`,{method:'POST',headers:hdrs(),body:JSON.stringify({enabled:on})});
    showToast(on?'🔴 Kill Switch ON':'🟢 Kill Switch OFF'); loadStats();
  }catch(e){ showToast('❌ '+e.message); }
}

async function upgradeUser(){
  const email=document.getElementById('upg-email').value.trim();
  const plan=document.getElementById('upg-plan').value;
  const months=document.getElementById('upg-months').value;
  if(!email){ showToast('⚠️ أدخل البريد'); return; }
  try{
    const r=await fetch(`${API}/admin/upgrade-user`,{method:'POST',headers:hdrs(),body:JSON.stringify({email,plan,months:parseInt(months)})});
    const d=await r.json();
    if(d.ok){ showToast(`✅ تمت ترقية ${email} → ${plan}`); loadUsers(); }
    else showToast('❌ '+JSON.stringify(d));
  }catch(e){ showToast('❌ '+e.message); }
}

async function clearCache(){
  if(!confirm('مسح الـ cache كاملاً؟')) return;
  try{
    await fetch(`${API}/admin/cache`,{method:'DELETE',headers:hdrs()});
    showToast('✅ Cache مُمسح'); loadStats();
  }catch(e){ showToast('❌ '+e.message); }
}

async function sendBroadcast(){
  const msg=document.getElementById('bc-msg').value.trim();
  if(!msg){ showToast('⚠️ أدخل الرسالة'); return; }
  try{
    await fetch(`${API}/admin/broadcast`,{method:'POST',headers:hdrs(),body:JSON.stringify({message:msg})});
    showToast('✅ تم الإرسال'); document.getElementById('bc-msg').value='';
  }catch(e){ showToast('❌ '+e.message); }
}

function switchTab(name){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('on'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  document.getElementById('tab-'+name).classList.add('on');
  event.target.classList.add('on');
  if(name==='users') loadUsers();
  if(name==='logs') loadLogs();
  if(name==='agents') loadAgents();
  if(name==='control') loadFlags();
}

function showToast(msg,dur=3000){
  const t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('on');
  setTimeout(()=>t.classList.remove('on'),dur);
}

// Auto-login if token in URL hash
const hashToken = location.hash.slice(1);
if(hashToken){ document.getElementById('admin-token-inp').value=hashToken; adminLogin(); }

// Auto-refresh every 30s
setInterval(()=>{if(ADMIN_TOKEN) loadStats();}, 30000);
</script>
</body>
</html>"""
