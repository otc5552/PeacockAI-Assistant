"""
services/agent.py — Multi-Step Agent v7 Final
Task Decomposition + Step Retry + Validation + Human Control
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time, re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, AsyncGenerator
from core.config import MODELS, FLAGS, PLANS, log
from core.database import get_db, AgentTask, PendingAction
from services.file_manager import (
    write_file, read_file, list_files, create_file,
    get_project_tree, FileManagerError
)
from services.llm import execute

MAX_STEPS          = 15
MAX_STEP_RETRIES   = 2
CONFIRM_EXPIRE_MIN = 10
MAX_CTX_CHARS      = 4000

# ══════════════════════════════════════════════════════════════════
# GUARDS
# ══════════════════════════════════════════════════════════════════

def require_pro(user_plan: str):
    if user_plan != "pro" or not PLANS["pro"].get("agent"):
        raise PermissionError("🔒 Agent Mode للـ Pro فقط. ترقية: 1500 جنيه / $35")

def check_agent_ops(user_id: str, user_plan: str) -> tuple:
    limit = PLANS.get(user_plan, {}).get("agent_ops", 0)
    if limit == 0: return False, "Agent غير متاح في خطتك"
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u and (u.agent_ops or 0) >= limit:
                return False, f"تجاوزت حد {limit} عملية/يوم"
    except Exception: pass
    return True, ""

def increment_agent_ops(user_id: str):
    try:
        with get_db() as db:
            from core.database import User
            u = db.query(User).filter_by(id=user_id).first()
            if u: u.agent_ops = (u.agent_ops or 0) + 1
    except Exception: pass


# ══════════════════════════════════════════════════════════════════
# INTENT CLASSIFICATION
# ══════════════════════════════════════════════════════════════════

class IntentClass:
    READ      = "read"
    WRITE     = "write"
    DELETE    = "delete"
    AMBIGUOUS = "ambiguous"

_READ_KW  = {"اشرح","explain","اقرأ","read file","افتح ملف","اعرض","show",
             "list files","حلل","analyze","review","ما هو","what is","كيف يعمل"}
_WRITE_KW = {"اعمل","ابني","أنشئ","build","create","عدل","modify","refactor",
             "edit","اكتب","احذف","delete","remove","امسح","غيّر","change","update","اضف"}
_CONFIRM_W = {"نعم","موافق","اوكي","ok","okay","confirm","proceed","ابدأ","نفذ","يلا","كمّل","تمام","go"}

def classify_intent(msg: str) -> str:
    low = msg.lower()
    if any(k in low for k in {"احذف","delete","remove","امسح"}): return IntentClass.DELETE
    if any(k in low for k in _WRITE_KW): return IntentClass.WRITE
    if any(k in low for k in _READ_KW):  return IntentClass.READ
    return IntentClass.AMBIGUOUS

def is_agent_request(msg: str) -> bool:
    low = msg.lower()
    return any(t in low for t in (_READ_KW | _WRITE_KW))

def is_explicit_execute(msg: str) -> bool:
    return any(w in msg.lower() for w in _CONFIRM_W)


# ══════════════════════════════════════════════════════════════════
# RISK ASSESSMENT
# ══════════════════════════════════════════════════════════════════

def assess_risk(steps: list) -> dict:
    files   = sum(1 for s in steps if s.get("type") in ("create_file","write_file"))
    deletes = sum(1 for s in steps if "delete" in s.get("type",""))
    reasons = []
    if files > 5:   reasons.append(f"تعديل {files} ملفات")
    if deletes > 0: reasons.append(f"حذف {deletes} ملف")
    if len(steps) > 8: reasons.append(f"{len(steps)} خطوة")
    level = "high" if (deletes > 0 or files > 8) else "medium" if (files > 3 or len(steps) > 5) else "low"
    return {"level":level,"reasons":reasons,"file_count":files,"has_delete":deletes>0,"step_count":len(steps)}

def build_confirm_msg(goal: str, steps: list, risk: dict) -> str:
    icons = {"low":"🟢","medium":"🟡","high":"🔴"}
    lines = [
        f"📋 **خطة التنفيذ**: {goal[:60]}",
        f"{icons[risk['level']]} خطورة: **{risk['level'].upper()}**",
    ]
    if risk["reasons"]: lines.append("⚠️ " + " | ".join(risk["reasons"]))
    lines.append("\n**الخطوات:**")
    step_icons = {"create_file":"📄","write_file":"✏️","read_file":"👁️",
                  "list_files":"📂","think":"🧠","summarise":"📝","delete_file":"🗑️"}
    for s in steps:
        ic  = step_icons.get(s.get("type",""),"⚡")
        fn  = f" `{s['filename']}`" if s.get("filename") else ""
        lines.append(f"  {s['id']}. {ic}{fn}: {s.get('description','')[:55]}")
    lines += ["","💬 **نعم** للتنفيذ | **لا** للإلغاء"]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════
# PENDING ACTIONS
# ══════════════════════════════════════════════════════════════════

def save_pending(user_id, task_id, action_type, summary, plan, risk_level) -> str:
    aid = secrets.token_hex(12)
    now = datetime.now()
    try:
        with get_db() as db:
            db.add(PendingAction(
                id=aid, user_id=user_id, task_id=task_id,
                action_type=action_type, summary=summary[:2000],
                plan_json=json.dumps(plan, ensure_ascii=False),
                risk_level=risk_level, status="pending",
                expires_at=(now+timedelta(minutes=CONFIRM_EXPIRE_MIN)).isoformat(),
                created_at=now.isoformat(),
            ))
    except Exception as e: log.warning(f"[Agent] save_pending: {e}")
    return aid

def get_pending(action_id, user_id) -> Optional[dict]:
    try:
        with get_db() as db:
            r = db.query(PendingAction).filter_by(id=action_id,user_id=user_id,status="pending").first()
            if not r: return None
            if datetime.now() > datetime.fromisoformat(r.expires_at):
                r.status = "expired"; return None
            return {"id":r.id,"task_id":r.task_id,"action_type":r.action_type,
                    "summary":r.summary,"plan":json.loads(r.plan_json),"risk_level":r.risk_level}
    except Exception: return None

def get_pending_for_user(user_id) -> Optional[dict]:
    try:
        with get_db() as db:
            r = db.query(PendingAction).filter_by(user_id=user_id,status="pending")\
                  .order_by(PendingAction.created_at.desc()).first()
            if not r: return None
            if datetime.now() > datetime.fromisoformat(r.expires_at):
                r.status = "expired"; return None
            return {"id":r.id,"task_id":r.task_id,"action_type":r.action_type,
                    "summary":r.summary,"plan":json.loads(r.plan_json),"risk_level":r.risk_level}
    except Exception: return None

def resolve_pending(action_id, user_id, decision):
    try:
        with get_db() as db:
            r = db.query(PendingAction).filter_by(id=action_id,user_id=user_id).first()
            if r: r.status = decision; r.decided_at = datetime.now().isoformat()
    except Exception: pass


# ══════════════════════════════════════════════════════════════════
# TASK DECOMPOSITION ENGINE  (AI-powered planning)
# ══════════════════════════════════════════════════════════════════

PLAN_PROMPT = """أنت PeacockGPT Agent — مخطط مهام متقدم من PeacockAI.
حلّل الطلب وقسّمه لخطوات تنفيذية منطقية.

أعد JSON فقط:
{
  "goal": "...",
  "complexity": "simple|medium|complex",
  "steps": [
    {"id":1,"type":"think","description":"..."},
    {"id":2,"type":"create_file","filename":"app.py","description":"..."},
    {"id":3,"type":"write_file","filename":"app.py","description":"..."},
    {"id":4,"type":"summarise","description":"..."}
  ]
}

أنواع الخطوات: think | create_file | write_file | read_file | list_files | summarise
قواعد: خطوات منطقية مرتبة | max 10 ملفات | JSON فقط بدون markdown"""

async def decompose_task(goal: str, context: str, groq_key: str, gemini_key: str) -> dict:
    """AI-powered task decomposition with validation."""
    msgs = [
        {"role":"system","content":PLAN_PROMPT},
        {"role":"user","content":f"الطلب: {goal}\nالسياق: {context[:400]}"}
    ]
    raw = ""
    try:
        async for chunk, _ in execute("peacockgpt-5", msgs, PLAN_PROMPT, groq_key, gemini_key, max_tokens=1500):
            raw += chunk
    except Exception as e:
        log.warning(f"[Agent] decompose error: {e}")
        return _fallback_plan(goal)

    # Parse JSON (handle fences)
    for attempt in [raw.strip(), *[p.strip().lstrip("json").strip() for p in raw.split("```") if p.strip()]]:
        try:
            data = json.loads(attempt)
            if "steps" in data:
                # Validate steps
                valid_types = {"think","create_file","write_file","read_file","list_files","summarise","delete_file"}
                data["steps"] = [s for s in data["steps"] if s.get("type") in valid_types][:MAX_STEPS]
                return data
        except Exception: pass

    return _fallback_plan(goal)

def _fallback_plan(goal: str) -> dict:
    return {"goal":goal,"complexity":"simple","steps":[
        {"id":1,"type":"think",      "description":f"تحليل: {goal}"},
        {"id":2,"type":"write_file", "filename":"output.md","description":"كتابة النتيجة"},
        {"id":3,"type":"summarise",  "description":"تلخيص"},
    ]}


# ══════════════════════════════════════════════════════════════════
# STEP EXECUTOR with RETRY + VALIDATION
# ══════════════════════════════════════════════════════════════════

STEP_SYS = """أنت PeacockGPT Agent من PeacockAI.
تنفذ: {step_desc}
ضمن مهمة: {goal}
{ctx}
{extra}
أجب بالمحتوى المطلوب مباشرة."""

async def execute_step_with_retry(step: dict, goal: str, user_id: str,
                                   ctx: str, groq_key: str, gemini_key: str) -> dict:
    """Execute step with retry on failure."""
    last_result = None
    for attempt in range(MAX_STEP_RETRIES):
        result = await _execute_step(step, goal, user_id, ctx, groq_key, gemini_key)
        if result["status"] == "done":
            return result
        last_result = result
        if attempt < MAX_STEP_RETRIES - 1:
            log.warning(f"[Agent] Step {step['id']} attempt {attempt+1} failed, retrying…")
            await asyncio.sleep(0.8)
    return last_result or {"step_id":step["id"],"type":step.get("type"),"status":"error","output":"فشل بعد عدة محاولات","filename":""}

async def _execute_step(step: dict, goal: str, user_id: str,
                         ctx: str, groq_key: str, gemini_key: str) -> dict:
    stype  = step.get("type","think")
    sdesc  = step.get("description","")
    fname  = step.get("filename","")
    result = {"step_id":step["id"],"type":stype,"status":"done","output":"","filename":""}

    try:
        if stype == "list_files":
            files = list_files(user_id)
            result["output"] = json.dumps([f["path"] for f in files], ensure_ascii=False)

        elif stype == "read_file":
            if not fname: result["status"]="skipped"; result["output"]="لا اسم ملف"; return result
            content, _ = read_file(user_id, fname)
            result["output"] = content[:3000]; result["filename"] = fname

        elif stype in ("create_file","write_file"):
            extra = f"اكتب محتوى `{fname}` كاملاً جاهزاً للتشغيل." if fname.endswith((".py",".js",".ts",".html")) else f"اكتب محتوى `{fname}`."
            prompt = STEP_SYS.format(goal=goal,step_desc=sdesc,ctx=ctx[:800] if ctx else "",extra=extra)
            msgs = [{"role":"system","content":prompt},{"role":"user","content":f"اكتب: {fname}"}]
            content = ""
            async for chunk, _ in execute("peacockgpt-5",msgs,prompt,groq_key,gemini_key,max_tokens=3000):
                content += chunk
            if not content.strip(): raise RuntimeError("استجابة فارغة من النموذج")
            write_file(user_id, fname, content, overwrite=True)
            result["output"] = content[:500]+("…" if len(content)>500 else "")
            result["filename"] = fname

        elif stype in ("think","summarise"):
            prompt = STEP_SYS.format(goal=goal,step_desc=sdesc,ctx=ctx[:600] if ctx else "",extra="")
            msgs = [{"role":"system","content":prompt},{"role":"user","content":sdesc}]
            out = ""
            async for chunk, _ in execute("peacockgpt-5-fast",msgs,prompt,groq_key,gemini_key,max_tokens=800):
                out += chunk
            result["output"] = out or "(لا استجابة)"

        else:
            result["status"] = "skipped"; result["output"] = f"نوع غير معروف: {stype}"

    except FileManagerError as e:
        result["status"]="error"; result["output"]=f"⛔ {e}"
    except RuntimeError as e:
        result["status"]="error"; result["output"]=str(e)
    except Exception as e:
        result["status"]="error"; result["output"]=f"خطأ: {e}"
        log.error(f"[Agent] Step {step['id']} error: {e}")

    return result


# ══════════════════════════════════════════════════════════════════
# PLAN + CONFIRM FLOW  (Human Control)
# ══════════════════════════════════════════════════════════════════

async def plan_and_request_confirmation(
    goal, user_id, user_plan, groq_key, gemini_key, context=""
) -> AsyncGenerator[str, None]:
    try: require_pro(user_plan)
    except PermissionError as e: yield _sse({"type":"error","content":str(e)}); return

    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok: yield _sse({"type":"error","content":reason}); return
    if FLAGS.get("kill_agent"): yield _sse({"type":"error","content":"⚠️ Agent متوقف مؤقتاً."}); return

    intent = classify_intent(goal)
    if intent == IntentClass.READ:
        yield _sse({"type":"agent_info","content":"👁️ قراءة فقط — تنفيذ مباشر."})
        async for chunk in run_agent(goal,user_id,user_plan,groq_key,gemini_key,context,True):
            yield chunk
        return
    if intent == IntentClass.AMBIGUOUS:
        yield _sse({"type":"agent_clarify","content":"🤔 ما فهمت. قل: اقرأ / اعمل / عدّل / احذف"}); return

    task_id = secrets.token_hex(10); now = datetime.now().isoformat()
    try:
        with get_db() as db:
            db.add(AgentTask(id=task_id,user_id=user_id,goal=goal,status="planning",created_at=now,updated_at=now))
    except Exception: pass

    yield _sse({"type":"agent_start","task_id":task_id,"message":f"🤖 تحليل: {goal[:60]}"})
    yield _sse({"type":"agent_phase","phase":"planning","message":"📋 جارٍ التخطيط…"})

    plan  = await decompose_task(goal, context, groq_key, gemini_key)
    steps = plan.get("steps",[])[:MAX_STEPS]
    risk  = assess_risk(steps)
    msg   = build_confirm_msg(goal, steps, risk)
    aid   = save_pending(user_id, task_id, intent, msg, steps, risk["level"])

    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.plan=json.dumps(steps,ensure_ascii=False)
                t.status="awaiting_confirm"; t.updated_at=datetime.now().isoformat()
    except Exception: pass

    yield _sse({"type":"agent_awaiting_confirm","task_id":task_id,"action_id":aid,
                "steps":steps,"risk":risk,"message":msg,"expires_min":CONFIRM_EXPIRE_MIN})


async def execute_confirmed_action(
    action_id, user_id, user_plan, groq_key, gemini_key
) -> AsyncGenerator[str, None]:
    pending = get_pending(action_id, user_id)
    if not pending:
        yield _sse({"type":"error","content":"⚠️ انتهت صلاحية الطلب. أرسله من جديد."}); return

    resolve_pending(action_id, user_id, "confirmed")
    yield _sse({"type":"agent_confirmed","task_id":pending["task_id"],
                "message":f"✅ تأكيد — بدء التنفيذ ({len(pending['plan'])} خطوة)"})
    async for chunk in _run_steps(pending["plan"],pending["task_id"],pending["summary"][:80],user_id,groq_key,gemini_key):
        yield chunk


async def run_agent(
    goal, user_id, user_plan, groq_key, gemini_key,
    context="", skip_confirmation=False
) -> AsyncGenerator[str, None]:
    try: require_pro(user_plan)
    except PermissionError as e: yield _sse({"type":"error","content":str(e)}); return
    ok, reason = check_agent_ops(user_id, user_plan)
    if not ok: yield _sse({"type":"error","content":reason}); return
    if FLAGS.get("kill_agent"): yield _sse({"type":"error","content":"Agent متوقف."}); return

    task_id = secrets.token_hex(10); now = datetime.now().isoformat()
    try:
        with get_db() as db:
            db.add(AgentTask(id=task_id,user_id=user_id,goal=goal,status="running",created_at=now,updated_at=now))
    except Exception: pass

    yield _sse({"type":"agent_start","task_id":task_id,"message":f"🤖 {goal[:60]}"})
    yield _sse({"type":"agent_phase","phase":"planning","message":"📋 التخطيط…"})

    plan  = await decompose_task(goal, context, groq_key, gemini_key)
    steps = plan.get("steps",[])[:MAX_STEPS]
    yield _sse({"type":"agent_plan","steps":steps,"complexity":plan.get("complexity",""),"message":f"✅ {len(steps)} خطوات"})

    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t: t.plan=json.dumps(steps,ensure_ascii=False); t.status="running"; t.updated_at=datetime.now().isoformat()
    except Exception: pass

    async for chunk in _run_steps(steps,task_id,goal,user_id,groq_key,gemini_key):
        yield chunk


# ══════════════════════════════════════════════════════════════════
# INTERNAL STEP RUNNER
# ══════════════════════════════════════════════════════════════════

async def _run_steps(steps,task_id,goal,user_id,groq_key,gemini_key) -> AsyncGenerator[str, None]:
    t0     = time.time()
    ops    = []
    ctx    = ""

    for step in steps:
        yield _sse({"type":"agent_step","step_id":step["id"],"step_type":step.get("type",""),
                    "message":f"⚡ خطوة {step['id']}: {step.get('description','')[:55]}"})

        result = await execute_step_with_retry(step,goal,user_id,ctx,groq_key,gemini_key)

        if result.get("output"):
            ctx += f"\n[{step['id']}]: {result['output'][:400]}"
            if len(ctx) > MAX_CTX_CHARS: ctx = ctx[-MAX_CTX_CHARS+500:]

        if result.get("filename"):
            ops.append({"step":step["id"],"type":step.get("type"),"file":result["filename"],"status":result["status"],"ts":datetime.now().isoformat()})
            log.info(f"[AUDIT][Agent] task={task_id} user={user_id[:12]} step={step['id']} op={step.get('type')} file='{result['filename']}' status={result['status']}")

        yield _sse({"type":"agent_step_done","step_id":result["step_id"],"status":result["status"],
                    "output":result.get("output","")[:300],"filename":result.get("filename",""),
                    "retried": result.get("_retried",False)})
        increment_agent_ops(user_id)
        await asyncio.sleep(0.05)

    elapsed = round(time.time()-t0, 1)
    try: files = list_files(user_id)
    except Exception: files = []

    summary = f"✅ اكتملت ({elapsed}s) | ملفات: {len(ops)}\n"
    summary += "\n".join(f"  {'✅' if o['status']=='done' else '❌'} {o['file']} ({o['type']})" for o in ops)
    summary += f"\n📂 إجمالي: {len(files)}"

    yield _sse({"type":"agent_done","task_id":task_id,"summary":summary,
                "files":[f["path"] for f in files],"ops_count":len(ops),"elapsed_s":elapsed})

    try:
        with get_db() as db:
            t = db.query(AgentTask).filter_by(id=task_id).first()
            if t:
                t.status="done"; t.result=summary[:1000]
                t.file_ops=json.dumps(ops,ensure_ascii=False)
                t.steps_done=len(steps); t.elapsed_s=elapsed
                t.updated_at=datetime.now().isoformat()
    except Exception: pass

    log.info(f"[AUDIT][Agent] task={task_id} user={user_id[:12]} goal='{goal[:50]}' steps={len(steps)} files={len(ops)} elapsed={elapsed}s")


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
