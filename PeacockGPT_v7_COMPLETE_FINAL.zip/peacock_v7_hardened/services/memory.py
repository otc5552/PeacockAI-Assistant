"""
services/memory.py — Hyper Memory System v7 ULTIMATE
أقوى نظام ذاكرة ممكن بدون external ML libraries
3 أنواع ذاكرة: Facts + Episodes + Vectors
Author: PeacockAI – Mostafa
"""
import re, math, json, hashlib, secrets, time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from core.config import FLAGS, log
from core.database import get_db, UserMemory, MemoryEpisode, MemoryVector

# ══════════════════════════════════════════════════════════════════
# IMPORTANCE SCORES
# ══════════════════════════════════════════════════════════════════
class Imp:
    CRITICAL = 1.00  # الاسم، المهنة — لا تُمسح أبداً
    HIGH     = 0.85  # المجال، المستوى، اللغة
    MEDIUM   = 0.60  # الاهتمامات، الأهداف، الأدوات
    LOW      = 0.35  # ذكريات عابرة
    SESSION  = 1.00  # تُحدَّث دائماً


# ══════════════════════════════════════════════════════════════════
# EMBEDDING ENGINE (بدون أي library خارجية)
# ══════════════════════════════════════════════════════════════════

def _embed(text: str, dims: int = 256) -> List[float]:
    """
    Deterministic semantic embedding.
    Character n-grams + word hashing → L2-normalized vector.
    """
    if not text: return []
    text = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text.lower()).strip()
    if not text: return []

    vec = [0.0] * dims

    # Word-level features
    words = text.split()
    for w in words:
        if len(w) < 2: continue
        # Two hash functions reduce collisions
        i1 = int(hashlib.md5(w.encode()).hexdigest(), 16) % dims
        i2 = int(hashlib.sha1(w.encode()).hexdigest(), 16) % dims
        vec[i1] += 1.0
        vec[i2] += 0.6

    # Bigram features (captures phrases)
    for i in range(len(words) - 1):
        bigram = f"{words[i]}_{words[i+1]}"
        ib = int(hashlib.md5(bigram.encode()).hexdigest(), 16) % dims
        vec[ib] += 1.5

    # Character trigrams (handles typos + Arabic morphology)
    for i in range(len(text) - 2):
        trig = text[i:i+3]
        it   = int(hashlib.md5(trig.encode()).hexdigest(), 16) % dims
        vec[it] += 0.3

    # L2 normalize
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [round(v/norm, 5) for v in vec]


def _cosine(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b): return 0.0
    return sum(x*y for x, y in zip(a, b))


def _embed_store(text: str) -> str:
    """Embed and return as JSON string for DB storage."""
    return json.dumps(_embed(text))


def _embed_load(s: str) -> List[float]:
    """Load embedding from JSON string."""
    try: return json.loads(s)
    except: return []


# ══════════════════════════════════════════════════════════════════
# LAYER 1: FACT MEMORY  (key→value, persistent)
# ══════════════════════════════════════════════════════════════════

def mem_get(user_id: str, scope: str) -> Dict[str, str]:
    if not user_id or user_id == "guest": return {}
    try:
        with get_db() as db:
            rows = db.query(UserMemory).filter_by(
                user_id=user_id, scope=scope
            ).order_by(UserMemory.confidence.desc()).all()
        return {r.key: r.value for r in rows}
    except Exception as e:
        log.warning(f"[Mem] get: {e}"); return {}


def mem_get_all(user_id: str) -> Dict:
    return {
        "short":   mem_get(user_id, "short"),
        "session": mem_get(user_id, "session"),
        "long":    mem_get(user_id, "long"),
    }


def mem_set(user_id: str, scope: str, key: str,
            value: str, confidence: float = 1.0):
    if not user_id or user_id == "guest": return
    mid = f"{user_id}:{scope}:{key}"
    now = datetime.now().isoformat()
    try:
        with get_db() as db:
            ex = db.query(UserMemory).filter_by(id=mid).first()
            if ex:
                if confidence >= (ex.confidence or 0):
                    ex.value      = str(value)[:500]
                    ex.confidence = confidence
                    ex.updated_at = now
            else:
                db.add(UserMemory(
                    id=mid, user_id=user_id, scope=scope,
                    key=key, value=str(value)[:500],
                    confidence=confidence, updated_at=now
                ))
    except Exception as e:
        log.warning(f"[Mem] set: {e}")


def mem_delete(user_id: str, scope: Optional[str] = None,
               key: Optional[str] = None):
    try:
        with get_db() as db:
            q = db.query(UserMemory).filter_by(user_id=user_id)
            if scope: q = q.filter_by(scope=scope)
            if key:   q = q.filter_by(key=key)
            q.delete()
    except Exception as e:
        log.warning(f"[Mem] delete: {e}")


# ══════════════════════════════════════════════════════════════════
# LAYER 2: EPISODIC MEMORY  (conversation summaries)
# ══════════════════════════════════════════════════════════════════

def save_episode(user_id: str, summary: str, topics: List[str],
                 importance: float = 0.5, turn_count: int = 0,
                 emotion: str = "neutral"):
    """Save a conversation episode to long-term memory."""
    try:
        eid = secrets.token_hex(16)
        with get_db() as db:
            db.add(MemoryEpisode(
                id         = eid,
                user_id    = user_id,
                summary    = summary[:1000],
                topics     = ",".join(topics[:10]),
                emotion    = emotion,
                importance = importance,
                turn_count = turn_count,
                created_at = datetime.now().isoformat(),
            ))
        # Also store as vector for semantic search
        _store_vector(user_id, summary, "episode", importance)
        log.debug(f"[Mem] Episode saved: {user_id[:12]} topics={topics[:3]}")
    except Exception as e:
        log.warning(f"[Mem] save_episode: {e}")


def get_episodes(user_id: str, limit: int = 10) -> List[dict]:
    """Get recent episodes sorted by importance."""
    try:
        with get_db() as db:
            rows = db.query(MemoryEpisode).filter_by(user_id=user_id)\
                     .order_by(MemoryEpisode.importance.desc(),
                               MemoryEpisode.created_at.desc())\
                     .limit(limit).all()
        return [{
            "summary":    r.summary,
            "topics":     r.topics.split(",") if r.topics else [],
            "importance": r.importance,
            "emotion":    r.emotion,
            "created_at": r.created_at,
        } for r in rows]
    except Exception as e:
        log.warning(f"[Mem] get_episodes: {e}"); return []


# ══════════════════════════════════════════════════════════════════
# LAYER 3: VECTOR MEMORY  (semantic search)
# ══════════════════════════════════════════════════════════════════

def _store_vector(user_id: str, content: str,
                  mem_type: str = "fact", importance: float = 0.5):
    """Store content as a searchable vector."""
    try:
        vid = secrets.token_hex(16)
        emb = _embed_store(content)
        with get_db() as db:
            db.add(MemoryVector(
                id           = vid,
                user_id      = user_id,
                content      = content[:500],
                embedding    = emb,
                mem_type     = mem_type,
                importance   = importance,
                access_count = 0,
                created_at   = datetime.now().isoformat(),
            ))
    except Exception as e:
        log.warning(f"[Mem] store_vector: {e}")


def semantic_search(user_id: str, query: str,
                    top_k: int = 5, min_score: float = 0.15) -> List[dict]:
    """
    Search memory semantically — returns most relevant memories.
    Used to retrieve context relevant to current message.
    """
    if not user_id or user_id == "guest": return []
    try:
        q_emb = _embed(query)
        if not q_emb: return []

        with get_db() as db:
            rows = db.query(MemoryVector).filter_by(user_id=user_id)\
                     .order_by(MemoryVector.importance.desc()).limit(200).all()

        scored = []
        for r in rows:
            r_emb = _embed_load(r.embedding)
            sim   = _cosine(q_emb, r_emb)
            if sim >= min_score:
                scored.append({
                    "content":    r.content,
                    "type":       r.mem_type,
                    "importance": r.importance,
                    "score":      round(sim, 3),
                })

        # Sort by combined score: similarity × importance
        scored.sort(key=lambda x: -(x["score"] * (1 + x["importance"])))

        # Update access count for top results
        if scored:
            try:
                with get_db() as db:
                    for item in scored[:top_k]:
                        rows_upd = db.query(MemoryVector).filter_by(
                            user_id=user_id, content=item["content"]
                        ).first()
                        if rows_upd:
                            rows_upd.access_count += 1
            except Exception: pass

        return scored[:top_k]
    except Exception as e:
        log.warning(f"[Mem] semantic_search: {e}"); return []


# ══════════════════════════════════════════════════════════════════
# EXTRACTION ENGINE  (message → structured facts)
# ══════════════════════════════════════════════════════════════════

_DOMAIN_MAP = {
    # Software
    "برمجة":"software","تطوير":"software","كود":"software","python":"software",
    "javascript":"software","typescript":"software","react":"software",
    "nodejs":"software","backend":"software","frontend":"software",
    "fullstack":"software","devops":"software","docker":"software",
    "git":"software","api":"software","database":"software",
    # AI/ML
    "ذكاء اصطناعي":"ai","ai":"ai","machine learning":"ai","deep learning":"ai",
    "llm":"ai","neural":"ai","gpt":"ai","transformer":"ai","تعلم آلة":"ai",
    # Medicine
    "طب":"medicine","دكتور":"medicine","مريض":"medicine","صيدلة":"medicine",
    "تشخيص":"medicine","علاج":"medicine",
    # Law
    "قانون":"law","محامي":"law","حقوق":"law","قضاء":"law","عقد":"law",
    # Finance
    "اقتصاد":"finance","مال":"finance","استثمار":"finance","بورصة":"finance",
    "تداول":"finance","بيتكوين":"crypto","crypto":"crypto",
    # Design
    "تصميم":"design","ui":"design","ux":"design","figma":"design",
    "photoshop":"design","canva":"design",
    # Education
    "تعليم":"education","دراسة":"education","جامعة":"education",
    "امتحان":"education","مدرسة":"education",
    # Business
    "بيزنس":"business","شركة":"business","تسويق":"business",
    "ريادة":"business","startup":"business","مشروع":"business",
    # Writing
    "كتابة":"writing","مقال":"writing","محتوى":"writing","رواية":"writing",
    "ترجمة":"translation",
}

_LEVEL_MAP = {
    "beginner": re.compile(
        r"مبتدئ|مش\s*فاهم|ازاي|ايه\s*معنى|لا\s*أعرف|مش\s*عارف|"
        r"للمبتدئين|أول\s*مرة|شرح\s*بسيط|من\s*الصفر|beginner|"
        r"i\s*don.t\s*know|step\s*by\s*step|how\s*to\s*start", re.I),
    "intermediate": re.compile(
        r"أفهم\s*الأساسيات|عندي\s*خبرة|intermediate|some\s*experience|"
        r"familiar\s*with|i\s*know\s*the\s*basics", re.I),
    "advanced": re.compile(
        r"architecture|trade.off|complexity|production|ci/cd|"
        r"distributed|microservices|scalable|concurrency|optimization|"
        r"benchmark|profiling|kubernetes|design\s*pattern|system\s*design|"
        r"متقدم|senior|expert|lead\s*dev|principal", re.I),
}

_NAME_RE   = re.compile(r"(?:اسمي|أنا|my\s+name\s+is|call\s+me)\s+([A-Za-z\u0600-\u06FF]{2,25})", re.I)
_ROLE_RE   = re.compile(r"(?:أنا|شغلتي|i\s+am|i\s+work\s+as)\s+(مطور|مهندس|دكتور|طبيب|محامي|مصمم|معلم|طالب|مدير|developer|engineer|doctor|lawyer|designer|student|teacher|manager|founder|ceo|cto)\b", re.I)
_AGE_RE    = re.compile(r"(?:عمري|عندي|i.m|i\s+am)\s+(\d{1,2})\s*(?:سنة|years?\s*old|سنه)", re.I)
_GOAL_RE   = re.compile(r"(?:هدفي|أريد|بدي|i\s+want\s+to|my\s+goal)\s+(.{10,80}?)(?:\.|،|$)", re.I)
_TOOL_RE   = re.compile(r"\b(vscode|vim|pycharm|android\s*studio|figma|notion|github|gitlab|postman|docker)\b", re.I)
_LANG_RE   = re.compile(r"\b(python|javascript|typescript|java|kotlin|swift|dart|go|rust|cpp|php|ruby)\b", re.I)
_LIKE_RE   = re.compile(r"(?:بحب|أحب|اهتمامي|i\s+love|i\s+like|interested\s+in)\s+([A-Za-z\u0600-\u06FF\s]{3,40}?)(?:\.|،|$)", re.I)
_EMOTION_RE = {
    "positive": re.compile(r"ممتاز|رائع|شكراً|مبسوط|سعيد|great|awesome|thanks|happy|love\s+it", re.I),
    "negative": re.compile(r"مش\s*تمام|صعب|مش\s*فاهم|زهقت|تعبت|frustrated|confused|difficult|hard", re.I),
}


def _detect_emotion(text: str) -> str:
    if _EMOTION_RE["positive"].search(text): return "positive"
    if _EMOTION_RE["negative"].search(text): return "negative"
    return "neutral"


def _score_importance(text: str) -> float:
    """Score how important this message is to remember (0-1)."""
    score = 0.3  # base
    if len(text) > 100: score += 0.1
    if len(text) > 300: score += 0.1
    # Contains personal info
    if _NAME_RE.search(text):  score += 0.3
    if _ROLE_RE.search(text):  score += 0.2
    if _GOAL_RE.search(text):  score += 0.2
    # Technical depth
    if _LANG_RE.search(text):  score += 0.1
    if _TOOL_RE.search(text):  score += 0.1
    return min(score, 1.0)


def extract_facts(message: str) -> List[dict]:
    """Extract all structured facts from a message."""
    low   = message.lower()
    facts = []

    # ── Domain (vote-based) ──────────────────────────────────────
    votes: Dict[str, float] = {}
    for kw, domain in _DOMAIN_MAP.items():
        if kw in low:
            votes[domain] = votes.get(domain, 0) + 1
    if votes:
        top   = max(votes, key=votes.get)  # type: ignore
        score = min(votes[top] * 0.2, Imp.HIGH)
        facts.append({"key":"domain","value":top,"scope":"long","conf":score})

    # ── Level ────────────────────────────────────────────────────
    for level, pat in _LEVEL_MAP.items():
        if pat.search(message):
            score = Imp.HIGH if level == "advanced" else Imp.MEDIUM
            facts.append({"key":"level","value":level,"scope":"long","conf":score})
            break

    # ── Name ────────────────────────────────────────────────────
    m = _NAME_RE.search(message)
    if m:
        name = m.group(1).strip()
        if 2 <= len(name) <= 25 and name.lower() not in {"ai","gpt","api","llm","app"}:
            facts.append({"key":"name","value":name,"scope":"long","conf":Imp.CRITICAL})

    # ── Role ────────────────────────────────────────────────────
    r = _ROLE_RE.search(message)
    if r:
        facts.append({"key":"role","value":r.group(1).lower(),"scope":"long","conf":Imp.HIGH})

    # ── Age ─────────────────────────────────────────────────────
    a = _AGE_RE.search(message)
    if a:
        age = int(a.group(1))
        if 10 <= age <= 80:
            facts.append({"key":"age","value":str(age),"scope":"long","conf":Imp.MEDIUM})

    # ── Goal ─────────────────────────────────────────────────────
    g = _GOAL_RE.search(message)
    if g:
        facts.append({"key":"goal","value":g.group(1).strip()[:100],"scope":"long","conf":Imp.MEDIUM})

    # ── Interests ────────────────────────────────────────────────
    likes = _LIKE_RE.findall(message)
    if likes:
        interest = likes[0].strip()[:60]
        facts.append({"key":"interest","value":interest,"scope":"long","conf":Imp.MEDIUM})

    # ── Tools / Languages ────────────────────────────────────────
    tools = list(set(t.lower() for t in _TOOL_RE.findall(message)))
    if tools:
        facts.append({"key":"tools","value":",".join(tools[:5]),"scope":"long","conf":Imp.MEDIUM})

    langs = list(set(l.lower() for l in _LANG_RE.findall(message)))
    if langs:
        facts.append({"key":"languages","value":",".join(langs[:5]),"scope":"long","conf":Imp.MEDIUM})

    # ── Language preference ───────────────────────────────────────
    eng = len(re.findall(r"\b[a-zA-Z]{4,}\b", message))
    ar  = len(re.findall(r"[\u0600-\u06FF]", message))
    if eng >= 6 and ar < 8:
        facts.append({"key":"lang_pref","value":"english","scope":"long","conf":Imp.LOW})
    elif eng >= 3 and ar > 10:
        facts.append({"key":"lang_pref","value":"bilingual","scope":"long","conf":Imp.LOW})

    # ── Session topic ─────────────────────────────────────────────
    if len(message) > 15:
        topic = message[:70].replace("\n"," ").strip()
        facts.append({"key":"last_topic","value":topic,"scope":"session","conf":Imp.SESSION})

    return facts


# ══════════════════════════════════════════════════════════════════
# MAIN PIPELINE: extract + store + vectorize
# ══════════════════════════════════════════════════════════════════

def extract_and_update(user_id: str, message: str, response: str = ""):
    """
    Full memory pipeline after each turn.
    1. Extract facts → store in UserMemory
    2. Store message as vector for semantic search
    3. Track message count
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest": return
    try:
        # Extract + store facts
        facts = extract_facts(message)
        for f in facts:
            mem_set(user_id, f["scope"], f["key"], f["value"], f["conf"])

        # Store message as searchable vector
        importance = _score_importance(message)
        if importance > 0.3:
            combined = f"{message[:300]}"
            if response: combined += f" | {response[:200]}"
            _store_vector(user_id, combined, "fact", importance)

        # Count messages
        long  = mem_get(user_id, "long")
        count = int(long.get("msg_count", 0)) + 1
        mem_set(user_id, "long", "msg_count", str(count), Imp.LOW)

        if facts:
            log.debug(f"[Mem] +{len(facts)} facts, importance={importance:.2f} → {user_id[:12]}")
    except Exception as e:
        log.warning(f"[Mem] extract_and_update: {e}")


def save_conversation_episode(user_id: str, messages: list):
    """
    Create an episodic memory from a conversation.
    Called after enough turns (every 10 messages).
    """
    if not user_id or not messages: return
    try:
        user_msgs = [m["content"] for m in messages if m.get("role") == "user"]
        ai_msgs   = [m["content"] for m in messages if m.get("role") == "assistant"]
        if len(user_msgs) < 3: return

        # Extract topics from user messages
        combined = " ".join(user_msgs).lower()
        topics   = []
        for kw, domain in _DOMAIN_MAP.items():
            if kw in combined and domain not in topics:
                topics.append(domain)
                if len(topics) >= 5: break

        # Build summary
        first_msg = user_msgs[0][:80]
        last_msg  = user_msgs[-1][:80]
        turn_cnt  = len(user_msgs)
        summary   = f"محادثة {turn_cnt} رسالة — بدأت بـ: {first_msg} | آخر موضوع: {last_msg}"

        # Score importance
        importance = min(0.3 + len(user_msgs) * 0.05, 0.9)

        # Detect overall emotion
        all_text = " ".join(user_msgs[-3:])
        emotion  = _detect_emotion(all_text)

        save_episode(user_id, summary, topics, importance, turn_cnt, emotion)

    except Exception as e:
        log.warning(f"[Mem] save_episode: {e}")


# ══════════════════════════════════════════════════════════════════
# USER PROFILE BUILDER
# ══════════════════════════════════════════════════════════════════

def build_user_profile(user_id: str) -> dict:
    """Build complete user profile from all memory layers."""
    long = mem_get(user_id, "long")
    return {
        "name":       long.get("name", ""),
        "role":       long.get("role", ""),
        "domain":     long.get("domain", "general"),
        "level":      long.get("level", "unknown"),
        "age":        long.get("age", ""),
        "goal":       long.get("goal", ""),
        "interest":   long.get("interest", ""),
        "tools":      long.get("tools", "").split(",") if long.get("tools") else [],
        "languages":  long.get("languages", "").split(",") if long.get("languages") else [],
        "lang_pref":  long.get("lang_pref", "arabic"),
        "msg_count":  int(long.get("msg_count", 0)),
    }


def get_adaptive_style(user_id: str) -> dict:
    """Return recommended response style based on user profile."""
    p = build_user_profile(user_id)
    style = {"depth":"normal","examples":True,"emoji":True,"formal":False,"code_pref":False}
    if p["level"] == "beginner":
        style.update({"depth":"normal","examples":True,"emoji":True})
    elif p["level"] == "advanced":
        style.update({"depth":"deep","examples":False,"emoji":False,"formal":True,"code_pref":True})
    if p["domain"] in ("software","ai"): style["code_pref"] = True
    if p["domain"] == "law":            style.update({"formal":True,"emoji":False})
    if p["msg_count"] > 50:            style["examples"] = False
    return style


# ══════════════════════════════════════════════════════════════════
# CONTEXT BUILDER  (الجزء المهم — يُدمج في كل prompt)
# ══════════════════════════════════════════════════════════════════

def build_memory_context(user_id: str, query: str = "") -> str:
    """
    Build the richest possible context string for the AI prompt.
    Combines: profile facts + semantic search + recent episodes.
    """
    if not FLAGS.get("user_memory") or not user_id or user_id == "guest": return ""
    try:
        parts = []
        long    = mem_get(user_id, "long")
        session = mem_get(user_id, "session")

        # ── Profile summary ──────────────────────────────────────
        if long:
            items = []
            ORDER = [
                ("name","اسمه"), ("role","مهنته"), ("domain","مجاله"),
                ("level","مستواه"), ("age","عمره"), ("goal","هدفه"),
                ("interest","اهتمامه"), ("languages","يبرمج بـ"),
                ("tools","يستخدم"), ("lang_pref","يفضل"),
            ]
            for k, label in ORDER:
                if k in long and long[k]:
                    val = long[k]
                    if k == "level":
                        val = {"beginner":"مبتدئ 🟢","intermediate":"متوسط 🟡","advanced":"متقدم 🔴"}.get(val, val)
                    items.append(f"{label}: {val}")
            if items:
                parts.append("👤 " + " | ".join(items))

        # ── Semantic memory search ────────────────────────────────
        if query:
            hits = semantic_search(user_id, query, top_k=4, min_score=0.18)
            relevant = [
                h["content"][:100]
                for h in hits
                if h["type"] in ("fact","episode")
            ]
            if relevant:
                parts.append("🧠 ذاكرة ذات صلة: " + " | ".join(relevant[:3]))

        # ── Recent episodes ───────────────────────────────────────
        episodes = get_episodes(user_id, limit=2)
        if episodes:
            ep_parts = [ep["summary"][:80] for ep in episodes[:2]]
            if ep_parts:
                parts.append("📖 محادثات سابقة: " + " | ".join(ep_parts))

        # ── Session context ───────────────────────────────────────
        if session:
            s = [f"{k}: {v}" for k, v in session.items() if k not in ("last_topic",)]
            if s: parts.append("📍 " + " | ".join(s))

        return "\n".join(parts)
    except Exception as e:
        log.warning(f"[Mem] build_context: {e}"); return ""
