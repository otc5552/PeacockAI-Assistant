# 📱 خطوات بناء APK — بالترتيب الدقيق

## الخطوة 1 — تحميل Android Studio (مرة واحدة بس)

1. اذهب لـ: **developer.android.com/studio**
2. حمّل النسخة المناسبة لجهازك (Windows / Mac)
3. ثبّته — هيأخذ 10-15 دقيقة
4. افتحه وخلّيه يكمّل الـ setup الأول تلقائياً

---

## الخطوة 2 — افتح المشروع

1. في Android Studio: **File → Open**
2. اختر مجلد: `peacock_capacitor/android/`
3. انتظر **Gradle Sync** ينتهي (2-5 دقائق أول مرة)

---

## الخطوة 3 — غيّر سطر واحد

افتح الملف:
```
app/src/main/java/com/peacockai/chatgpt/MainActivity.java
```

السطر رقم ~30:
```java
private static final String API_BASE = "http://YOUR_SERVER_IP:8000";
```

**بدّله لـ:**
```java
// لو Backend على لابتوبك ونفس الـ WiFi:
private static final String API_BASE = "http://192.168.1.XX:8000";

// لو نشرت على Railway:
private static final String API_BASE = "https://xxx.railway.app";
```

---

## الخطوة 4 — ابنِ APK

```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

⏳ انتظر 2-3 دقائق

✅ APK جاهز في:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## الخطوة 5 — ثبّت على تليفونك

**طريقة 1 (USB):**
```
adb install app-debug.apk
```

**طريقة 2 (يدوي):**
1. انقل APK للتليفون (USB أو Drive)
2. افتحه
3. لو طلب: Settings → Install Unknown Apps → سمح

---

## ⚠️ ملاحظات مهمة

- **Backend لازم يكون شغّال** قبل تفتح التطبيق
- للتطوير: شغّل `uvicorn main:app --host 0.0.0.0 --port 8000` على لابتوبك
- التليفون يكون على **نفس الـ WiFi** زي اللابتوب

---

## 🔑 API Keys في التطبيق

المستخدمين يضيفوا المفاتيح من داخل التطبيق:
- **Settings ⚙️ → Groq Key**: groq.com (مجاني)
- **Settings ⚙️ → Gemini Key**: aistudio.google.com (مجاني)

---

## وقت التنفيذ المتوقع
- تحميل Android Studio: 15 دقيقة
- فتح المشروع + Gradle: 5 دقائق
- تغيير الـ URL: دقيقة
- Build: 3 دقائق
- **إجمالي: ~25 دقيقة**
