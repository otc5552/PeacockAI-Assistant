#!/usr/bin/env python3
"""
setup.py — One-time setup script for PeacockAI Backend
Run: python setup.py
"""

import os
import sys
import subprocess


def print_banner():
    print("""
╔═══════════════════════════════════════╗
║      🦚  PeacockAI Backend Setup      ║
╚═══════════════════════════════════════╝
""")


def check_python():
    version = sys.version_info
    if version < (3, 11):
        print(f"❌ Python 3.11+ required. You have {version.major}.{version.minor}")
        sys.exit(1)
    print(f"✅ Python {version.major}.{version.minor}.{version.micro}")


def install_deps():
    print("\n📦 Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "-q"])
    print("✅ Dependencies installed")


def create_env():
    if os.path.exists(".env"):
        print("ℹ️  .env already exists — skipping")
        return

    groq_key    = input("\n🔑 Enter your GROQ API key (groq.com): ").strip()
    gemini_key  = input("🔑 Enter your GEMINI API key (aistudio.google.com): ").strip()
    dev_mode    = input("🛠️  Enable DEV_MODE? (skip Firebase auth) [y/N]: ").strip().lower() == 'y'

    env_content = f"""# PeacockAI Backend Environment
GROQ_API_KEY={groq_key}
GEMINI_API_KEY={gemini_key}
COHERE_API_KEY=
FIREBASE_CREDENTIALS_PATH=firebase-credentials.json
DEV_MODE={'true' if dev_mode else 'false'}
SECRET_KEY=peacockai-secret-{os.urandom(8).hex()}
DB_PATH=peacockai.db
"""
    with open(".env", "w") as f:
        f.write(env_content)
    print("✅ .env file created")


def check_firebase():
    if os.path.exists("firebase-credentials.json"):
        print("✅ firebase-credentials.json found")
    else:
        print("""
⚠️  firebase-credentials.json not found!

To get it:
1. Go to https://console.firebase.google.com
2. Select your project → Project Settings
3. Service Accounts → Generate New Private Key
4. Save the file as: backend/firebase-credentials.json
""")


def init_database():
    print("\n🗄️  Initializing database...")
    import asyncio
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from database import init_db
    asyncio.run(init_db())
    print("✅ Database initialized (peacockai.db)")


def print_success():
    print("""
╔═══════════════════════════════════════╗
║         ✅  Setup Complete!           ║
╠═══════════════════════════════════════╣
║                                       ║
║  Start server:                        ║
║  uvicorn main:app --reload            ║
║                                       ║
║  API Docs:                            ║
║  http://localhost:8000/docs           ║
║                                       ║
╚═══════════════════════════════════════╝
""")


if __name__ == "__main__":
    print_banner()
    check_python()
    install_deps()
    create_env()
    check_firebase()
    init_database()
    print_success()
