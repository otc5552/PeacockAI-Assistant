"""
Auth & Users API Routers
"""

from fastapi import APIRouter, Depends, HTTPException
from middleware.auth_middleware import get_current_user
from database import get_user_usage, update_user_usage, init_db
import aiosqlite

# ──────────────────────────────
# Auth Router
# ──────────────────────────────
router = APIRouter()

@router.post("/verify")
async def verify_token(current_user: dict = Depends(get_current_user)):
    """التحقق من صحة رمز Firebase"""
    return {"valid": True, "user": current_user}


@router.post("/register")
async def register_user(current_user: dict = Depends(get_current_user)):
    """تسجيل مستخدم جديد أو تحديث بياناته"""
    uid = current_user["uid"]
    async with aiosqlite.connect("peacockai.db") as db:
        await db.execute(
            """INSERT OR IGNORE INTO users (uid, email, display_name)
               VALUES (?, ?, ?)""",
            (uid, current_user.get("email", ""), current_user.get("name", ""))
        )
        await db.commit()
    return {"success": True, "uid": uid}
