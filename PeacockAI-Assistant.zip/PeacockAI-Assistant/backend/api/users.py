"""
Users API Router
"""
from fastapi import APIRouter, Depends, HTTPException
from middleware.auth_middleware import get_current_user
from database import get_user_usage
import aiosqlite

router = APIRouter()

@router.get("/{user_id}")
async def get_user(user_id: str, current_user: dict = Depends(get_current_user)):
    if current_user["uid"] != user_id:
        raise HTTPException(status_code=403, detail="غير مسموح")
    profile = await get_user_usage(user_id)
    if not profile:
        return {
            "uid": user_id,
            "email": current_user.get("email", ""),
            "plan": "free",
            "messages_used": 0,
            "messages_limit": 100,
        }
    return profile


@router.patch("/{user_id}/plan")
async def upgrade_plan(
    user_id: str,
    plan: str,
    current_user: dict = Depends(get_current_user)
):
    """ترقية الخطة (تُستدعى من نظام الدفع)"""
    limits = {"free": 100, "pro": 5000, "enterprise": 999999}
    new_limit = limits.get(plan, 100)
    async with aiosqlite.connect("peacockai.db") as db:
        await db.execute(
            "UPDATE users SET plan=?, messages_limit=? WHERE uid=?",
            (plan, new_limit, user_id)
        )
        await db.commit()
    return {"success": True, "plan": plan, "limit": new_limit}
