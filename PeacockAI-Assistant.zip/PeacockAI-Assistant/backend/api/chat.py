"""
Chat API - نقطة النهاية الرئيسية للمحادثة
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import StreamingResponse
import json
import base64

from models.request_models import ChatRequest, ChatResponse
from router.ai_router import ai_router
from middleware.auth_middleware import get_current_user
from database import get_db, save_message, get_session_history, update_user_usage


router = APIRouter()


@router.post("/message", response_model=ChatResponse)
async def send_message(
    request: ChatRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    الإرسال الرئيسي للرسائل
    يحلل النية ويوجه للخدمة المناسبة
    """
    try:
        # التحقق من حد الرسائل
        await check_rate_limit(current_user["uid"])

        # توجيه الطلب
        response = await ai_router.route(request)

        # حفظ في قاعدة البيانات
        await save_message(
            session_id=request.session_id,
            user_id=current_user["uid"],
            user_message=request.message,
            assistant_message=response.message,
            intent=response.intent,
        )

        # تحديث الاستهلاك
        await update_user_usage(current_user["uid"])

        return response

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/message/with-file")
async def send_message_with_file(
    message: str = Form(...),
    session_id: str = Form(...),
    user_id: str = Form(...),
    tool_hint: str = Form(None),
    file: UploadFile = File(None),
    current_user: dict = Depends(get_current_user)
):
    """إرسال رسالة مع ملف مرفق"""
    file_data = None
    file_name = None

    if file:
        content = await file.read()
        file_data = base64.b64encode(content).decode()
        file_name = file.filename

        # إذا كان نصياً، أرسله مباشرة
        if file.content_type in ["text/plain", "text/csv"]:
            file_data = content.decode("utf-8", errors="ignore")

    request = ChatRequest(
        message=message,
        session_id=session_id,
        user_id=user_id,
        tool_hint=tool_hint,
        file_data=file_data,
        file_name=file_name,
    )

    response = await ai_router.route(request)
    return response


@router.get("/sessions/{user_id}")
async def get_user_sessions(
    user_id: str,
    current_user: dict = Depends(get_current_user)
):
    """جلب سجل محادثات المستخدم"""
    sessions = await get_session_history(user_id)
    return {"sessions": sessions}


@router.delete("/sessions/{session_id}")
async def delete_session(
    session_id: str,
    current_user: dict = Depends(get_current_user)
):
    """حذف محادثة"""
    from database import delete_session as db_delete
    await db_delete(session_id, current_user["uid"])
    return {"success": True}


async def check_rate_limit(user_id: str):
    """التحقق من حد الاستخدام"""
    from database import get_user_usage
    usage = await get_user_usage(user_id)
    if usage and usage.get("messages_used", 0) >= usage.get("messages_limit", 100):
        raise HTTPException(
            status_code=429,
            detail="لقد وصلت إلى الحد الأقصى من الرسائل. يرجى الترقية."
        )
