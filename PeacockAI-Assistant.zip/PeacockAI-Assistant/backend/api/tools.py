"""
Tools API - نقاط النهاية المباشرة للأدوات
"""
from fastapi import APIRouter, Depends, HTTPException
from middleware.auth_middleware import get_current_user
from models.request_models import ImageGenRequest
import urllib.parse

router = APIRouter()


@router.post("/image/generate")
async def generate_image(
    req: ImageGenRequest,
    current_user: dict = Depends(get_current_user)
):
    """توليد صورة مباشرة عبر Pollinations AI"""
    prompt = f"{req.prompt}, {req.style} style"
    encoded = urllib.parse.quote(prompt)
    url = f"https://image.pollinations.ai/prompt/{encoded}?width={req.width}&height={req.height}&nologo=true"
    return {
        "image_url": url,
        "prompt": prompt,
        "width": req.width,
        "height": req.height,
    }


@router.get("/list")
async def list_tools(current_user: dict = Depends(get_current_user)):
    """قائمة الأدوات المتاحة"""
    return {
        "tools": [
            {"id": "image_gen",     "name": "إنشاء صورة",   "available": True},
            {"id": "app_build",     "name": "إنشاء تطبيق",  "available": True},
            {"id": "web_build",     "name": "إنشاء موقع",   "available": True},
            {"id": "file_analyze",  "name": "تحليل ملف",    "available": True},
            {"id": "web_search",    "name": "بحث إنترنت",   "available": True},
            {"id": "image_analyze", "name": "تحليل صورة",   "available": True},
            {"id": "writing",       "name": "كتابة مقال",   "available": True},
            {"id": "math",          "name": "حل رياضيات",   "available": True},
        ]
    }
