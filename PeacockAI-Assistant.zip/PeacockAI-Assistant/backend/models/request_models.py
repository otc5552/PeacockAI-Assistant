"""
نماذج البيانات - Request & Response Models
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Any
from enum import Enum


class MessageRole(str, Enum):
    USER      = "user"
    ASSISTANT = "assistant"
    SYSTEM    = "system"


class HistoryMessage(BaseModel):
    role: MessageRole
    content: str
    timestamp: Optional[str] = None


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10000)
    session_id: str
    user_id: str
    tool_hint: Optional[str] = None        # أداة اختارها المستخدم يدوياً
    file_data: Optional[str] = None        # base64
    image_data: Optional[str] = None       # base64
    file_name: Optional[str] = None
    history: List[HistoryMessage] = []

    class Config:
        json_schema_extra = {
            "example": {
                "message": "اكتب كود Python لحساب مضروب عدد",
                "session_id": "sess_abc123",
                "user_id": "uid_xyz",
                "tool_hint": None,
                "history": []
            }
        }


class ChatResponse(BaseModel):
    message: str
    intent: str
    confidence: float
    data: Optional[Any] = None            # بيانات إضافية (صورة، كود، ...)
    session_id: str
    tokens_used: Optional[int] = None
    error: Optional[str] = None


class ServiceResponse(BaseModel):
    text: str
    data: Optional[Any] = None


# ─────────────────────────────────
# Tool-specific models
# ─────────────────────────────────

class ImageGenRequest(BaseModel):
    prompt: str
    style: Optional[str] = "realistic"
    width: int = 512
    height: int = 512


class FileAnalyzeRequest(BaseModel):
    file_data: str      # base64
    file_name: str
    question: Optional[str] = "لخص هذا الملف"


class UserProfile(BaseModel):
    uid: str
    email: str
    display_name: Optional[str] = None
    photo_url: Optional[str] = None
    plan: str = "free"
    messages_used: int = 0
    messages_limit: int = 100


class SessionData(BaseModel):
    session_id: str
    user_id: str
    title: str = "محادثة جديدة"
    created_at: str
    updated_at: str
    message_count: int = 0
