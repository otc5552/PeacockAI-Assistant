"""
config.py — Centralized configuration using environment variables
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    # ── AI APIs ──────────────────────────────────
    GROQ_API_KEY:    str = os.getenv("GROQ_API_KEY", "")
    GEMINI_API_KEY:  str = os.getenv("GEMINI_API_KEY", "")
    COHERE_API_KEY:  str = os.getenv("COHERE_API_KEY", "")

    # ── Firebase ──────────────────────────────────
    FIREBASE_CREDENTIALS_PATH: str = os.getenv(
        "FIREBASE_CREDENTIALS_PATH", "firebase-credentials.json"
    )

    # ── App ──────────────────────────────────────
    DEV_MODE:   bool = os.getenv("DEV_MODE", "false").lower() == "true"
    SECRET_KEY: str  = os.getenv("SECRET_KEY", "dev-secret-change-in-production")
    DB_PATH:    str  = os.getenv("DB_PATH", "peacockai.db")

    # ── Limits ───────────────────────────────────
    FREE_PLAN_LIMIT:       int = 100
    PRO_PLAN_LIMIT:        int = 5000
    ENTERPRISE_PLAN_LIMIT: int = 999_999
    MAX_HISTORY_MESSAGES:  int = 12
    MAX_FILE_SIZE_MB:      int = 10

    # ── Models ───────────────────────────────────
    GROQ_DEFAULT_MODEL:   str = "llama-3.3-70b-versatile"
    GEMINI_DEFAULT_MODEL: str = "gemini-2.0-flash"

    def validate(self):
        warnings = []
        if not self.GROQ_API_KEY:
            warnings.append("⚠️  GROQ_API_KEY not set — AI chat will fail")
        if not self.GEMINI_API_KEY:
            warnings.append("⚠️  GEMINI_API_KEY not set — file analysis will fail")
        if self.DEV_MODE:
            warnings.append("⚠️  DEV_MODE=true — Firebase auth is bypassed")
        for w in warnings:
            print(w)


settings = Settings()
