"""
Database Layer - SQLite مع aiosqlite
"""

import aiosqlite
import uuid
from datetime import datetime
from typing import Optional, List

DB_PATH = "peacockai.db"


async def init_db():
    """إنشاء الجداول عند التشغيل"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                uid TEXT PRIMARY KEY,
                email TEXT NOT NULL,
                display_name TEXT,
                photo_url TEXT,
                plan TEXT DEFAULT 'free',
                messages_used INTEGER DEFAULT 0,
                messages_limit INTEGER DEFAULT 100,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT DEFAULT 'محادثة جديدة',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(uid)
            );

            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                intent TEXT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            );
        """)
        await db.commit()
    print("✅ Database initialized")


async def save_message(session_id: str, user_id: str, user_message: str,
                       assistant_message: str, intent: str = "general"):
    async with aiosqlite.connect(DB_PATH) as db:
        # تأكد أن الجلسة موجودة
        await db.execute(
            "INSERT OR IGNORE INTO sessions (session_id, user_id) VALUES (?, ?)",
            (session_id, user_id)
        )
        # احفظ رسالة المستخدم
        await db.execute(
            "INSERT INTO messages (session_id, user_id, role, content, intent) VALUES (?, ?, 'user', ?, ?)",
            (session_id, user_id, user_message, intent)
        )
        # احفظ رسالة المساعد
        await db.execute(
            "INSERT INTO messages (session_id, user_id, role, content, intent) VALUES (?, ?, 'assistant', ?, ?)",
            (session_id, user_id, assistant_message, intent)
        )
        # حدّث وقت الجلسة
        await db.execute(
            "UPDATE sessions SET updated_at=?, title=? WHERE session_id=?",
            (datetime.now().isoformat(), user_message[:50], session_id)
        )
        await db.commit()


async def get_session_history(user_id: str) -> List[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM sessions WHERE user_id=? ORDER BY updated_at DESC LIMIT 50",
            (user_id,)
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]


async def get_session_messages(session_id: str) -> List[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT role, content, intent, timestamp FROM messages WHERE session_id=? ORDER BY id ASC",
            (session_id,)
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]


async def get_user_usage(user_id: str) -> Optional[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE uid=?", (user_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def update_user_usage(user_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (uid, email) VALUES (?, '')", (user_id,)
        )
        await db.execute(
            "UPDATE users SET messages_used = messages_used + 1 WHERE uid=?", (user_id,)
        )
        await db.commit()


async def delete_session(session_id: str, user_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM sessions WHERE session_id=? AND user_id=?", (session_id, user_id)
        )
        await db.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
        await db.commit()


async def get_db():
    """Dependency للاستخدام مع FastAPI"""
    async with aiosqlite.connect(DB_PATH) as db:
        yield db
