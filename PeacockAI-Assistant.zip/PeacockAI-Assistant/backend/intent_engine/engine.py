"""
Intent Engine - تحليل نية المستخدم وتوجيه الطلب للنموذج المناسب
"""

import re
from enum import Enum
from dataclasses import dataclass
from typing import Optional


class Intent(str, Enum):
    CODING       = "coding"
    IMAGE_GEN    = "image_generation"
    WEB_SEARCH   = "web_search"
    FILE_ANALYZE = "file_analysis"
    IMAGE_ANALYZE= "image_analysis"
    MATH         = "math"
    WRITING      = "writing"
    APP_BUILD    = "app_build"
    WEB_BUILD    = "web_build"
    GENERAL      = "general"


@dataclass
class IntentResult:
    intent: Intent
    confidence: float
    extracted_prompt: str
    metadata: dict


# ──────────────────────────────────────────────
# Keyword Maps
# ──────────────────────────────────────────────

INTENT_PATTERNS = {
    Intent.CODING: [
        r"\b(code|كود|برمجة|اكتب|function|class|script|python|javascript|java|swift|kotlin|debug|خطأ برمجي|bug)\b",
    ],
    Intent.IMAGE_GEN: [
        r"\b(صورة|ارسم|generate image|create image|image of|صمم صورة|توليد صورة|انشئ صورة)\b",
    ],
    Intent.WEB_SEARCH: [
        r"\b(ابحث|search|اخبار|news|latest|حدث اليوم|ما هو آخر|google|find online)\b",
    ],
    Intent.FILE_ANALYZE: [
        r"\b(ملف|file|pdf|document|analyze file|حلل الملف|قرأ هذا الملف|xlsx|csv|docx)\b",
    ],
    Intent.IMAGE_ANALYZE: [
        r"\b(حلل الصورة|analyze image|what is in|ماذا يوجد|describe image|ما هذه الصورة)\b",
    ],
    Intent.MATH: [
        r"\b(احسب|calculate|solve|معادلة|equation|integral|derivative|رياضيات|math|حل مسألة)\b",
    ],
    Intent.WRITING: [
        r"\b(اكتب مقال|write article|blog post|قصة|story|رسالة|letter|essay|محتوى|content)\b",
    ],
    Intent.APP_BUILD: [
        r"\b(انشئ تطبيق|build app|create app|تطبيق أندرويد|mobile app|react native)\b",
    ],
    Intent.WEB_BUILD: [
        r"\b(انشئ موقع|build website|create website|html|landing page|موقع ويب)\b",
    ],
}


class IntentEngine:
    """
    محرك تحليل نية المستخدم
    يستخدم أولاً تحليل القواعد، ثم يمكن تعزيزه بنموذج NLP
    """

    def analyze(
        self,
        message: str,
        has_file: bool = False,
        has_image: bool = False,
        tool_hint: Optional[str] = None,
    ) -> IntentResult:

        # إذا كان المستخدم اختار أداة يدوياً
        if tool_hint:
            return self._from_tool_hint(tool_hint, message)

        # تحليل المرفقات
        if has_file:
            return IntentResult(
                intent=Intent.FILE_ANALYZE,
                confidence=0.95,
                extracted_prompt=message,
                metadata={"source": "attachment"}
            )
        if has_image:
            return IntentResult(
                intent=Intent.IMAGE_ANALYZE,
                confidence=0.95,
                extracted_prompt=message,
                metadata={"source": "attachment"}
            )

        # تحليل الكلمات المفتاحية
        scores = {}
        lower = message.lower()

        for intent, patterns in INTENT_PATTERNS.items():
            score = 0
            for pattern in patterns:
                matches = re.findall(pattern, lower, re.IGNORECASE | re.UNICODE)
                score += len(matches)
            if score > 0:
                scores[intent] = score

        if scores:
            best_intent = max(scores, key=scores.get)
            total = sum(scores.values())
            confidence = scores[best_intent] / total
            return IntentResult(
                intent=best_intent,
                confidence=min(confidence + 0.4, 0.95),
                extracted_prompt=message,
                metadata={"scores": {k.value: v for k, v in scores.items()}}
            )

        # افتراضي: استجابة عامة
        return IntentResult(
            intent=Intent.GENERAL,
            confidence=0.5,
            extracted_prompt=message,
            metadata={}
        )

    def _from_tool_hint(self, tool: str, message: str) -> IntentResult:
        mapping = {
            "image_gen":     Intent.IMAGE_GEN,
            "app_build":     Intent.APP_BUILD,
            "web_build":     Intent.WEB_BUILD,
            "file_analyze":  Intent.FILE_ANALYZE,
            "web_search":    Intent.WEB_SEARCH,
            "image_analyze": Intent.IMAGE_ANALYZE,
            "writing":       Intent.WRITING,
            "math":          Intent.MATH,
        }
        intent = mapping.get(tool, Intent.GENERAL)
        return IntentResult(
            intent=intent,
            confidence=1.0,
            extracted_prompt=message,
            metadata={"source": "tool_hint"}
        )


# Singleton
intent_engine = IntentEngine()
