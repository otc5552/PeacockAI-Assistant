"""
Firebase Auth Middleware - التحقق من رمز Firebase
"""

import os
from fastapi import HTTPException, Header
from typing import Optional
import firebase_admin
from firebase_admin import credentials, auth

# تهيئة Firebase Admin (مرة واحدة)
_firebase_initialized = False

def init_firebase():
    global _firebase_initialized
    if not _firebase_initialized:
        cred_path = os.getenv("FIREBASE_CREDENTIALS_PATH", "firebase-credentials.json")
        try:
            cred = credentials.Certificate(cred_path)
            firebase_admin.initialize_app(cred)
            _firebase_initialized = True
        except Exception as e:
            print(f"⚠️ Firebase init failed: {e}. Running in dev mode.")
            _firebase_initialized = True


async def get_current_user(authorization: Optional[str] = Header(None)) -> dict:
    """استخراج المستخدم من رمز Firebase"""
    init_firebase()

    if not authorization or not authorization.startswith("Bearer "):
        # وضع التطوير - مستخدم افتراضي
        if os.getenv("DEV_MODE", "false") == "true":
            return {"uid": "dev_user", "email": "dev@peacockai.com"}
        raise HTTPException(status_code=401, detail="رمز المصادقة مطلوب")

    token = authorization.split(" ")[1]

    try:
        decoded = auth.verify_id_token(token)
        return {
            "uid":   decoded["uid"],
            "email": decoded.get("email", ""),
            "name":  decoded.get("name", ""),
        }
    except Exception:
        raise HTTPException(status_code=401, detail="رمز المصادقة غير صالح")


async def verify_firebase_token(token: str) -> dict:
    """التحقق من رمز Firebase مباشرة"""
    return await get_current_user(authorization=f"Bearer {token}")
