"""
PeacockAI Assistant - Backend Server
FastAPI + AI Router + Intent Engine
"""

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn

from api.chat import router as chat_router
from api.auth import router as auth_router
from api.tools import router as tools_router
from api.users import router as users_router
from middleware.auth_middleware import verify_firebase_token
from database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize services on startup"""
    await init_db()
    print("✅ PeacockAI Backend Ready")
    yield
    print("🔴 Shutting down...")


app = FastAPI(
    title="PeacockAI Assistant API",
    description="Multi-tool AI Assistant Backend",
    version="1.0.0",
    lifespan=lifespan
)

# CORS for Android client
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(auth_router,   prefix="/api/auth",  tags=["Authentication"])
app.include_router(chat_router,   prefix="/api/chat",  tags=["Chat"])
app.include_router(tools_router,  prefix="/api/tools", tags=["Tools"])
app.include_router(users_router,  prefix="/api/users", tags=["Users"])


@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "PeacockAI Backend"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
