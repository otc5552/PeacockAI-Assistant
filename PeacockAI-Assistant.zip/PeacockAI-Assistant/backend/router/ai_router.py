"""
AI Router - توجيه الطلبات إلى النماذج المناسبة
"""

from intent_engine.engine import intent_engine, Intent, IntentResult
from services.base_service import BaseAIService
from services.coding_service import CodingService
from services.image_gen_service import ImageGenService
from services.search_service import WebSearchService
from services.file_service import FileAnalyzerService
from services.writing_service import WritingService
from services.math_service import MathService
from services.general_service import GeneralService
from models.request_models import ChatRequest, ChatResponse


class AIRouter:
    """
    الموجه الذكي - يحلل النية ويوجه لأنسب خدمة
    """

    def __init__(self):
        self.services: dict[Intent, BaseAIService] = {
            Intent.CODING:        CodingService(),
            Intent.APP_BUILD:     CodingService(mode="app"),
            Intent.WEB_BUILD:     CodingService(mode="web"),
            Intent.IMAGE_GEN:     ImageGenService(),
            Intent.IMAGE_ANALYZE: GeneralService(mode="vision"),
            Intent.WEB_SEARCH:    WebSearchService(),
            Intent.FILE_ANALYZE:  FileAnalyzerService(),
            Intent.WRITING:       WritingService(),
            Intent.MATH:          MathService(),
            Intent.GENERAL:       GeneralService(),
        }

    async def route(self, request: ChatRequest) -> ChatResponse:
        """
        1. تحليل النية
        2. توجيه للخدمة المناسبة
        3. إرجاع الاستجابة
        """
        intent_result: IntentResult = intent_engine.analyze(
            message=request.message,
            has_file=bool(request.file_data),
            has_image=bool(request.image_data),
            tool_hint=request.tool_hint,
        )

        service = self.services.get(intent_result.intent, self.services[Intent.GENERAL])

        response = await service.process(
            message=request.message,
            intent=intent_result,
            session_id=request.session_id,
            file_data=request.file_data,
            image_data=request.image_data,
            history=request.history,
        )

        return ChatResponse(
            message=response.text,
            intent=intent_result.intent.value,
            confidence=intent_result.confidence,
            data=response.data,
            session_id=request.session_id,
        )


# Singleton
ai_router = AIRouter()
