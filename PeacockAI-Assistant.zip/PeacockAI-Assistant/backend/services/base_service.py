"""
Base AI Service - القاعدة المشتركة لجميع خدمات الذكاء الاصطناعي
"""

from abc import ABC, abstractmethod
from typing import Optional, List
from models.request_models import ServiceResponse, HistoryMessage
from intent_engine.engine import IntentResult


class BaseAIService(ABC):
    """
    كل خدمة ذكاء اصطناعي ترث من هذه القاعدة
    """

    @abstractmethod
    async def process(
        self,
        message: str,
        intent: IntentResult,
        session_id: str,
        file_data: Optional[str] = None,
        image_data: Optional[str] = None,
        history: Optional[List[HistoryMessage]] = None,
    ) -> ServiceResponse:
        pass

    def _build_system_prompt(self) -> str:
        return (
            "أنت Peacock، مساعد ذكاء اصطناعي متقدم من PeacockAI. "
            "أجب دائماً بدقة واحترافية. "
            "إذا كان السؤال بالعربية أجب بالعربية، وإذا كان بالإنجليزية أجب بالإنجليزية."
        )

    def _format_history(self, history: List[HistoryMessage]) -> list:
        return [
            {"role": msg.role.value, "content": msg.content}
            for msg in (history or [])
        ]
