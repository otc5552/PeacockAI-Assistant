"""
AI Services - خدمات الذكاء الاصطناعي المتخصصة
كل خدمة توجّه لنموذج مختلف حسب النية
"""

import os
import httpx
from typing import Optional, List
from services.base_service import BaseAIService
from models.request_models import ServiceResponse, HistoryMessage
from intent_engine.engine import IntentResult


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

async def call_groq(messages: list, model: str = "llama-3.3-70b-versatile") -> str:
    """استدعاء Groq API"""
    api_key = os.getenv("GROQ_API_KEY", "")
    async with httpx.AsyncClient(timeout=60) as client:
        res = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={"model": model, "messages": messages, "max_tokens": 4096},
        )
        res.raise_for_status()
        return res.json()["choices"][0]["message"]["content"]


async def call_gemini(messages: list, model: str = "gemini-2.0-flash") -> str:
    """استدعاء Gemini API"""
    api_key = os.getenv("GEMINI_API_KEY", "")
    # تحويل صيغة الرسائل لصيغة Gemini
    contents = [{"role": m["role"], "parts": [{"text": m["content"]}]} for m in messages]
    async with httpx.AsyncClient(timeout=60) as client:
        res = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}",
            json={"contents": contents},
        )
        res.raise_for_status()
        return res.json()["candidates"][0]["content"]["parts"][0]["text"]


# ──────────────────────────────────────────────
# Coding Service
# ──────────────────────────────────────────────

class CodingService(BaseAIService):
    def __init__(self, mode: str = "code"):
        self.mode = mode

    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        mode_prompts = {
            "code": "أنت خبير برمجة. اكتب كوداً نظيفاً موثقاً مع شرح مختصر.",
            "app":  "أنت خبير تطوير تطبيقات موبايل. أنتج كود React Native كامل.",
            "web":  "أنت خبير تطوير ويب. أنتج HTML/CSS/JS كاملاً وجميلاً.",
        }

        messages = [
            {"role": "system", "content": mode_prompts.get(self.mode, mode_prompts["code"])},
            *self._format_history(history),
            {"role": "user", "content": message},
        ]

        text = await call_groq(messages, model="llama-3.3-70b-versatile")
        return ServiceResponse(text=text, data={"mode": self.mode})


# ──────────────────────────────────────────────
# Image Generation Service
# ──────────────────────────────────────────────

class ImageGenService(BaseAIService):
    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        # استخدام Pollinations AI (مجاني)
        import urllib.parse
        encoded = urllib.parse.quote(message)
        image_url = f"https://image.pollinations.ai/prompt/{encoded}?width=768&height=768&nologo=true"

        return ServiceResponse(
            text=f"تم إنشاء الصورة بناءً على: {message}",
            data={"image_url": image_url, "prompt": message}
        )


# ──────────────────────────────────────────────
# Web Search Service
# ──────────────────────────────────────────────

class WebSearchService(BaseAIService):
    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        # DuckDuckGo Search (لا يحتاج API key)
        import urllib.parse
        query = urllib.parse.quote(message)

        async with httpx.AsyncClient(timeout=15) as client:
            res = await client.get(
                f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1&skip_disambig=1"
            )
            data = res.json()

        abstract = data.get("AbstractText", "")
        related = [r["Text"] for r in data.get("RelatedTopics", [])[:3] if "Text" in r]

        if abstract:
            summary = f"**نتيجة البحث عن: {message}**\n\n{abstract}"
        else:
            summary = f"**نتائج متعلقة بـ: {message}**\n\n" + "\n".join(f"• {r}" for r in related)

        return ServiceResponse(
            text=summary or "لم يتم العثور على نتائج محددة.",
            data={"source": "DuckDuckGo", "query": message}
        )


# ──────────────────────────────────────────────
# File Analyzer Service
# ──────────────────────────────────────────────

class FileAnalyzerService(BaseAIService):
    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        if not file_data:
            return ServiceResponse(text="يرجى رفع ملف لتحليله.", data=None)

        messages = [
            {"role": "system", "content": "أنت محلل ملفات ووثائق متخصص. حلل المحتوى وقدم ملخصاً شاملاً."},
            {"role": "user", "content": f"محتوى الملف:\n{file_data[:8000]}\n\nالسؤال: {message}"},
        ]

        text = await call_gemini(messages)
        return ServiceResponse(text=text, data={"analyzed": True})


# ──────────────────────────────────────────────
# Writing Service
# ──────────────────────────────────────────────

class WritingService(BaseAIService):
    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        messages = [
            {"role": "system", "content": (
                "أنت كاتب محترف متخصص في كتابة المقالات والمحتوى الإبداعي. "
                "اكتب بأسلوب رصين، منظم، ومقنع."
            )},
            *self._format_history(history),
            {"role": "user", "content": message},
        ]

        text = await call_groq(messages)
        return ServiceResponse(text=text, data={"type": "article"})


# ──────────────────────────────────────────────
# Math Service
# ──────────────────────────────────────────────

class MathService(BaseAIService):
    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        messages = [
            {"role": "system", "content": (
                "أنت أستاذ رياضيات وفيزياء. حل المسائل خطوة بخطوة بشكل واضح ومنظم. "
                "استخدم الرموز الرياضية عند الحاجة."
            )},
            *self._format_history(history),
            {"role": "user", "content": message},
        ]

        text = await call_groq(messages)
        return ServiceResponse(text=text, data={"type": "math"})


# ──────────────────────────────────────────────
# General Service (default)
# ──────────────────────────────────────────────

class GeneralService(BaseAIService):
    def __init__(self, mode: str = "general"):
        self.mode = mode

    async def process(self, message, intent, session_id,
                      file_data=None, image_data=None, history=None) -> ServiceResponse:

        system = self._build_system_prompt()

        if self.mode == "vision" and image_data:
            # Gemini للرؤية
            messages = [
                {"role": "user", "content": f"حلل هذه الصورة: {message}"}
            ]
            text = await call_gemini(messages)
        else:
            messages = [
                {"role": "system", "content": system},
                *self._format_history(history),
                {"role": "user", "content": message},
            ]
            text = await call_groq(messages)

        return ServiceResponse(text=text, data=None)
