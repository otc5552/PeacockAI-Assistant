// ─────────────────────────────────────────────
// PeacockAI - Constants & Configuration
// ─────────────────────────────────────────────

export const API_BASE_URL = "http://10.0.2.2:8000/api"; // Android emulator → localhost

export const COLORS = {
  // Primary
  primary:     "#1A1A2E",
  secondary:   "#16213E",
  accent:      "#00D4AA",
  accentDark:  "#00A884",

  // Background
  bg:          "#0D0D1A",
  bgCard:      "#1A1A2E",
  bgInput:     "#242442",

  // Text
  textPrimary: "#FFFFFF",
  textSecond:  "#A0A0C0",
  textMuted:   "#606080",

  // Message bubbles
  userBubble:  "#00D4AA",
  aiBubble:    "#1E1E3A",

  // Status
  success:     "#00D4AA",
  error:       "#FF4757",
  warning:     "#FFA502",
  info:        "#54A0FF",

  // Tools
  coding:      "#54A0FF",
  imageGen:    "#FF6B9D",
  search:      "#FFA502",
  fileAnalyze: "#A29BFE",
  writing:     "#55EFC4",
  math:        "#FDCB6E",
  appBuild:    "#74B9FF",
  webBuild:    "#00CEC9",
};

export const FONTS = {
  regular: "System",
  medium:  "System",
  bold:    "System",
  mono:    "monospace",
};

export const TOOLS = [
  { id: "image_gen",     label: "إنشاء صورة",      icon: "image",          color: COLORS.imageGen,   hint: "صِف الصورة التي تريدها..." },
  { id: "app_build",     label: "إنشاء تطبيق",     icon: "smartphone",     color: COLORS.appBuild,   hint: "صِف التطبيق الذي تريده..." },
  { id: "web_build",     label: "إنشاء موقع",      icon: "globe",          color: COLORS.webBuild,   hint: "صِف الموقع الذي تريده..." },
  { id: "file_analyze",  label: "تحليل ملف",       icon: "file-text",      color: COLORS.fileAnalyze,hint: "ارفع ملفاً لتحليله..." },
  { id: "web_search",    label: "بحث إنترنت",      icon: "search",         color: COLORS.search,     hint: "ماذا تريد أن تبحث عنه؟" },
  { id: "image_analyze", label: "تحليل صورة",      icon: "camera",         color: COLORS.imageGen,   hint: "ارفع صورة لتحليلها..." },
  { id: "writing",       label: "كتابة مقال",      icon: "edit-3",         color: COLORS.writing,    hint: "اكتب موضوع المقال..." },
  { id: "math",          label: "حل رياضيات",      icon: "percent",        color: COLORS.math,       hint: "اكتب المسألة الرياضية..." },
];

export const INTENT_LABELS: Record<string, string> = {
  coding:          "💻 برمجة",
  app_build:       "📱 تطبيق",
  web_build:       "🌐 موقع ويب",
  image_generation:"🎨 إنشاء صورة",
  image_analysis:  "🔍 تحليل صورة",
  web_search:      "🔎 بحث",
  file_analysis:   "📄 تحليل ملف",
  writing:         "✍️ كتابة",
  math:            "🧮 رياضيات",
  general:         "🤖 عام",
};
