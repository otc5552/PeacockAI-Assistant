// ─────────────────────────────────────────────
// API Service - التواصل مع الـ Backend
// ─────────────────────────────────────────────

import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_BASE_URL } from "./constants";

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000,
});

// أضف رمز Firebase تلقائياً لكل طلب
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem("firebaseToken");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ──────────────────────────────
// Types
// ──────────────────────────────

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  intent?: string;
  timestamp: string;
  data?: any;
}

export interface ChatSession {
  session_id: string;
  title: string;
  updated_at: string;
  message_count: number;
}

// ──────────────────────────────
// Chat API
// ──────────────────────────────

export const sendMessage = async (params: {
  message: string;
  sessionId: string;
  userId: string;
  toolHint?: string;
  history?: { role: string; content: string }[];
}) => {
  const response = await api.post("/chat/message", {
    message:    params.message,
    session_id: params.sessionId,
    user_id:    params.userId,
    tool_hint:  params.toolHint || null,
    history:    params.history || [],
  });
  return response.data;
};

export const sendMessageWithFile = async (params: {
  message: string;
  sessionId: string;
  userId: string;
  toolHint?: string;
  file?: { uri: string; name: string; type: string };
}) => {
  const formData = new FormData();
  formData.append("message",    params.message);
  formData.append("session_id", params.sessionId);
  formData.append("user_id",    params.userId);
  if (params.toolHint) formData.append("tool_hint", params.toolHint);
  if (params.file) {
    formData.append("file", {
      uri:  params.file.uri,
      name: params.file.name,
      type: params.file.type,
    } as any);
  }
  const response = await api.post("/chat/message/with-file", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return response.data;
};

export const getUserSessions = async (userId: string): Promise<ChatSession[]> => {
  const response = await api.get(`/chat/sessions/${userId}`);
  return response.data.sessions;
};

export const deleteSession = async (sessionId: string) => {
  await api.delete(`/chat/sessions/${sessionId}`);
};

// ──────────────────────────────
// User API
// ──────────────────────────────

export const getUserProfile = async (userId: string) => {
  const response = await api.get(`/users/${userId}`);
  return response.data;
};

export const saveFirebaseToken = async (token: string) => {
  await AsyncStorage.setItem("firebaseToken", token);
};

export const clearToken = async () => {
  await AsyncStorage.removeItem("firebaseToken");
};
