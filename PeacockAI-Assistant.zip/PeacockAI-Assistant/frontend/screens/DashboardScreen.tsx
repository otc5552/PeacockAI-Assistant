// ─────────────────────────────────────────────
// DashboardScreen.tsx - لوحة تحكم المستخدم
// ─────────────────────────────────────────────

import React, { useState, useEffect } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, Alert, StatusBar, RefreshControl,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import auth from "@react-native-firebase/auth";
import { GoogleSignin } from "@react-native-google-signin/google-signin";
import { COLORS } from "../utils/constants";
import { getUserSessions, getUserProfile, clearToken, ChatSession } from "../utils/api";

export default function DashboardScreen({ navigation }: any) {
  const [user, setUser]       = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    const uid   = await AsyncStorage.getItem("userId") || "";
    const email = await AsyncStorage.getItem("userEmail") || "";
    const name  = await AsyncStorage.getItem("userName") || "";
    const photo = auth().currentUser?.photoURL || null;
    setUser({ uid, email, name, photo });

    try {
      const [prof, sess] = await Promise.all([
        getUserProfile(uid),
        getUserSessions(uid),
      ]);
      setProfile(prof);
      setSessions(sess);
    } catch {}
  };

  useEffect(() => { load(); }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const handleLogout = () => {
    Alert.alert("تسجيل الخروج", "هل أنت متأكد؟", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "خروج", style: "destructive",
        onPress: async () => {
          await GoogleSignin.revokeAccess();
          await auth().signOut();
          await clearToken();
          await AsyncStorage.multiRemove(["userId", "userEmail", "userName"]);
          navigation.replace("Login");
        },
      },
    ]);
  };

  const used  = profile?.messages_used  || 0;
  const limit = profile?.messages_limit || 100;
  const pct   = Math.min((used / limit) * 100, 100);
  const plan  = profile?.plan || "free";

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.accent} />}
    >
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Profile Header */}
      <View style={styles.header}>
        <View style={styles.avatarWrap}>
          {user?.photo ? (
            <Image source={{ uri: user.photo }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarFallback}>
              <Text style={styles.avatarInitial}>
                {user?.name?.charAt(0)?.toUpperCase() || "P"}
              </Text>
            </View>
          )}
          <View style={[styles.planBadge, plan === "pro" ? styles.planPro : styles.planFree]}>
            <Text style={styles.planText}>{plan === "pro" ? "⭐ PRO" : "FREE"}</Text>
          </View>
        </View>
        <Text style={styles.name}>{user?.name || "مستخدم"}</Text>
        <Text style={styles.email}>{user?.email}</Text>
      </View>

      {/* Usage Card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>استهلاك الرسائل</Text>
        <View style={styles.usageRow}>
          <Text style={styles.usageCount}>{used}</Text>
          <Text style={styles.usageLimit}> / {limit}</Text>
        </View>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${pct}%` as any,
            backgroundColor: pct > 80 ? COLORS.error : COLORS.accent }]} />
        </View>
        <Text style={styles.usageHint}>
          {limit - used} رسالة متبقية
          {plan === "free" && " · "}
          {plan === "free" && (
            <Text style={styles.upgradeText} onPress={() => {}}>ترقية إلى PRO</Text>
          )}
        </Text>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        {[
          { label: "المحادثات", value: sessions.length },
          { label: "الخطة", value: plan.toUpperCase() },
          { label: "الرسائل", value: used },
        ].map((s, i) => (
          <View key={i} style={styles.statCard}>
            <Text style={styles.statValue}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Chat History */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>سجل المحادثات</Text>
        {sessions.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyText}>لا توجد محادثات بعد</Text>
          </View>
        ) : (
          sessions.map(s => (
            <TouchableOpacity
              key={s.session_id}
              style={styles.sessionCard}
              onPress={() => navigation.navigate("Chat")}
            >
              <View style={styles.sessionIcon}>
                <Text>💬</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.sessionTitle} numberOfLines={1}>{s.title}</Text>
                <Text style={styles.sessionDate}>
                  {new Date(s.updated_at).toLocaleDateString("ar-SA")}
                </Text>
              </View>
              <Text style={styles.sessionArrow}>‹</Text>
            </TouchableOpacity>
          ))
        )}
      </View>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>🚪 تسجيل الخروج</Text>
      </TouchableOpacity>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.bg },
  header: {
    alignItems: "center", paddingTop: 60,
    paddingBottom: 28, backgroundColor: COLORS.secondary,
    borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  avatarWrap:   { position: "relative", marginBottom: 12 },
  avatar:       { width: 80, height: 80, borderRadius: 40, borderWidth: 2, borderColor: COLORS.accent },
  avatarFallback: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center",
  },
  avatarInitial: { fontSize: 32, fontWeight: "700", color: COLORS.primary },
  planBadge: {
    position: "absolute", bottom: 0, right: -4,
    paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8,
  },
  planPro:    { backgroundColor: "#FFD700" },
  planFree:   { backgroundColor: COLORS.bgInput },
  planText:   { fontSize: 9, fontWeight: "800", color: COLORS.primary },
  name:       { fontSize: 20, fontWeight: "800", color: COLORS.textPrimary },
  email:      { fontSize: 13, color: COLORS.textSecond, marginTop: 4 },
  card: {
    margin: 16, backgroundColor: COLORS.bgCard,
    borderRadius: 18, padding: 20,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  cardTitle:  { color: COLORS.textSecond, fontSize: 13, marginBottom: 10, fontWeight: "600" },
  usageRow:   { flexDirection: "row", alignItems: "baseline", marginBottom: 10 },
  usageCount: { fontSize: 32, fontWeight: "900", color: COLORS.textPrimary },
  usageLimit: { fontSize: 16, color: COLORS.textMuted },
  progressBar: {
    height: 8, backgroundColor: COLORS.bgInput,
    borderRadius: 4, overflow: "hidden", marginBottom: 8,
  },
  progressFill: { height: "100%", borderRadius: 4 },
  usageHint:  { fontSize: 12, color: COLORS.textMuted },
  upgradeText: { color: COLORS.accent, fontWeight: "700" },
  statsRow: {
    flexDirection: "row", gap: 12,
    marginHorizontal: 16, marginBottom: 4,
  },
  statCard: {
    flex: 1, backgroundColor: COLORS.bgCard,
    borderRadius: 14, padding: 14, alignItems: "center",
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  statValue:  { fontSize: 20, fontWeight: "800", color: COLORS.accent },
  statLabel:  { fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  section:    { margin: 16 },
  sectionTitle: { fontSize: 16, fontWeight: "700", color: COLORS.textPrimary, marginBottom: 12 },
  emptyBox:   {
    backgroundColor: COLORS.bgCard, borderRadius: 14,
    padding: 24, alignItems: "center",
  },
  emptyText:  { color: COLORS.textMuted },
  sessionCard: {
    flexDirection: "row", alignItems: "center",
    backgroundColor: COLORS.bgCard, borderRadius: 14,
    padding: 14, marginBottom: 8, gap: 12,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  sessionIcon: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: COLORS.bgInput, alignItems: "center", justifyContent: "center",
  },
  sessionTitle: { color: COLORS.textPrimary, fontSize: 14, fontWeight: "600" },
  sessionDate:  { color: COLORS.textMuted, fontSize: 12, marginTop: 2 },
  sessionArrow: { color: COLORS.textMuted, fontSize: 20 },
  logoutBtn: {
    margin: 16, backgroundColor: COLORS.bgCard,
    borderRadius: 14, padding: 16, alignItems: "center",
    borderWidth: 1, borderColor: COLORS.error + "40",
  },
  logoutText: { color: COLORS.error, fontWeight: "700", fontSize: 15 },
});
