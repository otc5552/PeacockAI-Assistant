// ─────────────────────────────────────────────
// CodeBuilderScreen.tsx - محرر الكود
// ─────────────────────────────────────────────

import React, { useState, useEffect } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Clipboard, Share, StatusBar, Dimensions, ToastAndroid, Alert,
} from "react-native";
import { COLORS, INTENT_LABELS } from "../utils/constants";

const { width } = Dimensions.get("window");

// استخراج بلوكات الكود من markdown
function extractCodeBlocks(text: string): { lang: string; code: string }[] {
  const regex = /```(\w*)\n([\s\S]*?)```/g;
  const blocks: { lang: string; code: string }[] = [];
  let m;
  while ((m = regex.exec(text)) !== null) {
    blocks.push({ lang: m[1] || "code", code: m[2].trim() });
  }
  if (blocks.length === 0) blocks.push({ lang: "code", code: text });
  return blocks;
}

export default function CodeBuilderScreen({ route, navigation }: any) {
  const { code = "", intent = "coding" } = route?.params || {};
  const [activeTab, setActiveTab] = useState(0);
  const [copied, setCopied] = useState(false);
  const blocks = extractCodeBlocks(code);

  const copyCode = () => {
    Clipboard.setString(blocks[activeTab]?.code || code);
    ToastAndroid.show("تم نسخ الكود ✓", ToastAndroid.SHORT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareCode = async () => {
    await Share.share({
      message: blocks[activeTab]?.code || code,
      title: "كود من PeacockAI",
    });
  };

  const downloadProject = () => {
    Alert.alert(
      "تحميل المشروع",
      "هذه الميزة ستحفظ الكود كملف في هاتفك (قريباً)",
      [{ text: "موافق" }]
    );
  };

  const langColors: Record<string, string> = {
    python: "#3572A5", javascript: "#F7DF1E", typescript: "#3178C6",
    java: "#B07219", kotlin: "#7F52FF", html: "#E34C26",
    css: "#563D7C", dart: "#00B4AB", swift: "#FA7343", code: COLORS.accent,
  };

  const activeBlock = blocks[activeTab] || blocks[0];
  const langColor   = langColors[activeBlock?.lang?.toLowerCase()] || COLORS.accent;
  const intentLabel = INTENT_LABELS[intent] || "💻 كود";

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>‹</Text>
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>محرر الكود</Text>
          <Text style={styles.headerSub}>{intentLabel}</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={shareCode} style={styles.iconBtn}>
            <Text>↑</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={downloadProject} style={styles.iconBtn}>
            <Text>⬇</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Language Tabs */}
      {blocks.length > 1 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsScroll}>
          {blocks.map((b, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.tab, activeTab === i && styles.tabActive]}
              onPress={() => setActiveTab(i)}
            >
              <Text style={[styles.tabText, activeTab === i && { color: COLORS.accent }]}>
                {b.lang || `ملف ${i + 1}`}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* Code Block */}
      <View style={styles.editorContainer}>
        <View style={styles.editorHeader}>
          <View style={styles.windowDots}>
            <View style={[styles.windowDot, { backgroundColor: "#FF5F56" }]} />
            <View style={[styles.windowDot, { backgroundColor: "#FFBD2E" }]} />
            <View style={[styles.windowDot, { backgroundColor: "#27C93F" }]} />
          </View>
          <View style={[styles.langBadge, { backgroundColor: langColor + "25" }]}>
            <View style={[styles.langDot, { backgroundColor: langColor }]} />
            <Text style={[styles.langText, { color: langColor }]}>
              {activeBlock?.lang?.toUpperCase() || "CODE"}
            </Text>
          </View>
          <TouchableOpacity onPress={copyCode} style={styles.copyBtn}>
            <Text style={styles.copyBtnText}>{copied ? "✓ تم" : "نسخ"}</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.codeScroll} horizontal>
          <ScrollView>
            <Text style={styles.code} selectable>
              {activeBlock?.code || code}
            </Text>
          </ScrollView>
        </ScrollView>
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={[styles.actionBtn, styles.actionCopy]} onPress={copyCode}>
          <Text style={styles.actionCopyText}>{copied ? "✓ تم النسخ" : "📋 نسخ الكود"}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.actionShare]} onPress={shareCode}>
          <Text style={styles.actionShareText}>↑ مشاركة</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: 50, paddingBottom: 12,
    backgroundColor: COLORS.secondary, borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  backBtn:      { width: 40, height: 40, justifyContent: "center" },
  backText:     { color: COLORS.accent, fontSize: 28, fontWeight: "300" },
  headerTitle:  { fontSize: 17, fontWeight: "700", color: COLORS.textPrimary },
  headerSub:    { fontSize: 12, color: COLORS.textMuted, marginTop: 1 },
  headerActions: { flexDirection: "row", gap: 8 },
  iconBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: COLORS.bgInput, alignItems: "center", justifyContent: "center",
  },
  tabsScroll:   { maxHeight: 44, backgroundColor: COLORS.secondary },
  tab: {
    paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 2, borderBottomColor: "transparent",
  },
  tabActive:    { borderBottomColor: COLORS.accent },
  tabText:      { color: COLORS.textMuted, fontSize: 13, fontWeight: "600" },
  editorContainer: {
    flex: 1, margin: 12,
    backgroundColor: "#0D0D1A", borderRadius: 16, overflow: "hidden",
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  editorHeader: {
    flexDirection: "row", alignItems: "center",
    backgroundColor: "#151520", paddingHorizontal: 14, paddingVertical: 10, gap: 10,
  },
  windowDots:   { flexDirection: "row", gap: 6 },
  windowDot:    { width: 10, height: 10, borderRadius: 5 },
  langBadge: {
    flex: 1, flexDirection: "row", alignItems: "center",
    gap: 6, paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: 8, alignSelf: "flex-start",
  },
  langDot:      { width: 6, height: 6, borderRadius: 3 },
  langText:     { fontSize: 11, fontWeight: "700" },
  copyBtn: {
    paddingHorizontal: 12, paddingVertical: 4,
    backgroundColor: COLORS.bgInput, borderRadius: 8,
  },
  copyBtnText:  { color: COLORS.textSecond, fontSize: 12, fontWeight: "600" },
  codeScroll:   { flex: 1, padding: 14 },
  code: {
    color: "#E0E0FF", fontSize: 13.5, lineHeight: 22,
    fontFamily: "monospace", letterSpacing: 0.3,
  },
  actions: {
    flexDirection: "row", gap: 12, padding: 16,
    backgroundColor: COLORS.secondary,
    borderTopWidth: 1, borderTopColor: COLORS.bgInput,
  },
  actionBtn:    { flex: 1, borderRadius: 14, paddingVertical: 14, alignItems: "center" },
  actionCopy:   { backgroundColor: COLORS.bgCard, borderWidth: 1, borderColor: COLORS.bgInput },
  actionCopyText: { color: COLORS.textPrimary, fontWeight: "700" },
  actionShare:  { backgroundColor: COLORS.accent },
  actionShareText: { color: COLORS.primary, fontWeight: "800" },
});
