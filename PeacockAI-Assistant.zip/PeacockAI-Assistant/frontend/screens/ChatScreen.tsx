// ─────────────────────────────────────────────
// ChatScreen.tsx - الشاشة الرئيسية للمحادثة
// ─────────────────────────────────────────────

import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  View, Text, StyleSheet, FlatList, TextInput,
  TouchableOpacity, KeyboardAvoidingView, Platform,
  ActivityIndicator, StatusBar, Alert, Animated,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import uuid from "react-native-uuid";
import DocumentPicker from "react-native-document-picker";
import { launchImageLibrary } from "react-native-image-picker";

import { COLORS, TOOLS, INTENT_LABELS } from "../utils/constants";
import { sendMessage, sendMessageWithFile, Message } from "../utils/api";
import MessageBubble from "../components/chat/MessageBubble";
import ToolsMenu from "../components/tools/ToolsMenu";

export default function ChatScreen({ navigation }: any) {
  const [messages, setMessages]       = useState<Message[]>([]);
  const [input, setInput]             = useState("");
  const [loading, setLoading]         = useState(false);
  const [showTools, setShowTools]     = useState(false);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [sessionId]                   = useState(() => uuid.v4() as string);
  const [userId, setUserId]           = useState("");
  const flatListRef                   = useRef<FlatList>(null);
  const toolsAnim                     = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    AsyncStorage.getItem("userId").then(id => setUserId(id || ""));
    setMessages([{
      id: "welcome",
      role: "assistant",
      content: "مرحباً! أنا Peacock 🦚 مساعدك الذكي الشامل.\n\nيمكنني مساعدتك في البرمجة، إنشاء الصور، البحث، تحليل الملفات، وأكثر!\n\nاضغط (+) لرؤية الأدوات المتاحة.",
      timestamp: new Date().toISOString(),
    }]);
  }, []);

  const toggleTools = () => {
    const toValue = showTools ? 0 : 1;
    setShowTools(!showTools);
    Animated.spring(toolsAnim, { toValue, useNativeDriver: true, tension: 80, friction: 10 }).start();
  };

  const handleSelectTool = (toolId: string) => {
    setSelectedTool(toolId);
    setShowTools(false);
    Animated.spring(toolsAnim, { toValue: 0, useNativeDriver: true }).start();
    const tool = TOOLS.find(t => t.id === toolId);
    if (tool) setInput(tool.hint || "");
  };

  const handleSend = useCallback(async (fileOverride?: any) => {
    const text = input.trim();
    if (!text && !fileOverride) return;
    if (loading) return;

    const userMsg: Message = {
      id: uuid.v4() as string,
      role: "user",
      content: text || (fileOverride?.name ? `📎 ${fileOverride.name}` : ""),
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const history = messages
        .filter(m => m.id !== "welcome")
        .slice(-10)
        .map(m => ({ role: m.role, content: m.content }));

      let response;
      if (fileOverride) {
        response = await sendMessageWithFile({
          message: text || "حلل هذا الملف",
          sessionId, userId,
          toolHint: selectedTool || undefined,
          file: fileOverride,
        });
      } else {
        response = await sendMessage({
          message: text, sessionId, userId,
          toolHint: selectedTool || undefined,
          history,
        });
      }

      const aiMsg: Message = {
        id: uuid.v4() as string,
        role: "assistant",
        content: response.message,
        intent: response.intent,
        timestamp: new Date().toISOString(),
        data: response.data,
      };

      setMessages(prev => [...prev, aiMsg]);
      setSelectedTool(null);

      // توجيه لشاشات خاصة
      if (response.intent === "image_generation" && response.data?.image_url) {
        navigation.navigate("ImageGen", { result: response.data });
      } else if (["coding", "app_build", "web_build"].includes(response.intent)) {
        navigation.navigate("CodeBuilder", { code: response.message, intent: response.intent });
      }

    } catch (err: any) {
      const errMsg: Message = {
        id: uuid.v4() as string,
        role: "assistant",
        content: "⚠️ حدث خطأ في الاتصال. تحقق من تشغيل الخادم وحاول مجدداً.",
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setLoading(false);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [input, loading, messages, sessionId, userId, selectedTool]);

  const handleAttachFile = async () => {
    try {
      const result = await DocumentPicker.pickSingle({
        type: [DocumentPicker.types.pdf, DocumentPicker.types.plainText,
               DocumentPicker.types.csv, DocumentPicker.types.doc],
      });
      handleSend({ uri: result.uri, name: result.name, type: result.type });
    } catch (e) {
      if (!DocumentPicker.isCancel(e)) Alert.alert("خطأ", "فشل رفع الملف");
    }
  };

  const handleAttachImage = async () => {
    const result = await launchImageLibrary({ mediaType: "photo", quality: 0.8 });
    if (result.assets?.[0]) {
      const img = result.assets[0];
      handleSend({ uri: img.uri, name: img.fileName || "image.jpg", type: img.type || "image/jpeg" });
    }
  };

  const selectedToolObj = TOOLS.find(t => t.id === selectedTool);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate("Dashboard")} style={styles.headerLeft}>
          <Text style={styles.headerEmoji}>🦚</Text>
          <View>
            <Text style={styles.headerTitle}>Peacock</Text>
            <View style={styles.onlineDot}>
              <View style={styles.dot} />
              <Text style={styles.onlineText}>متصل</Text>
            </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setMessages([{
          id: "welcome", role: "assistant",
          content: "محادثة جديدة 🦚 كيف يمكنني مساعدتك؟",
          timestamp: new Date().toISOString(),
        }])} style={styles.newChatBtn}>
          <Text style={styles.newChatText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Selected Tool Badge */}
      {selectedToolObj && (
        <View style={[styles.toolBadge, { borderColor: selectedToolObj.color }]}>
          <Text style={[styles.toolBadgeText, { color: selectedToolObj.color }]}>
            وضع: {selectedToolObj.label}
          </Text>
          <TouchableOpacity onPress={() => setSelectedTool(null)}>
            <Text style={styles.toolBadgeClose}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={m => m.id}
        renderItem={({ item }) => <MessageBubble message={item} />}
        contentContainerStyle={styles.messagesList}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        showsVerticalScrollIndicator={false}
      />

      {/* Loading indicator */}
      {loading && (
        <View style={styles.typingIndicator}>
          <Text style={styles.typingText}>Peacock يكتب</Text>
          <ActivityIndicator size="small" color={COLORS.accent} style={{ marginLeft: 8 }} />
        </View>
      )}

      {/* Tools Menu */}
      {showTools && (
        <Animated.View style={[styles.toolsPanel, {
          opacity: toolsAnim,
          transform: [{ translateY: toolsAnim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }]
        }]}>
          <ToolsMenu tools={TOOLS} onSelect={handleSelectTool} />
        </Animated.View>
      )}

      {/* Input Bar */}
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={80}
      >
        <View style={styles.inputBar}>
          <TouchableOpacity onPress={toggleTools} style={styles.addBtn}>
            <Text style={[styles.addBtnText, showTools && { color: COLORS.accent }]}>+</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleAttachFile} style={styles.iconBtn}>
            <Text style={styles.iconBtnText}>📎</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleAttachImage} style={styles.iconBtn}>
            <Text style={styles.iconBtnText}>🖼️</Text>
          </TouchableOpacity>

          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder={selectedToolObj?.hint || "اسألني أي شيء..."}
            placeholderTextColor={COLORS.textMuted}
            multiline
            maxLength={4000}
            onSubmitEditing={() => handleSend()}
          />

          <TouchableOpacity
            style={[styles.sendBtn, (!input.trim() || loading) && styles.sendBtnDisabled]}
            onPress={() => handleSend()}
            disabled={!input.trim() || loading}
          >
            <Text style={styles.sendBtnText}>➤</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: 50, paddingBottom: 12,
    backgroundColor: COLORS.secondary, borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  headerLeft:     { flexDirection: "row", alignItems: "center", gap: 10 },
  headerEmoji:    { fontSize: 28 },
  headerTitle:    { fontSize: 18, fontWeight: "800", color: COLORS.textPrimary },
  onlineDot:      { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 },
  dot:            { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.accent },
  onlineText:     { fontSize: 11, color: COLORS.accent },
  newChatBtn:     {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: COLORS.bgInput, alignItems: "center", justifyContent: "center",
  },
  newChatText:    { fontSize: 22, color: COLORS.accent, fontWeight: "300" },
  toolBadge: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    marginHorizontal: 16, marginTop: 8, paddingHorizontal: 14, paddingVertical: 6,
    borderRadius: 20, borderWidth: 1, backgroundColor: COLORS.bgCard,
  },
  toolBadgeText:  { fontSize: 13, fontWeight: "600" },
  toolBadgeClose: { color: COLORS.textMuted, fontSize: 14, paddingLeft: 12 },
  messagesList:   { padding: 16, paddingBottom: 8 },
  typingIndicator: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingVertical: 6,
  },
  typingText:     { color: COLORS.textMuted, fontSize: 13 },
  toolsPanel: {
    position: "absolute", bottom: 80, left: 0, right: 0, zIndex: 10,
  },
  inputBar: {
    flexDirection: "row", alignItems: "flex-end",
    paddingHorizontal: 10, paddingVertical: 10,
    backgroundColor: COLORS.secondary,
    borderTopWidth: 1, borderTopColor: COLORS.bgInput, gap: 6,
  },
  addBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: COLORS.bgInput, alignItems: "center", justifyContent: "center",
  },
  addBtnText:     { fontSize: 22, color: COLORS.textSecond, fontWeight: "300" },
  iconBtn:        { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  iconBtnText:    { fontSize: 18 },
  input: {
    flex: 1, backgroundColor: COLORS.bgInput,
    borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10,
    color: COLORS.textPrimary, fontSize: 15, maxHeight: 120,
    textAlign: "right",
  },
  sendBtn: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center",
  },
  sendBtnDisabled: { backgroundColor: COLORS.bgInput },
  sendBtnText:    { fontSize: 16, color: COLORS.primary, fontWeight: "700" },
});
