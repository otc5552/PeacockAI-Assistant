// ─────────────────────────────────────────────
// Splash Screen - شاشة البداية
// ─────────────────────────────────────────────

import React, { useEffect, useRef } from "react";
import {
  View, Text, StyleSheet, Animated, StatusBar, Dimensions
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { COLORS } from "../utils/constants";

const { width } = Dimensions.get("window");

export default function SplashScreen({ navigation }: any) {
  const scale   = useRef(new Animated.Value(0.3)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const tagOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // انيميشن الشعار
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale, {
          toValue: 1, tension: 50, friction: 7, useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1, duration: 600, useNativeDriver: true,
        }),
      ]),
      Animated.timing(tagOpacity, {
        toValue: 1, duration: 400, delay: 200, useNativeDriver: true,
      }),
    ]).start();

    // انتقال بعد 2.5 ثانية
    const timer = setTimeout(async () => {
      const token = await AsyncStorage.getItem("firebaseToken");
      navigation.replace(token ? "Main" : "Login");
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      <Animated.View style={[styles.logoContainer, { opacity, transform: [{ scale }] }]}>
        {/* Peacock Icon */}
        <View style={styles.iconWrapper}>
          <Text style={styles.peacockEmoji}>🦚</Text>
        </View>
        <Text style={styles.appName}>PeacockAI</Text>
      </Animated.View>

      <Animated.View style={[styles.tagContainer, { opacity: tagOpacity }]}>
        <Text style={styles.tagline}>مساعدك الذكي الشامل</Text>
        <View style={styles.dotRow}>
          {[0, 1, 2].map(i => (
            <View key={i} style={[styles.dot, i === 1 && styles.dotActive]} />
          ))}
        </View>
      </Animated.View>

      <Text style={styles.version}>v1.0.0</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bg,
    alignItems: "center",
    justifyContent: "center",
  },
  logoContainer: {
    alignItems: "center",
  },
  iconWrapper: {
    width: 100, height: 100,
    borderRadius: 30,
    backgroundColor: COLORS.bgCard,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: COLORS.accent,
    marginBottom: 16,
  },
  peacockEmoji: { fontSize: 52 },
  appName: {
    fontSize: 36, fontWeight: "800",
    color: COLORS.textPrimary, letterSpacing: 1,
  },
  tagContainer: { marginTop: 24, alignItems: "center" },
  tagline: {
    fontSize: 16, color: COLORS.textSecond,
    marginBottom: 20, letterSpacing: 0.5,
  },
  dotRow: { flexDirection: "row", gap: 8 },
  dot: {
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: COLORS.bgInput,
  },
  dotActive: { backgroundColor: COLORS.accent, width: 20 },
  version: {
    position: "absolute", bottom: 24,
    color: COLORS.textMuted, fontSize: 12,
  },
});
