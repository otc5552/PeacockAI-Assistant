// ─────────────────────────────────────────────
// ImageGenScreen.tsx - شاشة توليد الصور
// ─────────────────────────────────────────────

import React, { useState, useEffect } from "react";
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  Image, ScrollView, ActivityIndicator, StatusBar,
  Share, Alert, Dimensions,
} from "react-native";
import { COLORS } from "../utils/constants";
import { sendMessage } from "../utils/api";
import AsyncStorage from "@react-native-async-storage/async-storage";
import uuid from "react-native-uuid";

const { width } = Dimensions.get("window");

const STYLE_OPTIONS = [
  "واقعي", "كرتوني", "زيتي", "خيال علمي", "أنيمي", "بورتريه",
];

export default function ImageGenScreen({ route, navigation }: any) {
  const [prompt, setPrompt]   = useState("");
  const [style, setStyle]     = useState("واقعي");
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(
    route?.params?.result?.image_url || null
  );
  const [history, setHistory] = useState<string[]>([]);

  const generate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const uid = await AsyncStorage.getItem("userId") || "";
      const fullPrompt = `${prompt}, ${style} style`;
      const res = await sendMessage({
        message: fullPrompt,
        sessionId: uuid.v4() as string,
        userId: uid,
        toolHint: "image_gen",
      });
      const url = res.data?.image_url;
      if (url) {
        setImageUrl(url);
        setHistory(prev => [url, ...prev.slice(0, 5)]);
      }
    } catch {
      Alert.alert("خطأ", "فشل توليد الصورة. حاول مجدداً.");
    } finally {
      setLoading(false);
    }
  };

  const shareImage = async () => {
    if (!imageUrl) return;
    await Share.share({ url: imageUrl, message: `صورة من PeacockAI: ${prompt}` });
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>🎨 توليد الصور</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Image Preview */}
        <View style={styles.imageBox}>
          {loading ? (
            <View style={styles.loadingBox}>
              <ActivityIndicator size="large" color={COLORS.accent} />
              <Text style={styles.loadingText}>جاري إنشاء الصورة...</Text>
            </View>
          ) : imageUrl ? (
            <>
              <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="contain" />
              <View style={styles.imageActions}>
                <TouchableOpacity style={styles.actionBtn} onPress={shareImage}>
                  <Text style={styles.actionText}>↑ مشاركة</Text>
                </TouchableOpacity>
              </View>
            </>
          ) : (
            <View style={styles.placeholder}>
              <Text style={styles.placeholderEmoji}>🎨</Text>
              <Text style={styles.placeholderText}>أدخل وصفاً لإنشاء الصورة</Text>
            </View>
          )}
        </View>

        {/* Style Selector */}
        <Text style={styles.label}>النمط</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.styleScroll}>
          {STYLE_OPTIONS.map(s => (
            <TouchableOpacity
              key={s}
              style={[styles.styleChip, style === s && styles.styleChipActive]}
              onPress={() => setStyle(s)}
            >
              <Text style={[styles.styleText, style === s && styles.styleTextActive]}>{s}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Prompt Input */}
        <Text style={styles.label}>الوصف</Text>
        <TextInput
          style={styles.promptInput}
          value={prompt}
          onChangeText={setPrompt}
          placeholder="مثال: غروب شمس فوق جبال في الصحراء..."
          placeholderTextColor={COLORS.textMuted}
          multiline
          numberOfLines={3}
          textAlign="right"
        />

        {/* Generate Button */}
        <TouchableOpacity
          style={[styles.generateBtn, (!prompt.trim() || loading) && styles.generateBtnDisabled]}
          onPress={generate}
          disabled={!prompt.trim() || loading}
        >
          <Text style={styles.generateText}>
            {loading ? "جاري الإنشاء..." : "✨ إنشاء الصورة"}
          </Text>
        </TouchableOpacity>

        {/* History */}
        {history.length > 0 && (
          <>
            <Text style={[styles.label, { marginTop: 20 }]}>الصور السابقة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {history.map((url, i) => (
                <TouchableOpacity key={i} onPress={() => setImageUrl(url)}>
                  <Image source={{ uri: url }} style={styles.histThumb} />
                </TouchableOpacity>
              ))}
            </ScrollView>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: 50, paddingBottom: 12,
    backgroundColor: COLORS.secondary, borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  backBtn:      { width: 40, height: 40, justifyContent: "center" },
  backText:     { color: COLORS.accent, fontSize: 28, fontWeight: "300" },
  headerTitle:  { fontSize: 17, fontWeight: "700", color: COLORS.textPrimary },
  content:      { padding: 16, paddingBottom: 40 },
  imageBox: {
    height: 300, backgroundColor: COLORS.bgCard, borderRadius: 20,
    overflow: "hidden", marginBottom: 20,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  loadingBox:   { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText:  { color: COLORS.textMuted, fontSize: 14 },
  image:        { width: "100%", height: "100%" },
  imageActions: {
    position: "absolute", bottom: 10, right: 10, flexDirection: "row", gap: 8,
  },
  actionBtn: {
    backgroundColor: COLORS.bg + "CC", borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 6,
  },
  actionText:   { color: COLORS.accent, fontSize: 13, fontWeight: "600" },
  placeholder:  { flex: 1, alignItems: "center", justifyContent: "center" },
  placeholderEmoji: { fontSize: 48, marginBottom: 12 },
  placeholderText:  { color: COLORS.textMuted, fontSize: 14 },
  label:        { color: COLORS.textSecond, fontSize: 13, fontWeight: "600", marginBottom: 10 },
  styleScroll:  { marginBottom: 16 },
  styleChip: {
    paddingHorizontal: 14, paddingVertical: 8, marginRight: 8,
    backgroundColor: COLORS.bgCard, borderRadius: 20,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  styleChipActive: { backgroundColor: COLORS.accent + "20", borderColor: COLORS.accent },
  styleText:    { color: COLORS.textSecond, fontSize: 13 },
  styleTextActive: { color: COLORS.accent, fontWeight: "700" },
  promptInput: {
    backgroundColor: COLORS.bgCard, borderRadius: 16, padding: 14,
    color: COLORS.textPrimary, fontSize: 15,
    borderWidth: 1, borderColor: COLORS.bgInput, marginBottom: 16,
    textAlignVertical: "top",
  },
  generateBtn: {
    backgroundColor: COLORS.accent, borderRadius: 16,
    paddingVertical: 16, alignItems: "center",
  },
  generateBtnDisabled: { opacity: 0.5 },
  generateText: { color: COLORS.primary, fontWeight: "800", fontSize: 16 },
  histThumb: {
    width: 80, height: 80, borderRadius: 12, marginRight: 8,
    borderWidth: 2, borderColor: COLORS.bgInput,
  },
});
