// ─────────────────────────────────────────────
// Login Screen - شاشة تسجيل الدخول بـ Google
// ─────────────────────────────────────────────

import React, { useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity,
  ActivityIndicator, Alert, StatusBar, Dimensions
} from "react-native";
import {
  GoogleSignin,
  statusCodes,
} from "@react-native-google-signin/google-signin";
import auth from "@react-native-firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { COLORS } from "../utils/constants";
import { saveFirebaseToken } from "../utils/api";

GoogleSignin.configure({
  webClientId: "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com", // ← غيّر هذا
});

const { height } = Dimensions.get("window");

export default function LoginScreen({ navigation }: any) {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      await GoogleSignin.hasPlayServices();
      const { idToken } = await GoogleSignin.signIn();
      const credential  = auth.GoogleAuthProvider.credential(idToken!);
      const userCredential = await auth().signInWithCredential(credential);

      // احفظ رمز Firebase
      const token = await userCredential.user.getIdToken();
      await saveFirebaseToken(token);
      await AsyncStorage.setItem("userId", userCredential.user.uid);
      await AsyncStorage.setItem("userEmail", userCredential.user.email || "");
      await AsyncStorage.setItem("userName",  userCredential.user.displayName || "");

      navigation.replace("Main");
    } catch (error: any) {
      if (error.code === statusCodes.SIGN_IN_CANCELLED) return;
      if (error.code === statusCodes.IN_PROGRESS) return;
      Alert.alert("خطأ", "فشل تسجيل الدخول. حاول مجدداً.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.emoji}>🦚</Text>
        <Text style={styles.title}>PeacockAI</Text>
        <Text style={styles.subtitle}>مساعدك الذكي الشامل</Text>
      </View>

      {/* Features */}
      <View style={styles.features}>
        {[
          { icon: "💻", text: "برمجة وإنشاء تطبيقات" },
          { icon: "🎨", text: "توليد الصور" },
          { icon: "🔎", text: "البحث في الإنترنت" },
          { icon: "📄", text: "تحليل الملفات" },
          { icon: "✍️", text: "كتابة المقالات" },
        ].map((f, i) => (
          <View key={i} style={styles.featureRow}>
            <Text style={styles.featureIcon}>{f.icon}</Text>
            <Text style={styles.featureText}>{f.text}</Text>
          </View>
        ))}
      </View>

      {/* Login Button */}
      <View style={styles.loginSection}>
        <TouchableOpacity
          style={[styles.googleBtn, loading && styles.btnDisabled]}
          onPress={handleGoogleLogin}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <ActivityIndicator color={COLORS.primary} />
          ) : (
            <>
              <Text style={styles.googleIcon}>G</Text>
              <Text style={styles.googleText}>تسجيل الدخول بـ Google</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.terms}>
          بتسجيل دخولك، أنت توافق على شروط الخدمة وسياسة الخصوصية
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: COLORS.bg,
    paddingHorizontal: 28,
    justifyContent: "space-between",
    paddingVertical: 60,
  },
  header: { alignItems: "center", marginTop: 20 },
  emoji: { fontSize: 64, marginBottom: 16 },
  title: {
    fontSize: 38, fontWeight: "900",
    color: COLORS.textPrimary, letterSpacing: 1,
  },
  subtitle: {
    fontSize: 16, color: COLORS.textSecond, marginTop: 8,
  },
  features: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 20, padding: 24, gap: 16,
  },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 14 },
  featureIcon: { fontSize: 22 },
  featureText: { fontSize: 15, color: COLORS.textPrimary, fontWeight: "500" },
  loginSection: { gap: 16 },
  googleBtn: {
    backgroundColor: "#FFFFFF",
    borderRadius: 14, height: 56,
    flexDirection: "row", alignItems: "center",
    justifyContent: "center", gap: 12,
    elevation: 4,
  },
  btnDisabled: { opacity: 0.7 },
  googleIcon: {
    fontSize: 20, fontWeight: "900", color: "#4285F4",
  },
  googleText: {
    fontSize: 16, fontWeight: "700", color: "#333",
  },
  terms: {
    textAlign: "center", color: COLORS.textMuted, fontSize: 12, lineHeight: 18,
  },
});
