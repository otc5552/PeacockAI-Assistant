// ─────────────────────────────────────────────
// FileAnalyzerScreen.tsx - تحليل الملفات
// ─────────────────────────────────────────────

import React, { useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  ActivityIndicator, StatusBar, Alert,
} from "react-native";
import DocumentPicker from "react-native-document-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import uuid from "react-native-uuid";
import { COLORS } from "../utils/constants";
import { sendMessageWithFile } from "../utils/api";

interface FileInfo { name: string; type: string; uri: string; size?: number }

export default function FileAnalyzerScreen({ navigation }: any) {
  const [file, setFile]         = useState<FileInfo | null>(null);
  const [question, setQuestion] = useState("لخص هذا الملف وأبرز أهم النقاط");
  const [result, setResult]     = useState<string | null>(null);
  const [loading, setLoading]   = useState(false);

  const pickFile = async () => {
    try {
      const f = await DocumentPicker.pickSingle({
        type: [
          DocumentPicker.types.pdf, DocumentPicker.types.plainText,
          DocumentPicker.types.csv, DocumentPicker.types.doc,
          DocumentPicker.types.docx,
        ],
        copyTo: "cachesDirectory",
      });
      setFile({ name: f.name || "ملف", type: f.type || "text/plain", uri: f.fileCopyUri || f.uri });
      setResult(null);
    } catch (e) {
      if (!DocumentPicker.isCancel(e)) Alert.alert("خطأ", "لم يتم اختيار ملف");
    }
  };

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const uid = await AsyncStorage.getItem("userId") || "";
      const res = await sendMessageWithFile({
        message: question,
        sessionId: uuid.v4() as string,
        userId: uid,
        toolHint: "file_analyze",
        file: { uri: file.uri, name: file.name, type: file.type },
      });
      setResult(res.message);
    } catch {
      Alert.alert("خطأ", "فشل تحليل الملف. تأكد من تشغيل الخادم.");
    } finally {
      setLoading(false);
    }
  };

  const FILE_ICON: Record<string, string> = {
    pdf: "📄", txt: "📝", csv: "📊", doc: "📃", docx: "📃",
  };
  const ext = file?.name?.split(".").pop()?.toLowerCase() || "";

  const QUESTIONS = [
    "لخص هذا الملف وأبرز أهم النقاط",
    "استخرج البيانات المهمة",
    "اشرح محتوى هذا الملف",
    "ما الاستنتاجات الرئيسية؟",
  ];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>📄 تحليل الملفات</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>

        {/* Upload Zone */}
        <TouchableOpacity style={styles.uploadZone} onPress={pickFile}>
          {file ? (
            <View style={styles.fileInfo}>
              <Text style={styles.fileIcon}>{FILE_ICON[ext] || "📎"}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.fileName} numberOfLines={1}>{file.name}</Text>
                <Text style={styles.fileType}>{file.type}</Text>
              </View>
              <TouchableOpacity onPress={() => setFile(null)} style={styles.removeBtn}>
                <Text style={styles.removeText}>✕</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <Text style={styles.uploadIcon}>☁️</Text>
              <Text style={styles.uploadTitle}>ارفع ملفك هنا</Text>
              <Text style={styles.uploadSub}>PDF · TXT · CSV · DOC · DOCX</Text>
              <View style={styles.uploadBtn}>
                <Text style={styles.uploadBtnText}>اختر ملفاً</Text>
              </View>
            </>
          )}
        </TouchableOpacity>

        {/* Quick Questions */}
        <Text style={styles.label}>سؤال التحليل</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.qScroll}>
          {QUESTIONS.map(q => (
            <TouchableOpacity
              key={q}
              style={[styles.qChip, question === q && styles.qChipActive]}
              onPress={() => setQuestion(q)}
            >
              <Text style={[styles.qText, question === q && styles.qTextActive]}>{q}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Analyze Button */}
        <TouchableOpacity
          style={[styles.analyzeBtn, (!file || loading) && styles.analyzeBtnDisabled]}
          onPress={analyze}
          disabled={!file || loading}
        >
          {loading ? (
            <ActivityIndicator color={COLORS.primary} />
          ) : (
            <Text style={styles.analyzeBtnText}>🔍 تحليل الملف</Text>
          )}
        </TouchableOpacity>

        {/* Result */}
        {result && (
          <View style={styles.resultBox}>
            <View style={styles.resultHeader}>
              <Text style={styles.resultTitle}>📊 نتيجة التحليل</Text>
            </View>
            <Text style={styles.resultText} selectable>{result}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: 50, paddingBottom: 12,
    backgroundColor: COLORS.secondary, borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  backBtn:      { width: 40, height: 40, justifyContent: "center" },
  backText:     { color: COLORS.accent, fontSize: 28, fontWeight: "300" },
  headerTitle:  { fontSize: 17, fontWeight: "700", color: COLORS.textPrimary },
  content:      { padding: 16, paddingBottom: 40 },
  uploadZone: {
    height: 180, backgroundColor: COLORS.bgCard, borderRadius: 20,
    borderWidth: 2, borderColor: COLORS.bgInput, borderStyle: "dashed",
    alignItems: "center", justifyContent: "center", marginBottom: 20, gap: 8,
  },
  fileInfo: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, gap: 12, width: "100%",
  },
  fileIcon:     { fontSize: 36 },
  fileName:     { color: COLORS.textPrimary, fontWeight: "700", fontSize: 15 },
  fileType:     { color: COLORS.textMuted, fontSize: 12, marginTop: 2 },
  removeBtn:    { padding: 8 },
  removeText:   { color: COLORS.error, fontWeight: "700" },
  uploadIcon:   { fontSize: 36 },
  uploadTitle:  { color: COLORS.textPrimary, fontWeight: "700", fontSize: 16 },
  uploadSub:    { color: COLORS.textMuted, fontSize: 12 },
  uploadBtn: {
    marginTop: 8, paddingHorizontal: 20, paddingVertical: 8,
    backgroundColor: COLORS.accent + "20", borderRadius: 10,
    borderWidth: 1, borderColor: COLORS.accent,
  },
  uploadBtnText: { color: COLORS.accent, fontWeight: "700" },
  label:        { color: COLORS.textSecond, fontSize: 13, fontWeight: "600", marginBottom: 10 },
  qScroll:      { marginBottom: 16 },
  qChip: {
    paddingHorizontal: 14, paddingVertical: 8, marginRight: 8,
    backgroundColor: COLORS.bgCard, borderRadius: 20,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  qChipActive:  { borderColor: COLORS.accent, backgroundColor: COLORS.accent + "15" },
  qText:        { color: COLORS.textSecond, fontSize: 12 },
  qTextActive:  { color: COLORS.accent, fontWeight: "700" },
  analyzeBtn: {
    backgroundColor: COLORS.accent, borderRadius: 16,
    paddingVertical: 16, alignItems: "center", marginBottom: 20,
  },
  analyzeBtnDisabled: { opacity: 0.5 },
  analyzeBtnText: { color: COLORS.primary, fontWeight: "800", fontSize: 16 },
  resultBox: {
    backgroundColor: COLORS.bgCard, borderRadius: 18,
    borderWidth: 1, borderColor: COLORS.bgInput, overflow: "hidden",
  },
  resultHeader: {
    padding: 14, backgroundColor: COLORS.bgInput,
    borderBottomWidth: 1, borderBottomColor: COLORS.bgInput,
  },
  resultTitle:  { color: COLORS.accent, fontWeight: "700", fontSize: 14 },
  resultText:   { color: COLORS.textPrimary, fontSize: 14, lineHeight: 24, padding: 16 },
});
