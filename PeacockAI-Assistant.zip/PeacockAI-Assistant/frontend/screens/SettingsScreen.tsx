// ─────────────────────────────────────────────
// SettingsScreen.tsx - الإعدادات
// ─────────────────────────────────────────────

import React, { useState } from "react";
import {
  View, Text, StyleSheet, ScrollView,
  Switch, TouchableOpacity, StatusBar, Linking, Alert,
} from "react-native";
import { COLORS } from "../utils/constants";

export default function SettingsScreen() {
  const [darkMode, setDarkMode]   = useState(true);
  const [arabic, setArabic]       = useState(true);
  const [notifications, setNotif] = useState(true);
  const [streaming, setStreaming] = useState(true);

  const Row = ({ label, value, onToggle, isLast = false }: any) => (
    <View style={[styles.row, !isLast && styles.rowBorder]}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Switch
        value={value} onValueChange={onToggle}
        trackColor={{ false: COLORS.bgInput, true: COLORS.accent + "70" }}
        thumbColor={value ? COLORS.accent : COLORS.textMuted}
      />
    </View>
  );

  const LinkRow = ({ label, icon, onPress, isLast = false }: any) => (
    <TouchableOpacity
      style={[styles.row, !isLast && styles.rowBorder]}
      onPress={onPress}
    >
      <View style={styles.linkLeft}>
        <Text style={styles.rowIcon}>{icon}</Text>
        <Text style={styles.rowLabel}>{label}</Text>
      </View>
      <Text style={styles.arrow}>›</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
      <Text style={styles.pageTitle}>الإعدادات</Text>

      {/* Appearance */}
      <Text style={styles.groupTitle}>المظهر</Text>
      <View style={styles.group}>
        <Row label="الوضع الليلي 🌙" value={darkMode} onToggle={setDarkMode} />
        <Row label="اللغة العربية 🇸🇦" value={arabic} onToggle={setArabic} isLast />
      </View>

      {/* Behavior */}
      <Text style={styles.groupTitle}>السلوك</Text>
      <View style={styles.group}>
        <Row label="الإشعارات 🔔" value={notifications} onToggle={setNotif} />
        <Row label="البث المباشر للردود ⚡" value={streaming} onToggle={setStreaming} isLast />
      </View>

      {/* About */}
      <Text style={styles.groupTitle}>حول التطبيق</Text>
      <View style={styles.group}>
        <LinkRow label="سياسة الخصوصية" icon="🔒"
          onPress={() => Linking.openURL("https://peacockai.com/privacy")} />
        <LinkRow label="شروط الخدمة" icon="📜"
          onPress={() => Linking.openURL("https://peacockai.com/terms")} />
        <LinkRow label="تواصل معنا" icon="📧"
          onPress={() => Linking.openURL("mailto:support@peacockai.com")} />
        <LinkRow label="تقييم التطبيق" icon="⭐"
          onPress={() => Alert.alert("شكراً!", "سيفتح متجر Google Play قريباً.")}
          isLast />
      </View>

      {/* Version */}
      <View style={styles.versionBox}>
        <Text style={styles.versionLogo}>🦚</Text>
        <Text style={styles.versionName}>PeacockAI Assistant</Text>
        <Text style={styles.versionNum}>الإصدار 1.0.0</Text>
        <Text style={styles.versionCopy}>© 2025 PeacockAI · جميع الحقوق محفوظة</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: COLORS.bg },
  pageTitle: {
    fontSize: 26, fontWeight: "900", color: COLORS.textPrimary,
    paddingHorizontal: 20, paddingTop: 60, paddingBottom: 24,
  },
  groupTitle: {
    color: COLORS.textMuted, fontSize: 12, fontWeight: "700",
    paddingHorizontal: 20, marginBottom: 8, textTransform: "uppercase",
  },
  group: {
    backgroundColor: COLORS.bgCard, marginHorizontal: 16,
    borderRadius: 16, marginBottom: 24,
    borderWidth: 1, borderColor: COLORS.bgInput,
    overflow: "hidden",
  },
  row: {
    flexDirection: "row", alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16, paddingVertical: 14,
  },
  rowBorder:    { borderBottomWidth: 1, borderBottomColor: COLORS.bgInput },
  rowLabel:     { color: COLORS.textPrimary, fontSize: 15 },
  linkLeft:     { flexDirection: "row", alignItems: "center", gap: 10 },
  rowIcon:      { fontSize: 18 },
  arrow:        { color: COLORS.textMuted, fontSize: 20 },
  versionBox: {
    alignItems: "center", padding: 28,
    marginBottom: 40,
  },
  versionLogo:  { fontSize: 40, marginBottom: 8 },
  versionName:  { color: COLORS.textPrimary, fontWeight: "800", fontSize: 16 },
  versionNum:   { color: COLORS.textMuted, fontSize: 13, marginTop: 4 },
  versionCopy:  { color: COLORS.textMuted, fontSize: 11, marginTop: 4 },
});
