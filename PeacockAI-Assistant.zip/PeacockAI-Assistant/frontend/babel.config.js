module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: [
    [
      'module-resolver',
      {
        root: ['.'],
        extensions: ['.ios.js', '.android.js', '.js', '.ts', '.tsx', '.json'],
        alias: {
          '@screens': './screens',
          '@components': './components',
          '@utils': './utils',
          '@navigation': './navigation',
        },
      },
    ],
    'react-native-reanimated/plugin',
  ],
};
