// ─────────────────────────────────────────────
// Navigation - نظام التنقل بين الشاشات
// ─────────────────────────────────────────────

import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Icon from "react-native-vector-icons/Feather";
import { COLORS } from "../utils/constants";

// Screens
import SplashScreen    from "../screens/SplashScreen";
import LoginScreen     from "../screens/LoginScreen";
import ChatScreen      from "../screens/ChatScreen";
import DashboardScreen from "../screens/DashboardScreen";
import SettingsScreen  from "../screens/SettingsScreen";
import ImageGenScreen  from "../screens/ImageGenScreen";
import CodeBuilderScreen from "../screens/CodeBuilderScreen";
import FileAnalyzerScreen from "../screens/FileAnalyzerScreen";

const Stack = createStackNavigator();
const Tab   = createBottomTabNavigator();

// ── Bottom Tab Navigator (Main App) ─────────────────
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarStyle: {
          backgroundColor: COLORS.secondary,
          borderTopColor: COLORS.bgInput,
          height: 60,
          paddingBottom: 8,
        },
        tabBarActiveTintColor:   COLORS.accent,
        tabBarInactiveTintColor: COLORS.textMuted,
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          const icons: Record<string, string> = {
            Chat:      "message-circle",
            Dashboard: "user",
            Settings:  "settings",
          };
          return <Icon name={icons[route.name] || "circle"} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Chat"      component={ChatScreen}      options={{ tabBarLabel: "المحادثة" }} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ tabBarLabel: "لوحتي" }} />
      <Tab.Screen name="Settings"  component={SettingsScreen}  options={{ tabBarLabel: "الإعدادات" }} />
    </Tab.Navigator>
  );
}

// ── Root Stack Navigator ─────────────────────────────
export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{ headerShown: false, animationEnabled: true }}
        initialRouteName="Splash"
      >
        <Stack.Screen name="Splash"       component={SplashScreen} />
        <Stack.Screen name="Login"        component={LoginScreen} />
        <Stack.Screen name="Main"         component={MainTabs} />
        <Stack.Screen name="ImageGen"     component={ImageGenScreen} />
        <Stack.Screen name="CodeBuilder"  component={CodeBuilderScreen} />
        <Stack.Screen name="FileAnalyzer" component={FileAnalyzerScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
