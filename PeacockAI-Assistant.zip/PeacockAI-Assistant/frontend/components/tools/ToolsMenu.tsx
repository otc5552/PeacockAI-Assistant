// ─────────────────────────────────────────────
// ToolsMenu.tsx - قائمة الأدوات
// ─────────────────────────────────────────────

import React from "react";
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Dimensions,
} from "react-native";
import Icon from "react-native-vector-icons/Feather";
import { COLORS } from "../../utils/constants";

interface Tool {
  id: string;
  label: string;
  icon: string;
  color: string;
  hint?: string;
}

interface Props {
  tools: Tool[];
  onSelect: (id: string) => void;
}

const { width } = Dimensions.get("window");

export default function ToolsMenu({ tools, onSelect }: Props) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>اختر الأداة</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {tools.map(tool => (
          <TouchableOpacity
            key={tool.id}
            style={[styles.card, { borderColor: tool.color + "50" }]}
            onPress={() => onSelect(tool.id)}
            activeOpacity={0.75}
          >
            <View style={[styles.iconWrap, { backgroundColor: tool.color + "20" }]}>
              <Icon name={tool.icon} size={22} color={tool.color} />
            </View>
            <Text style={styles.label}>{tool.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.secondary,
    borderTopWidth: 1, borderTopColor: COLORS.bgInput,
    paddingVertical: 14, paddingTop: 10,
  },
  title: {
    color: COLORS.textMuted, fontSize: 12,
    paddingHorizontal: 16, marginBottom: 10, fontWeight: "600",
  },
  scroll: { paddingHorizontal: 12, gap: 10 },
  card: {
    width: 76, alignItems: "center", gap: 6,
    backgroundColor: COLORS.bgCard, borderRadius: 16,
    paddingVertical: 12, paddingHorizontal: 8,
    borderWidth: 1,
  },
  iconWrap: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: "center", justifyContent: "center",
  },
  label: {
    color: COLORS.textPrimary, fontSize: 11,
    textAlign: "center", fontWeight: "500",
  },
});
