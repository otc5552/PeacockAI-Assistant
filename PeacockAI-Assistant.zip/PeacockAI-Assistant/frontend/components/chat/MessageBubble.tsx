// ─────────────────────────────────────────────
// MessageBubble.tsx - فقاعة الرسائل
// ─────────────────────────────────────────────

import React, { useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity,
  Clipboard, ToastAndroid,
} from "react-native";
import Markdown from "react-native-markdown-display";
import { COLORS, INTENT_LABELS } from "../../utils/constants";
import { Message } from "../../utils/api";

interface Props { message: Message }

export default function MessageBubble({ message }: Props) {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === "user";

  const copyText = () => {
    Clipboard.setString(message.content);
    ToastAndroid.show("تم النسخ ✓", ToastAndroid.SHORT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
  };

  return (
    <View style={[styles.wrapper, isUser ? styles.wrapperUser : styles.wrapperAI]}>
      {!isUser && (
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>🦚</Text>
        </View>
      )}

      <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAI]}>
        {/* Intent Badge */}
        {!isUser && message.intent && message.intent !== "general" && (
          <View style={styles.intentBadge}>
            <Text style={styles.intentText}>
              {INTENT_LABELS[message.intent] || message.intent}
            </Text>
          </View>
        )}

        {/* Content */}
        {isUser ? (
          <Text style={styles.userText}>{message.content}</Text>
        ) : (
          <Markdown style={markdownStyles}>{message.content}</Markdown>
        )}

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.timestamp}>{formatTime(message.timestamp)}</Text>
          {!isUser && (
            <TouchableOpacity onPress={copyText} style={styles.copyBtn}>
              <Text style={styles.copyText}>{copied ? "✓ تم" : "نسخ"}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: "row", marginVertical: 6, maxWidth: "90%",
  },
  wrapperUser: { alignSelf: "flex-end", flexDirection: "row-reverse" },
  wrapperAI:   { alignSelf: "flex-start" },
  avatar: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: COLORS.bgCard, alignItems: "center",
    justifyContent: "center", marginRight: 8, alignSelf: "flex-end",
  },
  avatarText: { fontSize: 16 },
  bubble: {
    borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10,
    maxWidth: "100%", elevation: 1,
  },
  bubbleUser: {
    backgroundColor: COLORS.accent, borderBottomRightRadius: 4,
  },
  bubbleAI: {
    backgroundColor: COLORS.bgCard, borderBottomLeftRadius: 4,
    borderWidth: 1, borderColor: COLORS.bgInput,
  },
  intentBadge: {
    backgroundColor: COLORS.bgInput, borderRadius: 10,
    paddingHorizontal: 8, paddingVertical: 2, alignSelf: "flex-start",
    marginBottom: 6,
  },
  intentText: { fontSize: 11, color: COLORS.accent, fontWeight: "600" },
  userText:   { color: COLORS.primary, fontSize: 15, lineHeight: 22, textAlign: "right" },
  footer: {
    flexDirection: "row", justifyContent: "flex-end",
    alignItems: "center", marginTop: 6, gap: 8,
  },
  timestamp: { fontSize: 10, color: COLORS.textMuted },
  copyBtn:   { paddingHorizontal: 6, paddingVertical: 2 },
  copyText:  { fontSize: 11, color: COLORS.textMuted },
});

const markdownStyles = {
  body:       { color: COLORS.textPrimary, fontSize: 15, lineHeight: 24 },
  code_block: {
    backgroundColor: COLORS.bg, borderRadius: 8, padding: 12,
    color: "#A8FF78", fontFamily: "monospace", fontSize: 13,
  },
  code_inline: {
    backgroundColor: COLORS.bgInput, borderRadius: 4,
    color: "#A8FF78", fontFamily: "monospace",
  },
  heading1:   { color: COLORS.accent, fontWeight: "800" as const },
  heading2:   { color: COLORS.accent, fontWeight: "700" as const },
  strong:     { color: COLORS.textPrimary, fontWeight: "700" as const },
  bullet_list_icon: { color: COLORS.accent },
};
