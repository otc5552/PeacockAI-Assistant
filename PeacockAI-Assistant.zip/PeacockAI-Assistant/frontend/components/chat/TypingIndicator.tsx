/**
 * TypingIndicator — Animated "AI is typing" dots
 */

import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { COLORS } from '../../utils/constants';

export default function TypingIndicator() {
  const dots = [useRef(new Animated.Value(0)).current,
                useRef(new Animated.Value(0)).current,
                useRef(new Animated.Value(0)).current];

  useEffect(() => {
    const animations = dots.map((anim, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 160),
          Animated.timing(anim, { toValue: -6, duration: 300, useNativeDriver: true }),
          Animated.timing(anim, { toValue:  0, duration: 300, useNativeDriver: true }),
          Animated.delay(480 - i * 160),
        ])
      )
    );
    animations.forEach(a => a.start());
    return () => animations.forEach(a => a.stop());
  }, []);

  return (
    <View style={styles.wrapper}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>🦚</Text>
      </View>
      <View style={styles.bubble}>
        <Text style={styles.label}>Peacock يكتب</Text>
        <View style={styles.dotsRow}>
          {dots.map((anim, i) => (
            <Animated.View key={i} style={[styles.dot, { transform: [{ translateY: anim }] }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginVertical: 6,
    marginHorizontal: 16,
    gap: 8,
  },
  avatar: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: COLORS.bgCard,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 16 },
  bubble: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    borderRadius: 18,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 10,
    borderWidth: 1,
    borderColor: COLORS.bgInput,
  },
  label:   { color: COLORS.textMuted, fontSize: 12 },
  dotsRow: { flexDirection: 'row', gap: 4, alignItems: 'center' },
  dot: {
    width: 7, height: 7, borderRadius: 3.5,
    backgroundColor: COLORS.accent,
  },
});
