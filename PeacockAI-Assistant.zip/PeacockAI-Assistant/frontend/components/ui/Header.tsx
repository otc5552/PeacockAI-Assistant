/**
 * Header — Reusable screen header with back button
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { COLORS } from '../../utils/constants';

interface Props {
  title:        string;
  subtitle?:    string;
  onBack?:      () => void;
  rightElement?: React.ReactNode;
}

export default function Header({ title, subtitle, onBack, rightElement }: Props) {
  return (
    <View style={styles.header}>
      <View style={styles.left}>
        {onBack && (
          <TouchableOpacity onPress={onBack} style={styles.backBtn} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
            <Text style={styles.backIcon}>‹</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.center}>
        <Text style={styles.title} numberOfLines={1}>{title}</Text>
        {subtitle && <Text style={styles.subtitle} numberOfLines={1}>{subtitle}</Text>}
      </View>

      <View style={styles.right}>
        {rightElement || <View style={{ width: 40 }} />}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingTop: 50,
    paddingBottom: 12,
    backgroundColor: COLORS.secondary,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.bgInput,
  },
  left:    { width: 44 },
  center:  { flex: 1, alignItems: 'center' },
  right:   { width: 44, alignItems: 'flex-end' },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  backIcon:{ color: COLORS.accent, fontSize: 30, fontWeight: '300', lineHeight: 34 },
  title:   { fontSize: 17, fontWeight: '700', color: COLORS.textPrimary },
  subtitle:{ fontSize: 12, color: COLORS.textMuted, marginTop: 1 },
});
