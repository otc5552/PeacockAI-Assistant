/**
 * useChat — Custom hook for all chat state & logic
 * Separates business logic from ChatScreen UI
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import { FlatList, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import uuid from 'react-native-uuid';
import { sendMessage, sendMessageWithFile, Message } from '../utils/api';

const WELCOME_MESSAGE: Message = {
  id: 'welcome',
  role: 'assistant',
  content:
    'مرحباً! أنا Peacock 🦚 مساعدك الذكي الشامل.\n\n' +
    'يمكنني مساعدتك في:\n' +
    '• 💻 البرمجة وإنشاء التطبيقات\n' +
    '• 🎨 توليد الصور\n' +
    '• 🔎 البحث في الإنترنت\n' +
    '• 📄 تحليل الملفات\n' +
    '• ✍️ كتابة المقالات\n' +
    '• 🧮 حل المسائل الرياضية\n\n' +
    'اضغط (+) لرؤية جميع الأدوات المتاحة.',
  timestamp: new Date().toISOString(),
};

export function useChat(sessionId: string) {
  const [messages, setMessages]         = useState<Message[]>([WELCOME_MESSAGE]);
  const [input, setInput]               = useState('');
  const [loading, setLoading]           = useState(false);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [userId, setUserId]             = useState('');
  const flatListRef                     = useRef<FlatList>(null);

  useEffect(() => {
    AsyncStorage.getItem('userId').then(id => setUserId(id || ''));
  }, []);

  const scrollToBottom = () => {
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const resetChat = useCallback(() => {
    setMessages([{
      ...WELCOME_MESSAGE,
      id: uuid.v4() as string,
      content: 'محادثة جديدة 🦚 كيف يمكنني مساعدتك؟',
      timestamp: new Date().toISOString(),
    }]);
    setSelectedTool(null);
    setInput('');
  }, []);

  const buildHistory = useCallback(() => {
    return messages
      .filter(m => m.id !== 'welcome')
      .slice(-12)
      .map(m => ({ role: m.role, content: m.content }));
  }, [messages]);

  const addMessage = useCallback((msg: Message) => {
    setMessages(prev => [...prev, msg]);
  }, []);

  const send = useCallback(async (fileOverride?: { uri: string; name: string; type: string }) => {
    const text = input.trim();
    if (!text && !fileOverride) return;
    if (loading) return;

    const userMsg: Message = {
      id: uuid.v4() as string,
      role: 'user',
      content: text || (fileOverride?.name ? `📎 ${fileOverride.name}` : ''),
      timestamp: new Date().toISOString(),
    };

    addMessage(userMsg);
    setInput('');
    setLoading(true);

    try {
      let response;

      if (fileOverride) {
        response = await sendMessageWithFile({
          message:   text || 'حلل هذا الملف',
          sessionId,
          userId,
          toolHint:  selectedTool || undefined,
          file:      fileOverride,
        });
      } else {
        response = await sendMessage({
          message:   text,
          sessionId,
          userId,
          toolHint:  selectedTool || undefined,
          history:   buildHistory(),
        });
      }

      const aiMsg: Message = {
        id:        uuid.v4() as string,
        role:      'assistant',
        content:   response.message,
        intent:    response.intent,
        timestamp: new Date().toISOString(),
        data:      response.data,
      };

      addMessage(aiMsg);
      setSelectedTool(null);
      scrollToBottom();

      return response; // caller can check intent for navigation
    } catch (err: any) {
      addMessage({
        id:        uuid.v4() as string,
        role:      'assistant',
        content:   '⚠️ تعذّر الاتصال بالخادم. تأكد من تشغيل الـ Backend وحاول مجدداً.',
        timestamp: new Date().toISOString(),
      });
    } finally {
      setLoading(false);
      scrollToBottom();
    }
  }, [input, loading, sessionId, userId, selectedTool, buildHistory, addMessage]);

  return {
    messages, input, loading, selectedTool, userId,
    flatListRef,
    setInput, setSelectedTool, resetChat, send,
  };
}
