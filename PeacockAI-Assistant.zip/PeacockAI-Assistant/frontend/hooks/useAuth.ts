/**
 * useAuth — Firebase authentication state hook
 */

import { useState, useEffect } from 'react';
import auth, { FirebaseAuthTypes } from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { saveFirebaseToken, clearToken } from '../utils/api';

export interface AuthUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string | null;
}

export function useAuth() {
  const [user, setUser]           = useState<AuthUser | null>(null);
  const [initializing, setInit]   = useState(true);

  useEffect(() => {
    const unsubscribe = auth().onAuthStateChanged(async (firebaseUser: FirebaseAuthTypes.User | null) => {
      if (firebaseUser) {
        const token = await firebaseUser.getIdToken();
        await saveFirebaseToken(token);
        await AsyncStorage.setItem('userId',    firebaseUser.uid);
        await AsyncStorage.setItem('userEmail', firebaseUser.email || '');
        await AsyncStorage.setItem('userName',  firebaseUser.displayName || '');

        setUser({
          uid:         firebaseUser.uid,
          email:       firebaseUser.email || '',
          displayName: firebaseUser.displayName || '',
          photoURL:    firebaseUser.photoURL,
        });
      } else {
        await clearToken();
        setUser(null);
      }
      setInit(false);
    });

    return unsubscribe;
  }, []);

  const signOut = async () => {
    await auth().signOut();
    await clearToken();
    await AsyncStorage.multiRemove(['userId', 'userEmail', 'userName']);
  };

  const refreshToken = async () => {
    const current = auth().currentUser;
    if (current) {
      const token = await current.getIdToken(true); // force refresh
      await saveFirebaseToken(token);
    }
  };

  return { user, initializing, signOut, refreshToken };
}
