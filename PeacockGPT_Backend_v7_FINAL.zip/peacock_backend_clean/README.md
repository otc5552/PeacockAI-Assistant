# 🦚 PeacockGPT v7 — Backend API
**Production-Ready FastAPI Backend**
**Author: PeacockAI – Mostafa**

---

## 📁 Project Structure

```
backend/
├── app/
│   ├── main.py              ← FastAPI entry point
│   ├── core/
│   │   ├── config.py        ← App config, models, plans, pricing
│   │   ├── database.py      ← SQLAlchemy models (17 tables)
│   │   └── security.py      ← JWT + PBKDF2 + Rate limiting
│   ├── routes/
│   │   ├── auth.py          ← Register / Login / Me
│   │   ├── chat.py          ← Streaming chat endpoint
│   │   ├── agent_routes.py  ← Agent Plan/Confirm/Execute + Files
│   │   ├── workflow_routes.py← Workflows + Documents + Integrations
│   │   ├── payment_routes.py ← Stripe + PayPal + Manual
│   │   ├── admin_dashboard.py← Admin UI + API
│   │   └── all_routes.py    ← Conversations + Memory + Misc
│   ├── services/
│   │   ├── llm.py           ← AI calls (Groq + Gemini + fallback)
│   │   ├── agent.py         ← Multi-step agent (Human Control)
│   │   ├── memory.py        ← 3-layer memory + semantic search
│   │   ├── vector_cache.py  ← Semantic cache (embeddings)
│   │   ├── orchestrator.py  ← Full request pipeline
│   │   ├── document_service.py ← DOCX + PPTX + PDF generation
│   │   ├── workflow_engine.py  ← n8n-like workflow system
│   │   ├── integrations_service.py ← HTTP/Webhook/Telegram/etc
│   │   ├── payment_service.py  ← Stripe + PayPal + Manual
│   │   ├── file_manager.py     ← Sandboxed file operations
│   │   └── remote_build_service.py ← Android project builder
│   ├── models/
│   │   └── payment_models.py   ← Payment DB models
│   ├── schemas/
│   │   └── payment_schemas.py  ← Payment Pydantic schemas
│   └── workers/
│       └── jobs.py             ← Background job queue
├── tests/
├── scripts/
├── .env                 ← ⚠️ Fill in your values
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── README.md
```

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure .env
```bash
cp .env .env.local
# Edit .env with your values:
# - SECRET_KEY (random 64 chars)
# - ADMIN_TOKEN (your admin password)
# - STRIPE_SECRET_KEY (from stripe.com)
# - PAYPAL_CLIENT_ID (from developer.paypal.com)
```

### 3. Run
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. Docker
```bash
docker-compose up -d
```

---

## 📡 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /users/register | تسجيل مستخدم جديد |
| POST | /users/login | تسجيل دخول |
| GET  | /users/me | بيانات المستخدم |

### Chat
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /chat/stream | Streaming AI chat (SSE) |

### Payment 💰
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | /payments/plans | خطط الأسعار |
| POST | /payments/checkout | إنشاء checkout (Stripe/PayPal/Manual) |
| POST | /payments/paypal/capture | تأكيد دفع PayPal |
| POST | /payments/webhook/stripe | Stripe webhook |
| GET  | /payments/subscription | حالة الاشتراك |
| DELETE | /payments/subscription | إلغاء الاشتراك |
| GET  | /payments/orders | سجل المدفوعات |

### Agent (Pro only)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /agent/plan | تخطيط مهمة (بدون تنفيذ) |
| POST | /agent/confirm | تنفيذ بعد التأكيد |
| GET  | /agent/pending | المهام المنتظرة |

### Documents
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /documents/docx | إنشاء Word |
| POST | /documents/pptx | إنشاء PowerPoint |
| POST | /documents/pdf | إنشاء PDF |
| GET  | /documents/download/{id} | تحميل ملف |

### Workflows
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | /workflows/templates | Templates جاهزة |
| POST | /workflows | إنشاء workflow |
| POST | /workflows/{id}/run | تشغيل workflow (SSE) |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | /admin/ | Admin Dashboard UI |
| GET  | /admin/stats | إحصائيات النظام |
| POST | /payments/admin/confirm-manual | تأكيد دفع يدوي |
| GET  | /payments/admin/revenue | إحصائيات الإيرادات |

---

## 💰 Payment Integration

### Stripe Setup
1. اذهب إلى **dashboard.stripe.com**
2. احصل على `Secret Key` و `Webhook Secret`
3. أنشئ Products + Prices للخطط
4. أضف الـ Price IDs في `.env`
5. أضف Webhook URL: `https://yourapi.com/payments/webhook/stripe`

### PayPal Setup
1. اذهب إلى **developer.paypal.com**
2. أنشئ App → احصل على Client ID + Secret
3. أضفهم في `.env`
4. غيّر `PAYPAL_MODE=live` للإنتاج

### Manual Payment (EGP)
- المستخدم يختار Manual
- النظام يعطيه رقم مرجعي + تعليمات التحويل
- الأدمن يؤكد من `/payments/admin/confirm-manual`

---

## 🔐 Security

- **Passwords**: PBKDF2-HMAC-SHA256 (100,000 iterations)
- **JWT**: HS256 with JTI (anti-replay)
- **Rate Limiting**: sliding window per IP
- **Input Validation**: Pydantic + custom validators
- **Agent Sandbox**: path escape impossible
- **SSRF Protection**: on all HTTP integrations

---

## 📊 Admin Dashboard

اذهب إلى: `http://localhost:8000/admin`

Token: ما وضعته في `ADMIN_TOKEN`

**أو مباشرة من URL:**
`http://localhost:8000/admin#YOUR_ADMIN_TOKEN`

---

## 🗃️ Database Tables (17 tables)

Users, Sessions, Conversations, Messages, SemCache,
UserMemory, MemoryEpisode, MemoryVector, CacheEntry,
Logs, FeatureFlags, Analytics, Jobs, Onboarding,
Suggestions, AgentTasks, PendingActions, PdfRecords

---

**PeacockAI © 2025 — Mostafa**
