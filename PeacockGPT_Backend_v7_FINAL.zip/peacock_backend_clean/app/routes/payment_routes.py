"""
routes/payment_routes.py — Payment Endpoints v7
Stripe + PayPal + Manual + Admin confirm
Author: PeacockAI – Mostafa
"""
from fastapi import APIRouter, HTTPException, Header, Request, Body
from fastapi.responses import JSONResponse
from pydantic import BaseModel, validator
from typing import Optional

from core.security import verify_token
from core.database import get_db, User
from core.config import PRICING, PLANS, log

router = APIRouter(prefix="/payments", tags=["payments"])

# ── Auth ─────────────────────────────────────────────────────────
def _auth(x_token: Optional[str]) -> dict:
    if not x_token: raise HTTPException(401, "سجل دخولك أولاً")
    p = verify_token(x_token)
    if not p:       raise HTTPException(401, "Token غير صالح")
    try:
        with get_db() as db:
            u = db.query(User).filter_by(id=p["sub"]).first()
            if u: return {"id":u.id,"plan":u.plan or "free","email":u.email}
    except Exception: pass
    raise HTTPException(401, "مستخدم غير موجود")

def _admin_auth(x_admin_token: Optional[str] = Header(None)):
    import os
    ADMIN = os.getenv("ADMIN_TOKEN","peacockai_admin_2025_secret")
    if not x_admin_token or x_admin_token != ADMIN:
        raise HTTPException(403, "⛔ Admin access denied")


# ══════════════════════════════════════════════════════════════════
# SCHEMAS
# ══════════════════════════════════════════════════════════════════

class CheckoutReq(BaseModel):
    plan:        str
    period:      str = "monthly"   # monthly | yearly
    method:      str = "stripe"    # stripe | paypal | manual
    currency:    str = "usd"       # usd | egp
    success_url: str = ""
    cancel_url:  str = ""

    @validator("plan")
    def plan_valid(cls, v):
        if v not in ("plus","pro"): raise ValueError("الخطة يجب أن تكون plus أو pro")
        return v
    @validator("period")
    def period_valid(cls, v):
        if v not in ("monthly","yearly"): raise ValueError("monthly أو yearly فقط")
        return v
    @validator("method")
    def method_valid(cls, v):
        if v not in ("stripe","paypal","manual"): raise ValueError("stripe | paypal | manual")
        return v


# ══════════════════════════════════════════════════════════════════
# GET PLANS & PRICING
# ══════════════════════════════════════════════════════════════════

@router.get("/plans")
def get_plans():
    """Get all plans with pricing and features."""
    result = {}
    for plan_id, plan_data in PLANS.items():
        pricing = PRICING.get(plan_id, {})
        result[plan_id] = {
            "id":       plan_id,
            "name":     pricing.get("label", plan_id.title()),
            "price":    {"egp": pricing.get("egp",0), "usd": pricing.get("usd",0)},
            "yearly":   {"egp": pricing.get("egp",0)*10, "usd": pricing.get("usd",0)*10},
            "limits": {
                "messages":   plan_data.get("msg", 0),
                "images":     plan_data.get("img", 0),
                "searches":   plan_data.get("search", 0),
                "pdfs":       plan_data.get("pdf", 0),
                "agent_ops":  plan_data.get("agent_ops", 0),
            },
            "features": {
                "agent":      plan_data.get("agent", False),
                "models":     plan_data.get("models", []),
            }
        }
    return result


# ══════════════════════════════════════════════════════════════════
# CREATE CHECKOUT
# ══════════════════════════════════════════════════════════════════

@router.post("/checkout")
async def create_checkout(req: CheckoutReq,
                           x_token: Optional[str] = Header(None)):
    """
    Create a payment checkout session.
    Returns checkout_url for Stripe/PayPal or instructions for manual.
    """
    user = _auth(x_token)

    if user["plan"] == req.plan:
        raise HTTPException(400, f"أنت مشترك بالفعل في خطة {req.plan}")

    from services.payment_service import (
        create_stripe_checkout, create_paypal_order, create_manual_order
    )

    try:
        if req.method == "stripe":
            result = await create_stripe_checkout(
                user["id"], req.plan, req.period,
                req.success_url, req.cancel_url
            )
        elif req.method == "paypal":
            result = await create_paypal_order(user["id"], req.plan, req.period)
        elif req.method == "manual":
            result = create_manual_order(user["id"], req.plan, req.period)
        else:
            raise HTTPException(400, "طريقة دفع غير صالحة")

        return result

    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


# ══════════════════════════════════════════════════════════════════
# PAYPAL CAPTURE
# ══════════════════════════════════════════════════════════════════

@router.post("/paypal/capture")
async def paypal_capture(data: dict, x_token: Optional[str] = Header(None)):
    """Capture PayPal payment after user approves."""
    user = _auth(x_token)
    paypal_order_id = data.get("paypal_order_id","")
    our_order_id    = data.get("order_id","")
    if not paypal_order_id or not our_order_id:
        raise HTTPException(400, "paypal_order_id و order_id مطلوبان")
    from services.payment_service import capture_paypal_order, get_order
    order = get_order(our_order_id)
    if not order or order["user_id"] != user["id"]:
        raise HTTPException(403, "⛔ ليس لديك صلاحية على هذا الطلب")
    return await capture_paypal_order(paypal_order_id, our_order_id)


# ══════════════════════════════════════════════════════════════════
# STRIPE WEBHOOK
# ══════════════════════════════════════════════════════════════════

@router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    """Receive Stripe webhook events."""
    payload    = await request.body()
    sig_header = request.headers.get("stripe-signature","")
    try:
        from services.payment_service import handle_stripe_webhook
        result = handle_stripe_webhook(payload, sig_header)
        return result
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        log.error(f"[StripeWebhook] {e}")
        raise HTTPException(500, str(e))


# ══════════════════════════════════════════════════════════════════
# SUBSCRIPTION STATUS
# ══════════════════════════════════════════════════════════════════

@router.get("/subscription")
def get_subscription(x_token: Optional[str] = Header(None)):
    """Get current user subscription status."""
    user = _auth(x_token)
    from services.payment_service import get_subscription_status
    return get_subscription_status(user["id"])


@router.delete("/subscription")
def cancel_sub(x_token: Optional[str] = Header(None)):
    """Cancel subscription (takes effect at period end)."""
    user = _auth(x_token)
    from services.payment_service import cancel_subscription
    try:
        return cancel_subscription(user["id"])
    except Exception as e:
        raise HTTPException(500, str(e))


# ══════════════════════════════════════════════════════════════════
# ORDER HISTORY
# ══════════════════════════════════════════════════════════════════

@router.get("/orders")
def get_orders(x_token: Optional[str] = Header(None)):
    """Get user's payment order history."""
    user = _auth(x_token)
    from services.payment_service import get_user_orders
    orders = get_user_orders(user["id"])
    # Return safe version (no sensitive data)
    return {"orders": [{
        "id":         o["id"],
        "plan":       o["plan"],
        "period":     o["period"],
        "method":     o["method"],
        "amount":     o["amount"],
        "currency":   o["currency"],
        "status":     o["status"],
        "created_at": o["created_at"],
        "paid_at":    o.get("paid_at"),
        "expires_at": o.get("expires_at"),
        "reference":  o.get("reference"),  # for manual payments
    } for o in orders]}


# ══════════════════════════════════════════════════════════════════
# ADMIN ENDPOINTS
# ══════════════════════════════════════════════════════════════════

@router.post("/admin/confirm-manual")
def admin_confirm_manual(data: dict,
                          x_admin_token: Optional[str] = Header(None)):
    """Admin confirms a manual payment (EGP / bank transfer)."""
    _admin_auth(x_admin_token)
    order_id = data.get("order_id","")
    note     = data.get("note","")
    if not order_id: raise HTTPException(400, "order_id مطلوب")
    from services.payment_service import admin_confirm_manual_payment
    try:
        return admin_confirm_manual_payment(order_id, note)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/admin/orders")
def admin_all_orders(limit: int = 100,
                      x_admin_token: Optional[str] = Header(None)):
    """Admin: list all orders."""
    _admin_auth(x_admin_token)
    from services.payment_service import _orders
    orders = sorted(_orders.values(), key=lambda o: o["created_at"], reverse=True)[:limit]
    return {"orders": orders, "total": len(_orders)}


@router.get("/admin/revenue")
def admin_revenue(x_admin_token: Optional[str] = Header(None)):
    """Admin: get revenue statistics."""
    _admin_auth(x_admin_token)
    from services.payment_service import get_revenue_stats
    return get_revenue_stats()


@router.post("/admin/refund/{order_id}")
async def admin_refund(order_id: str,
                        data: dict = Body(default={}),
                        x_admin_token: Optional[str] = Header(None)):
    """Admin: refund a Stripe payment."""
    _admin_auth(x_admin_token)
    from services.payment_service import refund_stripe
    try:
        return await refund_stripe(order_id, data.get("reason",""))
    except Exception as e:
        raise HTTPException(500, str(e))
