"""
routes/workflow_routes.py — Workflow + Integrations + Document Routes v7
All endpoints for the 3 new systems
Author: PeacockAI – Mostafa
"""
import json
from fastapi import APIRouter, HTTPException, Header, Request
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel, validator
from typing import Optional, List, Dict, Any

from core.config import FLAGS, PLANS, log
from core.security import verify_token, check_rate_limit
from core.database import get_db, User

router = APIRouter(tags=["workflows"])

# ── Auth ─────────────────────────────────────────────────────────
def _auth(x_token: Optional[str]) -> dict:
    if not x_token: raise HTTPException(401, "سجل دخولك أولاً")
    p = verify_token(x_token)
    if not p: raise HTTPException(401, "Token غير صالح")
    try:
        with get_db() as db:
            u = db.query(User).filter_by(id=p["sub"]).first()
            if u: return {"id":u.id,"plan":u.plan or "free","name":u.name}
    except Exception: pass
    raise HTTPException(401, "مستخدم غير موجود")


# ══════════════════════════════════════════════════════════════════
# DOCUMENT GENERATION ROUTES
# ══════════════════════════════════════════════════════════════════

class DocRequest(BaseModel):
    content: str
    title:   str = "مستند"
    style:   str = "professional"  # professional|dark|elegant|colorful

    @validator("content")
    def not_empty(cls, v):
        if not v.strip(): raise ValueError("المحتوى مطلوب")
        return v

class PptxRequest(BaseModel):
    content: str
    title:   str = "عرض تقديمي"
    theme:   str = "dark"  # dark|light|gradient|corporate

class SlidesRequest(BaseModel):
    slides: List[Dict]
    title:  str = "عرض تقديمي"
    theme:  str = "dark"


@router.post("/documents/docx")
async def gen_docx(req: DocRequest, x_token: Optional[str] = Header(None)):
    """Generate professional Word .docx file."""
    user = _auth(x_token)
    from services.document_service import content_to_docx, check_doc_quota
    ok, msg = check_doc_quota(user["id"], user["plan"], "docx")
    if not ok: raise HTTPException(403, msg)
    try:
        data = content_to_docx(req.content, req.title, req.style)
        safe = req.title[:25].replace(" ","_")
        return Response(content=data,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition":f'attachment; filename="{safe}.docx"'})
    except RuntimeError as e: raise HTTPException(503, str(e))
    except Exception as e:    raise HTTPException(500, f"خطأ DOCX: {e}")


@router.post("/documents/pptx")
async def gen_pptx(req: PptxRequest, x_token: Optional[str] = Header(None)):
    """Generate professional PowerPoint .pptx file."""
    user = _auth(x_token)
    from services.document_service import content_to_pptx, check_doc_quota
    ok, msg = check_doc_quota(user["id"], user["plan"], "pptx")
    if not ok: raise HTTPException(403, msg)
    try:
        data = content_to_pptx(req.content, req.title, req.theme)
        safe = req.title[:25].replace(" ","_")
        return Response(content=data,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition":f'attachment; filename="{safe}.pptx"'})
    except RuntimeError as e: raise HTTPException(503, str(e))
    except Exception as e:    raise HTTPException(500, f"خطأ PPTX: {e}")


@router.post("/documents/pptx/slides")
async def gen_pptx_slides(req: SlidesRequest, x_token: Optional[str] = Header(None)):
    """Generate PPTX from structured slides data."""
    user = _auth(x_token)
    from services.document_service import generate_pptx, check_doc_quota
    ok, msg = check_doc_quota(user["id"], user["plan"], "pptx")
    if not ok: raise HTTPException(403, msg)
    try:
        data = generate_pptx(req.slides, req.title, req.theme)
        safe = req.title[:25].replace(" ","_")
        return Response(content=data,
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={"Content-Disposition":f'attachment; filename="{safe}.pptx"'})
    except Exception as e: raise HTTPException(500, str(e))


@router.post("/documents/pdf")
async def gen_pdf_adv(req: DocRequest, x_token: Optional[str] = Header(None)):
    """Generate multi-page PDF with full formatting."""
    user = _auth(x_token)
    from services.document_service import content_to_pdf, check_doc_quota
    ok, msg = check_doc_quota(user["id"], user["plan"], "pdf")
    if not ok: raise HTTPException(403, msg)
    try:
        data = content_to_pdf(req.content, req.title)
        safe = req.title[:25].replace(" ","_")
        return Response(content=data, media_type="application/pdf",
            headers={"Content-Disposition":f'attachment; filename="{safe}.pdf"'})
    except Exception as e: raise HTTPException(500, f"خطأ PDF: {e}")


@router.get("/documents/download/{file_id}")
def download_file(file_id: str, x_token: Optional[str] = Header(None)):
    """Download a generated document."""
    user = _auth(x_token)
    from services.workflow_engine import get_file
    f = get_file(file_id, user["id"])
    if not f: raise HTTPException(404, "الملف غير موجود أو انتهت صلاحيته")
    ext = f["ext"]
    media_types = {
        "docx":"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "pptx":"application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "pdf": "application/pdf",
        "zip": "application/zip",
    }
    return Response(content=f["data"],
        media_type=media_types.get(ext,"application/octet-stream"),
        headers={"Content-Disposition":f'attachment; filename="peacock_{file_id[:8]}.{ext}"'})


# ══════════════════════════════════════════════════════════════════
# WORKFLOW ROUTES
# ══════════════════════════════════════════════════════════════════

class WorkflowCreateReq(BaseModel):
    name:           str
    description:    str = ""
    trigger:        str = "manual"
    trigger_config: dict = {}
    steps:          List[dict]

    @validator("name")
    def name_ok(cls, v):
        if not v.strip(): raise ValueError("الاسم مطلوب")
        return v.strip()

    @validator("steps")
    def steps_ok(cls, v):
        if not v: raise ValueError("يجب أن يحتوي Workflow على خطوة واحدة على الأقل")
        return v


class WorkflowRunReq(BaseModel):
    input_data: dict = {}


@router.get("/workflows/templates")
def wf_templates(x_token: Optional[str] = Header(None)):
    """Get all built-in workflow templates."""
    _auth(x_token)
    from services.workflow_engine import TEMPLATES
    return {"templates": TEMPLATES}


@router.post("/workflows")
def wf_create(req: WorkflowCreateReq, x_token: Optional[str] = Header(None)):
    """Create and save a new workflow."""
    user = _auth(x_token)
    from services.workflow_engine import create_workflow
    try:
        wf = create_workflow(user["id"], user["plan"], req.dict())
        return wf
    except PermissionError as e: raise HTTPException(403, str(e))
    except Exception as e:       raise HTTPException(500, str(e))


@router.get("/workflows")
def wf_list(x_token: Optional[str] = Header(None)):
    """List all user workflows."""
    user = _auth(x_token)
    from services.workflow_engine import list_workflows
    return {"workflows": list_workflows(user["id"])}


@router.get("/workflows/{wf_id}")
def wf_get(wf_id: str, x_token: Optional[str] = Header(None)):
    """Get a specific workflow."""
    user = _auth(x_token)
    from services.workflow_engine import get_workflow
    wf = get_workflow(wf_id, user["id"])
    if not wf: raise HTTPException(404, "Workflow غير موجود")
    return wf


@router.patch("/workflows/{wf_id}")
def wf_update(wf_id: str, data: dict, x_token: Optional[str] = Header(None)):
    """Update a workflow."""
    user = _auth(x_token)
    from services.workflow_engine import update_workflow
    wf = update_workflow(wf_id, user["id"], data)
    if not wf: raise HTTPException(404, "Workflow غير موجود")
    return wf


@router.delete("/workflows/{wf_id}")
def wf_delete(wf_id: str, x_token: Optional[str] = Header(None)):
    """Delete a workflow."""
    user = _auth(x_token)
    from services.workflow_engine import delete_workflow
    if not delete_workflow(wf_id, user["id"]): raise HTTPException(404, "Workflow غير موجود")
    return {"ok": True}


@router.post("/workflows/{wf_id}/run")
async def wf_run(wf_id: str, req: WorkflowRunReq,
                 x_token: Optional[str] = Header(None),
                 x_groq_key: Optional[str] = Header(None),
                 x_gemini_key: Optional[str] = Header(None)):
    """Run a workflow (SSE streaming)."""
    user = _auth(x_token)

    # Rate limit: 20 runs/hour
    allowed, _ = check_rate_limit(f"wf_run:{user['id']}", max_calls=20, window_s=3600)
    if not allowed: raise HTTPException(429, "تجاوزت حد تشغيل Workflows. انتظر ساعة.")

    from services.workflow_engine import run_workflow
    return StreamingResponse(
        run_workflow(wf_id, user["id"], user["plan"],
                     req.input_data, x_groq_key or "", x_gemini_key or ""),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"}
    )


@router.post("/workflows/template/{template_id}/run")
async def wf_run_template(template_id: str, req: WorkflowRunReq,
                           x_token: Optional[str] = Header(None),
                           x_groq_key: Optional[str] = Header(None),
                           x_gemini_key: Optional[str] = Header(None)):
    """Run a built-in template directly (creates temp workflow + runs it)."""
    user = _auth(x_token)
    from services.workflow_engine import TEMPLATES, create_workflow, run_workflow
    tmpl = next((t for t in TEMPLATES if t["id"] == template_id), None)
    if not tmpl: raise HTTPException(404, f"Template '{template_id}' غير موجود")

    # Create temp workflow from template
    try:
        wf = create_workflow(user["id"], user["plan"], tmpl)
    except PermissionError as e:
        raise HTTPException(403, str(e))

    return StreamingResponse(
        run_workflow(wf["id"], user["id"], user["plan"],
                     req.input_data, x_groq_key or "", x_gemini_key or ""),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"}
    )


@router.get("/workflows/{wf_id}/runs")
def wf_runs(wf_id: str, x_token: Optional[str] = Header(None)):
    """Get run history for a workflow."""
    user = _auth(x_token)
    from services.workflow_engine import get_workflow_runs
    return {"runs": get_workflow_runs(wf_id, user["id"])}


# ══════════════════════════════════════════════════════════════════
# INTEGRATIONS ROUTES
# ══════════════════════════════════════════════════════════════════

class IntegrationReq(BaseModel):
    name:   str
    type:   str
    config: dict

    @validator("type")
    def type_valid(cls, v):
        from services.integrations_service import INTEGRATION_TYPES
        if v not in INTEGRATION_TYPES: raise ValueError(f"نوع غير صالح: {v}")
        return v


@router.get("/integrations/types")
def int_types(x_token: Optional[str] = Header(None)):
    """List all supported integration types."""
    _auth(x_token)
    from services.integrations_service import INTEGRATION_TYPES
    return {"types": INTEGRATION_TYPES}


@router.post("/integrations")
def int_create(req: IntegrationReq, x_token: Optional[str] = Header(None)):
    """Save a new integration connector."""
    user = _auth(x_token)
    from services.integrations_service import save_integration
    result = save_integration(user["id"], req.type, req.name, req.config)
    return result


@router.get("/integrations")
def int_list(x_token: Optional[str] = Header(None)):
    """List user's saved integrations."""
    user = _auth(x_token)
    from services.integrations_service import list_integrations
    return {"integrations": list_integrations(user["id"])}


@router.delete("/integrations/{int_id}")
def int_delete(int_id: str, x_token: Optional[str] = Header(None)):
    """Delete an integration."""
    user = _auth(x_token)
    from services.integrations_service import delete_integration
    if not delete_integration(int_id, user["id"]): raise HTTPException(404, "Integration غير موجود")
    return {"ok": True}


@router.post("/integrations/{int_id}/test")
async def int_test(int_id: str, x_token: Optional[str] = Header(None)):
    """Test a saved integration."""
    user = _auth(x_token)
    from services.integrations_service import test_integration
    result = await test_integration(int_id, user["id"])
    return result


@router.post("/integrations/call-api")
async def call_api_direct(data: dict, x_token: Optional[str] = Header(None)):
    """Make a direct API call (no saved integration needed)."""
    user = _auth(x_token)
    from services.integrations_service import call_api
    url    = data.get("url","")
    method = data.get("method","GET")
    if not url: raise HTTPException(400, "URL مطلوب")
    result = await call_api(url, method, data.get("headers",{}), data.get("body"))
    return result


@router.post("/integrations/send-webhook")
async def send_wh(data: dict, x_token: Optional[str] = Header(None)):
    """Send a webhook."""
    user = _auth(x_token)
    from services.integrations_service import send_webhook
    url = data.get("url","")
    if not url: raise HTTPException(400, "URL مطلوب")
    return await send_webhook(url, data.get("payload",{}), data.get("secret",""))


# ══════════════════════════════════════════════════════════════════
# AUTOMATION RULES ROUTES
# ══════════════════════════════════════════════════════════════════

class RuleReq(BaseModel):
    name:           str = ""
    trigger_type:   str  # keyword | schedule | message_count
    trigger_config: dict
    action_wf_id:   str


@router.post("/automations")
def auto_create(req: RuleReq, x_token: Optional[str] = Header(None)):
    """Create an automation rule."""
    user = _auth(x_token)
    if user["plan"] == "free": raise HTTPException(403, "🔒 Automations للـ Plus/Pro فقط")
    from services.workflow_engine import create_rule
    return create_rule(user["id"], req.trigger_type, req.trigger_config,
                       req.action_wf_id, req.name)


@router.get("/automations")
def auto_list(x_token: Optional[str] = Header(None)):
    """List user's automation rules."""
    user = _auth(x_token)
    from services.workflow_engine import list_rules
    return {"rules": list_rules(user["id"])}


@router.delete("/automations/{rule_id}")
def auto_delete(rule_id: str, x_token: Optional[str] = Header(None)):
    """Delete an automation rule."""
    user = _auth(x_token)
    from services.workflow_engine import delete_rule
    if not delete_rule(rule_id, user["id"]): raise HTTPException(404, "Rule غير موجود")
    return {"ok": True}
