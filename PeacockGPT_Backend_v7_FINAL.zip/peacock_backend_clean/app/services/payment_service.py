"""
services/payment_service.py — Payment & Subscription System v7
Supports: Stripe + PayPal + Manual (cash/EGP)
Webhooks: /payments/webhook/stripe | /payments/webhook/paypal
Author: PeacockAI – Mostafa
"""
import json, secrets, hashlib, hmac
from datetime import datetime, timedelta
from typing import Optional, Dict, Tuple
from core.config import log, PRICING, PLANS

# ══════════════════════════════════════════════════════════════════
# PAYMENT CONFIG
# ══════════════════════════════════════════════════════════════════
import os

STRIPE_SECRET_KEY    = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET= os.getenv("STRIPE_WEBHOOK_SECRET", "")
PAYPAL_CLIENT_ID     = os.getenv("PAYPAL_CLIENT_ID", "")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET", "")
PAYPAL_MODE          = os.getenv("PAYPAL_MODE", "sandbox")  # sandbox | live

# Plan → Stripe Price ID mapping (set in .env)
STRIPE_PRICE_IDS = {
    "plus_monthly": os.getenv("STRIPE_PRICE_PLUS_MONTHLY", "price_xxx"),
    "plus_yearly":  os.getenv("STRIPE_PRICE_PLUS_YEARLY",  "price_xxx"),
    "pro_monthly":  os.getenv("STRIPE_PRICE_PRO_MONTHLY",  "price_xxx"),
    "pro_yearly":   os.getenv("STRIPE_PRICE_PRO_YEARLY",   "price_xxx"),
}

# ══════════════════════════════════════════════════════════════════
# ORDER / INVOICE STORE  (use DB table in production)
# ══════════════════════════════════════════════════════════════════
_orders: Dict[str, dict] = {}


def create_order(user_id: str, plan: str, period: str = "monthly",
                 method: str = "stripe", currency: str = "usd") -> dict:
    """
    Create a payment order.
    period: monthly | yearly
    method: stripe | paypal | manual
    currency: usd | egp
    """
    order_id = f"ord_{secrets.token_hex(12)}"
    pricing  = PRICING.get(plan, {})

    if currency == "egp":
        amount = pricing.get("egp", 0)
        if period == "yearly": amount = int(amount * 10)  # 2 months free
    else:
        amount = pricing.get("usd", 0)
        if period == "yearly": amount = int(amount * 10)

    order = {
        "id":         order_id,
        "user_id":    user_id,
        "plan":       plan,
        "period":     period,
        "method":     method,
        "currency":   currency,
        "amount":     amount,
        "status":     "pending",   # pending | paid | failed | refunded
        "provider_id":None,        # Stripe session ID or PayPal order ID
        "created_at": datetime.now().isoformat(),
        "paid_at":    None,
        "expires_at": None,
    }
    _orders[order_id] = order
    log.info(f"[Payment] Order created: {order_id} user={user_id[:12]} plan={plan} amount={amount}{currency}")
    return order


def get_order(order_id: str) -> Optional[dict]:
    return _orders.get(order_id)


def get_user_orders(user_id: str) -> list:
    return [o for o in _orders.values() if o["user_id"] == user_id]


def mark_paid(order_id: str, provider_id: str = "") -> Optional[dict]:
    """Mark an order as paid and activate subscription."""
    order = _orders.get(order_id)
    if not order: return None

    now     = datetime.now()
    months  = 12 if order["period"] == "yearly" else 1
    expires = (now + timedelta(days=30 * months)).isoformat()

    order["status"]      = "paid"
    order["provider_id"] = provider_id
    order["paid_at"]     = now.isoformat()
    order["expires_at"]  = expires

    # Activate subscription in database
    _activate_user_subscription(order["user_id"], order["plan"], expires)

    log.info(f"[Payment] ✅ PAID: {order_id} user={order['user_id'][:12]} "
             f"plan={order['plan']} expires={expires}")
    return order


def mark_failed(order_id: str, reason: str = "") -> Optional[dict]:
    order = _orders.get(order_id)
    if not order: return None
    order["status"] = "failed"
    log.warning(f"[Payment] ❌ FAILED: {order_id} reason={reason}")
    return order


def _activate_user_subscription(user_id: str, plan: str, expires_at: str):
    """Activate subscription in the User table."""
    try:
        from core.database import get_db, User
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                u.plan        = plan
                u.sub_expires = expires_at
                log.info(f"[Payment] Subscription activated: {user_id[:12]} → {plan}")
    except Exception as e:
        log.error(f"[Payment] Failed to activate subscription: {e}")


# ══════════════════════════════════════════════════════════════════
# STRIPE INTEGRATION
# ══════════════════════════════════════════════════════════════════

async def create_stripe_checkout(user_id: str, plan: str,
                                  period: str = "monthly",
                                  success_url: str = "",
                                  cancel_url:  str = "") -> dict:
    """
    Create a Stripe Checkout Session.
    Returns {session_id, checkout_url, order_id}
    """
    if not STRIPE_SECRET_KEY:
        raise RuntimeError("STRIPE_SECRET_KEY غير مضبوط في .env")

    try:
        import stripe
        stripe.api_key = STRIPE_SECRET_KEY
    except ImportError:
        raise RuntimeError("stripe غير مثبت. شغّل: pip install stripe")

    price_key = f"{plan}_{period}"
    price_id  = STRIPE_PRICE_IDS.get(price_key)
    if not price_id or price_id == "price_xxx":
        raise ValueError(f"Stripe Price ID غير مضبوط لـ {price_key}. أضفه في .env")

    order = create_order(user_id, plan, period, "stripe", "usd")

    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{"price": price_id, "quantity": 1}],
            mode="subscription",
            success_url=success_url or f"https://yourdomain.com/payment/success?order={order['id']}",
            cancel_url=cancel_url   or f"https://yourdomain.com/payment/cancel?order={order['id']}",
            metadata={
                "order_id": order["id"],
                "user_id":  user_id,
                "plan":     plan,
            },
            customer_email=_get_user_email(user_id),
        )
        order["provider_id"] = session.id
        log.info(f"[Stripe] Session created: {session.id} for order {order['id']}")
        return {
            "order_id":     order["id"],
            "session_id":   session.id,
            "checkout_url": session.url,
            "amount":       order["amount"],
            "currency":     "usd",
        }
    except Exception as e:
        mark_failed(order["id"], str(e))
        raise RuntimeError(f"Stripe error: {e}")


def handle_stripe_webhook(payload: bytes, sig_header: str) -> dict:
    """
    Process Stripe webhook event.
    Verifies signature, handles checkout.session.completed.
    """
    if not STRIPE_WEBHOOK_SECRET:
        raise ValueError("STRIPE_WEBHOOK_SECRET غير مضبوط")

    try:
        import stripe
        stripe.api_key = STRIPE_SECRET_KEY
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except Exception as e:
        raise ValueError(f"Stripe webhook signature invalid: {e}")

    event_type = event["type"]
    log.info(f"[Stripe] Webhook: {event_type}")

    if event_type == "checkout.session.completed":
        session  = event["data"]["object"]
        order_id = session.get("metadata", {}).get("order_id")
        if order_id:
            mark_paid(order_id, session["id"])
            return {"ok": True, "action": "subscription_activated"}

    elif event_type == "invoice.payment_failed":
        sub_id = event["data"]["object"].get("subscription")
        # Find order by provider_id and mark failed
        for order in _orders.values():
            if order.get("provider_id") == sub_id:
                mark_failed(order["id"], "payment_failed")
                break

    elif event_type in ("customer.subscription.deleted", "customer.subscription.canceled"):
        # Downgrade user to free
        sub_id = event["data"]["object"]["id"]
        for order in _orders.values():
            if order.get("provider_id") == sub_id and order["status"] == "paid":
                _activate_user_subscription(order["user_id"], "free",
                                            datetime.now().isoformat())
                log.info(f"[Stripe] Subscription cancelled → downgraded to free")
                break

    return {"ok": True, "action": event_type}


# ══════════════════════════════════════════════════════════════════
# PAYPAL INTEGRATION
# ══════════════════════════════════════════════════════════════════

async def create_paypal_order(user_id: str, plan: str,
                               period: str = "monthly") -> dict:
    """
    Create a PayPal order.
    Returns {order_id, paypal_order_id, approval_url}
    """
    if not PAYPAL_CLIENT_ID or not PAYPAL_CLIENT_SECRET:
        raise RuntimeError("PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET غير مضبوطين في .env")

    order    = create_order(user_id, plan, period, "paypal", "usd")
    base_url = ("https://api-m.sandbox.paypal.com" if PAYPAL_MODE == "sandbox"
                else "https://api-m.paypal.com")

    import httpx

    # Get access token
    async with httpx.AsyncClient() as client:
        token_r = await client.post(
            f"{base_url}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"},
        )
        if token_r.status_code != 200:
            raise RuntimeError(f"PayPal auth failed: {token_r.text[:200]}")
        access_token = token_r.json()["access_token"]

    # Create order
    async with httpx.AsyncClient() as client:
        order_r = await client.post(
            f"{base_url}/v2/checkout/orders",
            headers={"Authorization": f"Bearer {access_token}",
                     "Content-Type": "application/json"},
            json={
                "intent": "CAPTURE",
                "purchase_units": [{
                    "amount": {"currency_code":"USD","value":str(order["amount"])},
                    "description": f"PeacockAI {plan.title()} Plan - {period}",
                    "custom_id": order["id"],
                }],
                "application_context": {
                    "return_url": f"https://yourdomain.com/payment/paypal/success?order={order['id']}",
                    "cancel_url": f"https://yourdomain.com/payment/paypal/cancel?order={order['id']}",
                }
            }
        )
        if order_r.status_code not in (200, 201):
            mark_failed(order["id"], order_r.text[:200])
            raise RuntimeError(f"PayPal order failed: {order_r.text[:200]}")

        pp_order    = order_r.json()
        pp_order_id = pp_order["id"]
        approval    = next(
            (l["href"] for l in pp_order.get("links",[]) if l["rel"] == "approve"),
            None
        )

    order["provider_id"] = pp_order_id
    log.info(f"[PayPal] Order created: {pp_order_id} for order {order['id']}")
    return {
        "order_id":       order["id"],
        "paypal_order_id":pp_order_id,
        "approval_url":   approval,
        "amount":         order["amount"],
        "currency":       "usd",
    }


async def capture_paypal_order(paypal_order_id: str, our_order_id: str) -> dict:
    """Capture (confirm) a PayPal payment after user approves."""
    base_url = ("https://api-m.sandbox.paypal.com" if PAYPAL_MODE == "sandbox"
                else "https://api-m.paypal.com")
    import httpx

    async with httpx.AsyncClient() as client:
        token_r = await client.post(
            f"{base_url}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"},
        )
        access_token = token_r.json()["access_token"]

        capture_r = await client.post(
            f"{base_url}/v2/checkout/orders/{paypal_order_id}/capture",
            headers={"Authorization": f"Bearer {access_token}",
                     "Content-Type": "application/json"},
        )

    if capture_r.status_code in (200, 201):
        mark_paid(our_order_id, paypal_order_id)
        return {"ok": True, "status": "paid"}
    else:
        mark_failed(our_order_id, capture_r.text[:200])
        return {"ok": False, "error": capture_r.text[:200]}


# ══════════════════════════════════════════════════════════════════
# MANUAL PAYMENT  (EGP / Cash / Bank Transfer)
# ══════════════════════════════════════════════════════════════════

def create_manual_order(user_id: str, plan: str,
                         period: str = "monthly") -> dict:
    """
    Create a manual payment order (for EGP / bank transfer).
    Admin confirms payment manually via /admin/confirm-payment
    """
    order = create_order(user_id, plan, period, "manual", "egp")
    # Generate a unique reference number for the customer
    ref = f"PK{order['id'][-8:].upper()}"
    order["reference"] = ref
    log.info(f"[Manual] Order {order['id']} ref={ref} amount={order['amount']} EGP")
    return {
        "order_id":    order["id"],
        "reference":   ref,
        "amount_egp":  order["amount"],
        "plan":        plan,
        "instructions":{
            "ar": (f"حوّل {order['amount']} جنيه على رقم الفودافون كاش / إنستاباي.\n"
                   f"أرسل صورة الإيصال مع الكود: {ref}\n"
                   f"واتساب: +20XXXXXXXXXX"),
            "en": (f"Transfer {order['amount']} EGP to our Vodafone Cash / InstaPay.\n"
                   f"Send receipt screenshot with code: {ref}")
        }
    }


def admin_confirm_manual_payment(order_id: str, admin_note: str = "") -> dict:
    """Admin confirms a manual payment. Called from admin dashboard."""
    order = _orders.get(order_id)
    if not order:
        raise ValueError(f"Order {order_id} غير موجود")
    if order["method"] != "manual":
        raise ValueError("هذا الـ endpoint للمدفوعات اليدوية فقط")
    if order["status"] == "paid":
        raise ValueError("هذا الطلب مدفوع بالفعل")

    result = mark_paid(order_id, f"manual:{admin_note[:50]}")
    return {"ok": True, "order": result}


# ══════════════════════════════════════════════════════════════════
# REFUND
# ══════════════════════════════════════════════════════════════════

async def refund_stripe(order_id: str, reason: str = "") -> dict:
    """Refund a Stripe payment."""
    order = _orders.get(order_id)
    if not order or order["method"] != "stripe":
        raise ValueError("Order غير موجود أو ليس Stripe")
    if order["status"] != "paid":
        raise ValueError("لا يمكن استرداد مبلغ لطلب غير مدفوع")

    if not STRIPE_SECRET_KEY: raise RuntimeError("STRIPE_SECRET_KEY غير مضبوط")
    try:
        import stripe
        stripe.api_key = STRIPE_SECRET_KEY
        refund = stripe.Refund.create(
            payment_intent=order["provider_id"],
            reason="requested_by_customer",
            metadata={"order_id": order_id, "reason": reason[:200]}
        )
        order["status"] = "refunded"
        # Downgrade user
        _activate_user_subscription(order["user_id"], "free", datetime.now().isoformat())
        log.info(f"[Stripe] Refund: {refund.id} for order {order_id}")
        return {"ok": True, "refund_id": refund.id}
    except Exception as e:
        raise RuntimeError(f"Refund failed: {e}")


# ══════════════════════════════════════════════════════════════════
# SUBSCRIPTION MANAGEMENT
# ══════════════════════════════════════════════════════════════════

def get_subscription_status(user_id: str) -> dict:
    """Get current subscription details for a user."""
    try:
        from core.database import get_db, User
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if not u:
                return {"plan":"free","status":"active","expires_at":None}

            plan    = u.plan or "free"
            expires = u.sub_expires

            if plan == "free":
                status = "active"
            elif expires:
                status = "active" if datetime.now() < datetime.fromisoformat(expires) else "expired"
            else:
                status = "active"

            # Get latest paid order
            paid_orders = [o for o in _orders.values()
                           if o["user_id"] == user_id and o["status"] == "paid"]
            latest = paid_orders[-1] if paid_orders else None

            return {
                "plan":       plan,
                "status":     status,
                "expires_at": expires,
                "method":     latest["method"] if latest else None,
                "period":     latest["period"] if latest else None,
            }
    except Exception as e:
        log.warning(f"[Payment] get_subscription_status error: {e}")
        return {"plan":"free","status":"active","expires_at":None}


def cancel_subscription(user_id: str) -> dict:
    """Cancel subscription at period end (doesn't immediately downgrade)."""
    try:
        from core.database import get_db, User
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            if u:
                # Mark for cancellation — will downgrade when expires_at passes
                log.info(f"[Payment] Cancellation requested: {user_id[:12]}")
                return {"ok": True, "message": "سيتم إلغاء اشتراكك في نهاية الفترة الحالية"}
    except Exception as e:
        raise RuntimeError(str(e))
    return {"ok": True}


# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def _get_user_email(user_id: str) -> str:
    try:
        from core.database import get_db, User
        with get_db() as db:
            u = db.query(User).filter_by(id=user_id).first()
            return u.email if u else ""
    except Exception:
        return ""


def get_revenue_stats() -> dict:
    """Get revenue statistics for admin dashboard."""
    paid = [o for o in _orders.values() if o["status"] == "paid"]
    return {
        "total_orders":    len(_orders),
        "paid_orders":     len(paid),
        "total_usd":       sum(o["amount"] for o in paid if o["currency"] == "usd"),
        "total_egp":       sum(o["amount"] for o in paid if o["currency"] == "egp"),
        "by_plan": {
            "plus": sum(1 for o in paid if o["plan"] == "plus"),
            "pro":  sum(1 for o in paid if o["plan"] == "pro"),
        },
        "by_method": {
            "stripe": sum(1 for o in paid if o["method"] == "stripe"),
            "paypal": sum(1 for o in paid if o["method"] == "paypal"),
            "manual": sum(1 for o in paid if o["method"] == "manual"),
        },
    }
