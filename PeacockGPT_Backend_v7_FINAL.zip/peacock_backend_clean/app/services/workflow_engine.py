"""
services/workflow_engine.py — Full n8n-like Workflow Engine v7
Trigger → Actions → Result | Save | Run | Edit | Automate
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio, time
from datetime import datetime
from typing import List, Dict, Optional, Any, AsyncGenerator
from core.config import log, PLANS
from core.database import get_db
import httpx

# ══════════════════════════════════════════════════════════════════
# WORKFLOW PLAN LIMITS
# ══════════════════════════════════════════════════════════════════
WORKFLOW_LIMITS = {
    "free": {"max_workflows":2,  "max_steps":3,  "can_schedule":False, "can_webhook":False},
    "plus": {"max_workflows":10, "max_steps":10, "can_schedule":True,  "can_webhook":True},
    "pro":  {"max_workflows":-1, "max_steps":-1, "can_schedule":True,  "can_webhook":True},
}

# ══════════════════════════════════════════════════════════════════
# IN-MEMORY WORKFLOW STORE  (use DB in production)
# ══════════════════════════════════════════════════════════════════
_workflows: Dict[str, Dict] = {}   # wf_id → workflow
_wf_runs:   Dict[str, List] = {}   # wf_id → [run_records]

# ══════════════════════════════════════════════════════════════════
# WORKFLOW CRUD
# ══════════════════════════════════════════════════════════════════

def create_workflow(user_id: str, user_plan: str, data: dict) -> Dict:
    """Create and save a new workflow. Returns workflow dict."""
    limits = WORKFLOW_LIMITS.get(user_plan, WORKFLOW_LIMITS["free"])

    # Check quota
    user_wfs = [w for w in _workflows.values() if w["user_id"] == user_id]
    if limits["max_workflows"] != -1 and len(user_wfs) >= limits["max_workflows"]:
        raise PermissionError(f"وصلت للحد الأقصى ({limits['max_workflows']}) workflows في خطتك")

    # Validate steps
    steps = data.get("steps", [])
    if limits["max_steps"] != -1 and len(steps) > limits["max_steps"]:
        raise PermissionError(f"الحد الأقصى {limits['max_steps']} خطوات في خطتك")

    wf_id = secrets.token_hex(12)
    now   = datetime.now().isoformat()
    wf    = {
        "id":          wf_id,
        "user_id":     user_id,
        "name":        data.get("name","Workflow جديد")[:80],
        "description": data.get("description","")[:200],
        "trigger":     data.get("trigger","manual"),
        "trigger_config": data.get("trigger_config",{}),
        "steps":       steps,
        "enabled":     True,
        "run_count":   0,
        "last_run":    None,
        "created_at":  now,
        "updated_at":  now,
    }
    _workflows[wf_id] = wf
    log.info(f"[Workflow] Created '{wf['name']}' for {user_id[:12]}")
    return wf


def get_workflow(wf_id: str, user_id: str) -> Optional[Dict]:
    wf = _workflows.get(wf_id)
    if not wf or wf["user_id"] != user_id: return None
    return wf


def list_workflows(user_id: str) -> List[Dict]:
    return [w for w in _workflows.values() if w["user_id"] == user_id]


def update_workflow(wf_id: str, user_id: str, data: dict) -> Optional[Dict]:
    wf = get_workflow(wf_id, user_id)
    if not wf: return None
    for k in ("name","description","steps","trigger","trigger_config","enabled"):
        if k in data: wf[k] = data[k]
    wf["updated_at"] = datetime.now().isoformat()
    return wf


def delete_workflow(wf_id: str, user_id: str) -> bool:
    wf = get_workflow(wf_id, user_id)
    if not wf: return False
    del _workflows[wf_id]
    _wf_runs.pop(wf_id, None)
    return True


def get_workflow_runs(wf_id: str, user_id: str, limit: int = 10) -> List[Dict]:
    wf = get_workflow(wf_id, user_id)
    if not wf: return []
    return _wf_runs.get(wf_id, [])[-limit:]


# ══════════════════════════════════════════════════════════════════
# SSRF PROTECTION
# ══════════════════════════════════════════════════════════════════

import urllib.parse, ipaddress

def _check_ssrf(url: str):
    try:
        parsed = urllib.parse.urlparse(url)
        host   = parsed.hostname or ""
        blocked = {"localhost","127.0.0.1","0.0.0.0","::1","169.254.169.254","metadata.google.internal"}
        if host in blocked:
            raise ValueError(f"⛔ URL محظور: {host}")
        try:
            ip = ipaddress.ip_address(host)
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                raise ValueError("⛔ IPs الداخلية محظورة")
        except ValueError as e:
            if "⛔" in str(e): raise
    except Exception as e:
        if "⛔" in str(e): raise
        pass


# ══════════════════════════════════════════════════════════════════
# STEP EXECUTOR
# ══════════════════════════════════════════════════════════════════

async def _execute_step(step: dict, context: dict,
                         user_id: str, groq_key: str,
                         gemini_key: str) -> dict:
    """Execute one workflow step. Returns {ok, output, error}."""
    stype  = step.get("type","")
    cfg    = _resolve_vars(step.get("config",{}), context)
    result = {"ok":True,"output":None,"error":None,"type":stype}

    try:
        # ── AI Generate ──────────────────────────────────────────
        if stype == "ai_generate":
            from services.llm import generate
            prompt = cfg.get("prompt", context.get("message",""))
            model  = cfg.get("model","auto")
            system = cfg.get("system","أنت مساعد ذكي من PeacockAI.")
            output = await generate(prompt, groq_key, gemini_key, model, system, max_tokens=2000)
            result["output"] = output
            context["ai_output"] = output
            context["last_output"] = output

        # ── AI Summarize ─────────────────────────────────────────
        elif stype == "ai_summarize":
            from services.llm import generate
            text   = cfg.get("text", context.get("last_output",""))
            prompt = f"لخّص هذا بإيجاز شديد:\n{text[:2000]}"
            output = await generate(prompt, groq_key, gemini_key, "peacockgpt-5-fast", max_tokens=400)
            result["output"] = output
            context["summary"] = output
            context["last_output"] = output

        # ── Generate DOCX ─────────────────────────────────────────
        elif stype == "generate_docx":
            from services.document_service import content_to_docx
            content = cfg.get("content", context.get("last_output",""))
            title   = cfg.get("title", "مستند")
            style   = cfg.get("style","professional")
            docx_b  = content_to_docx(content, title, style)
            fid     = _save_file(user_id, docx_b, "docx", title)
            result["output"] = {"file_id":fid,"type":"docx","title":title,
                                 "size_kb":round(len(docx_b)/1024,1),
                                 "download":f"/documents/download/{fid}"}
            context["last_file"] = result["output"]

        # ── Generate PPTX ─────────────────────────────────────────
        elif stype == "generate_pptx":
            from services.document_service import content_to_pptx
            content = cfg.get("content", context.get("last_output",""))
            title   = cfg.get("title","عرض تقديمي")
            theme   = cfg.get("theme","dark")
            pptx_b  = content_to_pptx(content, title, theme)
            fid     = _save_file(user_id, pptx_b, "pptx", title)
            result["output"] = {"file_id":fid,"type":"pptx","title":title,
                                 "size_kb":round(len(pptx_b)/1024,1),
                                 "download":f"/documents/download/{fid}"}
            context["last_file"] = result["output"]

        # ── Generate PDF ──────────────────────────────────────────
        elif stype == "generate_pdf":
            from services.document_service import content_to_pdf
            content = cfg.get("content", context.get("last_output",""))
            title   = cfg.get("title","مستند PDF")
            pdf_b   = content_to_pdf(content, title)
            fid     = _save_file(user_id, pdf_b, "pdf", title)
            result["output"] = {"file_id":fid,"type":"pdf","title":title,
                                 "size_kb":round(len(pdf_b)/1024,1),
                                 "download":f"/documents/download/{fid}"}
            context["last_file"] = result["output"]

        # ── HTTP Request ──────────────────────────────────────────
        elif stype == "http_request":
            url     = cfg.get("url","")
            method  = cfg.get("method","GET").upper()
            headers = cfg.get("headers",{})
            body    = cfg.get("body")
            timeout = min(int(cfg.get("timeout",30)), 60)
            if not url or not url.startswith("http"):
                raise ValueError("URL غير صالح")
            _check_ssrf(url)
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.request(method, url, headers=headers, json=body)
            try:   resp = r.json()
            except: resp = r.text[:2000]
            result["output"] = {"status":r.status_code,"response":resp}
            context["http_response"] = resp
            context["last_output"]   = str(resp)[:500]

        # ── Send Webhook ──────────────────────────────────────────
        elif stype == "send_webhook":
            url     = cfg.get("url","")
            payload = cfg.get("payload", {"data": context.get("last_output","")})
            if not url: raise ValueError("Webhook URL مطلوب")
            _check_ssrf(url)
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.post(url, json=payload)
            result["output"] = {"status":r.status_code,"ok":r.status_code < 400}

        # ── Save to Memory ────────────────────────────────────────
        elif stype == "save_memory":
            from services.memory import mem_set
            key   = cfg.get("key","workflow_result")
            value = cfg.get("value", context.get("last_output",""))
            scope = cfg.get("scope","long")
            mem_set(user_id, scope, key, str(value)[:500], 0.8)
            result["output"] = {"saved":True,"key":key}

        # ── Condition / Filter ────────────────────────────────────
        elif stype == "condition":
            expr    = cfg.get("if","")
            val     = context.get(cfg.get("var","last_output"),"")
            op      = cfg.get("operator","contains")
            compare = cfg.get("value","")
            if op == "contains":    passed = compare in str(val)
            elif op == "equals":    passed = str(val) == compare
            elif op == "not_empty": passed = bool(val)
            else:                   passed = True
            result["output"]  = {"condition":passed}
            context["condition_passed"] = passed
            if not passed:
                result["skip_remaining"] = True

        # ── Transform ─────────────────────────────────────────────
        elif stype == "transform":
            input_val = context.get(cfg.get("from","last_output"),"")
            op        = cfg.get("operation","uppercase")
            if op == "uppercase":     out = str(input_val).upper()
            elif op == "lowercase":   out = str(input_val).lower()
            elif op == "trim":        out = str(input_val).strip()
            elif op == "truncate":    out = str(input_val)[:int(cfg.get("length",200))]
            elif op == "prepend":     out = cfg.get("text","") + str(input_val)
            elif op == "append":      out = str(input_val) + cfg.get("text","")
            else:                     out = input_val
            result["output"] = out
            context["last_output"] = out

        # ── Wait / Delay ──────────────────────────────────────────
        elif stype == "wait":
            seconds = min(int(cfg.get("seconds",1)), 30)
            await asyncio.sleep(seconds)
            result["output"] = {"waited":seconds}

        # ── Log / Note ────────────────────────────────────────────
        elif stype == "log":
            msg = cfg.get("message", str(context.get("last_output",""))[:200])
            log.info(f"[Workflow][Log] {msg}")
            result["output"] = {"logged": msg}

        else:
            result["ok"]    = False
            result["error"] = f"نوع خطوة غير معروف: {stype}"

    except PermissionError as e:
        result["ok"] = False; result["error"] = str(e)
    except Exception as e:
        result["ok"] = False; result["error"] = f"خطأ: {e}"
        log.warning(f"[Workflow] Step '{stype}' error: {e}")

    return result


def _resolve_vars(cfg: dict, context: dict) -> dict:
    """Replace {{var}} placeholders in config values with context values."""
    out = {}
    for k, v in cfg.items():
        if isinstance(v, str):
            for ck, cv in context.items():
                v = v.replace(f"{{{{{ck}}}}}", str(cv))
            out[k] = v
        else:
            out[k] = v
    return out


# ══════════════════════════════════════════════════════════════════
# FILE STORE  (for workflow outputs)
# ══════════════════════════════════════════════════════════════════
_file_store: Dict[str, dict] = {}

def _save_file(user_id: str, data: bytes, ext: str, title: str = "") -> str:
    fid = secrets.token_hex(14)
    _file_store[fid] = {
        "user_id":   user_id,
        "data":      data,
        "ext":       ext,
        "title":     title,
        "created_at":datetime.now().isoformat(),
    }
    return fid

def get_file(fid: str, user_id: str) -> Optional[dict]:
    f = _file_store.get(fid)
    if not f or f["user_id"] != user_id: return None
    return f


# ══════════════════════════════════════════════════════════════════
# WORKFLOW RUNNER  (streaming)
# ══════════════════════════════════════════════════════════════════

async def run_workflow(wf_id: str, user_id: str, user_plan: str,
                       input_data: dict = None,
                       groq_key: str = "", gemini_key: str = ""
                       ) -> AsyncGenerator[str, None]:
    """
    Execute a saved workflow step by step.
    Yields SSE-formatted progress events.
    """
    wf = get_workflow(wf_id, user_id)
    if not wf:
        yield _sse({"type":"error","message":"Workflow غير موجود"}); return

    if not wf.get("enabled"):
        yield _sse({"type":"error","message":"هذا الـ Workflow معطّل"}); return

    run_id = secrets.token_hex(8)
    t0     = time.time()
    steps  = wf.get("steps",[])

    run_record = {
        "run_id":    run_id,
        "status":    "running",
        "started":   datetime.now().isoformat(),
        "steps":     [],
        "error":     None,
        "outputs":   {},
    }

    yield _sse({"type":"wf_start","run_id":run_id,
                "name":wf["name"],"steps":len(steps),
                "message":f"▶ بدء تشغيل: {wf['name']}"})

    # Context carries data between steps
    context = {**(input_data or {}), "user_id":user_id, "wf_id":wf_id}

    step_results = []
    success      = True

    for i, step in enumerate(steps):
        step_id   = step.get("id", f"step_{i+1}")
        step_name = step.get("name", step.get("type",""))

        yield _sse({"type":"wf_step","step_id":step_id,"step_num":i+1,
                    "total":len(steps),"name":step_name,
                    "message":f"⚡ خطوة {i+1}/{len(steps)}: {step_name}"})

        result = await _execute_step(step, context, user_id, groq_key, gemini_key)
        step_results.append({"step_id":step_id,"name":step_name,"result":result})

        if result["ok"]:
            yield _sse({"type":"wf_step_done","step_id":step_id,
                        "output": _serialize_output(result["output"]),
                        "message":f"✅ {step_name}"})
        else:
            success = False
            yield _sse({"type":"wf_step_error","step_id":step_id,
                        "error":result["error"],
                        "message":f"❌ {step_name}: {result['error']}"})
            if step.get("stop_on_error", True): break

        if result.get("skip_remaining"): break
        await asyncio.sleep(0.05)

    elapsed = round(time.time()-t0, 2)

    # Save run record
    run_record.update({
        "status":  "done" if success else "failed",
        "elapsed": elapsed,
        "steps":   step_results,
        "outputs": {s["step_id"]: _serialize_output(s["result"].get("output")) for s in step_results},
        "last_file": context.get("last_file"),
    })
    _wf_runs.setdefault(wf_id, []).append(run_record)
    wf["run_count"]  += 1
    wf["last_run"]    = datetime.now().isoformat()

    # Find downloadable file
    last_file = context.get("last_file")

    yield _sse({
        "type":      "wf_done",
        "run_id":    run_id,
        "success":   success,
        "elapsed_s": elapsed,
        "last_file": last_file,
        "message":   f"{'✅ اكتمل' if success else '❌ فشل'} في {elapsed}s",
    })

    log.info(f"[Workflow] '{wf['name']}' run={run_id} success={success} elapsed={elapsed}s")


def _serialize_output(output: Any) -> Any:
    """Make output JSON-serializable."""
    if isinstance(output, bytes): return f"<binary {len(output)} bytes>"
    if isinstance(output, dict):  return {k: _serialize_output(v) for k,v in output.items()}
    return output


def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


# ══════════════════════════════════════════════════════════════════
# AUTOMATION RULES  (Trigger-based auto actions)
# ══════════════════════════════════════════════════════════════════
_automation_rules: Dict[str, dict] = {}

def create_rule(user_id: str, trigger_type: str, trigger_config: dict,
                action_wf_id: str, name: str = "") -> dict:
    """
    Create an automation rule.
    trigger_type: 'keyword' | 'schedule' | 'message_count'
    """
    rule_id = secrets.token_hex(8)
    rule    = {
        "id":             rule_id,
        "user_id":        user_id,
        "name":           name or f"Rule {rule_id[:6]}",
        "trigger_type":   trigger_type,
        "trigger_config": trigger_config,
        "action_wf_id":   action_wf_id,
        "enabled":        True,
        "fire_count":     0,
        "created_at":     datetime.now().isoformat(),
    }
    _automation_rules[rule_id] = rule
    return rule


def check_keyword_trigger(user_id: str, message: str) -> List[dict]:
    """Check if message triggers any automation rules for user."""
    triggered = []
    for rule in _automation_rules.values():
        if rule["user_id"] != user_id or not rule["enabled"]: continue
        if rule["trigger_type"] != "keyword": continue
        keywords = rule["trigger_config"].get("keywords",[])
        if any(kw.lower() in message.lower() for kw in keywords):
            triggered.append(rule)
    return triggered


def list_rules(user_id: str) -> List[dict]:
    return [r for r in _automation_rules.values() if r["user_id"] == user_id]

def delete_rule(rule_id: str, user_id: str) -> bool:
    r = _automation_rules.get(rule_id)
    if not r or r["user_id"] != user_id: return False
    del _automation_rules[rule_id]
    return True


# ══════════════════════════════════════════════════════════════════
# BUILT-IN WORKFLOW TEMPLATES
# ══════════════════════════════════════════════════════════════════
TEMPLATES = [
    {
        "id":          "tpl_idea_to_pdf",
        "name":        "💡 فكرة → PDF",
        "description": "يحوّل فكرتك لمستند PDF احترافي",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_generate","name":"كتابة المحتوى",
             "config":{"prompt":"اكتب محتوى احترافي ومنظم عن: {{message}}","model":"peacockgpt-5"}},
            {"id":"s2","type":"generate_pdf","name":"إنشاء PDF",
             "config":{"content":"{{last_output}}","title":"{{message}}"}},
        ]
    },
    {
        "id":          "tpl_idea_to_pptx",
        "name":        "📊 فكرة → PowerPoint",
        "description": "يبني عرض تقديمي من فكرتك",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_generate","name":"بناء المحتوى",
             "config":{"prompt":"أنشئ محتوى عرض تقديمي عن: {{message}}. استخدم ## للعناوين و- للنقاط","model":"peacockgpt-5"}},
            {"id":"s2","type":"generate_pptx","name":"إنشاء PowerPoint",
             "config":{"content":"{{last_output}}","title":"{{message}}","theme":"dark"}},
        ]
    },
    {
        "id":          "tpl_idea_to_docx",
        "name":        "📄 فكرة → Word",
        "description": "يكتب مستند Word من موضوعك",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_generate","name":"كتابة المستند",
             "config":{"prompt":"اكتب مستند Word كامل ومنظم عن: {{message}}","model":"peacockgpt-5"}},
            {"id":"s2","type":"generate_docx","name":"إنشاء Word",
             "config":{"content":"{{last_output}}","title":"{{message}}","style":"professional"}},
        ]
    },
    {
        "id":          "tpl_summarize_pdf",
        "name":        "📋 تلخيص → PDF",
        "description": "يلخّص النص ويصدّره PDF",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_summarize","name":"تلخيص النص",
             "config":{"text":"{{message}}"}},
            {"id":"s2","type":"generate_pdf","name":"تصدير PDF",
             "config":{"content":"{{last_output}}","title":"ملخص"}},
        ]
    },
    {
        "id":          "tpl_research_report",
        "name":        "🔍 بحث → تقرير كامل",
        "description": "يبحث ويكتب تقريراً + Word",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_generate","name":"كتابة التقرير",
             "config":{"prompt":"اكتب تقريراً علمياً شاملاً ومرجعياً عن: {{message}}. اشمل مقدمة وأقسام وجداول وخلاصة.",
                       "model":"peacockgpt-5","system":"أنت باحث أكاديمي متخصص من PeacockAI."}},
            {"id":"s2","type":"generate_docx","name":"حفظ كـ Word",
             "config":{"content":"{{last_output}}","title":"تقرير: {{message}}","style":"professional"}},
        ]
    },
    {
        "id":          "tpl_api_then_pdf",
        "name":        "🌐 API → PDF",
        "description": "يجلب بيانات من API ويعملها PDF",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"http_request","name":"جلب البيانات",
             "config":{"url":"{{api_url}}","method":"GET"}},
            {"id":"s2","type":"ai_generate","name":"تحليل البيانات",
             "config":{"prompt":"حلّل هذه البيانات وقدّم ملخصاً: {{http_response}}"}},
            {"id":"s3","type":"generate_pdf","name":"إنشاء تقرير",
             "config":{"content":"{{last_output}}","title":"تقرير API"}},
        ]
    },
    {
        "id":          "tpl_webhook_notify",
        "name":        "🔔 AI → Webhook",
        "description": "يولّد رد AI ويرسله لـ Webhook",
        "trigger":     "manual",
        "steps": [
            {"id":"s1","type":"ai_generate","name":"توليد الرد",
             "config":{"prompt":"{{message}}","model":"auto"}},
            {"id":"s2","type":"send_webhook","name":"إرسال Webhook",
             "config":{"url":"{{webhook_url}}","payload":{"result":"{{last_output}}","user":"{{user_id}}"}}},
        ]
    },
]
