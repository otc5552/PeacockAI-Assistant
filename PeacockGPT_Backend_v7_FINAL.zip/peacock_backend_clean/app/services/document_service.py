"""
services/document_service.py — Professional Document Generation System v7
DOCX + PPTX + PDF with full formatting, tables, themes, multi-page support
Author: PeacockAI – Mostafa
"""
import io, re, secrets, os
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from core.config import log, PDF_OUTPUT_DIR

# ══════════════════════════════════════════════════════════════════
# PLAN LIMITS
# ══════════════════════════════════════════════════════════════════
DOC_LIMITS = {
    "free": {"pdf": 1,  "docx": 1,  "pptx": 0},
    "plus": {"pdf": 10, "docx": 10, "pptx": 5},
    "pro":  {"pdf": -1, "docx": -1, "pptx": -1},  # unlimited
}

def check_doc_quota(user_id: str, user_plan: str, doc_type: str) -> Tuple[bool, str]:
    limit = DOC_LIMITS.get(user_plan, DOC_LIMITS["free"]).get(doc_type, 0)
    if limit == -1: return True, ""
    if limit == 0:  return False, f"إنشاء {doc_type.upper()} غير متاح في خطتك"
    return True, ""


# ══════════════════════════════════════════════════════════════════
# CONTENT PARSER  (Markdown → Structured blocks)
# ══════════════════════════════════════════════════════════════════

def parse_content(content: str) -> List[dict]:
    """
    Parse markdown-like content into structured blocks.
    Returns list of {type, text, level, rows} blocks.
    """
    blocks = []
    lines  = content.split("\n")
    i      = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Code block
        if stripped.startswith("```"):
            lang = stripped[3:].strip() or "code"
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            blocks.append({"type":"code","text":"\n".join(code_lines),"lang":lang})

        # Heading 1
        elif stripped.startswith("# "):
            blocks.append({"type":"h1","text":stripped[2:].strip()})

        # Heading 2
        elif stripped.startswith("## "):
            blocks.append({"type":"h2","text":stripped[3:].strip()})

        # Heading 3
        elif stripped.startswith("### "):
            blocks.append({"type":"h3","text":stripped[4:].strip()})

        # Table (| col | col |)
        elif stripped.startswith("|") and stripped.endswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = lines[i].strip().strip("|")
                if "---" not in row:
                    cells = [c.strip() for c in row.split("|")]
                    rows.append(cells)
                i += 1
            if rows:
                blocks.append({"type":"table","rows":rows})
            continue

        # Bullet
        elif re.match(r"^[-*•]\s", stripped):
            blocks.append({"type":"bullet","text":stripped[2:].strip()})

        # Numbered list
        elif re.match(r"^\d+\.\s", stripped):
            text = re.sub(r"^\d+\.\s", "", stripped)
            blocks.append({"type":"numbered","text":text})

        # Bold line
        elif stripped.startswith("**") and stripped.endswith("**") and len(stripped) > 4:
            blocks.append({"type":"bold","text":stripped.strip("*")})

        # Horizontal rule
        elif stripped in ("---", "***", "___"):
            blocks.append({"type":"hr","text":""})

        # Normal paragraph
        elif stripped:
            blocks.append({"type":"para","text":stripped})

        i += 1

    return blocks


# ══════════════════════════════════════════════════════════════════
# DOCX GENERATOR — Full professional Word document
# ══════════════════════════════════════════════════════════════════

def generate_docx(content: str, title: str = "PeacockGPT Document",
                  author: str = "PeacockAI", style: str = "professional") -> bytes:
    """
    Generate a professional .docx file.
    Supports: headings, paragraphs, tables, bullet lists, code blocks, bold.
    """
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor, Inches, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except ImportError:
        raise RuntimeError("python-docx غير مثبت. شغّل: pip install python-docx")

    doc = Document()

    # ── Page setup ───────────────────────────────────────────────
    section = doc.sections[0]
    section.page_width  = Inches(8.27)   # A4
    section.page_height = Inches(11.69)
    section.left_margin = section.right_margin = Inches(1)
    section.top_margin  = section.bottom_margin = Inches(0.8)

    # ── Theme colors ─────────────────────────────────────────────
    THEMES = {
        "professional": {"primary": RGBColor(71,84,172),  "accent": RGBColor(99,179,237),  "text": RGBColor(30,30,46)},
        "dark":         {"primary": RGBColor(112,96,255), "accent": RGBColor(155,143,255),  "text": RGBColor(20,20,35)},
        "elegant":      {"primary": RGBColor(30,30,30),   "accent": RGBColor(180,140,80),   "text": RGBColor(30,30,30)},
        "colorful":     {"primary": RGBColor(220,50,50),  "accent": RGBColor(50,150,220),   "text": RGBColor(30,30,30)},
    }
    theme = THEMES.get(style, THEMES["professional"])

    # ── Title page ───────────────────────────────────────────────
    # Blue header bar via paragraph shading
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run  = title_para.add_run(f"\n{title}\n")
    title_run.font.size  = Pt(26)
    title_run.font.bold  = True
    title_run.font.color.rgb = theme["primary"]

    meta_para = doc.add_paragraph()
    meta_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta_run  = meta_para.add_run(
        f"أُعدّ بواسطة {author}  •  {datetime.now().strftime('%Y-%m-%d')}"
    )
    meta_run.font.size  = Pt(10)
    meta_run.font.color.rgb = RGBColor(136,136,176)

    doc.add_paragraph()  # spacer

    # ── Content blocks ───────────────────────────────────────────
    blocks = parse_content(content)

    for block in blocks:
        btype = block["type"]
        text  = block.get("text","")

        if btype == "h1":
            p = doc.add_heading("", level=1)
            run = p.add_run(text)
            run.font.color.rgb = theme["primary"]
            run.font.size = Pt(18)

        elif btype == "h2":
            p = doc.add_heading("", level=2)
            run = p.add_run(text)
            run.font.color.rgb = theme["accent"]
            run.font.size = Pt(14)

        elif btype == "h3":
            p = doc.add_heading("", level=3)
            run = p.add_run(text)
            run.font.size = Pt(12)

        elif btype == "para":
            p = doc.add_paragraph()
            # Handle inline bold **text**
            parts = re.split(r"\*\*(.+?)\*\*", text)
            for idx, part in enumerate(parts):
                if part:
                    r = p.add_run(part)
                    r.bold = (idx % 2 == 1)
                    r.font.size = Pt(11)

        elif btype == "bullet":
            p = doc.add_paragraph(style="List Bullet")
            r = p.add_run(text)
            r.font.size = Pt(11)

        elif btype == "numbered":
            p = doc.add_paragraph(style="List Number")
            r = p.add_run(text)
            r.font.size = Pt(11)

        elif btype == "bold":
            p = doc.add_paragraph()
            r = p.add_run(text)
            r.bold = True
            r.font.size = Pt(12)
            r.font.color.rgb = theme["primary"]

        elif btype == "code":
            p = doc.add_paragraph()
            r = p.add_run(text)
            r.font.name = "Courier New"
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor(0,180,160)
            # Add shading to paragraph
            pPr = p._p.get_or_add_pPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:val"), "clear")
            shd.set(qn("w:color"), "auto")
            shd.set(qn("w:fill"), "1A1A2E")
            pPr.append(shd)

        elif btype == "table":
            rows = block.get("rows", [])
            if rows and len(rows) > 0:
                cols = len(rows[0])
                tbl  = doc.add_table(rows=len(rows), cols=cols)
                tbl.style = "Table Grid"
                for ri, row in enumerate(rows):
                    for ci, cell_text in enumerate(row):
                        cell = tbl.cell(ri, ci)
                        cell.text = cell_text
                        if ri == 0:  # Header row
                            cell.paragraphs[0].runs[0].bold = True
                            cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(255,255,255)
                            # Header cell background
                            tc_pr = cell._tc.get_or_add_tcPr()
                            shd   = OxmlElement("w:shd")
                            shd.set(qn("w:val"), "clear")
                            shd.set(qn("w:color"), "auto")
                            hex_color = f"{theme['primary'].red:02x}{theme['primary'].green:02x}{theme['primary'].blue:02x}"
                            shd.set(qn("w:fill"), hex_color)
                            tc_pr.append(shd)
                doc.add_paragraph()

        elif btype == "hr":
            p = doc.add_paragraph()
            p.add_run("─" * 50)
            p.runs[0].font.color.rgb = RGBColor(100,100,150)

    # ── Footer ───────────────────────────────────────────────────
    doc.add_paragraph()
    footer_p = doc.add_paragraph()
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = footer_p.add_run("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    fr.font.color.rgb = RGBColor(80,80,120)
    footer_p2 = doc.add_paragraph()
    footer_p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr2 = footer_p2.add_run(f"🦚 Powered by PeacockAI  •  {title}")
    fr2.font.size  = Pt(9)
    fr2.font.color.rgb = theme["primary"]

    buf = io.BytesIO()
    doc.save(buf)
    log.info(f"[DocService] DOCX: '{title}' style={style} blocks={len(blocks)}")
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════
# PPTX GENERATOR — Professional dark-themed presentation
# ══════════════════════════════════════════════════════════════════

def generate_pptx(slides_data: List[Dict], title: str = "PeacockGPT Presentation",
                  theme: str = "dark") -> bytes:
    """
    Generate professional .pptx presentation.
    themes: dark | light | gradient | corporate
    """
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt, Emu
        from pptx.dml.color import RGBColor
        from pptx.enum.text import PP_ALIGN
    except ImportError:
        raise RuntimeError("python-pptx غير مثبت. شغّل: pip install python-pptx")

    THEMES = {
        "dark":      {"bg":RGBColor(8,8,20),    "title_bg":RGBColor(14,14,24),  "accent":RGBColor(112,96,255),"text":RGBColor(226,226,240),"sub":RGBColor(136,136,176)},
        "light":     {"bg":RGBColor(248,248,255),"title_bg":RGBColor(230,230,250),"accent":RGBColor(71,84,172),"text":RGBColor(30,30,46),  "sub":RGBColor(100,100,140)},
        "gradient":  {"bg":RGBColor(10,10,40),   "title_bg":RGBColor(30,10,80),  "accent":RGBColor(155,100,255),"text":RGBColor(240,240,255),"sub":RGBColor(180,160,220)},
        "corporate": {"bg":RGBColor(255,255,255),"title_bg":RGBColor(0,70,127),  "accent":RGBColor(0,120,215),"text":RGBColor(30,30,30),  "sub":RGBColor(80,80,80)},
    }
    T = THEMES.get(theme, THEMES["dark"])

    prs = Presentation()
    prs.slide_width  = Inches(13.33)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]

    def _set_bg(slide, color):
        fill = slide.background.fill
        fill.solid()
        fill.fore_color.rgb = color

    def _add_textbox(slide, left, top, width, height, text, size, bold=False,
                     color=None, align=PP_ALIGN.RIGHT, wrap=True):
        from pptx.util import Inches, Pt
        color = color or T["text"]
        txb = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
        tf  = txb.text_frame
        tf.word_wrap = wrap
        p   = tf.paragraphs[0]
        p.alignment = align
        r   = p.add_run()
        r.text = text
        r.font.size  = Pt(size)
        r.font.bold  = bold
        r.font.color.rgb = color
        return txb

    def _add_shape(slide, left, top, width, height, color):
        from pptx.util import Inches
        shp = slide.shapes.add_shape(1, Inches(left), Inches(top), Inches(width), Inches(height))
        shp.fill.solid()
        shp.fill.fore_color.rgb = color
        shp.line.fill.background()
        return shp

    # ── Slide 1: Title slide ─────────────────────────────────────
    s0 = prs.slides.add_slide(blank)
    _set_bg(s0, T["bg"])
    _add_shape(s0, 0, 2.8, 13.33, 0.06, T["accent"])
    _add_shape(s0, 0, 0, 0.15, 7.5, T["accent"])
    _add_textbox(s0, 0.5, 1.0, 12.33, 2.2, title, 42, bold=True, align=PP_ALIGN.CENTER, color=T["text"])
    _add_textbox(s0, 0.5, 3.2, 12.33, 0.8,
                 f"🦚 PeacockAI  •  {datetime.now().strftime('%Y-%m-%d')}",
                 16, align=PP_ALIGN.CENTER, color=T["sub"])
    _add_textbox(s0, 0.5, 4.5, 12.33, 0.8,
                 f"{len(slides_data)} شريحة",
                 14, align=PP_ALIGN.CENTER, color=T["accent"])

    # ── Content slides ───────────────────────────────────────────
    for idx, slide_data in enumerate(slides_data):
        s = prs.slides.add_slide(blank)
        _set_bg(s, T["bg"])

        slide_title   = slide_data.get("title", f"شريحة {idx+1}")
        slide_content = slide_data.get("content", "")
        bullets       = slide_data.get("bullets", [])
        has_table     = slide_data.get("table")

        # Title bar
        _add_shape(s, 0, 0, 13.33, 1.4, T["title_bg"])
        _add_shape(s, 0, 1.4, 13.33, 0.05, T["accent"])

        # Slide number
        _add_textbox(s, 12.0, 0.05, 1.2, 0.5,
                     f"{idx+1}/{len(slides_data)}", 11, color=T["sub"])

        # Title
        _add_textbox(s, 0.4, 0.15, 12.5, 1.1, slide_title,
                     26, bold=True, color=T["accent"])

        # Accent left bar
        _add_shape(s, 0, 1.45, 0.08, 5.8, T["accent"])

        # Content
        if bullets:
            from pptx.util import Inches, Pt
            bx = s.shapes.add_textbox(Inches(0.4), Inches(1.6), Inches(12.4), Inches(5.5))
            tf = bx.text_frame
            tf.word_wrap = True
            bullet_icons = ["◆","◇","▸","•","→"]
            for bi, bullet in enumerate(bullets[:10]):
                p = tf.add_paragraph() if bi > 0 else tf.paragraphs[0]
                p.alignment = PP_ALIGN.RIGHT
                p.space_before = Pt(6)
                r = p.add_run()
                icon = bullet_icons[bi % len(bullet_icons)]
                r.text = f"{icon}  {bullet}"
                r.font.size = Pt(19)
                r.font.color.rgb = T["text"] if bi % 2 == 0 else T["sub"]

        elif slide_content:
            _add_textbox(s, 0.4, 1.6, 12.4, 5.5, slide_content,
                         18, color=T["text"], wrap=True)

        if has_table:
            rows = slide_data["table"]
            if rows:
                from pptx.util import Inches, Pt
                cols   = len(rows[0])
                col_w  = 12.0 / cols
                tbl_top = 1.7 if not (bullets or slide_content) else 4.0
                tbl = s.shapes.add_table(len(rows), cols,
                                         Inches(0.5), Inches(tbl_top),
                                         Inches(12.3), Inches(min(len(rows)*0.4, 3.0))).table
                for ri, row in enumerate(rows):
                    for ci, cell_text in enumerate(row):
                        cell = tbl.cell(ri, ci)
                        cell.text = cell_text
                        p = cell.text_frame.paragraphs[0]
                        p.alignment = PP_ALIGN.CENTER
                        r = p.runs[0] if p.runs else p.add_run()
                        r.font.size = Pt(13)
                        r.font.bold = (ri == 0)
                        if ri == 0:
                            r.font.color.rgb = RGBColor(255,255,255)
                            cell.fill.solid()
                            cell.fill.fore_color.rgb = T["accent"]
                        else:
                            r.font.color.rgb = T["text"]
                            cell.fill.solid()
                            bg = RGBColor(20,20,40) if theme == "dark" else RGBColor(240,240,255)
                            cell.fill.fore_color.rgb = bg

    # ── End slide ────────────────────────────────────────────────
    se = prs.slides.add_slide(blank)
    _set_bg(se, T["bg"])
    _add_shape(se, 0, 2.5, 13.33, 0.08, T["accent"])
    _add_textbox(se, 0.5, 1.5, 12.33, 2.0, "شكراً 🦚", 54, bold=True,
                 align=PP_ALIGN.CENTER, color=T["accent"])
    _add_textbox(se, 0.5, 4.0, 12.33, 0.8, f"Powered by PeacockAI  •  {title}",
                 14, align=PP_ALIGN.CENTER, color=T["sub"])

    buf = io.BytesIO()
    prs.save(buf)
    log.info(f"[DocService] PPTX: '{title}' theme={theme} slides={len(slides_data)+2}")
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════
# PDF GENERATOR — Multi-page with full formatting
# ══════════════════════════════════════════════════════════════════

def generate_pdf_advanced(content: str, title: str = "PeacockGPT Document",
                           author: str = "PeacockAI") -> bytes:
    """
    Generate multi-page PDF using ReportLab.
    Full formatting: headings, paragraphs, tables, code blocks, bullets.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table,
            TableStyle, HRFlowable, PageBreak, Preformatted
        )
        from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except ImportError:
        # Fallback to basic PDF if reportlab not available
        return _generate_pdf_basic(content, title, author)

    buf    = io.BytesIO()
    margin = 2*cm

    # Colors
    PRIMARY  = colors.HexColor("#7060FF")
    ACCENT   = colors.HexColor("#9B8FFF")
    DARK     = colors.HexColor("#0E0E18")
    TEXT     = colors.HexColor("#2A2A3E")
    GRAY     = colors.HexColor("#8888B0")
    CODE_BG  = colors.HexColor("#1A1A2E")
    CODE_FG  = colors.HexColor("#00C8B4")

    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=margin, rightMargin=margin,
        topMargin=margin,  bottomMargin=margin,
        title=title, author=author,
    )

    styles = getSampleStyleSheet()

    # Custom styles
    s_title = ParagraphStyle("PTitle",
        fontSize=24, fontName="Helvetica-Bold", alignment=TA_CENTER,
        textColor=PRIMARY, spaceAfter=6, leading=30)
    s_h1 = ParagraphStyle("PH1",
        fontSize=18, fontName="Helvetica-Bold",
        textColor=PRIMARY, spaceBefore=14, spaceAfter=6, leading=22)
    s_h2 = ParagraphStyle("PH2",
        fontSize=14, fontName="Helvetica-Bold",
        textColor=ACCENT, spaceBefore=10, spaceAfter=4, leading=18)
    s_h3 = ParagraphStyle("PH3",
        fontSize=12, fontName="Helvetica-Bold",
        textColor=TEXT, spaceBefore=8, spaceAfter=4)
    s_body = ParagraphStyle("PBody",
        fontSize=11, fontName="Helvetica",
        textColor=TEXT, leading=16, spaceAfter=6)
    s_bullet = ParagraphStyle("PBullet",
        fontSize=11, fontName="Helvetica",
        textColor=TEXT, leftIndent=20, bulletIndent=8,
        leading=15, spaceAfter=3)
    s_meta = ParagraphStyle("PMeta",
        fontSize=9, fontName="Helvetica",
        textColor=GRAY, alignment=TA_CENTER, spaceAfter=20)
    s_code = ParagraphStyle("PCode",
        fontSize=9, fontName="Courier",
        textColor=CODE_FG, backColor=CODE_BG,
        leftIndent=12, rightIndent=12,
        spaceBefore=6, spaceAfter=6, leading=13,
        borderPadding=(6,6,6,6))

    story = []

    # Title page header
    story.append(Paragraph(title, s_title))
    story.append(Paragraph(
        f"أُعدّ بواسطة {author}  •  {datetime.now().strftime('%Y-%m-%d')}",
        s_meta
    ))
    story.append(HRFlowable(width="100%", thickness=2, color=PRIMARY, spaceAfter=16))

    # Parse and render blocks
    blocks = parse_content(content)

    for block in blocks:
        btype = block["type"]
        text  = block.get("text","")

        if btype == "h1":
            story.append(Paragraph(text, s_h1))
        elif btype == "h2":
            story.append(Paragraph(text, s_h2))
        elif btype == "h3":
            story.append(Paragraph(text, s_h3))
        elif btype == "para":
            # Handle **bold** inline
            text_fmt = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
            story.append(Paragraph(text_fmt, s_body))
        elif btype == "bullet":
            story.append(Paragraph(f"◆  {text}", s_bullet))
        elif btype == "numbered":
            story.append(Paragraph(f"•  {text}", s_bullet))
        elif btype == "bold":
            story.append(Paragraph(f"<b>{text}</b>", s_body))
        elif btype == "code":
            story.append(Preformatted(text, s_code))
        elif btype == "hr":
            story.append(HRFlowable(width="80%", thickness=1, color=GRAY,
                                     hAlign="CENTER", spaceAfter=8))
        elif btype == "table":
            rows = block.get("rows",[])
            if rows:
                tbl_data = [[Paragraph(str(c), s_body) for c in row] for row in rows]
                col_count = len(rows[0]) if rows else 1
                col_w = [(A4[0] - 2*margin) / col_count] * col_count
                t = Table(tbl_data, colWidths=col_w)
                t.setStyle(TableStyle([
                    ("BACKGROUND",    (0,0), (-1,0),  PRIMARY),
                    ("TEXTCOLOR",     (0,0), (-1,0),  colors.white),
                    ("FONTNAME",      (0,0), (-1,0),  "Helvetica-Bold"),
                    ("FONTSIZE",      (0,0), (-1,0),  11),
                    ("ALIGN",         (0,0), (-1,-1), "CENTER"),
                    ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
                    ("BACKGROUND",    (0,1), (-1,-1), colors.HexColor("#F0F0FA")),
                    ("ROWBACKGROUNDS",(0,1), (-1,-1), [colors.white, colors.HexColor("#F0F0FA")]),
                    ("GRID",          (0,0), (-1,-1), 0.5, colors.HexColor("#C0C0D8")),
                    ("TOPPADDING",    (0,0), (-1,-1), 6),
                    ("BOTTOMPADDING", (0,0), (-1,-1), 6),
                    ("LEFTPADDING",   (0,0), (-1,-1), 8),
                    ("RIGHTPADDING",  (0,0), (-1,-1), 8),
                ]))
                story.append(t)
                story.append(Spacer(1, 10))

        story.append(Spacer(1, 2))

    # Footer
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=1, color=PRIMARY))
    story.append(Paragraph(f"🦚 Powered by PeacockAI  •  {title}", s_meta))

    def _add_page_num(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(GRAY)
        canvas.drawCentredString(A4[0]/2, 1.2*cm, f"صفحة {doc_obj.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=_add_page_num, onLaterPages=_add_page_num)
    log.info(f"[DocService] PDF: '{title}' blocks={len(blocks)}")
    return buf.getvalue()


def _generate_pdf_basic(content: str, title: str, author: str) -> bytes:
    """Fallback basic PDF using only stdlib."""
    # Simple text-based PDF (no images/tables, but always works)
    lines = [f"% {title}", f"% By {author}", f"% {datetime.now().isoformat()}", ""]
    lines.extend(content.split("\n"))
    text = "\n".join(lines)
    # Minimal valid PDF
    pdf = f"""%PDF-1.4
1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj
2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj
3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R/Resources<</Font<</F1<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>>>>>>>endobj
4 0 obj<</Length {len(text)}>>stream\n{text}\nendstream\nendobj
xref\n0 5\n0000000000 65535 f\n0000000009 00000 n\n0000000058 00000 n\n0000000115 00000 n\n0000000274 00000 n\ntrailer<</Size 5/Root 1 0 R>>\nstartxref\n{300+len(text)}\n%%EOF"""
    return pdf.encode()


# ══════════════════════════════════════════════════════════════════
# CONTENT → SLIDES PARSER
# ══════════════════════════════════════════════════════════════════

def content_to_slides(content: str, title: str = "") -> List[Dict]:
    """Parse text/markdown into structured slide data."""
    slides  = []
    current = {"title":"","bullets":[],"content":"","table":None}

    for line in content.split("\n"):
        stripped = line.strip()

        if stripped.startswith("## ") or stripped.startswith("# "):
            if current["title"] or current["bullets"] or current["content"]:
                slides.append(dict(current))
            current = {"title": stripped.lstrip("#").strip(),
                       "bullets":[], "content":"", "table":None}
        elif re.match(r"^[-*•]\s", stripped) or re.match(r"^\d+\.\s", stripped):
            text = re.sub(r"^[-*•\d.]\s*", "", stripped)
            current["bullets"].append(text)
        elif stripped.startswith("|") and stripped.endswith("|") and "---" not in stripped:
            if not current["table"]: current["table"] = []
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            current["table"].append(cells)
        elif stripped and not stripped.startswith("```"):
            if current["content"]:
                current["content"] += " " + stripped
            else:
                current["content"] = stripped

    if current["title"] or current["bullets"] or current["content"]:
        slides.append(current)

    if not slides:
        slides = [{"title": title or "محتوى", "content": content[:500],
                   "bullets": [], "table": None}]

    return slides[:25]


# ══════════════════════════════════════════════════════════════════
# CONVENIENCE WRAPPERS
# ══════════════════════════════════════════════════════════════════

def content_to_docx(content: str, title: str, style: str = "professional") -> bytes:
    return generate_docx(content, title, style=style)

def content_to_pptx(content: str, title: str, theme: str = "dark") -> bytes:
    slides = content_to_slides(content, title)
    return generate_pptx(slides, title, theme=theme)

def content_to_pdf(content: str, title: str) -> bytes:
    return generate_pdf_advanced(content, title)
