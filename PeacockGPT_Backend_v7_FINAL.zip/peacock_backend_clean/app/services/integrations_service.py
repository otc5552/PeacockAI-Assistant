"""
services/integrations_service.py — Integrations & Auto Actions v7
HTTP | Webhooks | Email (SMTP) | Google Drive (OAuth)
Author: PeacockAI – Mostafa
"""
import json, secrets, asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from core.config import log
import httpx

# ══════════════════════════════════════════════════════════════════
# INTEGRATION REGISTRY  (user-saved connectors)
# ══════════════════════════════════════════════════════════════════
_integrations: Dict[str, dict] = {}  # int_id → integration

INTEGRATION_TYPES = {
    "http_api":   "HTTP API عام",
    "webhook":    "Webhook",
    "email_smtp": "بريد إلكتروني (SMTP)",
    "slack":      "Slack",
    "discord":    "Discord",
    "telegram":   "Telegram Bot",
    "notion":     "Notion API",
    "airtable":   "Airtable",
    "google_sheets": "Google Sheets",
}


def save_integration(user_id: str, int_type: str, name: str,
                     config: dict) -> dict:
    """Save a named integration connector for reuse."""
    # Mask secrets in stored config
    safe_cfg = {k: ("***" if any(s in k.lower() for s in ("key","token","secret","pass","auth")) else v)
                for k, v in config.items()}
    int_id = secrets.token_hex(10)
    integration = {
        "id":         int_id,
        "user_id":    user_id,
        "type":       int_type,
        "name":       name[:60],
        "config":     config,      # full config (encrypted in production)
        "safe_config":safe_cfg,    # masked for display
        "created_at": datetime.now().isoformat(),
        "test_status":None,
    }
    _integrations[int_id] = integration
    log.info(f"[Integrations] Saved '{name}' ({int_type}) for {user_id[:12]}")
    return {**integration, "config": safe_cfg}  # never return secrets


def list_integrations(user_id: str) -> List[dict]:
    return [{**i, "config": i["safe_config"]}
            for i in _integrations.values() if i["user_id"] == user_id]


def delete_integration(int_id: str, user_id: str) -> bool:
    i = _integrations.get(int_id)
    if not i or i["user_id"] != user_id: return False
    del _integrations[int_id]
    return True


# ══════════════════════════════════════════════════════════════════
# SSRF PROTECTION
# ══════════════════════════════════════════════════════════════════

import urllib.parse, ipaddress

def _check_url(url: str):
    try:
        h = urllib.parse.urlparse(url).hostname or ""
        blocked = {"localhost","127.0.0.1","0.0.0.0","::1","169.254.169.254"}
        if h in blocked: raise ValueError(f"⛔ {h} محظور")
        try:
            ip = ipaddress.ip_address(h)
            if ip.is_private or ip.is_loopback:
                raise ValueError("⛔ IPs الداخلية محظورة")
        except ValueError as e:
            if "⛔" in str(e): raise
    except Exception as e:
        if "⛔" in str(e): raise


# ══════════════════════════════════════════════════════════════════
# CALL API  (generic HTTP)
# ══════════════════════════════════════════════════════════════════

async def call_api(url: str, method: str = "GET", headers: dict = None,
                   body: Any = None, timeout: int = 30) -> dict:
    """
    Make an HTTP API call safely.
    Returns {ok, status_code, response, error}
    """
    _check_url(url)
    method  = method.upper()
    headers = headers or {}
    timeout = min(timeout, 60)

    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            r = await client.request(method, url, headers=headers, json=body)
        try:   resp = r.json()
        except: resp = r.text[:3000]
        return {"ok": r.status_code < 400, "status_code":r.status_code,
                "response":resp, "error":None}
    except Exception as e:
        return {"ok":False,"status_code":None,"response":None,"error":str(e)}


# ══════════════════════════════════════════════════════════════════
# SEND WEBHOOK
# ══════════════════════════════════════════════════════════════════

async def send_webhook(url: str, payload: dict,
                        secret: str = "", timeout: int = 15) -> dict:
    """Send a webhook POST request with optional HMAC signature."""
    _check_url(url)
    headers = {"Content-Type":"application/json","User-Agent":"PeacockAI-Webhook/7.0"}
    if secret:
        import hmac, hashlib
        body_b = json.dumps(payload).encode()
        sig    = hmac.new(secret.encode(), body_b, hashlib.sha256).hexdigest()
        headers["X-PeacockAI-Signature"] = f"sha256={sig}"
    try:
        async with httpx.AsyncClient(timeout=min(timeout,30)) as client:
            r = await client.post(url, json=payload, headers=headers)
        return {"ok":r.status_code < 400,"status_code":r.status_code,"error":None}
    except Exception as e:
        return {"ok":False,"status_code":None,"error":str(e)}


# ══════════════════════════════════════════════════════════════════
# SEND EMAIL  (SMTP)
# ══════════════════════════════════════════════════════════════════

async def send_email(smtp_host: str, smtp_port: int, username: str,
                      password: str, to_email: str, subject: str,
                      body: str, use_tls: bool = True) -> dict:
    """Send email via SMTP. Uses smtplib in executor."""
    import smtplib, ssl
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    def _send():
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = username
        msg["To"]      = to_email
        msg.attach(MIMEText(body, "plain", "utf-8"))
        msg.attach(MIMEText(f"<p>{body}</p>", "html", "utf-8"))
        ctx = ssl.create_default_context() if use_tls else None
        if use_tls and smtp_port == 465:
            with smtplib.SMTP_SSL(smtp_host, smtp_port, context=ctx) as s:
                s.login(username, password)
                s.sendmail(username, to_email, msg.as_string())
        else:
            with smtplib.SMTP(smtp_host, smtp_port) as s:
                if use_tls: s.starttls(context=ctx)
                s.login(username, password)
                s.sendmail(username, to_email, msg.as_string())
        return True

    try:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, _send)
        return {"ok":True,"error":None}
    except Exception as e:
        return {"ok":False,"error":str(e)}


# ══════════════════════════════════════════════════════════════════
# SLACK NOTIFICATION
# ══════════════════════════════════════════════════════════════════

async def send_slack(webhook_url: str, text: str,
                      channel: str = "", username: str = "PeacockAI") -> dict:
    """Send a Slack message via Incoming Webhook."""
    payload = {"text":text,"username":username}
    if channel: payload["channel"] = channel
    return await send_webhook(webhook_url, payload)


# ══════════════════════════════════════════════════════════════════
# TELEGRAM NOTIFICATION
# ══════════════════════════════════════════════════════════════════

async def send_telegram(bot_token: str, chat_id: str, text: str) -> dict:
    """Send Telegram message via Bot API."""
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    return await call_api(url, "POST", body={"chat_id":chat_id,"text":text,"parse_mode":"Markdown"})


# ══════════════════════════════════════════════════════════════════
# DISCORD NOTIFICATION
# ══════════════════════════════════════════════════════════════════

async def send_discord(webhook_url: str, content: str,
                        username: str = "PeacockAI 🦚") -> dict:
    """Send Discord message via Webhook."""
    return await send_webhook(webhook_url, {"content":content[:2000],"username":username})


# ══════════════════════════════════════════════════════════════════
# GOOGLE SHEETS  (via Sheets API v4)
# ══════════════════════════════════════════════════════════════════

async def append_to_sheet(api_key: str, sheet_id: str,
                           range_: str, values: List[List]) -> dict:
    """Append rows to Google Sheet."""
    url = (f"https://sheets.googleapis.com/v4/spreadsheets/{sheet_id}"
           f"/values/{range_}:append?valueInputOption=USER_ENTERED&key={api_key}")
    return await call_api(url, "POST", body={"values":values})


# ══════════════════════════════════════════════════════════════════
# NOTION  (via Notion API v1)
# ══════════════════════════════════════════════════════════════════

async def create_notion_page(token: str, database_id: str,
                              title: str, content: str) -> dict:
    """Create a new Notion page in a database."""
    url     = "https://api.notion.com/v1/pages"
    headers = {"Authorization":f"Bearer {token}","Notion-Version":"2022-06-28",
               "Content-Type":"application/json"}
    body    = {
        "parent":     {"database_id": database_id},
        "properties": {"title":{"title":[{"text":{"content":title}}]}},
        "children": [{
            "object":"block","type":"paragraph",
            "paragraph":{"rich_text":[{"type":"text","text":{"content":content[:2000]}}]}
        }]
    }
    return await call_api(url, "POST", headers, body)


# ══════════════════════════════════════════════════════════════════
# INTEGRATION TEST
# ══════════════════════════════════════════════════════════════════

async def test_integration(int_id: str, user_id: str) -> dict:
    """Test a saved integration. Returns {ok, message}."""
    integration = _integrations.get(int_id)
    if not integration or integration["user_id"] != user_id:
        return {"ok":False,"message":"Integration غير موجود"}

    cfg     = integration["config"]
    int_type = integration["type"]

    try:
        if int_type == "http_api":
            result = await call_api(cfg.get("url",""), "GET")
            ok = result["ok"]
            msg = f"HTTP {result.get('status_code')} — {'✅' if ok else '❌'}"

        elif int_type == "webhook":
            result = await send_webhook(cfg.get("url",""), {"test":True,"from":"PeacockAI"})
            ok = result["ok"]
            msg = f"Webhook {'✅ يعمل' if ok else '❌ فشل'}"

        elif int_type == "telegram":
            result = await send_telegram(cfg["bot_token"], cfg["chat_id"], "🦚 PeacockAI Test")
            ok = result["ok"]
            msg = f"Telegram {'✅' if ok else '❌: '+str(result.get('error',''))}"

        elif int_type == "discord":
            result = await send_discord(cfg["webhook_url"], "🦚 PeacockAI Test Message")
            ok = result["ok"]
            msg = f"Discord {'✅' if ok else '❌'}"

        elif int_type == "slack":
            result = await send_slack(cfg["webhook_url"], "🦚 PeacockAI Test")
            ok = result["ok"]
            msg = f"Slack {'✅' if ok else '❌'}"

        else:
            ok = True; msg = "لا يوجد اختبار لهذا النوع"

        # Update test status
        integration["test_status"] = {"ok":ok,"message":msg,"tested_at":datetime.now().isoformat()}
        return {"ok":ok,"message":msg}

    except Exception as e:
        return {"ok":False,"message":str(e)}
