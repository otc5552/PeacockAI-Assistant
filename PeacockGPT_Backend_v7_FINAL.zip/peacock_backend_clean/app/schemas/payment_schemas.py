"""
schemas/payment_schemas.py — Payment Pydantic Schemas
"""
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class CheckoutRequest(BaseModel):
    plan:        str
    period:      str = "monthly"
    method:      str = "stripe"
    currency:    str = "usd"
    success_url: str = ""
    cancel_url:  str = ""

class OrderResponse(BaseModel):
    id:          str
    plan:        str
    period:      str
    method:      str
    amount:      float
    currency:    str
    status:      str
    created_at:  str
    paid_at:     Optional[str] = None
    expires_at:  Optional[str] = None
    reference:   Optional[str] = None

class SubscriptionStatus(BaseModel):
    plan:       str
    status:     str
    expires_at: Optional[str] = None
    method:     Optional[str] = None
    period:     Optional[str] = None
