"""
models/payment_models.py — Payment SQLAlchemy Models
Add to database.py for persistent storage
"""
from sqlalchemy import Column, String, Float, Integer, Text
from core.database import Base

class PaymentOrder(Base):
    """Persistent payment orders table."""
    __tablename__ = "payment_orders"
    id          = Column(String(40),  primary_key=True)
    user_id     = Column(String(64),  nullable=False, index=True)
    plan        = Column(String(20),  nullable=False)
    period      = Column(String(20),  default="monthly")
    method      = Column(String(20),  nullable=False)
    currency    = Column(String(10),  default="usd")
    amount      = Column(Float,       default=0.0)
    status      = Column(String(20),  default="pending")
    provider_id = Column(String(200))
    reference   = Column(String(30))
    created_at  = Column(String(40),  nullable=False)
    paid_at     = Column(String(40))
    expires_at  = Column(String(40))
    note        = Column(Text)
