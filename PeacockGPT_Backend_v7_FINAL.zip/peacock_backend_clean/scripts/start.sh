#!/bin/bash
# Start PeacockGPT Backend
echo "🦚 Starting PeacockGPT v7 Backend..."
cd "$(dirname "$0")/.."
pip install -r requirements.txt -q
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
