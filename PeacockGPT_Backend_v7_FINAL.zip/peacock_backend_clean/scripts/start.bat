@echo off
echo 🦚 Starting PeacockGPT v7 Backend...
cd /d "%~dp0\.."
pip install -r requirements.txt -q
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
pause
