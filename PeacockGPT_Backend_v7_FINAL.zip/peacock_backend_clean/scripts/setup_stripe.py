#!/usr/bin/env python3
"""
scripts/setup_stripe.py
Creates Stripe Products and Prices automatically.
Usage: python scripts/setup_stripe.py
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def setup_stripe():
    sk = os.getenv("STRIPE_SECRET_KEY","")
    if not sk or "xxx" in sk:
        print("❌ أضف STRIPE_SECRET_KEY في .env أولاً")
        return

    try:
        import stripe
        stripe.api_key = sk
    except ImportError:
        print("❌ stripe غير مثبت. شغّل: pip install stripe")
        return

    plans = {
        "plus": {"egp": 700,  "usd": 20,  "name": "PeacockGPT Plus"},
        "pro":  {"egp": 1500, "usd": 35,  "name": "PeacockGPT Pro"},
    }

    print("🔧 إنشاء Stripe Products & Prices...\n")
    price_ids = {}

    for plan_id, plan in plans.items():
        # Create product
        product = stripe.Product.create(
            name=plan["name"],
            metadata={"plan": plan_id}
        )
        print(f"✅ Product: {plan['name']} ({product.id})")

        # Monthly price
        monthly = stripe.Price.create(
            product=product.id,
            unit_amount=int(plan["usd"] * 100),
            currency="usd",
            recurring={"interval":"month"},
        )
        price_ids[f"{plan_id}_monthly"] = monthly.id
        print(f"   Monthly: {monthly.id} → ${plan['usd']}/month")

        # Yearly price (10 months)
        yearly = stripe.Price.create(
            product=product.id,
            unit_amount=int(plan["usd"] * 100 * 10),
            currency="usd",
            recurring={"interval":"year"},
        )
        price_ids[f"{plan_id}_yearly"] = yearly.id
        print(f"   Yearly:  {yearly.id} → ${plan['usd']*10}/year\n")

    print("📋 أضف هذا في .env:\n")
    for k, v in price_ids.items():
        env_key = f"STRIPE_PRICE_{k.upper()}"
        print(f"{env_key}={v}")

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    setup_stripe()
